package com.r1vs.platform.rox.common.util;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;

/**
 * Methods helping processing Throwable.
 *
 */
public class ExceptionUtil {

	/**
	 * Return the root cause of the incoming Throwable if found. Otherwise it will return the original Throwable.
	 *
	 * @param throwable
	 * @return
	 */
	public static Throwable getRootException(final Throwable throwable) {

		if (throwable == null) {
			throw new RuntimeException("Null throwable passed in");
		}
		final Throwable rootCause = ExceptionUtils.getRootCause(throwable);
		if (rootCause == null) {
			return throwable;
		}
		return rootCause;
	}

	/**
	 * Return the message of the root cause like: RuntimeException: {message}.
	 *
	 * @param throwable
	 * @return
	 */
	public static String getRootExceptionMessage(final Throwable throwable) {

		final Throwable rootCause = getRootException(throwable);
		return ExceptionUtils.getMessage(rootCause);
	}

	/**
	 * Return the message of the root cause like: {message}
	 *
	 * @param throwable
	 * @return
	 */
	public static String getPlainRootExceptionMessage(final Throwable throwable) {

		final Throwable rootCause = getRootException(throwable);
		return StringUtils.defaultString(rootCause.getMessage());
	}
}
