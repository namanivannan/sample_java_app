package com.r1vs.platform.rox.common.model.ds;

public enum InteractionName {
	FMCSA_SEARCH,
	UCC_DEBTOR_SEARCH,
	UCC_DEBTOR_FILING,
	UCC_DOCUMENT_CALLBACK
}
