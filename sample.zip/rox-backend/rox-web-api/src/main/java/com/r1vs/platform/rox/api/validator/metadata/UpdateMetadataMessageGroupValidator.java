package com.r1vs.platform.rox.api.validator.metadata;

import com.r1vs.platform.rox.api.model.metadata.UpdateMetadataMessageGroupRequest;
import com.r1vs.platform.rox.api.service.messagetemplate.MessageGroupApiService;
import com.r1vs.platform.rox.api.validator.RoxWriteWebApiValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

@Component
public class UpdateMetadataMessageGroupValidator extends MetadataValidator
		implements
		RoxWriteWebApiValidator<UpdateMetadataMessageGroupRequest> {

	@Autowired
	private MessageSource messageSource;

	@Autowired
	private MessageGroupApiService messageGroupApiService;

	@Override
	public void validate(final UpdateMetadataMessageGroupRequest updateMetadataMessageGroupRequest) {

	}

	public void setMessageGroupApiService(final MessageGroupApiService messageGroupApiService) {

		this.messageGroupApiService = messageGroupApiService;
	}

	public void setMessageSource(final MessageSource messageSource) {

		this.messageSource = messageSource;
	}

}
