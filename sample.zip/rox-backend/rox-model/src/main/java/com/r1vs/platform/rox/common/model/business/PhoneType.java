package com.r1vs.platform.rox.common.model.business;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "phone_type")
public class PhoneType {

	@Id
	@Column(name = "id")
	private int id;

	@Column(name = "type")
	private String type;

	public int getId() {

		return this.id;
	}

	public void setId(int id) {

		this.id = id;
	}

	public String getType() {

		return this.type;
	}

	public void setType(String type) {

		this.type = type;
	}
}
