package com.r1vs.platform.rox.filemanagement.services;

import com.amazonaws.AmazonServiceException;
import com.r1vs.platform.rox.StorageSpringBootApplication;
import com.r1vs.platform.rox.common.db.repository.business.ApplicationRepository;
import com.r1vs.platform.rox.common.db.repository.business.storage.RoxFileRepository;
import com.r1vs.platform.rox.common.model.business.Application;
import com.r1vs.platform.rox.common.model.business.storage.RoxFile;
import com.r1vs.platform.rox.filemanagement.exceptions.RoxStorageException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.orm.jpa.JpaObjectRetrievalFailureException;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityNotFoundException;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.io.IOException;
import java.util.UUID;

@SpringBootTest(classes = StorageSpringBootApplication.class)
@RunWith(SpringRunner.class)
@ActiveProfiles("test")
@Sql("fixture.sql")
public class StorageServiceTest {

	@Autowired
	private ApplicationRepository applicationRepository;

	@SpyBean
	private S3Storage s3Storage;

	@Autowired
	private StorageService storageService;

	@Autowired
	private RoxFileRepository roxFileRepository;

	@Before
	public void resetMocks() {

		reset(s3Storage);
	}

	@Test
	@Transactional
	public void givenValidFile_WhenUploadFileToS3_thenFileIsStoredInS3AndInfoOnDB() throws IOException {

		//Given
		MockMultipartFile file = new MockMultipartFile(
				"testFile1234",
				"testFile1234.txt",
				MediaType.TEXT_PLAIN_VALUE,
				"Test Upload File".getBytes());

		//When
		Application application = applicationRepository.getById(11L);
		RoxFile result = storageService.uploadFile("11", file, "Purpose", application);

		//Then
		assertThat(result.getUuid()).isNotNull();
		assertThat(result.getFileName()).isEqualTo("testFile1234.txt");
		assertThat(result.getFileType()).isEqualTo("text/plain");
		assertThat(result.getFileSize()).isEqualTo(16);
		assertThat(result.getKey()).startsWith("11/382b9037-5842-43e8-b99b-2f4611784cd6").endsWith("-testFile1234.txt");
		assertThat(result.getApplication()).isNotNull();
		assertThat(result.getPurpose()).isEqualTo("Purpose");

		assertThat(roxFileRepository.getRoxFileByApplicationAndUuid(application, result.getUuid())).isNotNull();
		assertThat(storageService.getFile(result).getInputStream().readAllBytes())
				.isEqualTo(file.getInputStream().readAllBytes());
	}

	@Test
	@Transactional
	public void givenValidStoredFileInS3_whenGettingFileFromS3_thenReturnFile() throws IOException {

		//Given
		MockMultipartFile file = new MockMultipartFile(
				"testFile12345",
				"testFile12345.txt",
				MediaType.TEXT_PLAIN_VALUE,
				"Test Upload File".getBytes());
		RoxFile roxFile = new RoxFile();
		roxFile.setUuid(UUID.randomUUID());
		roxFile.setFileName(file.getOriginalFilename());
		roxFile.setFileType(file.getContentType());
		roxFile.setFileSize(file.getSize());
		roxFile.setPurpose("purpose 1");
		Application application = applicationRepository.getById(11L);

		roxFile.setKey(storageService.uploadFile("11", file, "Purpose", application).getKey());

		//When
		Resource result = storageService.getFile(roxFile);

		//Then
		assertThat(result.getInputStream().readAllBytes()).isEqualTo(file.getInputStream().readAllBytes());
	}

	@Test
	@Transactional
	public void givenValidStoredFileInS3_whenDeletingFileFromS3_thenDeleteFile() throws IOException {

		//Given
		MockMultipartFile file = new MockMultipartFile(
				"testFile1234",
				"testFile1234.txt",
				MediaType.TEXT_PLAIN_VALUE,
				"Test Upload File".getBytes());
		Application application = applicationRepository.getById(11L);
		RoxFile result = storageService.uploadFile("11", file, "Purpose", application);

		//When
		storageService.deleteFile(result);
		Throwable thrownS3 = catchThrowable(() -> storageService.getFile(result));
		Throwable thrownDB = catchThrowable(() -> roxFileRepository.getById(result.getId()));

		//Then
		assertThat(thrownS3).isInstanceOf(RoxStorageException.class)
				.getRootCause().isInstanceOf(AmazonServiceException.class)
				.hasMessageContaining("The specified key does not exist.");
		AmazonServiceException cause = (AmazonServiceException) thrownS3.getCause();
		assertThat(cause.getStatusCode()).isEqualTo(404);

		assertThat(thrownDB).isInstanceOf(JpaObjectRetrievalFailureException.class)
				.getRootCause().isInstanceOf(EntityNotFoundException.class).hasMessageContaining("Unable to find");
	}
}