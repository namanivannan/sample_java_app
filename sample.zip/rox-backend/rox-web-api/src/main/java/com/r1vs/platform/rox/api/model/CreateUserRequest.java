package com.r1vs.platform.rox.api.model;

import java.util.List;

public class CreateUserRequest extends UserRequest {

	private static final long serialVersionUID = 1L;

	private List<String> userRoles;

	public List<String> getUserRoles() {

		return userRoles;
	}

	public void setUserRoles(List<String> userRoles) {

		this.userRoles = userRoles;
	}
}
