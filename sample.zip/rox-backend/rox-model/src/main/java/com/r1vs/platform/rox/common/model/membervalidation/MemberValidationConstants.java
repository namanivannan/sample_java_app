package com.r1vs.platform.rox.common.model.membervalidation;

public final class MemberValidationConstants {

	public static final String VALIDATION_CRITERIA_TYPE = "validationCriteriaType";

	public static final String GROUP_ID = "groupId";

	public static final String PLAN_ID = "planId";

	public static final String PERSON_CODE = "personCode";

	public static final String PATIENT_RELATIONSHIP_CODE = "patientRelationshipCode";

	public static final String CARHOLDER_ID = "cardholderId";

	public static final String CARDHOLDER_FIRST_NAME = "cardholderFirstName";

	public static final String CARDHOLDER_LAST_NAME = "cardholderLastName";

	public static final String DATE_OF_BIRTH = "dateOfBirth";

	public static final String PATIENT_GENDER_CODE = "patientGenderCode";

	public static final String PATIENT_FIRST_NAME = "patientFirstName";

	public static final String PATIENT_LAST_NAME = "patientLastName";

	public static final String PATIENT_ID_QUALIFIER = "patientIdQualifier";

	public static final String PATIENT_ID = "patientId";

	public static final String DATE_OF_SERVICE = "dateOfService";

	public static final String PATIENT_MULTI_BIRTH_CODE = "patientMultiBirthCode";

	public static final String X_VALIDATION_FAIL_ACTION_HEADER_KEY = "X-VALIDATION-FAIL-ACTION";

	private MemberValidationConstants() {

	}
}
