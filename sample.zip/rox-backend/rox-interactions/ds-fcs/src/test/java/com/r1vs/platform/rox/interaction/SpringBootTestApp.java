package com.r1vs.platform.rox.interaction;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootTestApp {
}
