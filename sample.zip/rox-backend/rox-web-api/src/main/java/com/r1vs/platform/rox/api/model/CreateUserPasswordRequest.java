package com.r1vs.platform.rox.api.model;

import com.r1vs.platform.rox.api.validator.user.ValidPassword;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;

public class CreateUserPasswordRequest implements Serializable {

	private static final long serialVersionUID = 1L;

	@NotNull
	private Integer userId;

	@NotNull
	private String registrationToken;

	@ValidPassword
	@Size(min = 8, message = "Password length must be at least 8 characters")
	@NotNull
	private String password;

	public Integer getUserId() {

		return userId;
	}

	public void setUserId(final Integer userId) {

		this.userId = userId;
	}

	public String getRegistrationToken() {

		return registrationToken;
	}

	public void setRegistrationToken(final String registrationToken) {

		this.registrationToken = registrationToken;
	}

	public String getPassword() {

		return password;
	}

	public void setPassword(final String password) {

		this.password = password;
	}

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof CreateUserPasswordRequest)) {
			return false;
		}
		final CreateUserPasswordRequest castOther = (CreateUserPasswordRequest) other;
		return new EqualsBuilder().append(userId, castOther.userId)
				.append(registrationToken, castOther.registrationToken).append(password, castOther.password).isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(userId).append(registrationToken).append(password).toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("userId", userId).append("registrationToken", registrationToken)
				.append("password", password).toString();
	}

}
