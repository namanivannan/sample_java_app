package com.r1vs.platform.rox.api.model;

import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

public enum UserStatus {

	PENDING(1, "Pending"),
	ACTIVE(2, "Active"),
	INACTIVE(3, "Inactive");

	private Integer key;

	private String value;

	UserStatus(final Integer key, final String value) {

		this.key = key;
		this.value = value;
	}

	public Integer key() {

		return key;
	}

	public String value() {

		return value;
	}

	public static Map<Integer, String> getUserStatusList() {

		return Arrays.stream(UserStatus.values()).collect(Collectors.toMap(UserStatus::key, UserStatus::value));
	}

}
