package com.r1vs.platform.rox.api.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.time.OffsetDateTime;

public class UserAuditResponse {

	@JsonProperty(value = "username")
	private String username;

	@JsonProperty(value = "firstName")
	private String firstName;

	@JsonProperty(value = "lastName")
	private String lastName;

	@JsonProperty(value = "email")
	private String email;

	@JsonProperty(value = "isPasswordUpdated")
	private Boolean passwordUpdated;

	@JsonProperty(value = "phoneType")
	private String phoneTypeDescription;

	@JsonProperty(value = "phoneNumber")
	private String phone;

	@JsonProperty(value = "userRole")
	private String roleDescription;

	@JsonProperty(value = "activeAt")
	private OffsetDateTime registeredDate;

	@JsonProperty(value = "inactiveAt")
	private OffsetDateTime terminationDate;

	@JsonProperty(value = "invitedAt")
	private OffsetDateTime invitedAt;

	@JsonProperty(value = "invitedBy")
	private String invitedBy;

	@JsonProperty(value = "updatedAt")
	private OffsetDateTime updatedAt;

	@JsonProperty(value = "updatedByFirstName")
	private String updatedByFirstName;

	@JsonProperty(value = "updatedByLastName")
	private String updatedByLastName;

	public String getUsername() {

		return username;
	}

	public void setUsername(final String username) {

		this.username = username;
	}

	public String getFirstName() {

		return firstName;
	}

	public void setFirstName(final String firstName) {

		this.firstName = firstName;
	}

	public String getLastName() {

		return lastName;
	}

	public void setLastName(final String lastName) {

		this.lastName = lastName;
	}

	public String getEmail() {

		return email;
	}

	public void setEmail(final String email) {

		this.email = email;
	}

	public Boolean isPasswordUpdated() {

		return passwordUpdated;
	}

	public void setPasswordUpdated(final Boolean passwordUpdated) {

		this.passwordUpdated = passwordUpdated;
	}

	public String getPhoneTypeDescription() {

		return phoneTypeDescription;
	}

	public void setPhoneTypeDescription(final String phoneTypeDescription) {

		this.phoneTypeDescription = phoneTypeDescription;
	}

	public String getPhone() {

		return phone;
	}

	public void setPhone(final String phone) {

		this.phone = phone;
	}

	public String getRoleDescription() {

		return roleDescription;
	}

	public void setRoleDescription(final String roleDescription) {

		this.roleDescription = roleDescription;
	}

	public OffsetDateTime getRegisteredDate() {

		return registeredDate;
	}

	public void setRegisteredDate(final OffsetDateTime registeredDate) {

		this.registeredDate = registeredDate;
	}

	public OffsetDateTime getTerminationDate() {

		return terminationDate;
	}

	public void setTerminationDate(final OffsetDateTime terminationDate) {

		this.terminationDate = terminationDate;
	}

	public OffsetDateTime getInvitedAt() {

		return invitedAt;
	}

	public void setInvitedAt(final OffsetDateTime invitedAt) {

		this.invitedAt = invitedAt;
	}

	public String getInvitedBy() {

		return invitedBy;
	}

	public void setInvitedBy(final String invitedBy) {

		this.invitedBy = invitedBy;
	}

	public OffsetDateTime getUpdatedAt() {

		return updatedAt;
	}

	public void setUpdatedAt(final OffsetDateTime updatedAt) {

		this.updatedAt = updatedAt;
	}

	public String getUpdatedByFirstName() {

		return updatedByFirstName;
	}

	public void setUpdatedByFirstName(final String updatedByFirstName) {

		this.updatedByFirstName = updatedByFirstName;
	}

	public String getUpdatedByLastName() {

		return updatedByLastName;
	}

	public void setUpdatedByLastName(final String updatedByLastName) {

		this.updatedByLastName = updatedByLastName;
	}

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof UserAuditResponse)) {
			return false;
		}
		final UserAuditResponse castOther = (UserAuditResponse) other;
		return new EqualsBuilder().append(username, castOther.username).append(firstName, castOther.firstName)
				.append(lastName, castOther.lastName).append(email, castOther.email)
				.append(passwordUpdated, castOther.passwordUpdated)
				.append(phoneTypeDescription, castOther.phoneTypeDescription).append(phone, castOther.phone)
				.append(roleDescription, castOther.roleDescription).append(registeredDate, castOther.registeredDate)
				.append(terminationDate, castOther.terminationDate).append(invitedAt, castOther.invitedAt)
				.append(invitedBy, castOther.invitedBy).append(updatedAt, castOther.updatedAt)
				.append(updatedByFirstName, castOther.updatedByFirstName)
				.append(updatedByLastName, castOther.updatedByLastName).isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(username).append(firstName).append(lastName).append(email)
				.append(passwordUpdated).append(phoneTypeDescription).append(phone).append(roleDescription)
				.append(registeredDate).append(terminationDate).append(invitedAt).append(invitedBy).append(updatedAt)
				.append(updatedByFirstName).append(updatedByLastName).toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("username", username).append("firstName", firstName)
				.append("lastName", lastName).append("email", email).append("passwordUpdated", passwordUpdated)
				.append("phoneTypeDescription", phoneTypeDescription).append("phone", phone)
				.append("roleDescription", roleDescription).append("registeredDate", registeredDate)
				.append("terminationDate", terminationDate).append("invitedAt", invitedAt)
				.append("invitedBy", invitedBy).append("updatedAt", updatedAt)
				.append("updatedByFirstName", updatedByFirstName).append("updatedByLastName", updatedByLastName)
				.toString();
	}

}
