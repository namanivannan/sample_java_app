package com.r1vs.platform.rox.common.model.business;

import com.r1vs.platform.rox.common.model.AuditedEntity;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "address")
@EntityListeners(AuditingEntityListener.class)
public class Address extends AuditedEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@OneToOne
	@JoinColumn(name = "address_type_id")
	private AddressType addressType;

	@Column(name = "description")
	private String description;

	@Column(name = "xref_id")
	private Long xrefId;

	@Column(name = "xref_type_id")
	private Long xrefTypeId;

	@Column(name = "is_primary")
	private Boolean isPrimary;

	@Column(name = "address1")
	private String address1;

	@Column(name = "address2")
	private String address2;

	@Column(name = "city")
	private String city;

	@Column(name = "state")
	private String state;

	@Column(name = "zip4")
	private String zip4;

	@Column(name = "zip5")
	private String zip5;

	@Column(name = "country_code")
	private String countryCode;

	@Column(name = "county")
	private String county;

	public Long getId() {

		return this.id;
	}

	public void setId(Long id) {

		this.id = id;
	}

	public AddressType getAddressType() {

		return addressType;
	}

	public void setAddressType(AddressType addressType) {

		this.addressType = addressType;
	}

	public String getDescription() {

		return this.description;
	}

	public void setDescription(String description) {

		this.description = description;
	}

	public Long getXrefId() {

		return this.xrefId;
	}

	public void setXrefId(Long xrefId) {

		this.xrefId = xrefId;
	}

	public Long getXrefTypeId() {

		return this.xrefTypeId;
	}

	public void setXrefTypeId(Long xrefTypeId) {

		this.xrefTypeId = xrefTypeId;
	}

	public Boolean getIsPrimary() {

		return this.isPrimary;
	}

	public void setIsPrimary(Boolean isPrimary) {

		this.isPrimary = isPrimary;
	}

	public String getAddress1() {

		return this.address1;
	}

	public void setAddress1(String address1) {

		this.address1 = address1;
	}

	public String getAddress2() {

		return this.address2;
	}

	public void setAddress2(String address2) {

		this.address2 = address2;
	}

	public String getCity() {

		return this.city;
	}

	public void setCity(String city) {

		this.city = city;
	}

	public String getState() {

		return this.state;
	}

	public void setState(String state) {

		this.state = state;
	}

	public String getZip4() {

		return this.zip4;
	}

	public void setZip4(String zip4) {

		this.zip4 = zip4;
	}

	public String getZip5() {

		return this.zip5;
	}

	public void setZip5(String zip5) {

		this.zip5 = zip5;
	}

	public String getCountryCode() {

		return this.countryCode;
	}

	public void setCountryCode(String countryCode) {

		this.countryCode = countryCode;
	}

	public String getCounty() {

		return this.county;
	}

	public void setCounty(String county) {

		this.county = county;
	}
}
