package com.r1vs.platform.rox.api.service;

import com.r1vs.platform.rox.api.model.application.initiate.NotesDTO;
import com.r1vs.platform.rox.api.model.application.initiate.UpdateNoteDTO;
import com.r1vs.platform.rox.common.db.repository.note.NotesRepository;
import com.r1vs.platform.rox.common.model.business.Application;
import com.r1vs.platform.rox.common.model.business.Client;
import com.r1vs.platform.rox.common.model.business.storage.RoxFile;
import com.r1vs.platform.rox.common.model.notes.Notes;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;

@Service
public class NotesService {

	private static final Logger LOGGER = LoggerFactory.getLogger(NotesService.class);

	@Autowired
	private NotesRepository notesRepository;

	@Autowired
	private ValidationUtils validationUtils;

	@Autowired
	private AuditUtilsService auditUtilsService;

	@Autowired
	@Qualifier("nonNullModelMapper")
	private ModelMapper nonNullModelMapper;

	public Notes createNote(NotesDTO notesDTO) {

		Notes note = new Notes();
		note.setUuid(UUID.randomUUID());
		nonNullModelMapper.map(notesDTO, note);
		notesRepository.save(note);
		auditUtilsService.recoverAuditObjects(note);
		return note;
	}

	@Transactional
	public NotesDTO createNoteInApplication(String clientId, UUID applicationId, NotesDTO notesDTO) {

		Client client = validationUtils.requireClient(clientId);
		Application application = validationUtils.requireApplication(applicationId, client);
		Notes note = createNote(notesDTO);
		note.setApplication(application);
		notesRepository.save(note);
		auditUtilsService.touchApplicationUpdateFields(application, note);
		nonNullModelMapper.map(note, notesDTO);
		return notesDTO;
	}

	@Transactional
	public NotesDTO createNoteInAttachment(String clientId, UUID applicationId, UUID fileId, NotesDTO notesDTO) {

		Client client = validationUtils.requireClient(clientId);
		Application application = validationUtils.requireApplication(applicationId, client);
		RoxFile roxFile = validationUtils.requireRoxFile(fileId, application);
		Notes note = createNote(notesDTO);
		note.setRoxFile(roxFile);
		note.setApplication(application);
		notesRepository.save(note);
		auditUtilsService.touchRoxFileUpdateFields(note.getRoxFile(), note);
		nonNullModelMapper.map(note, notesDTO);
		return notesDTO;
	}

	public Notes editNote(UpdateNoteDTO updateNoteDTO, Notes note) {

		nonNullModelMapper.map(updateNoteDTO, note);
		auditUtilsService.recoverAuditObjects(note);
		return note;
	}

	public NotesDTO editNoteInApplication(String clientId, UUID applicationId, UUID noteId,
			UpdateNoteDTO updateNoteDTO) {

		Client client = validationUtils.requireClient(clientId);
		Application application = validationUtils.requireApplication(applicationId, client);
		Notes note = validationUtils.requireApplicationNote(noteId, application);
		editNote(updateNoteDTO, note);
		notesRepository.save(note);
		auditUtilsService.touchApplicationUpdateFields(application, note);

		NotesDTO notesDTO = new NotesDTO();
		nonNullModelMapper.map(note, notesDTO);
		return notesDTO;
	}

	public NotesDTO editNoteInAttachment(String clientId, UUID applicationId, UUID fileId, UUID noteId,
			UpdateNoteDTO updateNoteDTO) {

		Client client = validationUtils.requireClient(clientId);
		Application application = validationUtils.requireApplication(applicationId, client);
		RoxFile roxFile = validationUtils.requireRoxFile(fileId, application);
		Notes note = validationUtils.requireAttachmentNote(application, noteId, roxFile);
		editNote(updateNoteDTO, note);
		notesRepository.save(note);

		auditUtilsService.recoverAuditObjects(note);
		auditUtilsService.touchRoxFileUpdateFields(note.getRoxFile(), note);

		NotesDTO notesDTO = new NotesDTO();
		nonNullModelMapper.map(note, notesDTO);
		return notesDTO;
	}

	public Page<NotesDTO> getNotes(UUID applicationId, String clientId, Pageable pageParams) {

		Client client = validationUtils.requireClient(clientId);
		return notesRepository
				.findAllByApplicationAndRoxFileNull(validationUtils.requireApplication(applicationId, client),
						pageParams)
				.map((entity) -> nonNullModelMapper.map(entity, NotesDTO.class));
	}

	public NotesDTO getNote(UUID applicationId, UUID noteId, String clientId) {

		return nonNullModelMapper.map(validationUtils.requireNote(clientId, applicationId, noteId), NotesDTO.class);
	}
}
