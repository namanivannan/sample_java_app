package com.r1vs.platform.rox.api.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.r1vs.platform.rox.common.model.security.AssignedSecurityContext;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.List;

public class UserResponse implements Serializable {

	private static final long serialVersionUID = 1L;

	private Integer userId;

	private String username;

	private String firstName;

	private String lastName;

	private String email;

	private Integer phoneTypeCodeId;

	@JsonProperty(value = "phoneType")
	private String phoneTypeDescription;

	@JsonProperty(value = "phone")
	private String phone;

	private List<Integer> roleIds;

	@JsonProperty(value = "role")
	private String roleDescription;

	private String status;

	private Boolean canBeResent = false;

	@JsonProperty(value = "activeAt")
	private OffsetDateTime registeredDate;

	@JsonProperty(value = "inactiveAt")
	private OffsetDateTime terminationDate;

	@JsonProperty(value = "createdAt")
	private OffsetDateTime createdAt;

	@JsonProperty(value = "createdByFirstName")
	private String createdByFirstName;

	@JsonProperty(value = "createdByLastName")
	private String createdByLastName;

	private AssignedSecurityContext securityContext;

	private Integer accessGroupId;

	private String accessGroupName;

	public Integer getUserId() {

		return userId;
	}

	public void setUserId(final Integer userId) {

		this.userId = userId;
	}

	public String getUsername() {

		return username;
	}

	public void setUsername(final String username) {

		this.username = username;
	}

	public String getFirstName() {

		return firstName;
	}

	public void setFirstName(final String firstName) {

		this.firstName = firstName;
	}

	public String getLastName() {

		return lastName;
	}

	public void setLastName(final String lastName) {

		this.lastName = lastName;
	}

	public String getEmail() {

		return email;
	}

	public void setEmail(final String email) {

		this.email = email;
	}

	public Integer getPhoneTypeCodeId() {

		return phoneTypeCodeId;
	}

	public void setPhoneTypeCodeId(final Integer phoneTypeCodeId) {

		this.phoneTypeCodeId = phoneTypeCodeId;
	}

	public String getPhoneTypeDescription() {

		return phoneTypeDescription;
	}

	public void setPhoneTypeDescription(final String phoneTypeDescription) {

		this.phoneTypeDescription = phoneTypeDescription;
	}

	public String getPhone() {

		return phone;
	}

	public void setPhone(final String phone) {

		this.phone = phone;
	}

	public List<Integer> getRoleIds() {

		return roleIds;
	}

	public void setRoleIds(final List<Integer> roleIds) {

		this.roleIds = roleIds;
	}

	public String getRoleDescription() {

		return roleDescription;
	}

	public void setRoleDescription(final String roleDescription) {

		this.roleDescription = roleDescription;
	}

	public String getStatus() {

		return status;
	}

	public void setStatus(final String status) {

		this.status = status;
	}

	public Boolean getCanBeResent() {

		return canBeResent;
	}

	public void setCanBeResent(final Boolean canBeResent) {

		this.canBeResent = canBeResent;
	}

	public OffsetDateTime getRegisteredDate() {

		return registeredDate;
	}

	public void setRegisteredDate(final OffsetDateTime registeredDate) {

		this.registeredDate = registeredDate;
	}

	public OffsetDateTime getTerminationDate() {

		return terminationDate;
	}

	public void setTerminationDate(final OffsetDateTime terminationDate) {

		this.terminationDate = terminationDate;
	}

	public OffsetDateTime getCreatedAt() {

		return createdAt;
	}

	public void setCreatedAt(final OffsetDateTime createdAt) {

		this.createdAt = createdAt;
	}

	public String getCreatedByFirstName() {

		return createdByFirstName;
	}

	public void setCreatedByFirstName(final String createdByFirstName) {

		this.createdByFirstName = createdByFirstName;
	}

	public String getCreatedByLastName() {

		return createdByLastName;
	}

	public void setCreatedByLastName(final String createdByLastName) {

		this.createdByLastName = createdByLastName;
	}

	public AssignedSecurityContext getSecurityContext() {

		return securityContext;
	}

	public void setSecurityContext(final AssignedSecurityContext securityContext) {

		this.securityContext = securityContext;
	}

	public Integer getAccessGroupId() {

		return accessGroupId;
	}

	public void setAccessGroupId(final Integer accessGroupId) {

		this.accessGroupId = accessGroupId;
	}

	public String getAccessGroupName() {

		return accessGroupName;
	}

	public void setAccessGroupName(final String accessGroupName) {

		this.accessGroupName = accessGroupName;
	}

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof UserResponse)) {
			return false;
		}
		final UserResponse castOther = (UserResponse) other;
		return new EqualsBuilder().append(userId, castOther.userId).append(username, castOther.username)
				.append(firstName, castOther.firstName).append(lastName, castOther.lastName)
				.append(email, castOther.email).append(phoneTypeCodeId, castOther.phoneTypeCodeId)
				.append(phoneTypeDescription, castOther.phoneTypeDescription).append(phone, castOther.phone)
				.append(roleIds, castOther.roleIds).append(roleDescription, castOther.roleDescription)
				.append(status, castOther.status).append(canBeResent, castOther.canBeResent)
				.append(securityContext, castOther.securityContext).append(canBeResent, castOther.securityContext)
				.append(accessGroupId, castOther.accessGroupId).append(canBeResent, castOther.accessGroupId)
				.append(accessGroupName, castOther.accessGroupName).append(canBeResent, castOther.accessGroupName)
				.append(registeredDate, castOther.registeredDate).append(terminationDate, castOther.terminationDate)
				.append(createdAt, castOther.createdAt).append(createdByFirstName, castOther.createdByFirstName)
				.append(createdByLastName, castOther.createdByLastName).isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(userId).append(username).append(firstName).append(lastName).append(email)
				.append(phoneTypeCodeId).append(phoneTypeDescription).append(phone).append(roleIds)
				.append(roleDescription).append(status).append(canBeResent).append(registeredDate)
				.append(terminationDate).append(createdAt).append(createdByFirstName).append(createdByLastName)
				.append(securityContext)
				.append(accessGroupId)
				.append(accessGroupName)
				.toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("userId", userId).append("username", username)
				.append("firstName", firstName).append("lastName", lastName).append("email", email)
				.append("phoneTypeCodeId", phoneTypeCodeId).append("phoneTypeDescription", phoneTypeDescription)
				.append("phone", phone).append("roleIds", roleIds).append("roleDescription", roleDescription)
				.append("status", status).append("canBeResent", canBeResent).append("registeredDate", registeredDate)
				.append("terminationDate", terminationDate).append("createdAt", createdAt)
				.append("createdByFirstName", createdByFirstName).append("createdByLastName", createdByLastName)
				.append("securityContext", securityContext)
				.append("accessGroupId", accessGroupId)
				.append("accessGroupName", accessGroupName)
				.toString();
	}

}
