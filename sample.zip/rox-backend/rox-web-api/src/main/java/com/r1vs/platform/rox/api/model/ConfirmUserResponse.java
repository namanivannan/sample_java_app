package com.r1vs.platform.rox.api.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

public class ConfirmUserResponse {

	@JsonProperty(value = "userId")
	private Long userId;

	public Long getUserId() {

		return userId;
	}

	public void setUserId(final Long userId) {

		this.userId = userId;
	}

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof ConfirmUserResponse)) {
			return false;
		}
		final ConfirmUserResponse castOther = (ConfirmUserResponse) other;
		return new EqualsBuilder().append(userId, castOther.userId).isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(userId).toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("userId", userId).toString();
	}

}
