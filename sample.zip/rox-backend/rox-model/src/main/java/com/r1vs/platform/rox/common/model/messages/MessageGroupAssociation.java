package com.r1vs.platform.rox.common.model.messages;

import java.io.Serializable;

public class MessageGroupAssociation implements Serializable {

	private Integer messageTemplateId;

	private String triggerCriteria;

	public Integer getMessageTemplateId() {

		return messageTemplateId;
	}

	public void setMessageTemplateId(Integer messageTemplateId) {

		this.messageTemplateId = messageTemplateId;
	}

	public String getTriggerCriteria() {

		return triggerCriteria;
	}

	public void setTriggerCriteria(String triggerCriteria) {

		this.triggerCriteria = triggerCriteria;
	}

}
