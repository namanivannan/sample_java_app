package com.r1vs.platform.rox.filemanagement.services;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.s3.model.*;
import com.r1vs.platform.rox.common.model.business.storage.RoxFile;

import java.io.InputStream;

import com.r1vs.platform.rox.filemanagement.exceptions.RoxStorageException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import com.amazonaws.services.s3.AmazonS3;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

/**
 * This Service class has the methods that connect with S3, storing, downloading and deleting files
 */
@Service
public class S3Storage {

	private AmazonS3Config amazonS3Config;

	private AmazonS3 amazonS3;

	@Autowired
	public S3Storage(AmazonS3 amazonS3, AmazonS3Config awsS3Config) {

		this.amazonS3 = amazonS3;
		this.amazonS3Config = awsS3Config;
	}

	public void storeFile(RoxFile roxFile, InputStream inputStream) {

		try {
			ObjectMetadata objectMetadata = new ObjectMetadata();

			objectMetadata.setContentLength(roxFile.getFileSize());
			objectMetadata.setContentType(roxFile.getFileType());

			amazonS3.putObject(amazonS3Config.getBucketName(), roxFile.getKey(), inputStream, objectMetadata);
		} catch (AmazonS3Exception e) {
			throw new RoxStorageException("S3: " + e.getErrorMessage(), e, HttpStatus.INTERNAL_SERVER_ERROR);
		} catch (Exception e) {
			throw new RoxStorageException(e.getMessage(), e, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	public Resource getFile(RoxFile roxFile) throws RoxStorageException {

		try {
			S3Object s3Object = amazonS3.getObject(amazonS3Config.getBucketName(), roxFile.getKey());
			S3ObjectInputStream s3ObjectInputStream = s3Object.getObjectContent();
			return new InputStreamResource(s3ObjectInputStream);

		} catch (AmazonServiceException e) {
			throw new RoxStorageException("S3: " + e.getErrorMessage(), e, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	public String getFileURL(RoxFile roxFile) throws RoxStorageException {

		try {
			return amazonS3.getUrl(amazonS3Config.getBucketName(), roxFile.getKey()).toString();
		} catch (AmazonServiceException e) {
			throw new RoxStorageException("S3: " + e.getErrorMessage(), e, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	public void deleteFile(RoxFile roxFile) throws RoxStorageException {

		try {
			amazonS3.deleteObject(amazonS3Config.getBucketName(), roxFile.getKey());
		} catch (AmazonServiceException e) {
			throw new RoxStorageException("S3: " + e.getErrorMessage(), e, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
