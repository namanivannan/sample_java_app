package com.r1vs.platform.rox.common.model.business;

import com.r1vs.platform.rox.common.model.AuditedEntity;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@Entity
@Table(name = "owner")
@EntityListeners(AuditingEntityListener.class)
public class Owner extends AuditedEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@Column(name = "uuid", nullable = false, updatable = false)
	private UUID uuid;

	@OneToOne
	@JoinColumn(name = "application_id", nullable = false)
	private Application application;

	@Column(name = "first_name")
	private String firstName;

	@Column(name = "last_name")
	private String lastName;

	@Column(name = "identifier")
	private String identifier;

	@Column(name = "date_of_birth")
	private Date dateOfBirth;

	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "owner_address",
			joinColumns = @JoinColumn(name = "owner_id"),
			inverseJoinColumns = @JoinColumn(name = "address_id"))
	@JoinColumn(name = "address_id", nullable = false)
	private List<Address> addresses;

	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "owner_email",
			joinColumns = @JoinColumn(name = "owner_id"),
			inverseJoinColumns = @JoinColumn(name = "email_id"))
	private List<Email> emails;

	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "owner_identification",
			joinColumns = @JoinColumn(name = "owner_id"),
			inverseJoinColumns = @JoinColumn(name = "identification_id"))
	private List<Identification> identifications;

	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "owner_phone",
			joinColumns = @JoinColumn(name = "owner_id"),
			inverseJoinColumns = @JoinColumn(name = "phone_id"))
	private List<Phone> phones;

	public Long getId() {

		return this.id;
	}

	public void setId(Long id) {

		this.id = id;
	}

	public Application getApplication() {

		return application;
	}

	public void setApplication(Application application) {

		this.application = application;
	}

	public String getFirstName() {

		return this.firstName;
	}

	public void setFirstName(String firstName) {

		this.firstName = firstName;
	}

	public String getLastName() {

		return this.lastName;
	}

	public void setLastName(String lastName) {

		this.lastName = lastName;
	}

	public String getIdentifier() {

		return this.identifier;
	}

	public void setIdentifier(String identifier) {

		this.identifier = identifier;
	}

	public List<Address> getAddresses() {

		return addresses;
	}

	public void setAddresses(List<Address> addresses) {

		this.addresses = addresses;
	}

	public List<Email> getEmails() {

		return emails;
	}

	public void setEmails(List<Email> emails) {

		this.emails = emails;
	}

	public List<Identification> getIdentifications() {

		return identifications;
	}

	public void setIdentifications(List<Identification> identifications) {

		this.identifications = identifications;
	}

	public List<Phone> getPhones() {

		return phones;
	}

	public void setPhones(List<Phone> phones) {

		this.phones = phones;
	}

	public Date getDateOfBirth() {

		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {

		this.dateOfBirth = dateOfBirth;
	}

	public UUID getUuid() {

		return uuid;
	}

	public void setUuid(UUID uuid) {

		this.uuid = uuid;
	}
}
