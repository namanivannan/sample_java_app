package com.r1vs.platform.rox.common.model.ds;

public enum InteractionResponseCode {
	VALID,
	ERROR
}
