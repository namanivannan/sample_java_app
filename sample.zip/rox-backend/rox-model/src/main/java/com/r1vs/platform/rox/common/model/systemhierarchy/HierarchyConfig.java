package com.r1vs.platform.rox.common.model.systemhierarchy;

public interface HierarchyConfig {

}
