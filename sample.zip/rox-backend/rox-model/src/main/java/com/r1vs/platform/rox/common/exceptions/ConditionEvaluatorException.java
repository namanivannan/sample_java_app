package com.r1vs.platform.rox.common.exceptions;

public class ConditionEvaluatorException extends RuntimeException {

	public ConditionEvaluatorException() {

	}

	public ConditionEvaluatorException(final String message) {

		super(message);
	}

	public ConditionEvaluatorException(final String message, final Throwable cause) {

		super(message, cause);
	}
}
