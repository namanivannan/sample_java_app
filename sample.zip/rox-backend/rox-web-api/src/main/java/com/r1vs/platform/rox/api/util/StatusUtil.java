package com.r1vs.platform.rox.api.util;

import com.r1vs.platform.rox.common.model.types.StatusType;

public class StatusUtil {

	/**
	 * Is request statusId Inactive
	 *
	 * @param statusId statusId
	 * @return true - if statusId is Inactive
	 */
	public static boolean isInactivation(final Integer statusId) {

		return StatusType.INACTIVE.key().equals(statusId);
	}

	/**
	 * Is request statusId Deleted
	 *
	 * @param statusId statusId
	 * @return true - if statusId is Deleted
	 */
	public static boolean isDeletion(final Integer statusId) {

		return StatusType.DELETED.key().equals(statusId);
	}

	/**
	 * Is request statusId Active
	 *
	 * @param statusId statusId
	 * @return true - if statusId is Active
	 */
	public static boolean isActivation(final Integer statusId) {

		return StatusType.ACTIVE.key().equals(statusId);
	}

	/**
	 * Is request statusId not Draft
	 *
	 * @param statusId statusId
	 * @return true - if statusId is not Draft
	 */
	public static boolean isNonDraftStatus(final Integer statusId) {

		return !StatusType.DRAFT.key().equals(statusId);
	}

	/**
	 * Is status change Active --&gt; Inactive
	 *
	 * @param oldStatusId oldStatusId
	 * @param newStatusId newStatusId
	 * @return true - if status change Active --&gt; Inactive
	 */
	public static boolean isActiveToInactiveStatusChange(final Integer oldStatusId, final Integer newStatusId) {

		return StatusType.ACTIVE.key().equals(oldStatusId) && StatusType.INACTIVE.key().equals(newStatusId);
	}

	/**
	 * Is status change Draft --&gt; Deleted
	 *
	 * @param oldStatusId oldStatusId
	 * @param newStatusId newStatusId
	 * @return true - if status change Draft --&gt; Deleted
	 */
	public static boolean isDraftToDeletedStatusChange(final Integer oldStatusId, final Integer newStatusId) {

		return StatusType.DRAFT.key().equals(oldStatusId) && StatusType.DELETED.key().equals(newStatusId);
	}

}
