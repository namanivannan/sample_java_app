package com.r1vs.platform.rox.api.util;

/**
 * This class contains common constants that will be used in the prescriber module.
 */
public class PrescriberConstants {

	public static final String GREATER_THAN = ">";

	public static final String LESS_THAN = "<";

	public static final String CITY_EQUALS = "<:";

	public static final String EQUALS = ":";

	public static final String NOT_EQUALS = "!:";

	public static final String LIKE = "::";

	public static final String LOCATION_FILTER = "<<:";

	public static final String ALIAS_FILTER = ">>:";

	public static final String DEACTIVATED_EQUALS = ">:";

	public static final String ACTIVE_FILTER = "???";

	public final static String PROCESSOR_PRESCRIBER_ID_QUALIFIER = "88";

	public final static String INTERNAL_PRESCRIBER_ID = "internalPrescriberId";

	public final static String EFFECTIVE_START_DATE = "effectiveStartDate";

	public final static String EFFECTIVE_END_DATE = "effectiveEndDate";

	public final static String ENTITY_TYPE = "entityType";

	public final static String SOLE_PROPRIETOR = "soleProprietor";

	public final static String ORGANIZATION_SUB_PART = "organizationSubPart";

	public final static String NPI_DEACTIVATION_REASON = "npiDeactivationReason";

	public final static String LANGUAGE_CODE = "languageCode";

	public final static String PRESCRIBER_GROUP_TYPE = "prescriberGroupType";

	public final static String PRESCRIBER_PARENT_TYPE = "prescriberParentType";

	public final static String UPDATE_PRESCRIBER_REQUEST = "updatePrescriberRequest";

	public final static String PRESCRIBER_PRIMARY_REQUEST = "prescriberPrimary";

	public final static String PRESCRIBER_CITY = "city";

	public final static String PRESCRIBER_GROUP_CITY = "city";

	public final static String PRESCRIBER_PARENT_CITY = "city";

	public final static String PRESCRIBER_GROUP_STATE = "stateCode";

	public final static String PRESCRIBER_TAXONOMY_STATE = "taxonomyState";

	public final static String PRESCRIBER_PARENT_STATE = "stateCode";

	public static final String STATUS_ID = "statusId";

	public static final String PRESCRIBER_NAME = "prescriberLegalName";

	public static final String PRESCRIBER_GROUP_NAME = "name";

	public static final String PRESCRIBER_LOCATION = "prescriberLocation";

	public static final String PRESCRIBER_GROUP_LOCATION = "prescriberGroupLocation";

	public static final String PRESCRIBER_GROUP_REQUEST = "prescriberGroupRequest";

	public static final String PRESCRIBER_ALIAS_REQUEST = "prescriberAliasRequest";

	public static final String PRESCRIBER_PARENT_REQUEST = "prescriberParentRequest";

	public static final String PBM_ID = "pbmId";

	public static final String PRESCRIBER_GROUP_ID = "prescriberGroupId";

	public static final String PRESCRIBER_GROUP_PRIMARY_ID = "id";

	public static final String PRESCRIBER_PARENT_PRIMARY_ID = "id";

	public static final String PROCESSOR_PRESCRIBER_ID = "processorPrescriberId";

	public static final String SERVICE_PRESCRIBER_ID_QUALIFIER = "servicePrescriberIdQualifier";

	public static final String SERVICE_PRESCRIBER_ID = "servicePrescriberId";

	public static final String PRESCRIBER_ALIAS_ID = "prescriberAliasId";

	public static final String SERVICE_PRESCRIBER_ID_STATE = "servicePrescriberIdState";

	public static final String PRESCRIBER_PRIMARY_ID = "prescriberPrimaryId";

	public static final String PRESCRIBER_STATE = "stateCode";

	public static final String PRESCRIBER_ZIP_CODE = "zipCode";

	public static final String PRESCRIBER_GROUP_ADDRESS_LINE_1 = "address1";

	public static final String PRESCRIBER_PARENT_ADDRESS_LINE_1 = "address1";

	public static final String PRESCRIBER_GROUP_ZIP_CODE = "zipCode";

	public static final String PRESCRIBER_PARENT_ZIP_CODE = "zipCode";

	public static final String DEACTIVATED_AT = "deactivatedAt";

	public static final String PRESRCIBER_NAME = "prescriberLegalName";

	public static final String PRESCRIBER_PARENT_NAME = "name";

	public static final String PRESCRIBER_ENTITY_TYPE = "entityType";

	public static final String PRESCRIBER_PARENT_ID = "prescriberParentId";

	public static final String PRESCRIBER_TAXONOMY_ID = "prescriberTaxonomyId";

	public static final String PRESCRIBER_CONTACT_TYPE = "contactType";

	public static final String PRESCRIBER_GROUP_CONTACT_TYPE = "contactType";

	public static final String PRESCRIBER_PARENT_CONTACT_TYPE = "contactType";

	public static final String TAXONOMY_CODE = "taxonomyCode";

	public static final String TAXONOMY_FLAG = "taxonomyFlag";

	public static final String LANGUAGE_CODE_1 = "languageCode1";

	public static final String LANGUAGE_CODE_2 = "languageCode2";

	public static final String LANGUAGE_CODE_3 = "languageCode3";

	public static final String LANGUAGE_CODE_4 = "languageCode4";

	public static final String LANGUAGE_CODE_5 = "languageCode5";

	public static final String CONTACT_FIRST_NAME = "firstName";

	public static final String CONTACT_LAST_NAME = "lastName";

	public static final String PRESCRIBER_PRIMARY_DETAILS = "prescriberPrimaryDetails";

	public static final String PRESCRIBER_GROUP_DETAILS = "prescriberGroupDetails";

	public static final String PRESCRIBER_PARENT_LOCATION = "prescriberParentLocation";

	public static final String INVALID_LANGUAGE_CODE_1 = "INVALID_LANGUAGE_CODE_1";

	public static final String INVALID_LANGUAGE_CODE_2 = "INVALID_LANGUAGE_CODE_2";

	public static final String INVALID_LANGUAGE_CODE_3 = "INVALID_LANGUAGE_CODE_3";

	public static final String INVALID_LANGUAGE_CODE_4 = "INVALID_LANGUAGE_CODE_4";

	public static final String INVALID_LANGUAGE_CODE_5 = "INVALID_LANGUAGE_CODE_5";

	public static final String INVALID_PRESCRIBER = "INVALID_PRESCRIBER";

	public static final String INVALID_CONTACT_TYPE = "INVALID_CONTACT_TYPE";

	public static final String INVALID_STATE = "INVALID_STATE";

	public static final String INVALID_ZIP_CODE = "INVALID_ZIP_CODE";

	public static final String INACTIVE_PRESCRIBER = "INACTIVE_PRESCRIBER";

	public static final String INVALID_SERVICE_PRESCRIBER_ID_QUALIFIER = "INVALID_SERVICE_PRESCRIBER_ID_QUALIFIER";

	public static final String INVALID_SERVICE_PRESCRIBER_ID_STATE = "INVALID_SERVICE_PRESCRIBER_ID_STATE";

	public static final String INVALID_PRESCRIBER_ALIAS_REQUEST = "INVALID_PRESCRIBER_ALIAS_REQUEST";

	public static final String PROCESSOR_PRESCRIBER_ID_ALREADY_EXISTS = "PROCESSOR_PRESCRIBER_ID_ALREADY_EXISTS";

	public static final String PROCESSOR_PRESCRIBER_ID_CANNOT_BE_NULL = "PROCESSOR_PRESCRIBER_ID_CANNOT_BE_NULL";

	public static final String PRESCRIBER_NAME_ALREADY_EXISTS = "PRESCRIBER_NAME_ALREADY_EXISTS";

	public static final String PRESCRIBER_NAME_CANNOT_BE_NULL = "PRESCRIBER_NAME_CANNOT_BE_NULL";

	public static final String PRESCRIBER_ENTITY_TYPE_CANNOT_BE_NULL = "PRESCRIBER_ENTITY_TYPE_CANNOT_BE_NULL";

	public static final String PRESCRIBER_GROUP_NAME_ALREADY_EXISTS = "PRESCRIBER_GROUP_NAME_ALREADY_EXISTS";

	public static final String PRESCRIBER_PARENT_NAME_ALREADY_EXISTS = "PRESCRIBER_PARENT_NAME_ALREADY_EXISTS";

	public static final String PRESCRIBER_PRIMARY_ID_CANNOT_BE_NULL = "PRESCRIBER_PRIMARY_ID_CANNOT_BE_NULL";

	public static final String PRESCRIBER_GROUP_ID_CANNOT_BE_NULL = "PRESCRIBER_GROUP_ID_CANNOT_BE_NULL";

	public static final String PRESCRIBER_PARENT_ID_CANNOT_BE_NULL = "PRESCRIBER_PARENT_ID_CANNOT_BE_NULL";

	public static final String PRESCRIBER_GROUP_NAME_CANNOT_BE_NULL = "PRESCRIBER_GROUP_NAME_CANNOT_BE_NULL";

	public static final String PRESCRIBER_PARENT_NAME_CANNOT_BE_NULL = "PRESCRIBER_PARENT_NAME_CANNOT_BE_NULL";

	public static final String PRESCRIBER_GROUP_LOCATION_CANNOT_BE_NULL = "PRESCRIBER_GROUP_LOCATION_CANNOT_BE_NULL";

	public static final String PRESCRIBER_PARENT_LOCATION_CANNOT_BE_NULL = "PRESCRIBER_PARENT_LOCATION_CANNOT_BE_NULL";

	public static final String TAXONOMY_CODE_CANNOT_BE_NULL = "TAXONOMY_CODE_CANNOT_BE_NULL";

	public static final String PRESCRIBER_GROUP_ADDRESS_LINE_1_CANNOT_BE_NULL =
			"PRESCRIBER_GROUP_ADDRESS_LINE_1_CANNOT_BE_NULL";

	public static final String PRESCRIBER_PARENT_ADDRESS_LINE_1_CANNOT_BE_NULL =
			"PRESCRIBER_PARENT_ADDRESS_LINE_1_CANNOT_BE_NULL";

	public static final String PRESCRIBER_GROUP_STATE_CANNOT_BE_NULL = "PRESCRIBER_GROUP_STATE_CANNOT_BE_NULL";

	public static final String PRESCRIBER_PARENT_STATE_CANNOT_BE_NULL = "PRESCRIBER_PARENT_STATE_CANNOT_BE_NULL";

	public static final String PRESCRIBER_GROUP_CITY_CANNOT_BE_NULL = "PRESCRIBER_GROUP_CITY_CANNOT_BE_NULL";

	public static final String PRESCRIBER_PARENT_CITY_CANNOT_BE_NULL = "PRESCRIBER_PARENT_CITY_CANNOT_BE_NULL";

	public static final String PRESCRIBER_GROUP_ZIPCODE_CANNOT_BE_NULL = "PRESCRIBER_GROUP_ZIPCODE_CANNOT_BE_NULL";

	public static final String PRESCRIBER_PARENT_ZIPCODE_CANNOT_BE_NULL = "PRESCRIBER_PARENT_ZIPCODE_CANNOT_BE_NULL";

	public static final String PRESCRIBER_LOCATION_CANNOT_BE_NULL = "PRESCRIBER_LOCATION_CANNOT_BE_NULL";

	public static final String PRESCRIBER_ADDRESS_LINE_1_CANNOT_BE_NULL = "PRESCRIBER_ADDRESS_LINE_1_CANNOT_BE_NULL";

	public static final String PRESCRIBER_STATE_CANNOT_BE_NULL = "PRESCRIBER_STATE_CANNOT_BE_NULL";

	public static final String PRESCRIBER_CITY_CANNOT_BE_NULL = "PRESCRIBER_CITY_CANNOT_BE_NULL";

	public static final String PRESCRIBER_ZIPCODE_CANNOT_BE_NULL = "PRESCRIBER_ZIPCODE_CANNOT_BE_NULL";

	public static final String PRESCRIBER_TAXONOMY_ID_CANNOT_BE_NULL = "PRESCRIBER_TAXONOMY_ID_CANNOT_BE_NULL";

	public static final String PRESCRIBER_GROUP_PRIMARY_ID_CANNOT_BE_NULL =
			"PRESCRIBER_GROUP_PRIMARY_ID_CANNOT_BE_NULL";

	public static final String PRESCRIBER_PARENT_PRIMARY_ID_CANNOT_BE_NULL =
			"PRESCRIBER_PARENT_PRIMARY_ID_CANNOT_BE_NULL";

	public static final String PRESCRIBER_PRIMARY_DETAILS_CANNOT_BE_NULL = "PRESCRIBER_PRIMARY_DETAILS_CANNOT_BE_NULL";

	public static final String PRESCRIBER_GROUP_DETAILS_CANNOT_BE_NULL = "PRESCRIBER_GROUP_DETAILS_CANNOT_BE_NULL";

	public static final String SERVICE_PRESCRIBER_ID_CANNOT_BE_NULL = "SERVICE_PRESCRIBER_ID_CANNOT_BE_NULL";

	public static final String SERVICE_PRESCRIBER_ID_QUALIFIER_CANNOT_BE_NULL =
			"SERVICE_PRESCRIBER_ID_QUALIFIER_CANNOT_BE_NULL";

	public static final String PRESCRIBER_ALIAS_ID_CANNOT_BE_NULL = "PRESCRIBER_ALIAS_ID_CANNOT_BE_NULL";

	public static final String CONTACT_FIRST_NAME_CANNOT_BE_NULL = "CONTACT_FIRST_NAME_CANNOT_BE_NULL";

	public static final String CONTACT_LAST_NAME_CANNOT_BE_NULL = "CONTACT_LAST_NAME_CANNOT_BE_NULL";

	public static final String INVALID_PRESCRIBER_PRIMARY = "INVALID_PRESCRIBER_PRIMARY";

	public static final String INVALID_UPDATE_PRESCRIBER_REQUEST = "INVALID_UPDATE_PRESCRIBER_REQUEST";

	public static final String INVALID_PRESCRIBER_GROUP = "INVALID_PRESCRIBER_GROUP";

	public static final String INVALID_PRESCRIBER_PARENT = "INVALID_PRESCRIBER_PARENT";

	public static final String PRESCRIBER_GROUP_ID_ALREADY_EXISTS = "PRESCRIBER_GROUP_ID_ALREADY_EXISTS";

	public static final String PRESCRIBER_PARENT_ID_ALREADY_EXISTS = "PRESCRIBER_PARENT_ID_ALREADY_EXISTS";

	public static final String PROCESSOR_PRESCRIBER_ID_DOES_NOT_EXISTS = "PROCESSOR_PRESCRIBER_ID_DOES_NOT_EXISTS";

	public static final String ERROR_WHILE_PROCESSING_PRESCRIBER_DATA = "ERROR_WHILE_PROCESSING_PRESCRIBER_DATA";

	public static final String ERROR_WHILE_PROCESSING_TAXONOMY_DATA = "ERROR_WHILE_PROCESSING_TAXONOMY_DATA";

	public static final String ERROR_WHILE_PROCESSING_PRESCRIBER_GROUP_DATA =
			"ERROR_WHILE_PROCESSING_PRESCRIBER_GROUP_DATA";

	public static final String ERROR_WHILE_PROCESSING_PRESCRIBER_PARENT_DATA =
			"ERROR_WHILE_PROCESSING_PRESCRIBER_PARENT_DATA";

	public static final String ERROR_WHILE_PROCESSING_PRESCRIBER_ALIAS = "ERROR_WHILE_PROCESSING_PRESCRIBER_ALIAS";

	public static final String INVALID_PRESCRIBER_ALIAS = "Prescriber Alias is not effective";

	public static final String INVALID_PRESCRIBER_TAXONOMY = "Prescriber taxonomy is invalid";

}
