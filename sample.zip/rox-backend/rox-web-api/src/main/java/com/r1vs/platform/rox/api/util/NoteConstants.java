package com.r1vs.platform.rox.api.util;

/**
 * This class contains common constants that will be used in the notes module.
 */
public class NoteConstants {

	public static final String NOTE_ID = "noteId";

	public static final String NOTES = "notes";

	public static final String MEMBER_ID = "memberId";

	public static final String TRANSACTION_ID = "transactionId";

	public static final String ELEMENT_SOURCE = "elementSource";

	public static final String ROOT_NOTE_ID = "rootNoteId";

	public static final String NOTE_TYPE = "noteType";

	public static final String CREATED_BY = "createdBy";

	public static final String STATUS_ID = "statusId";

	public static final String EQUALS = "==";

	public static final String IN = "%%";

	public static final String PARENT_NOTE_EQUALS = "?==";

	public static final String INVALID_NOTES = "INVALID_NOTES";

	public static final String INVALID_NOTE_ID = "INVALID_NOTE_ID";

	public static final String INVALID_NOTE_TYPE = "INVALID_NOTE_TYPE";

	public static final String INVALID_MINIMUM_LENGTH = "INVALID_MINIMUM_LENGTH";

	public static final String INVALID_MAXIMUM_LENGTH = "INVALID_MAXIMUM_LENGTH";

	public static final String ROOT_NOTE_ID_SHOULD_NOT_BE_BLANK = "ROOT_NOTE_ID_SHOULD_NOT_BE_BLANK";

	public static final String INVALID_MEMBER_ID = "INVALID_MEMBER_ID_FOR_NOTE";

	public static final String INVALID_TRANSACTION_ID = "INVALID_TRANSACTION_ID_FOR_NOTE";

	public static final String INVALID_ELEMENT_SOURCE = "INVALID_ELEMENT_SOURCE";

	public static final String ERROR_WHILE_PROCESSING_NOTES = "ERROR_WHILE_PROCESSING_NOTES";

	public static final String ERROR_WHILE_FETCHING_NOTES = "ERROR_WHILE_FETCHING_NOTES";

	public static final String ERROR_WHILE_DELETING_NOTES = "ERROR_WHILE_DELETING_NOTES";

	public static final String CHILD_NOTE_EXISTS = "CHILD_NOTE_EXISTS";

}
