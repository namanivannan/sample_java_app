package com.r1vs.platform.rox.common.model.batch;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * The base model to present a record in the batch text file.
 *
 */
public class TextRecord implements Serializable {

	private static final long serialVersionUID = 8329110166256240496L;

	/**
	 * Most likely the original text of the record.
	 */
	private String text;

	/**
	 * If the record is single-line based, this will be the line number. It may not be available depending on the
	 * implementation.
	 *
	 * Optional.
	 */
	private Integer lineNumber;

	/**
	 * Optional.
	 */
	private String fileName;

	/**
	 * Most likely a FileResourceContext
	 */
	private Serializable context;

	/**
	 * Carry the last exception happened on the record.
	 */
	private transient Exception exception;

	public String getText() {

		return text;
	}

	public void setText(final String text) {

		this.text = text;
	}

	public Integer getLineNumber() {

		return lineNumber;
	}

	public void setLineNumber(final Integer lineNumber) {

		this.lineNumber = lineNumber;
	}

	@Override
	public String toString() {

		final ToStringBuilder builder = new ToStringBuilder(this);
		builder.append("text", text).append("lineNumber", lineNumber);
		return builder.toString();
	}

	public String getFileName() {

		return fileName;
	}

	public void setFileName(final String fileName) {

		this.fileName = fileName;
	}

	public Serializable getContext() {

		return context;
	}

	public void setContext(final Serializable context) {

		this.context = context;
	}

	public Exception getException() {

		return exception;
	}

	public void setException(final Exception exception) {

		this.exception = exception;
	}
}
