package com.r1vs.platform.rox.api.processor;

import com.r1vs.platform.rox.api.exception.Error;
import com.r1vs.platform.rox.api.util.DetachableEntityFilter;
import com.r1vs.platform.rox.api.util.InterceptorConstants;
import com.r1vs.platform.rox.api.validator.ValidationMessages;
import com.r1vs.platform.rox.common.bean.DateConfigurationUtil;
import com.r1vs.platform.rox.common.model.types.StatusType;
import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.converter.builtin.PassThroughConverter;
import ma.glasnost.orika.impl.DefaultMapperFactory;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.stream.Collectors;

import static com.r1vs.platform.rox.api.response.ResponseMessages.*;
import static com.r1vs.platform.rox.api.util.ValidationUtil.addError;
import static com.r1vs.platform.rox.api.util.ValidationUtil.handleException;

public class CommonProcessor<T> {

	private static final Integer NO_MORE_PAGES = -1;

	private static final String BOOLEAN_TRUE = "true";

	public static final String STATUS = "status";

	public static MapperFacade mapperFacade = null;

	/**
	 * Get Mapper facade for mapping entities to DTO.
	 *
	 * @return {@link MapperFacade}
	 */
	static {

		final MapperFactory mapperFactory = new DefaultMapperFactory.Builder().build();
		mapperFactory.getConverterFactory().registerConverter(new PassThroughConverter(LocalDate.class));
		mapperFactory.getConverterFactory().registerConverter(new PassThroughConverter(OffsetDateTime.class));
		mapperFactory.registerFilter(new DetachableEntityFilter<>());
		mapperFacade = mapperFactory.getMapperFacade();
	}

	/**
	 * Create response with pagination.
	 *
	 * @param totalCount total records
	 * @param pageNum page number
	 * @param pageLimit page limit
	 * @param objects object
	 * @return {@link ResponseEntity}
	 */
	public ResponseEntity<List<T>> buildResponseAsListWithPagination(final long totalCount, final int pageNum,
			final int pageLimit, final List<T> objects) {

		final HttpHeaders httpHeaders = getHttpHeaders(totalCount, pageNum, pageLimit, objects);

		if (httpHeaders.size() > 0) {

			final List<String> headers = httpHeaders.get(X_PAGINATION_HAS_NEXT_PAGE);

			if (headers != null && headers.contains(BOOLEAN_TRUE)) {

				return new ResponseEntity<>(objects, httpHeaders, HttpStatus.PARTIAL_CONTENT);
			}
		}

		return new ResponseEntity<>(objects, httpHeaders, HttpStatus.OK);
	}

	/**
	 * Create response as List with Pagination using directly a Page object.
	 *
	 * @param source Page object containing the required numbers to build the headers and the data to build the
	 *            response.
	 * @return {@link ResponseEntity}
	 */
	public ResponseEntity<List<T>> buildResponseAsListWithPagination(Page<T> source) {

		final long totalCount = source.getTotalElements();
		final int pageNum = source.getNumber();
		final int pageLimit = source.getPageable().getPageSize();
		final List<T> objects = source.get().collect(Collectors.toList());

		return buildResponseAsListWithPagination(totalCount, pageNum, pageLimit, objects);
	}

	/**
	 * Get http headers
	 *
	 * @param totalCount totalCount
	 * @param pageNum pageNum
	 * @param pageLimit pageLimit
	 * @param objects objects
	 * @return httpHeaders
	 */
	protected HttpHeaders getHttpHeaders(final long totalCount, final int pageNum, final int pageLimit,
			final List<T> objects) {

		if (CollectionUtils.isEmpty(objects)) {
			return createHttpHeaderForPagination(totalCount, pageNum, pageLimit, 0);
		}

		return createHttpHeaderForPagination(totalCount, pageNum, pageLimit, objects.size());
	}

	/**
	 * Generate HTTP header with pagination details.
	 *
	 * @param totalCount total records
	 * @param pageNum page number
	 * @param pageLimit page limit
	 * @param resultSize resultSize
	 * @return {@link HttpHeaders}
	 */
	public HttpHeaders createHttpHeaderForPagination(final Long totalCount, final Integer pageNum,
			final Integer pageLimit, final Integer resultSize) {

		final HttpHeaders headerInfo = new HttpHeaders();

		final Long results = totalCount - (pageNum.longValue() + 1) * pageLimit.longValue();

		headerInfo.add(X_PAGINATION_LIMIT, String.valueOf(resultSize));
		headerInfo.add(X_PAGINATION_TOTAL_RECORDS, String.valueOf(totalCount));
		headerInfo.add(X_PAGINATION_TOTAL_PAGES,
				String.valueOf((int) Math.ceil((double) totalCount / (double) pageLimit)));
		headerInfo.add(X_PAGINATION_CURRENT_PAGE_NUM, String.valueOf(pageNum));
		if (results > 0 && resultSize.equals(pageLimit)) {
			headerInfo.add(X_PAGINATION_NEXT_PAGE_NUM, String.valueOf(pageNum + 1));
			headerInfo.add(X_PAGINATION_HAS_NEXT_PAGE, String.valueOf(true));
		} else {
			headerInfo.add(X_PAGINATION_NEXT_PAGE_NUM, String.valueOf(NO_MORE_PAGES));
			headerInfo.add(X_PAGINATION_HAS_NEXT_PAGE, String.valueOf(false));

		}
		return headerInfo;
	}

	/**
	 * Validate Status for PTA
	 *
	 * @param updatedStatus updatedStatus
	 * @param originalStatus originalStatus
	 */

	/**
	 * If the status promotion is not from active to draft returns true so that the we can update the deactivated_at for
	 * the previous record.
	 *
	 * @param originalStatus originalStatus
	 * @param updatedStatus updatedStatus
	 * @return boolean
	 */
	public boolean isNotActiveToDraftPromotion(final Integer originalStatus, final Integer updatedStatus) {

		return !isInvalidStatusUpdateForNonPTA(updatedStatus, originalStatus);
	}

	/**
	 * Validate Status for Non-PTA
	 *
	 * @param updatedStatus updatedStatus
	 * @param originalStatus originalStatus
	 */
	public void validateStatusNonPTA(final Integer updatedStatus, final Integer originalStatus) {

		if (isInvalidStatusUpdate(updatedStatus, originalStatus)
				|| isInvalidStatusUpdateForNonPTA(updatedStatus, originalStatus)) {

			final Error error = new Error();
			addError(error, STATUS, ValidationMessages.STATUS_CANNOT_BE_UPDATED, null);
			handleException(error);
		}

	}

	private boolean isInvalidStatusUpdateForNonPTA(final Integer updatedStatus, final Integer originalStatus) {

		return originalStatus.equals(StatusType.ACTIVE.key()) && updatedStatus.equals(StatusType.DRAFT.key());
	}

	/**
	 * This method checks against invalid statuses for the original record and invalid status transitions from the
	 * original --> updated status
	 *
	 * @param updatedStatus updatedStatus
	 * @param originalStatus originalStatus
	 * @return boolean
	 */
	private boolean isInvalidStatusUpdate(final Integer updatedStatus, final Integer originalStatus) {

		return StatusType.INACTIVE.key().equals(originalStatus) || StatusType.DELETED.key().equals(originalStatus)
				|| originalStatus.equals(StatusType.DRAFT.key()) && updatedStatus.equals(StatusType.INACTIVE.key())
				|| originalStatus.equals(StatusType.ACTIVE.key()) && updatedStatus.equals(StatusType.DELETED.key())
				|| originalStatus.equals(StatusType.ACTIVE.key()) && updatedStatus.equals(StatusType.ACTIVE.key());
	}

	/**
	 * Validate entity to be updated. If the deactivated_at for the record is not set to forever date than raise an
	 * exception as its an invalid record which is already deleted or in activated.
	 *
	 * @param deactivatedAt deactivatedAt
	 * @param field field
	 * @param errorMessage errorMessage
	 * @param rejectedValue rejectedValue
	 */
	public void checkEntityNotDeactivated(final OffsetDateTime deactivatedAt, final String field,
			final String errorMessage, final String rejectedValue) {

		if (deactivatedAt != null && !deactivatedAt.equals(DateConfigurationUtil.foreverOffsetDateTime())) {
			final Error error = new Error();
			addError(error, field, errorMessage, rejectedValue);
			handleException(error);
		}
	}

	/**
	 * Validate and get the client id from the request stored in the interceptor.
	 *
	 * @return pbmId
	 */
	public Integer getClientIdForRequest() {

		final ServletRequestAttributes requestAttributes = (ServletRequestAttributes) RequestContextHolder
				.currentRequestAttributes();
		final HttpServletRequest request = requestAttributes.getRequest();
		if (!StringUtils.isNumeric(request.getHeader(InterceptorConstants.CLIENT_ID))) {
			final Error error = new Error();
			addError(error, InterceptorConstants.CLIENT_ID, ValidationMessages.INVALID_CLIENT_ID, StringUtils.EMPTY);
			handleException(error);
		}
		return Integer.valueOf(request.getHeader(InterceptorConstants.CLIENT_ID));
	}

	/**
	 * Validate and get the user id from the request stored in the interceptor.
	 *
	 * @return userId
	 */
	public Long getUserIdForRequest() {

		final ServletRequestAttributes requestAttributes = (ServletRequestAttributes) RequestContextHolder
				.currentRequestAttributes();
		final HttpServletRequest request = requestAttributes.getRequest();
		final Long userId = (Long) request.getAttribute(InterceptorConstants.USER_ID);
		if (userId == null) {
			final Error error = new Error();
			addError(error, InterceptorConstants.USER_ID, ValidationMessages.INVALID_USER_ID, null);
			handleException(error);
		}

		return userId;
	}

	public Integer getClientIdForTheCurrentRequest() {

		final ServletRequestAttributes requestAttributes = (ServletRequestAttributes) RequestContextHolder
				.currentRequestAttributes();
		final HttpServletRequest request = requestAttributes.getRequest();
		if (StringUtils.isNumeric(request.getHeader(InterceptorConstants.CLIENT_ID))) {
            return Integer.valueOf(request.getHeader(InterceptorConstants.CLIENT_ID));
		}
        return null;

	}

}
