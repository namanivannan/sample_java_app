package com.r1vs.platform.rox.common;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.data.domain.AuditorAware;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

import java.util.Optional;

@SpringBootApplication
@EnableJpaAuditing(auditorAwareRef = "auditorProvider")
public class SpringBootTestApp {

    /**
     * Provides a valid value for @CreatedBy and @UpdatedBy annotations
     *
     * @return Optional of 11L indicating the ID of the User we have in seed data for testing.
     */
    @Bean
    public AuditorAware<Long> auditorProvider() {

        return () -> Optional.ofNullable(Long.valueOf(11L));
    }
}
