package com.r1vs.platform.rox.api.service;

import com.r1vs.platform.rox.api.RoxApiConfiguration;
import com.r1vs.platform.rox.api.model.application.initiate.IdentificationDTO;
import com.r1vs.platform.rox.common.model.business.Identification;
import org.junit.Before;
import org.junit.Test;
import org.modelmapper.ModelMapper;
import org.springframework.test.util.ReflectionTestUtils;

import static org.assertj.core.api.Assertions.assertThat;

public class MapperServiceTest {

    ModelMapper modelMapper;

    @Before
    public void initialize() {

        RoxApiConfiguration roxApiConfiguration = new RoxApiConfiguration();
        MapperService mapperService = new MapperService();
        modelMapper = roxApiConfiguration.nonNullModelMapper();

        // Using reflection as "configureMappingRules(ModelMapper m)" is private.
        ReflectionTestUtils.invokeMethod(mapperService, "configureMappingRules", modelMapper);

        // Using reflection as this constant is private.
        ReflectionTestUtils.setField(mapperService, "IDENTIFICATION_SHOWN_CHARACTERS", 3);

        //modelMapper.validate();
    }

    @Test
    public void givenIdentificationObject_whenMappingToDto_thenItCensorsIdentificationData() {
        Identification identification = new Identification();
        identification.setId(1234L);
        identification.setIdentification("123456789");

        IdentificationDTO map = modelMapper.map(identification, IdentificationDTO.class);

        assertThat(map.getIdentification()).isEqualTo("******789");

    }


}