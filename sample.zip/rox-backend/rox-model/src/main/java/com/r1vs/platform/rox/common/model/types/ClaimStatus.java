package com.r1vs.platform.rox.common.model.types;

import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

public enum ClaimStatus {

	REJECTION(0, "Rejected"),
	PAID(1, "Paid"),
	REVERSAL(2, "Reversal"),
	DENIED(3, "Denied"),
	DUPLICATE_OF_APPROVED(4,
			"Duplicate of Approved");

	private final Integer key;

	private final String value;

	ClaimStatus(final Integer key, final String value) {

		this.value = value;
		this.key = key;
	}

	public Integer key() {

		return this.key;
	}

	public String value() {

		return this.value;
	}

	public static Map<Integer, String> getStatusMap() {

		return Arrays.stream(ClaimStatus.values()).collect(Collectors.toMap(ClaimStatus::key, ClaimStatus::value));

	}
}
