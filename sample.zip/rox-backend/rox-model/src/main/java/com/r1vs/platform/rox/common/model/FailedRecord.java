package com.r1vs.platform.rox.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.hibernate.annotations.CreationTimestamp;

@Entity
@Table(name = "failed_records")
public class FailedRecord implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "failed_record_id", nullable = false)
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer failedRecordId;

	@CreationTimestamp
	@Column(name = "created_at")
	private Date createdAt;

	@Column(name = "job_type")
	@Size(max = 100)
	@NotNull
	private String jobType;

	@Column(name = "filename")
	@Size(max = 255)
	private String filename;

	@Column(name = "line_number")
	private Integer lineNumber;

	@Column(name = "class_name")
	@Size(max = 255)
	@NotNull
	private String className;

	@Column(name = "message")
	@Size(max = 512)
	@NotNull
	private String message;

	@Column(name = "payload")
	@NotNull
	private String payload;

	public Integer getFailedRecordId() {

		return this.failedRecordId;
	}

	public void setFailedRecordId(final Integer failedRecordId) {

		this.failedRecordId = failedRecordId;
	}

	public String getJobType() {

		return this.jobType;
	}

	public void setJobType(final String jobType) {

		this.jobType = jobType;
	}

	public String getFilename() {

		return this.filename;
	}

	public void setFilename(final String filename) {

		this.filename = filename;
	}

	public Integer getLineNumber() {

		return this.lineNumber;
	}

	public void setLineNumber(final Integer i) {

		this.lineNumber = i;
	}

	public String getClassName() {

		return this.className;
	}

	public void setClassName(final String className) {

		this.className = className;
	}

	public String getMessage() {

		return this.message;
	}

	public void setMessage(final String message) {

		this.message = message;
	}

	public String getPayload() {

		return this.payload;
	}

	public void setPayload(final String payload) {

		this.payload = payload;
	}

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof FailedRecord)) {
			return false;
		}
		final FailedRecord castOther = (FailedRecord) other;
		return new EqualsBuilder().append(failedRecordId, castOther.failedRecordId)
				.append(createdAt, castOther.createdAt).append(jobType, castOther.jobType)
				.append(filename, castOther.filename).append(lineNumber, castOther.lineNumber)
				.append(className, castOther.className).append(message, castOther.message)
				.append(payload, castOther.payload).isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(failedRecordId).append(createdAt).append(jobType).append(filename)
				.append(lineNumber).append(className).append(message).append(payload).toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("failedRecordId", failedRecordId).append("createdAt", createdAt)
				.append("jobType", jobType).append("filename", filename).append("lineNumber", lineNumber)
				.append("className", className).append("message", message).append("payload", payload).toString();
	}
}
