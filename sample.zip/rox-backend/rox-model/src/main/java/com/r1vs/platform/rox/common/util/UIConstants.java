package com.r1vs.platform.rox.common.util;

import static com.r1vs.platform.rox.common.model.metadatacategories.MetadataCategoryConstants.*;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class UIConstants {

	public static final String KEY_VALUE_DELIMITER = " - ";

	// Represents the Metadata categories we don't want to show on the UI
	public static final Set<Integer> DISALLOWED_METADATA_CATEGORY_IDS = Collections.unmodifiableSet(new HashSet<>(
			Arrays.asList(FORMULARY_OPEN_FLAG_TYPE_ID, FORMULARY_CLOSED_FLAG_TYPE_ID, PREFERRED_DRUG_FLAG_TYPE_ID,
					PRIOR_AUTHORIZATION_FLAG_TYPE_ID, POS_REBATE_COVERAGE_FLAG_TYPE_ID, BRAND_CLASS_EDIT_CATEGORY_ID,
					BENEFIT_COVERAGE_FLAG_TYPE_ID)));
}
