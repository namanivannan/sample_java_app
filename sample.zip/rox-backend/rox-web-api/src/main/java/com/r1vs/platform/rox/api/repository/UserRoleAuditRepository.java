package com.r1vs.platform.rox.api.repository;

import com.r1vs.platform.rox.common.model.users.UserRoleAudit;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRoleAuditRepository extends JpaRepository<UserRoleAudit, Long> {

}
