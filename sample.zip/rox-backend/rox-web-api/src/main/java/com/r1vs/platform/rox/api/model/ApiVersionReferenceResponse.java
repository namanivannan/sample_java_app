package com.r1vs.platform.rox.api.model;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

public class ApiVersionReferenceResponse {

	private String version;

	public String getVersion() {

		return version;
	}

	public void setVersion(final String version) {

		this.version = version;
	}

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof ApiVersionReferenceResponse)) {
			return false;
		}
		final ApiVersionReferenceResponse castOther = (ApiVersionReferenceResponse) other;
		return new EqualsBuilder().append(version, castOther.version).isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(version).toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("version", version).toString();
	}

}
