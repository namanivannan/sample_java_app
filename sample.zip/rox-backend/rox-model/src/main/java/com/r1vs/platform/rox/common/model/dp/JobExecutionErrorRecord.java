package com.r1vs.platform.rox.common.model.dp;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.r1vs.platform.rox.common.model.AuditedEntity;

@Entity
@Table(name = "dp_job_execution_error_record")
public class JobExecutionErrorRecord extends AuditedEntity implements Serializable {

	private static final long serialVersionUID = 2628233015010123904L;

	@Id
	@Column(name = "id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(name = "job_execution_id")
	private Integer jobExecutionId;

	@Column(name = "input_id")
	private Integer inputId;

	@Column(name = "pbm_id")
	private Integer pbmId;

	@Column(name = "file_uuid")
	private String fileUUID;

	@Column(name = "file_name")
	private String fileName;

	@Column(name = "line_number")
	private Integer lineNumber;

	@Column(name = "record_text")
	private String recordText;

	@Column(name = "job_type")
	private String jobType;

	@Column(name = "error_class")
	private String errorClass;

	@Column(name = "error_stack")
	private String errorStack;

	@Column(name = "primary_error_code")
	private String primaryErrorCode;

	@Column(name = "primary_error_message")
	private String primaryErrorMessage;

	@Column(name = "detail_errors")
	private String detailErrors;

	public Integer getId() {

		return id;
	}

	public void setId(final Integer id) {

		this.id = id;
	}

	public Integer getJobExecutionId() {

		return jobExecutionId;
	}

	public void setJobExecutionId(final Integer jobExecutionId) {

		this.jobExecutionId = jobExecutionId;
	}

	public Integer getInputId() {

		return inputId;
	}

	public void setInputId(final Integer inputId) {

		this.inputId = inputId;
	}

	public Integer getPbmId() {

		return pbmId;
	}

	public void setPbmId(final Integer pbmId) {

		this.pbmId = pbmId;
	}

	public String getFileUUID() {

		return fileUUID;
	}

	public void setFileUUID(final String fileUUID) {

		this.fileUUID = fileUUID;
	}

	public String getFileName() {

		return fileName;
	}

	public void setFileName(final String fileName) {

		this.fileName = fileName;
	}

	public Integer getLineNumber() {

		return lineNumber;
	}

	public void setLineNumber(final Integer lineNumber) {

		this.lineNumber = lineNumber;
	}

	public String getRecordText() {

		return recordText;
	}

	public void setRecordText(final String recordText) {

		this.recordText = recordText;
	}

	public String getJobType() {

		return jobType;
	}

	public void setJobType(final String jobType) {

		this.jobType = jobType;
	}

	public String getErrorClass() {

		return errorClass;
	}

	public void setErrorClass(final String errorClass) {

		this.errorClass = errorClass;
	}

	public String getPrimaryErrorCode() {

		return primaryErrorCode;
	}

	public void setPrimaryErrorCode(final String primaryErrorCode) {

		this.primaryErrorCode = primaryErrorCode;
	}

	public String getPrimaryErrorMessage() {

		return primaryErrorMessage;
	}

	public void setPrimaryErrorMessage(final String primaryErrorMessage) {

		this.primaryErrorMessage = primaryErrorMessage;
	}

	public String getDetailErrors() {

		return detailErrors;
	}

	public void setDetailErrors(final String detailErrors) {

		this.detailErrors = detailErrors;
	}

	public String getErrorStack() {

		return errorStack;
	}

	public void setErrorStack(final String errorStack) {

		this.errorStack = errorStack;
	}

}
