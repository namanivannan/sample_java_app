package com.r1vs.platform.rox.api.controller;

import com.r1vs.platform.rox.api.model.application.initiate.BusinessDTO;
import com.r1vs.platform.rox.api.model.application.initiate.UpdateBusinessDTO;
import com.r1vs.platform.rox.api.service.BusinessService;
import com.r1vs.platform.rox.common.model.business.BusinessCategory;
import com.r1vs.platform.rox.common.model.business.BusinessType;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.UUID;

import static com.r1vs.platform.rox.api.util.InterceptorConstants.CLIENT_ID;

@CrossOrigin
@RestController
@RequestMapping(value = "/v1", produces = { MediaType.APPLICATION_JSON_VALUE })
@Tag(name = "Business",
		description = "Business Controller provides operations to create, update and delete Business related " +
				"to an Application")

public class BusinessController {

	@Autowired
	private BusinessService businessService;

	private static final Logger LOGGER = LoggerFactory.getLogger(BusinessController.class);

	@PatchMapping("/applications/{applicationId}/business")
	@Operation(summary = "Modifies certain information of a Business")
	public ResponseEntity<BusinessDTO> updateBusiness(@RequestHeader(CLIENT_ID) String clientId,
			@PathVariable UUID applicationId,
			@Valid @RequestBody UpdateBusinessDTO updateBusinessDTO) {

		return new ResponseEntity<>(
				businessService.updateBusiness(clientId, applicationId, updateBusinessDTO, BusinessCategory.BUSINESS),
				HttpStatus.OK);
	}

}
