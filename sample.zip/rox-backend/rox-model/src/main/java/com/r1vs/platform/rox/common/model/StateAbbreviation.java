package com.r1vs.platform.rox.common.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@Entity
@Table(name = "state_abbreviation")
public class StateAbbreviation implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "id", nullable = false)
	private Integer id;

	@Column(name = "state_abbreviation", nullable = false)
	private String stateAbbreviation;

	@Column(name = "state", nullable = false)
	private String state;

	public Integer getId() {

		return id;
	}

	public void setId(final Integer id) {

		this.id = id;
	}

	public String getStateAbbreviation() {

		return stateAbbreviation;
	}

	public void setStateAbbreviation(final String stateAbbreviation) {

		this.stateAbbreviation = stateAbbreviation;
	}

	public String getState() {

		return state;
	}

	public void setState(final String state) {

		this.state = state;
	}

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof StateAbbreviation)) {
			return false;
		}
		final StateAbbreviation castOther = (StateAbbreviation) other;
		return new EqualsBuilder().append(id, castOther.id).append(stateAbbreviation, castOther.stateAbbreviation)
				.append(state, castOther.state).isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(id).append(stateAbbreviation).append(state).toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("id", id).append("stateAbbreviation", stateAbbreviation)
				.append("state", state).toString();
	}

}
