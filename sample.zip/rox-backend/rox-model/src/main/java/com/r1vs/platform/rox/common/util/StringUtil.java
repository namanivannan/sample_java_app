package com.r1vs.platform.rox.common.util;

import java.util.regex.Pattern;

public final class StringUtil {

	// Regex representing a 5 digit zip code or a 9 digit zip (5 base + 4 extension)
	private static final Pattern ZIP_CODE = Pattern.compile("^\\d{5}(\\d{4})?$");

	private StringUtil() {

		throw new IllegalStateException("Utility class");
	}

	public static boolean isNotNullOrEmpty(final String input) {

		return input != null && !input.isEmpty();
	}

	public static boolean isNotNullOrEmpty(final Character input) {

		return input != null;
	}

	public static boolean isNullOrEmpty(final String input) {

		return input == null || input.isEmpty();
	}

	public static boolean isZipCode(final String input) {

		return ZIP_CODE.matcher(input).matches();
	}

	public static boolean equal(final String str1, final String str2) {

		return str1 == null ? str2 == null : str1.equals(str2);
	}

	/**
	 * Used to postfix a field.
	 * 
	 * If the field is 'someArray' and the index is 0, this method will return 'someArray[0]'.
	 * 
	 * @param field
	 * @param index
	 * @return
	 */
	public static String postFixField(String field, int index) {

		return String.join("", field, "[", String.valueOf(index), "]");
	}

	/**
	 * Used to prefix a field.
	 * 
	 * If a prefix is 'someArray[0]' and the field is 'someAttribute', this method will return
	 * 'someArray[0].someAttribute'.
	 * 
	 * @param prefix
	 * @param field
	 * @return
	 */
	public static String prefixField(String prefix, String field) {

		return String.join("", prefix, ".", field);
	}

}
