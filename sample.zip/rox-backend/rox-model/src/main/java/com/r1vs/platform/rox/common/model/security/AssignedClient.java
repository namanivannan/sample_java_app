package com.r1vs.platform.rox.common.model.security;

import java.io.Serializable;
import java.util.Objects;

/**
 * This represents a client in the system. Normally it is assigned to a user as an association in the user_client table.
 */
public class AssignedClient implements Serializable {

	private static final long serialVersionUID = 155875799252196168L;

	private int clientId;

	private String clientName;

	public AssignedClient() {

		super();
	}

	public AssignedClient(final int clientId, final String clientName) {

		super();
		this.clientId = clientId;
		this.clientName = clientName;
	}

	public int getClientId() {

		return clientId;
	}

	public void setClientId(final int clientId) {

		this.clientId = clientId;
	}

	public String getClientName() {

		return clientName;
	}

	public void setClientName(final String clientName) {

		this.clientName = clientName;
	}

	@Override
	public int hashCode() {

		return Objects.hash(clientId);
	}

	@Override
	public boolean equals(final Object obj) {

		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final AssignedClient other = (AssignedClient) obj;
		return clientId == other.clientId;
	}

	@Override
	public String toString() {

		return "AssignedClient [clientId=" + clientId + ", clientName=" + clientName + "]";
	}

}
