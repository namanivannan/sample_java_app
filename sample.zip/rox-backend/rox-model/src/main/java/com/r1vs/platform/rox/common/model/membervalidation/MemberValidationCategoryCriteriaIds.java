package com.r1vs.platform.rox.common.model.membervalidation;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.io.Serializable;
import java.util.List;

public class MemberValidationCategoryCriteriaIds implements Serializable {

	private static final long serialVersionUID = -2025902691195709607L;

	private List<Long> memberIdentificationCriteriaIds;

	private List<Long> memberClarificationCriteriaIds;

	private List<Long> memberAuthenticationCriteriaIds;

	public List<Long> getMemberIdentificationCriteriaIds() {

		return memberIdentificationCriteriaIds;
	}

	public void setMemberIdentificationCriteriaIds(final List<Long> memberIdentificationCriteriaIds) {

		this.memberIdentificationCriteriaIds = memberIdentificationCriteriaIds;
	}

	public List<Long> getMemberClarificationCriteriaIds() {

		return memberClarificationCriteriaIds;
	}

	public void setMemberClarificationCriteriaIds(final List<Long> memberClarificationCriteriaIds) {

		this.memberClarificationCriteriaIds = memberClarificationCriteriaIds;
	}

	public List<Long> getMemberAuthenticationCriteriaIds() {

		return memberAuthenticationCriteriaIds;
	}

	public void setMemberAuthenticationCriteriaIds(final List<Long> memberAuthenticationCriteriaIds) {

		this.memberAuthenticationCriteriaIds = memberAuthenticationCriteriaIds;
	}

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof MemberValidationCategoryCriteriaIds)) {
			return false;
		}
		final MemberValidationCategoryCriteriaIds castOther = (MemberValidationCategoryCriteriaIds) other;
		return new EqualsBuilder().append(memberIdentificationCriteriaIds, castOther.memberIdentificationCriteriaIds)
				.append(memberClarificationCriteriaIds, castOther.memberClarificationCriteriaIds)
				.append(memberAuthenticationCriteriaIds, castOther.memberAuthenticationCriteriaIds).isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(memberIdentificationCriteriaIds).append(memberClarificationCriteriaIds)
				.append(memberAuthenticationCriteriaIds).toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("memberIdentificationCriteriaIds", memberIdentificationCriteriaIds)
				.append("memberClarificationCriteriaIds", memberClarificationCriteriaIds)
				.append("memberAuthenticationCriteriaIds", memberAuthenticationCriteriaIds).toString();
	}

}
