package com.r1vs.platform.rox.api.business;

import com.r1vs.platform.rox.api.model.admin.RoleSearchRequestDTO;
import com.r1vs.platform.rox.api.repository.RoleRepository;
import com.r1vs.platform.rox.common.model.users.Role;
import com.r1vs.platform.rox.common.model.users.Role_;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;

import static java.util.Objects.nonNull;

@Component
public class RoleService {

	@Autowired
	private RoleRepository roleRepository;

	/**
	 * Find a list of the roles based on the incoming role ids.
	 *
	 * @param roleIds
	 * @return
	 */
	public List<Role> findByRoleIdIn(final List<Integer> roleIds) {

		return roleRepository.findByRoleIdIn(roleIds);
	}

	/**
	 * Find a list of the roles based on the incoming role name.
	 *
	 * @param roleNames
	 * @return
	 */
	public List<Role> findByRoleName(final List<String> roleNames) {

		return roleRepository.findByRoleNames(roleNames);
	}

	/**
	 * Get Role by RoleId
	 *
	 * @param roleId the role id
	 * @return the Role object
	 */
	public Role getRoleByRoleId(final Integer roleId) {

		return roleRepository.findByRoleId(roleId);
	}

	public Role save(final Role role) {

		return roleRepository.save(role);
	}

	public Page<Role> getAllWithPagination(RoleSearchRequestDTO searchRequest, final Pageable pageable) {
        Specification<Role> specification = getRoleSpecification(searchRequest);
		return roleRepository.findAll(specification,pageable);
	}

	private Specification<Role> getRoleSpecification(RoleSearchRequestDTO searchRequest) {

		return new Specification<Role>() {

			public Predicate toPredicate(final Root<Role> root, final CriteriaQuery<?> query,
					final CriteriaBuilder cb) {

				final List<Predicate> predicateList = new ArrayList();
                /* exclude rox admin role by default from the list */
                predicateList.add(cb.greaterThan(root.get(Role_.roleId), 1));

                if (nonNull(searchRequest)) {
                    if (nonNull(searchRequest.getRoleId())) {
                        predicateList.add(cb.equal(root.get(Role_.roleId), searchRequest.getRoleId()));
                    }
                    if (nonNull(searchRequest.getRoleName())) {
                        predicateList.add(cb.like(root.get(Role_.NAME), "%" + searchRequest.getRoleName() + "%"));
                    }
                    if (nonNull(searchRequest.getStatus())) {
                        predicateList.add(cb.equal(root.get(Role_.statusId), searchRequest.getStatus()));
                    }
                }
				query.orderBy(cb.desc(root.get(Role_.UPDATED_AT)));

				if (!predicateList.isEmpty()) {
					return cb.and(predicateList.toArray(new Predicate[predicateList.size()]));
				}
				return null;
			}
		};
	}

	public List<Role> findBySystemName(final String roleSystemName) {

		return roleRepository.findBySystemName(roleSystemName);
	}

	public void remove(final Role role) {

		roleRepository.delete(role);
	}
}
