package com.r1vs.platform.rox.api.validator.role;

import com.r1vs.platform.rox.api.exception.Error;
import com.r1vs.platform.rox.api.model.role.CreateRoleRequest;
import com.r1vs.platform.rox.api.validator.RoxWriteWebApiValidator;
import org.springframework.stereotype.Component;

import static com.r1vs.platform.rox.api.util.ValidationUtil.handleException;

@Component
public class CreateRoleValidator extends RoleRequestValidator
		implements RoxWriteWebApiValidator<CreateRoleRequest> {

	@Override
	public void validate(final CreateRoleRequest roleRequest) {

		final Error error = new Error();

		validateRoleName(error, roleRequest);

		validateRoleSystemName(error, roleRequest);

		validateStatusCode(error, roleRequest.getStatusId());

		validateStatusFlowForCreate(error, roleRequest.getStatusId());

		validateAccessType(error, roleRequest);

		handleException(error);
	}

}
