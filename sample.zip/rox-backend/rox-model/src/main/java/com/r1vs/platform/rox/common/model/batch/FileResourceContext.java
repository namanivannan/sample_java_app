package com.r1vs.platform.rox.common.model.batch;

import java.io.Serializable;
import java.util.Objects;

import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * Batch framework will provide domain models to support recording of the file meta information.
 *
 */
public class FileResourceContext implements Serializable {

	private static final long serialVersionUID = -7741061422919176030L;

	private String jobExecutionId;

	private String dataInputId;

	private String pbmId;

	private String fileUUID;

	private String filePath;

	private String fileName;

	public String getJobExecutionId() {

		return jobExecutionId;
	}

	public void setJobExecutionId(final String jobExecutionId) {

		this.jobExecutionId = jobExecutionId;
	}

	public String getDataInputId() {

		return dataInputId;
	}

	public void setDataInputId(final String dataInputId) {

		this.dataInputId = dataInputId;
	}

	public String getPbmId() {

		return pbmId;
	}

	public void setPbmId(final String pbmId) {

		this.pbmId = pbmId;
	}

	public String getFileUUID() {

		return fileUUID;
	}

	public void setFileUUID(final String fileUUID) {

		this.fileUUID = fileUUID;
	}

	public String getFilePath() {

		return filePath;
	}

	public void setFilePath(final String filePath) {

		this.filePath = filePath;
	}

	public String getFileName() {

		return fileName;
	}

	public void setFileName(final String fileName) {

		this.fileName = fileName;
	}

	@Override
	public int hashCode() {

		return Objects.hash(dataInputId, fileName, filePath, fileUUID, jobExecutionId, pbmId);
	}

	@Override
	public boolean equals(final Object obj) {

		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final FileResourceContext other = (FileResourceContext) obj;
		return Objects.equals(dataInputId, other.dataInputId) && Objects.equals(fileName, other.fileName)
				&& Objects.equals(filePath, other.filePath) && Objects.equals(fileUUID, other.fileUUID)
				&& Objects.equals(jobExecutionId, other.jobExecutionId) && Objects.equals(pbmId, other.pbmId);
	}

	@Override
	public String toString() {

		final ToStringBuilder builder = new ToStringBuilder(this);
		if (jobExecutionId != null) {
			builder.append("jobExecutionId", jobExecutionId);
		}
		if (dataInputId != null) {
			builder.append("dataInputId", dataInputId);
		}
		if (pbmId != null) {
			builder.append("pbmId", pbmId);
		}
		if (fileUUID != null) {
			builder.append("fileUUID", fileUUID);
		}
		if (filePath != null) {
			builder.append("filePath", filePath);
		}
		if (fileName != null) {
			builder.append("fileName", fileName);
		}
		return builder.toString();
	}
}
