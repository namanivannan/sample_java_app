package com.r1vs.platform.rox.common.model.types;

import java.util.HashMap;
import java.util.Map;

import com.r1vs.platform.rox.common.util.UIConstants;

public enum ContactType {

	GENERAL("00", "General/Other"),
	ACCOUNT_MANAGEMENT("01", "Account Management"),
	ACCOUNTING("02",
			"Accounting"),
	AUDIT("03", "Audit"),
	AUTHORIZED_OFFICIAL("04",
			"Authorized Official"),
	NON_AUTHORIZED_OFFICIAL("05", "Non-Authorized Official"),
	BILLING("06",
			"Billing"),
	CLINICIAN("07", "Clinician"),
	CONTRACTING("08", "Contracting"),
	DATA_MANAGEMENT(
			"09", "Data Management"),
	ELIGIBILITY("10", "Eligibility"),
	EXECUTIVE("11",
			"Executive"),
	FINANCE("12", "Finance"),
	HUMAN_RESOURCES("13",
			"Human Resources"),
	LEGAL("14", "Legal"),
	PHARMACIST_INCHARGE("15",
			"Pharmacist-in-Charge"),
	PRIMARY("16",
			"Primary"),
	SECONDARY("17", "Secondary"),
	TECHNICAL(
			"18", "Technical"),
	SALES("19",
			"Sales"),
	MAILING_ADDRESS("20",
			"Mailing Address"),
	OPERATIONAL(
			"21",
			"Operational");

	private final String key;

	private final String value;

	ContactType(final String key, final String value) {

		this.key = key;
		this.value = value;
	}

	public String key() {

		return this.key;
	}

	public String value() {

		return this.value;
	}

	public static Map<String, String> getContactTypeMap() {

		final Map<String, String> codeMap = new HashMap<>();

		for (final ContactType type : ContactType.values()) {
			codeMap.put(type.key(), type.key() + UIConstants.KEY_VALUE_DELIMITER + type.value());
		}

		return codeMap;
	}

}
