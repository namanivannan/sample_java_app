package com.r1vs.platform.rox.common.model.types;

/*
 * This class holds references CodeType entities
 */
public final class SystemCodeType {

	public static final Integer NCPDP_VERSION_RELEASE_TYPE_ID = 1;

	public static final Integer NCPDP_TRANSACTION_CODE_TYPE_ID = 2;

	public static final Integer SERVICE_PROVIDER_ID_QUALIFIER_TYPE_ID = 3;

	public static final Integer SERVICE_PRODUCT_ID_QUALIFIER_TYPE_ID = 4;

	public static final Integer PRESCRIBER_ID_QUALIFIER_TYPE_ID = 5;

	public static final Integer CLAIM_SUBMISSION_METHOD_TYPE_ID = 6;

	private SystemCodeType() {

	}

}
