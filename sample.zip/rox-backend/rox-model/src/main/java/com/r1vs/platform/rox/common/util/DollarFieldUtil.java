package com.r1vs.platform.rox.common.util;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class DollarFieldUtil {

	private static final Logger LOGGER = LoggerFactory.getLogger(DollarFieldUtil.class);

	private static final Integer DECIMAL_PLACES = 2;

	private static final BigDecimal ONE_HUNDRED = new BigDecimal("100");

	private static final BigDecimal ONE_MILLION = new BigDecimal("1000000");

	// A-I OR {
	private static final String POSITIVE_VALUE_REGEX = "[A-I\\u007B]";

	// J-R OR }
	private static final String NEGATIVE_VALUE_REGEX = "[J-R\\u007D]";

	// key : value = A-J, {} : 0-9
	private static final Map<String, String> CHARMAP = new HashMap<>();

	// key : value = A-I, { : 0-9
	private static final Map<String, String> POSITIVE_CHARMAP = new HashMap<>();

	// key : value = 0-9 : A-I, {
	private static final Map<String, String> POSITIVE_CHARMAP_REVERSED;

	// key : value = J-R, } : 0-9
	private static final Map<String, String> NEGATIVE_CHARMAP = new HashMap<>();

	// key: value = 0-9 : J-R, }
	private static final Map<String, String> NEGATIVE_CHARMAP_REVERSED;

	private static final String PERIOD = ".";

	private static final String ZERO_OVERPUNCH_CONVERSION = "00{";

	static {

		// POSITIVE VALUES
		POSITIVE_CHARMAP.put("{", "0"); // positive
		POSITIVE_CHARMAP.put("A", "1");
		POSITIVE_CHARMAP.put("B", "2");
		POSITIVE_CHARMAP.put("C", "3");

		POSITIVE_CHARMAP.put("D", "4");
		POSITIVE_CHARMAP.put("E", "5");
		POSITIVE_CHARMAP.put("F", "6");

		POSITIVE_CHARMAP.put("G", "7");
		POSITIVE_CHARMAP.put("H", "8");
		POSITIVE_CHARMAP.put("I", "9");

		POSITIVE_CHARMAP_REVERSED = POSITIVE_CHARMAP.entrySet().stream()
				.collect(Collectors.toMap(Map.Entry::getValue, Map.Entry::getKey));

		// NEGATIVE VALUES
		NEGATIVE_CHARMAP.put("}", "0"); // negative
		NEGATIVE_CHARMAP.put("J", "1");
		NEGATIVE_CHARMAP.put("K", "2");
		NEGATIVE_CHARMAP.put("L", "3");

		NEGATIVE_CHARMAP.put("M", "4");
		NEGATIVE_CHARMAP.put("N", "5");
		NEGATIVE_CHARMAP.put("O", "6");

		NEGATIVE_CHARMAP.put("P", "7");
		NEGATIVE_CHARMAP.put("Q", "8");
		NEGATIVE_CHARMAP.put("R", "9");

		NEGATIVE_CHARMAP_REVERSED = NEGATIVE_CHARMAP.entrySet().stream()
				.collect(Collectors.toMap(Map.Entry::getValue, Map.Entry::getKey));

		CHARMAP.putAll(POSITIVE_CHARMAP);
		CHARMAP.putAll(NEGATIVE_CHARMAP);
	}

	private DollarFieldUtil() {

	}

	/**
	 * Read in an NCPDP / overpunch formatted String and convert it to a BigDecimal format; e.g.: '35A' to 3.51; e.g.:
	 * '35J' to -3.51.
	 *
	 * @param dollar string value to convert from overpunch format to BigDecimal
	 * @return BigDecimal formatted version of dollar parameter
	 */
	public static BigDecimal convertNcpdpDollarToDecimal(final String dollar) {

		return convertNcpdpDollarToDecimal(dollar, null);
	}

	/**
	 * Read in an NCPDP / overpunch formatted String and convert it to a percentage in BigDecimal format; e.g.:
	 * '350000A' to 3.500001;
	 *
	 * @param percentage stringe value to convert from overpunch format to BigDecimal
	 * @return BigDecimal formatted version of percentage parameter
	 */
	public static BigDecimal convertNcpdpPercentageToDecimal(final String percentage) {

		return convertNcpdpDollarToDecimal(percentage, ONE_MILLION);
	}

	/**
	 * Read in an NCPDP / overpunch formatted String and convert it to a BigDecimal format; e.g.: '35A' to 3.51; e.g.:
	 * '35J' to -3.51.
	 *
	 * @param dollar string value to convert from overpunch format to BigDecimal
	 * @param divisor divisor for decimal value
	 * @return BigDecimal formatted version of dollar parameter
	 */
	private static BigDecimal convertNcpdpDollarToDecimal(final String dollar, final BigDecimal divisor) {

		if (StringUtil.isNullOrEmpty(dollar)) {

			return null;

		} else if (dollar.contains(PERIOD)) {

			LOGGER.warn("convertNcpdpDollarToDecimal: cannot convert overpunch with decimals; probably not overpunch.");
			return null;
		}

		BigDecimal result = null;
		String lastCharConverted = null;
		boolean isNegative = false;
		final String lastChar = String.valueOf(dollar.charAt(dollar.length() - 1));

		if (Pattern.matches(POSITIVE_VALUE_REGEX, lastChar)) {
			isNegative = false;
			lastCharConverted = CHARMAP.get(lastChar);

		} else if (Pattern.matches(NEGATIVE_VALUE_REGEX, lastChar)) {
			isNegative = true;
			lastCharConverted = CHARMAP.get(lastChar);
		} else {

			LOGGER.warn(
					"convertNcpdpDollarToDecimal: value: {} does not end in overpunch notation; probably not overpunch.",
					dollar);
		}

		String dollarAmt;

		if (lastCharConverted == null) {
			dollarAmt = dollar;
		} else {
			dollarAmt = dollar.substring(0, dollar.length() - 1).concat(lastCharConverted);
		}

		if (divisor != null) {
			result = new BigDecimal(dollarAmt).divide(divisor);
		} else {
			result = new BigDecimal(dollarAmt).divide(ONE_HUNDRED);
		}

		if (isNegative) {
			result = result.negate();
		}
		return result;
	}

	/**
	 * Read in a BigDecimal and convert it to an NCPDP format (EBCDIC); e.g.: 3.51 to '35A'; e.g.: -3.51 to '35J'
	 *
	 * @param dollar BigDecimal value to convert to overpunch format
	 * @return ncpdp / overpunch formatted string
	 */
	public static String convertDecimalToNcpdpDollar(final BigDecimal dollar) {

		String result = null;

		if (dollar == null) {
			return result;
		} else if (dollar.compareTo(BigDecimal.ZERO) == 0) {
			return ZERO_OVERPUNCH_CONVERSION;
		}

		final String lastCharConverted;

		// multiply by 100, round to 2 decimal places, convert to String
		final BigInteger dollarNoDecimalsBigInteger = dollar.setScale(DECIMAL_PLACES, BigDecimal.ROUND_HALF_UP)
				.multiply(ONE_HUNDRED).toBigInteger();
		final String dollarNoDecimalsString = dollarNoDecimalsBigInteger.toString();

		// get last char as string
		final String lastChar = String.valueOf(dollarNoDecimalsString.charAt(dollarNoDecimalsString.length() - 1));

		// determine if positive or negative; convert final character to A-R, {} value
		if (dollarNoDecimalsBigInteger.equals(BigInteger.ZERO)) {
			result = ZERO_OVERPUNCH_CONVERSION;
		} else if (dollarNoDecimalsBigInteger.compareTo(BigInteger.ZERO) > 0) {
			lastCharConverted = POSITIVE_CHARMAP_REVERSED.get(lastChar);
			result = dollarNoDecimalsString.substring(0, dollarNoDecimalsString.length() - 1).concat(lastCharConverted);
		} else {
			lastCharConverted = NEGATIVE_CHARMAP_REVERSED.get(lastChar);
			result = dollarNoDecimalsString.substring(1, dollarNoDecimalsString.length() - 1).concat(lastCharConverted);
		}

		return result;
	}

	/**
	 * Converts a String dollar value (non-overpunch) into an overpunch String equivalent. e.g.: "3.51" to "35A"; it
	 * handles type juggling between String to BigDecimal to String.
	 *
	 * @param dollar string dollar amount which is NOT in overpunch notation
	 * @return string dollar amount in overpunch notation
	 */
	public static String convertStringToNcpdpDollar(final String dollar) {

		return convertDecimalToNcpdpDollar(new BigDecimal(dollar));
	}

}
