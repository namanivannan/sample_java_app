package com.r1vs.platform.rox.api.controller.admin;

import com.r1vs.platform.rox.api.model.admin.*;
import com.r1vs.platform.rox.api.model.application.initiate.OwnerDTO;
import com.r1vs.platform.rox.api.processor.ClientProcessor;
import com.r1vs.platform.rox.api.service.rule.ClientService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

import java.util.List;
import java.util.UUID;

import static com.r1vs.platform.rox.api.constants.ControllerConstants.*;
import static com.r1vs.platform.rox.api.util.ControllerUtils.getPageableFromHeaderParams;
import static com.r1vs.platform.rox.api.util.InterceptorConstants.CLIENT_ID;

@RestController
@RequestMapping("/v1")
@Tag(name = "Client", description = "Client Service")
public class ClientController {

	private static final Logger LOGGER = LoggerFactory.getLogger(ClientController.class);

	@Autowired
	private ClientService clientService;

	@Autowired
	private ClientProcessor clientProcessor;

	@PostMapping("/clients")
	@Operation(summary = "Creates new Client with Admin user")
	public ResponseEntity<ClientWithUserDTO> createClient(@Valid @RequestBody CreateClientDTO clientDTO) {

		return new ResponseEntity<>(clientService.createClient(clientDTO), HttpStatus.CREATED);
	}

	@GetMapping("/clients")
	@Operation(summary = "Get Clients")
	public ResponseEntity<List<ClientDTO>> getClients(
			@RequestHeader(value = X_PAGINATION_LIMIT, defaultValue = "20") Integer pageLimit,
			@RequestHeader(value = X_PAGINATION_NUM, defaultValue = "0") Integer pageNumber,
			@RequestHeader(value = X_PAGINATION_SORT, defaultValue = "createdAt,desc") String sortingParam,
			@ModelAttribute ClientSearchRequestDTO searchRequest) {

		Pageable pageParams = getPageableFromHeaderParams(pageLimit, pageNumber, sortingParam);
		return clientProcessor.getClients(searchRequest, pageParams);
	}

	@PatchMapping(value = "/clients/{clientId}")
	@Operation(summary = "Modify Client")
	public ResponseEntity<ClientDTO> updateClient(@PathVariable UUID clientId,
			@RequestBody ClientDTO clientDTO) {

		LOGGER.debug("Patch Client endpoint hit");
		return new ResponseEntity<>(clientService.patchClient(clientId, clientDTO), HttpStatus.OK);

	}

	@GetMapping(value = "/clients/{clientId}")
	@Operation(summary = "Get Client")
	public ResponseEntity<ClientDTO> getClient(@PathVariable UUID clientId) {

		LOGGER.debug("Get Client endpoint hit");
		return new ResponseEntity<>(clientService.getClient(clientId), HttpStatus.OK);
	}

}
