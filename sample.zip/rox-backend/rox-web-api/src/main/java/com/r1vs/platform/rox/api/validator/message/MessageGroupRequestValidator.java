package com.r1vs.platform.rox.api.validator.message;

import com.jsoniter.JsonIterator;
import com.r1vs.platform.rox.api.exception.Error;
import com.r1vs.platform.rox.api.model.message.CreateMessageGroupRequest;
import com.r1vs.platform.rox.api.model.message.UpdateMessageGroupRequest;
import com.r1vs.platform.rox.api.service.messagetemplate.MessageGroupApiService;
import com.r1vs.platform.rox.api.service.messagetemplate.MessageTemplateApiService;
import com.r1vs.platform.rox.api.util.MessageGroupConstants;
import com.r1vs.platform.rox.common.model.messages.MessageAssociation;
import com.r1vs.platform.rox.common.model.messages.MessageGroup;
import com.r1vs.platform.rox.common.model.messages.MessageGroupAssociation;
import com.r1vs.platform.rox.common.model.types.StatusType;
import com.r1vs.platform.rox.common.model.types.message.PrivacyLevelType;
import com.r1vs.platform.rox.common.model.types.message.PrivacySettingType;
import com.r1vs.platform.rox.common.model.types.message.TriggerCriteriaType;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import java.util.*;

import static com.r1vs.platform.rox.api.util.MessageGroupConstants.*;
import static com.r1vs.platform.rox.api.util.MessageTemplateConstants.MESSAGE_NAME;
import static com.r1vs.platform.rox.api.util.ValidationUtil.addError;

@Component
public class MessageGroupRequestValidator {

	@Autowired
	private MessageGroupApiService messageGroupApiService;

	@Autowired
	private MessageTemplateApiService messageTemplateApiService;

	@Autowired
	protected MessageSource messageSource;

	/**
	 * Validate messageGroup privacyLevel
	 *
	 * @param error error
	 * @param privacyLevel privacyLevel
	 */
	protected void validatePrivacyLevel(final Error error, final String privacyLevel) {

		if (privacyLevel != null && !PrivacyLevelType.HELPER.containsKey(privacyLevel)) {
			addError(error, PRIVACY_LEVEL, messageSource.getMessage(INVALID_PRIVACY_LEVEL, null, Locale.getDefault()),
					String.valueOf(privacyLevel));
		}
	}

	/**
	 * Validate messageGroup privacySetting
	 *
	 * @param error error
	 * @param privacySetting privacySetting
	 */
	protected void validatePrivacySetting(final Error error, final String privacySetting) {

		if (privacySetting != null && !PrivacySettingType.HELPER.containsKey(privacySetting)) {
			addError(error, PRIVACY_SETTING,
					messageSource.getMessage(INVALID_PRIVACY_SETTING, null, Locale.getDefault()),
					String.valueOf(privacySetting));
		}
	}

	/**
	 * Validate uniqueness for Message Group Name
	 *
	 * @param error error
	 * @param messageGroupName message group name
	 */
	protected void validateMessageGroupName(final Error error, final String messageGroupName, final Integer pbmId) {

		if (messageGroupName == null || messageGroupName.isEmpty() || messageGroupName.length() > 50) {
			addError(error, MESSAGE_NAME,
					messageSource.getMessage(INVALID_LENGTH_IN_MESSAGE_GROUP_NAME, null, Locale.getDefault()),
					messageGroupName);
		}

		if (!CollectionUtils.isEmpty(messageGroupApiService.findByMessageGroupName(messageGroupName, pbmId))) {
			addError(error, MESSAGE_GROUP_NAME,
					messageSource.getMessage(MESSAGE_GROUP_NAME_ALREADY_EXISTS, null, Locale.getDefault()),
					messageGroupName);
		}

	}

	protected void validateMessageGroupNameForUpdate(final Error error,
			final UpdateMessageGroupRequest updateMessageGroupRequest, final Integer pbmId) {

		final String messageGroupName = messageGroupApiService.getMessageGroupById(updateMessageGroupRequest.getId())
				.map(MessageGroup::getMessageGroupName).orElse(StringUtils.EMPTY);

		if (!(Objects.equals(updateMessageGroupRequest.getMessageGroupName(), messageGroupName))
				&& CollectionUtils.isNotEmpty(messageGroupApiService
						.findByMessageGroupName(updateMessageGroupRequest.getMessageGroupName(), pbmId))) {
			addError(error, MESSAGE_GROUP_NAME,
					messageSource.getMessage(MESSAGE_GROUP_NAME_ALREADY_EXISTS, null, Locale.getDefault()),
					updateMessageGroupRequest.getMessageGroupName());

		}
	}

	public void validateMessageGroupAssociation(final Error error, final String messagesAndCriteriaJson) {

		final Optional<MessageAssociation> messageAssociation = getDeserialize(error, messagesAndCriteriaJson);

		if (messageAssociation.isEmpty()) {
			addError(error, messageSource.getMessage(MESSAGES_IN_MESSAGE_GROUPS, null, Locale.getDefault()),
					messageSource.getMessage(MessageGroupConstants.MESSAGES_IN_MESSAGE_ARE_INVALID, null,
							Locale.getDefault()),
					messagesAndCriteriaJson);
			return;
		}

		if (messageAssociation.isPresent() && messageAssociation.get().getMessages().size() > 10) {
			addError(error, messageSource.getMessage(MESSAGES_IN_MESSAGE_GROUPS, null, Locale.getDefault()),
					messageSource.getMessage(INVALID_NUMBER_OF_MESSAGES, null, Locale.getDefault()),
					"[]");
			return;
		}

		if (messageAssociation.isPresent() && messageAssociation.get().getMessages().isEmpty()) {
			addError(error, messageSource.getMessage(MESSAGES_IN_MESSAGE_GROUPS, null, Locale.getDefault()),
					messageSource.getMessage(MessageGroupConstants.INVALID_NUMBER_OF_MESSAGE_ASSOCIATIONS, null,
							Locale.getDefault()),
					Arrays.toString(messageAssociation.get().getMessages().toArray()));
		}

		validateMessages(error, messageAssociation.get().getMessages());
	}

	private Optional<MessageAssociation> getDeserialize(final Error error, final String messagesAndCriteriaJson) {

		Optional<MessageAssociation> result = Optional.empty();

		try {
			result = Optional.of(JsonIterator.deserialize(messagesAndCriteriaJson, MessageAssociation.class));

		} catch (Exception e) {
			addError(error, messageSource.getMessage(MESSAGES_IN_MESSAGE_GROUPS, null, Locale.getDefault()),
					messageSource.getMessage(MessageGroupConstants.MESSAGES_IN_MESSAGE_ARE_INVALID, null,
							Locale.getDefault()),
					messagesAndCriteriaJson);
		} finally {
			return result;
		}
	}

	private void validateMessages(final Error error, final List<MessageGroupAssociation> messages) {

		final boolean isAnyMessageTemplateIdInvalid =
				messages.stream().anyMatch(m -> (m.getMessageTemplateId() == null || m.getMessageTemplateId() < 0));
		final boolean isAnyMessageTemplateTriggerInvalid =
				messages.stream().anyMatch(m -> (m.getTriggerCriteria() == null));

		if (isAnyMessageTemplateIdInvalid || isAnyMessageTemplateTriggerInvalid) {
			addError(error, MESSAGES_IN_MESSAGE_GROUPS,
					messageSource.getMessage(MESSAGES_IN_MESSAGE_ARE_INVALID, null, Locale.getDefault()), "");
		}

		final boolean areTriggerCriteriaValid =
				messages.stream().allMatch(m -> isValidTriggerCriteria(m.getTriggerCriteria()));

		if (!areTriggerCriteriaValid) {
			addError(error, MESSAGES_IN_MESSAGE_GROUPS,
					messageSource.getMessage(CRITERIA_MESSAGES_IN_MESSAGE_GROUP_ARE_INVALID, null, Locale.getDefault()),
					"");
		}

		final boolean areTheMessagesActive = messages.stream().allMatch(
				m -> messageTemplateApiService.getActiveMessageTemplateById(m.getMessageTemplateId()).isPresent());

		if (!areTheMessagesActive) {
			addError(error, MESSAGES_IN_MESSAGE_GROUPS,
					messageSource.getMessage(MESSAGES_IN_MESSAGE_GROUP_DONOT_EXISTS, null, Locale.getDefault()), "");
		}
	}

	private boolean isValidTriggerCriteria(final String triggerCriteria) {

		return triggerCriteria != null
				&& (TriggerCriteriaType.HELPER.containsKey(triggerCriteria));
	}

	protected void validateStatusCode(final Error error, final Integer status) {

		if (!StatusType.getStatusTypeMap().containsKey(status)) {
			addError(error, MessageGroupConstants.STATUS, messageSource.getMessage(MessageGroupConstants.INVALID_STATUS,
					new Object[] { status }, Locale.getDefault()), String.valueOf(status));
		}
	}

	protected void validateMessageGroupDescription(final Error error, final String description) {

		if (description == null || description.isEmpty() || description.length() > 100) {
			addError(error, MESSAGE_NAME,
					messageSource.getMessage(INVALID_LENGTH_IN_MESSAGE_GROUP_DESCRIPTION, null, Locale.getDefault()),
					description);
		}
	}

	protected void validateStatusIdForCreateMessageGroup(final Error error,
			final CreateMessageGroupRequest createMessageGroupRequest) {

		final Integer status = createMessageGroupRequest.getStatusId();

		final Object[] args = new Object[] { StatusType.getStatusTypeMap().get(status) };

		if (!StatusType.DRAFT.key().equals(status)) {
			addError(error, messageSource.getMessage(MessageGroupConstants.STATUS, args, Locale.getDefault()),
					messageSource.getMessage(INVALID_MESSAGE_GROUP_STATUS,
							args, Locale.getDefault()),
					String.valueOf(status));
		}
	}

	public MessageGroupApiService getMessageGroupApiService() {

		return messageGroupApiService;
	}

	public void setMessageGroupApiService(final MessageGroupApiService messageGroupApiService) {

		this.messageGroupApiService = messageGroupApiService;
	}

	public MessageTemplateApiService getMessageTemplateApiService() {

		return messageTemplateApiService;
	}

	public void setMessageTemplateApiService(final MessageTemplateApiService messageTemplateApiService) {

		this.messageTemplateApiService = messageTemplateApiService;
	}

	public MessageSource getMessageSource() {

		return messageSource;
	}

	public void setMessageSource(final MessageSource messageSource) {

		this.messageSource = messageSource;
	}
}
