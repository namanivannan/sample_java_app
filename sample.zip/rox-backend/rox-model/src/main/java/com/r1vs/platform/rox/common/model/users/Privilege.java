package com.r1vs.platform.rox.common.model.users;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import com.r1vs.platform.rox.common.model.AuditedEntity;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "privilege")
public class Privilege extends AuditedEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "privilege_id", nullable = false)
	private Integer privilegeId;

	@Column(name = "system_name", nullable = false, unique=true, updatable = false)
	private String systemName;

	@Column(name = "name", nullable = false)
	private String name;

	@ManyToMany(mappedBy = "privileges")
	private Set<Role> role;

	public Integer getPrivilegeId() {

		return privilegeId;
	}

	public void setPrivilegeId(final Integer privilegeId) {

		this.privilegeId = privilegeId;
	}

	public String getSystemName() {

		return systemName;
	}

	public void setSystemName(final String systemName) {

		this.systemName = systemName;
	}

	public String getName() {

		return name;
	}

	public void setName(final String name) {

		this.name = name;
	}

	public Set<Role> getRole() {

		return role;
	}

	public void setRole(final Set<Role> role) {

		this.role = role;
	}

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof Privilege)) {
			return false;
		}
		final Privilege castOther = (Privilege) other;
		return new EqualsBuilder().append(privilegeId, castOther.privilegeId).append(systemName, castOther.systemName)
				.append(name, castOther.name).isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(privilegeId).append(systemName).append(name).toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("privilegeId", privilegeId).append("systemName", systemName)
				.append("name", name).toString();
	}

}
