package com.r1vs.platform.rox.api.processor;

import com.r1vs.platform.rox.api.model.application.initiate.RoxFileDTO;
import com.r1vs.platform.rox.api.model.application.initiate.RoxFileWithNotesDTO;
import com.r1vs.platform.rox.api.service.MapperService;
import com.r1vs.platform.rox.api.service.ValidationUtils;
import com.r1vs.platform.rox.common.model.business.Application;
import com.r1vs.platform.rox.common.model.business.Client;
import com.r1vs.platform.rox.common.model.business.storage.RoxFile;
import com.r1vs.platform.rox.filemanagement.services.StorageService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.UUID;

@Component
public class FileProcessor {

	/**
	 * This class will serve as a bridge between RoxFileController and Storage Service in the rox-file-management Module
	 * And also contain the logic for validations and mapping for RoxFile
	 */

	@Autowired
	private ValidationUtils validationUtils;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private StorageService storageService;

	@Autowired
	private MapperService mapperService;

	public RoxFileDTO getValidateAndUploadFile(String clientId, UUID applicationId, MultipartFile file, String purpose)
			throws IOException {

		Client client = validationUtils.requireClient(clientId);
		Application application = validationUtils.requireApplication(applicationId, client);
		return modelMapper.map(storageService.uploadFile(clientId, file, purpose, application), RoxFileDTO.class);
	}

	public RoxFileWithNotesDTO getFileInfoWithNotes(String clientId, UUID applicationId, UUID fileId)
			throws IOException {

		Client client = validationUtils.requireClient(clientId);
		Application application = validationUtils.requireApplication(applicationId, client);
		RoxFile roxFile = validationUtils.requireRoxFile(fileId, application);

		return mapperService.getDTOFromEntity(roxFile);

	}

	public RoxFile getFile(String clientId, UUID applicationId, UUID fileId) throws IOException {

		Client client = validationUtils.requireClient(clientId);
		Application application = validationUtils.requireApplication(applicationId, client);
		return validationUtils.requireRoxFile(fileId, application);

	}
}
