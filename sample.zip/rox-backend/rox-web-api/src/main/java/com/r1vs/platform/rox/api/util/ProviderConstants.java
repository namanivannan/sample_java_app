package com.r1vs.platform.rox.api.util;

public class ProviderConstants {

	public final static String PROCESSOR_PROVIDER_ID_QUALIFIER = "88";

	public final static String SERVICE_ID_QUALIFIER = "serviceProviderIdQualifier";

	public final static Character PROVIDER_SERVICES_CODE_INDICATOR_NO = 'N';

	public final static Character PROVIDER_SERVICES_CODE_INDICATOR_YES = 'Y';

	public final static String PROVIDER_24_HOUR_OP_FLAG_NO = "N";

	public final static String PROVIDER_24_HOUR_OP_FLAG_YES = "Y";

	public final static String PROVIDER_REQUEST = "providerRequest";

	public final static String PROVIDER_PRIMARY_ID = "providerPrimaryId";

	public final static String SERVICE_PROVIDER_ID = "serviceProviderId";

	public final static String PROCESSOR_PROVIDER_ID = "processorProviderId";

	public final static String PROVIDER_NAME = "providerName";

	public final static String DISPENSER_CLASS_CODE = "dispenserClassCode";

	public final static String PRIMARY_PROVIDER_TYPE_CODE = "primaryProviderTypeCode";

	public final static String SECONDARY_PROVIDER_TYPE_CODE = "secondaryProviderTypeCode";

	public final static String TERTIARY_PROVIDER_TYPE_CODE = "tertiaryProviderTypeCode";

	public final static String DEACTIVATION_CODE = "deactivationCode";

	public final static String REINSTATEMENT_CODE = "reinstatementCode";

	public final static String STATE = "state";

	public final static String LANGUAGE_CODE = "languageCode";

	public final static String LANGUAGE_CODE_1 = "languageCode1";

	public final static String LANGUAGE_CODE_2 = "languageCode2";

	public final static String LANGUAGE_CODE_3 = "languageCode3";

	public final static String LANGUAGE_CODE_4 = "languageCode4";

	public final static String LANGUAGE_CODE_5 = " languageCode5";

	public final static String CONTACT_TYPE = "contactType";

	public final static String ACCEPTS_E_PRESCRIPTIONS_CODE = "acceptsEprescriptionsCode";

	public final static String CLOSED_DOOR_FACILITY_CODE = "closedDoorFacilityStatusCode";

	public final static String COMPOUNDING_SERVICE_CODE = "compoundingServiceCode";

	public final static String DELIVERY_SERVICE_CODE = "deliveryServiceCode";

	public final static String DRIVE_UP_WINDOW_CODE = "driveUpWindowCode";

	public final static String DURABLE_MEDICAL_EQUIPMENT_CODE = "durableMedicalEquipmentCode";

	public final static String HANDICAPPED_ACCESSIBLE_CODE = "handicappedAccessibleCode";

	public final static String IMMUNIZATIONS_PROVIDED_CODE = "immunizationsProvidedCode";

	public final static String MULTIDOSE_COMPLIANCE_PACKAGING_CODE = "multiDoseCompliancePackagingCode";

	public final static String THREE_FORTY_B_STATUS_CODE = "340bStatusCode";

	public final static String TWENTY_FOUR_HOUR_EMERGENCY_CODE = "24HourEmergencyServiceCode";

	public final static String WALKIN_CLINIC_CODE = "walkInClinicCode";

	public final static String EPRESCRIBING_NETWORK_IDENTIFIER = "ePrescribingNetworkIdentifier";

	public final static String EPRESCRIBING_SERVICE_LEVEL_CODES = "ePrescribingServiceLevelCodes";

	public final static String PROVIDER_GROUP_NAME = "providerGroupName";

	public final static String PROVIDER_GROUP_TYPE = "providerGroupType";

	public final static String PROVIDER_GROUP_REQUEST = "providerGroupRequest";

	public final static String PROVIDER_GROUP_ID = "providerGroupId";

	public final static String PROVIDER_GROUP_NPI = "providerGroupNPI";

	public final static String PROVIDER_GROUP_FEDERAL_TAX_ID = "providerGroupFederalTaxId";

	public final static String PROVIDER_GROUP_ADDRESS_LINE1 = "addressLine1";

	public final static String PROVIDER_GROUP_CITY = "city";

	public final static String PROVIDER_GROUP_STATE_CODE = "stateCode";

	public final static String PROVIDER_GROUP_ZIP_CODE = "zipCode";

	public final static String PROVIDER_GROUP_LOCATION = "providerGroupLocation";

	public final static String PROVIDER_RELATIONSHIP_ID = "relationshipId";

	public final static String PROVIDER_GRP_ID = "id";

	public static final String STATUS = "status";

	public final static String PROVIDER_NETWORK_CONFIG_ID = "providerNetworkConfigId";

	public final static String EXTERNAL_PROVIDER_NETWORK_ID = "providerNetworkId";

	public final static String PROVIDER = "provider";

	public final static String PROVIDER_GROUP = "providerGroup";

	public final static String PROVIDER_PARENT = "providerParent";

	public final static String EDIT = "edit";

	public final static String CRITERIA = "criteria";

	public final static String PROVIDER_NETWORK = "providerNetwork";

	public final static String PROVIDER_NETWORK_JSON = "providerNetworkJson";

	public final static String PROVIDER_NETWORK_NAME = "providerNetworkName";

}
