package com.r1vs.platform.rox.api.util;

import com.r1vs.platform.rox.api.model.common.CodeDescriptionDTO;
import com.r1vs.platform.rox.common.model.types.KeyValueEnum;
import com.r1vs.platform.rox.common.util.KeyValueEnumUtils;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static org.apache.commons.lang3.StringUtils.isNotEmpty;

public class CodeDescriptionDTOUtils {

	/**
	 *
	 * @param <E>
	 * @param code the key in the Enum
	 * @param enumClass the Enum class implementing KeyValueEnum
	 *
	 * @return CodeDescriptionDTO object
	 */
	public static <E extends Enum<E> & KeyValueEnum> CodeDescriptionDTO getCodeDescriptionFromEnum(final String code,
			final Class<E> enumClass) {

		final CodeDescriptionDTO codeDescriptionDTO = new CodeDescriptionDTO();

		if (isNotEmpty(code)) {

			final String description = KeyValueEnumUtils.getValueByKey(enumClass, code);

			codeDescriptionDTO.setCode(code).setDescription(description);

		}

		return codeDescriptionDTO;
	}

	/**
	 *
	 * @param <E>
	 * @param enumClass
	 *
	 * @return a list of CodeDescriptionDTO objects
	 */
	public static <E extends Enum<E> & KeyValueEnum> List<CodeDescriptionDTO> getAllCodeDescriptionsFromEnum(
			final Class<E> enumClass) {

		return Arrays.stream(enumClass.getEnumConstants()).map(enumObJ -> {
			return new CodeDescriptionDTO().setCode(enumObJ.key()).setDescription(enumObJ.value());
		}).collect(Collectors.toList());
	}

}
