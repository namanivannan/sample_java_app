package com.r1vs.platform.rox.common.util;

public class SystemHierarchyConstants {

	public static final String ACCOUNT_STATUS = "accountStatus";

	public static final String ACCOUNT_TYPE = "accountType";

	public static final String CARRIER_TYPE = "carrierType";

	public static final String CARRIER_STATUS = "carrierStatus";

	public static final String SPONSOR_NAME = "sponsorName";

	public static final String SPONSOR_STATUS = "sponsorStatus";

	public static final String SPONSOR_TYPE = "sponsorType";

	public static final String PBM_TYPE = "pbmType";

	public static final String PRORATION_TYPE = "proration";

	public static final String PLAN_TYPE = "planType";

	public static final String ACTION_FOR_PLAN_MAX = "actionForPlanMax";

	public static final String COMPOUND_COVERAGE = "compoundCoverage";

	public static final String DISPENSING_FEE_METHOD = "dispensingFeeMethod";

	public static final String COB_METHOD = "cobMethod";

	public static final String MEMBER_FINANCIAL_RESPONSIBILITY = "memberFinancialResponsibility";

	public static final String REJECT_FOR_PROVIDER_DENIAL = "rejectProvider";

	public static final String COB_NOT_COVERED = "cobNotCovered";

	public static final String COB_PAYMENT_NOT_COLLECTED = "cobPaymentReject";

	public static final String REQUIRE_OTHER_PAYER_AMOUNT = "requireOtherPayerAmountPaid";

	public static final String REQUIRE_OTHER_PAYER = "requireOtherPayer";

	public static final String COST_AVOIDANCE_METHOD = "costAvoidanceMethod";

	public static final String OTHER_COVERAGE_CODE = "otherCoverageCode";

	public static final String NETWORK_ASSIGNMENT = "networkAssignment";

	public static final String NETWORK_CLASSIFICATION = "networkClassification";

	public static final String CLAIM_TYPE = "claimType";

	public static final String OPERATOR = "operator";

	public static final String REPORTING_NETWORK = "reportNetwork";

	public static final String RESPONSE_NETWORK_ID = "responseNetworkId";

	public static final String RETURN_RESPONSE_GROUP = "responseGroupId";

	public static final String INDUSTRY_TYPE = "industryType";

	public static final String HELP_DESK_PHONE_TYPE = "helpDeskPhoneType";

	public static final String ACCOUNT_ASSIGNMENT = "accountId";

	public static final String SPONSOR_ASSIGNMENT = "sponsorId";

	public static final String CARRIER_ASSIGNMENT = "carrierId";

	public static final String PBM_ASSIGNMENT = "pbmId";

	public static final String STATE_EXCLUSIONS = "stateExclusions";

}
