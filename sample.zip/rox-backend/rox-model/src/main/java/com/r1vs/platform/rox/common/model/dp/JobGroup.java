package com.r1vs.platform.rox.common.model.dp;

import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Version;

import com.r1vs.platform.rox.common.model.AuditedEntity;

@Entity
@Table(name = "dp_job_group")
public class JobGroup extends AuditedEntity implements Serializable {

	private static final long serialVersionUID = 2628233015010123904L;

	@Id
	@Column(name = "id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Version
	private Integer version;

	@Column(name = "pbm_id")
	private Integer pbmId;

	@Column(name = "input_id")
	private Integer inputId;

	@Column(name = "registration_code")
	private String registrationCode;

	@Column(name = "state", nullable = false)
	private String state;

	@Column(name = "start_at", updatable = true)
	private OffsetDateTime startAt;

	@Column(name = "end_at", updatable = true)
	private OffsetDateTime endAt;

	@Column(name = "error_code")
	private String errorCode;

	@Column(name = "error_message")
	private String errorMessage;

	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.PERSIST, mappedBy = "jobGroup")
	private List<Job> jobs = new ArrayList<>();

	public Integer getId() {

		return id;
	}

	public void setId(final Integer id) {

		this.id = id;
	}

	public Integer getVersion() {

		return version;
	}

	public void setVersion(final Integer version) {

		this.version = version;
	}

	public Integer getPbmId() {

		return pbmId;
	}

	public void setPbmId(final Integer pbmId) {

		this.pbmId = pbmId;
	}

	public String getRegistrationCode() {

		return registrationCode;
	}

	public void setRegistrationCode(final String registrationCode) {

		this.registrationCode = registrationCode;
	}

	public String getState() {

		return state;
	}

	public void setState(final String state) {

		this.state = state;
	}

	public OffsetDateTime getStartAt() {

		return startAt;
	}

	public void setStartAt(final OffsetDateTime startAt) {

		this.startAt = startAt;
	}

	public OffsetDateTime getEndAt() {

		return endAt;
	}

	public void setEndAt(final OffsetDateTime endAt) {

		this.endAt = endAt;
	}

	public String getErrorCode() {

		return errorCode;
	}

	public void setErrorCode(final String errorCode) {

		this.errorCode = errorCode;
	}

	public String getErrorMessage() {

		return errorMessage;
	}

	public void setErrorMessage(final String errorMessage) {

		this.errorMessage = errorMessage;
	}

	public List<Job> getJobs() {

		return jobs;
	}

	public void setJobs(final List<Job> jobs) {

		this.jobs = jobs;
	}

	public Integer getInputId() {

		return inputId;
	}

	public void setInputId(final Integer inputId) {

		this.inputId = inputId;
	}

}
