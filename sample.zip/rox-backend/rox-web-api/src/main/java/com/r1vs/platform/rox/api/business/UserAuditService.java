package com.r1vs.platform.rox.api.business;

import com.r1vs.platform.rox.common.db.service.core.QueryService;
import com.r1vs.platform.rox.common.model.users.UserAudit;
import com.r1vs.platform.rox.common.model.users.UserAudit_;
import org.springframework.stereotype.Component;

import javax.persistence.criteria.*;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;

@Component
public class UserAuditService extends QueryService {

	/**
	 * Get a user's history for a given date range
	 *
	 * @param userId the user Id
	 * @param startDate the start date
	 * @param endDate the end date
	 * @return List of UserAudit history
	 */
	public List<UserAudit> findByUserId(final Long userId, final LocalDate startDate, final LocalDate endDate) {

		final CriteriaBuilder cb = getEntityManager().getCriteriaBuilder();
		final CriteriaQuery<UserAudit> cq = cb.createQuery(UserAudit.class);
		final Root<UserAudit> root = cq.from(UserAudit.class);

		final List<Predicate> predicates = new ArrayList<>();
		predicates.add(cb.equal(root.get(UserAudit_.userId), userId));

		if (startDate != null && endDate != null) {
			predicates.add(
					cb.and(cb.greaterThanOrEqualTo(root.get(UserAudit_.createdAt.getName()),
							startDate.atStartOfDay().atOffset(ZoneOffset.UTC)),
							cb.lessThanOrEqualTo(root.get(UserAudit_.createdAt.getName()),
									endDate.atTime(23, 59, 59).atOffset(ZoneOffset.UTC))));

		}

		cq.where(predicates.toArray(new Predicate[predicates.size()]));

		final List<Order> orders = new ArrayList<>();
		orders.add(cb.desc(root.get(UserAudit_.version.getName())));

		cq.orderBy(orders);

		return getEntityManager().createQuery(cq).getResultList();

	}
}
