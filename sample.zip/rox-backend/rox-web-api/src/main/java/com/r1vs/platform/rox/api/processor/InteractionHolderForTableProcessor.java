package com.r1vs.platform.rox.api.processor;

import com.r1vs.platform.rox.api.model.application.ds.InteractionHolderForTableDTO;
import com.r1vs.platform.rox.api.model.application.ds.InteractionResponseDTO;
import com.r1vs.platform.rox.api.model.interaction.InteractionResponseSearchParams;
import com.r1vs.platform.rox.api.service.MapperService;
import com.r1vs.platform.rox.api.service.ds.InteractionResponseService;
import com.r1vs.platform.rox.common.model.ds.InteractionResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.UUID;

@Component
public class InteractionHolderForTableProcessor extends CommonProcessor<InteractionHolderForTableDTO> {

	@Autowired
	private InteractionResponseService interactionResponseService;

	public ResponseEntity<List<InteractionHolderForTableDTO>> getInteractionHolders(String clientId, UUID applicationId,
			InteractionResponseSearchParams searchRequest, Pageable pageParams) {

		Page<InteractionResponse> results =
				interactionResponseService.getInteractionResponses(clientId, applicationId, searchRequest, pageParams);
		Page<InteractionHolderForTableDTO> holders = interactionResponseService.getInteractionResponseHolders(results);
		return buildResponseAsListWithPagination(holders);
	}
}
