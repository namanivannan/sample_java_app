package com.r1vs.platform.rox.common.model.memberenrollment;

import com.r1vs.platform.rox.common.model.BitemporalEntity;
import com.r1vs.platform.rox.common.model.business.Address;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.hibernate.annotations.LazyToOne;
import org.hibernate.annotations.LazyToOneOption;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Objects;

@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "member_profile")
public class MemberProfile extends BitemporalEntity implements Serializable {

	private static final long serialVersionUID = -687991491209605033L;

	@Id
	@Column(name = "member_profile_id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long memberProfileId;

	@Column(name = "member_id", nullable = false)
	@NotNull
	private Integer memberId;

	@Column(name = "pbm_id")
	private Integer pbmId;

	@Column(name = "primary_member_id")
	private Integer primaryMemberId;

	@Column(name = "last_name")
	@NotNull
	@Size(min = 1, max = 25)
	private String lastName;

	@Column(name = "first_name")
	@NotNull
	@Size(min = 1, max = 15)
	private String firstName;

	@Column(name = "middle_initial")
	@Size(max = 1)
	private String middleInitial;

	@Column(name = "suffix")
	private String suffix;

	@Column(name = "gender")
	@NotNull
	@Size(min = 1, max = 1)
	private String gender;

	@Column(name = "date_of_birth")
	@NotNull
	@Past
	private LocalDate dateOfBirth;

	@Column(name = "date_of_death")
	private LocalDate dateOfDeath;

	@Column(name = "multi_birth_code")
	@Size(max = 1)
	private String multiBirthCode;

	@Column(name = "person_code")
	@Size(max = 3)
	private String personCode;

	@Column(name = "relationship_code")
	@NotNull
	@Size(min = 1, max = 1)
	private String relationshipCode;

	@Column(name = "language_name_code")
	@Size(max = 1)
	private String languageNameCode;

	@Column(name = "reporting_sub_group_id")
	@Size(max = 25)
	private String reportingSubGroupId;

	@Column(name = "eligibility_effective_start_date")
	private LocalDate eligibilityEffectiveStartDate;

	@Column(name = "eligibility_effective_end_date")
	private LocalDate eligibilityEffectiveEndDate;

	@Column(name = "input_id")
	private String inputId;

	/**
	 * Relationships
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@LazyToOne(LazyToOneOption.NO_PROXY)
	@JoinColumn(name = "member_id", nullable = false, insertable = false, updatable = false)
	private Member member;

	@ManyToOne(fetch = FetchType.LAZY)
	@LazyToOne(LazyToOneOption.NO_PROXY)
	@JoinColumn(name = "primary_member_id", referencedColumnName = "member_id", nullable = false, insertable = false,
			updatable = false)
	private Member cardholder;

	@OneToMany(fetch = FetchType.LAZY)
	@JoinColumn(name = "member_id", referencedColumnName = "member_id", nullable = true, insertable = false,
			updatable = false)
	private List<Address> address;

	public MemberProfile() {

	}

	private MemberProfile(final Builder builder) {

		memberId = builder.memberId;
		pbmId = builder.pbmId;
		primaryMemberId = builder.primaryMemberId;
		lastName = builder.lastName;
		firstName = builder.firstName;
		middleInitial = builder.middleInitial;
		suffix = builder.suffix;
		gender = builder.gender;
		dateOfBirth = builder.dateOfBirth;
		dateOfDeath = builder.dateOfDeath;
		multiBirthCode = builder.multiBirthCode;
		personCode = builder.personCode;
		relationshipCode = builder.relationshipCode;
		languageNameCode = builder.languageNameCode;
		reportingSubGroupId = builder.reportingSubGroupId;
		effectiveStartDate = builder.effectiveStartDate;
		effectiveEndDate = builder.effectiveEndDate;
		deactivatedAt = builder.deactivatedAt;
		activatedAt = builder.activatedAt;
		eligibilityEffectiveStartDate = builder.eligibilityEffectiveStartDate;
		eligibilityEffectiveEndDate = builder.eligibilityEffectiveEndDate;

	}

	public static class Builder {

		private final Integer memberId;

		private final Integer pbmId;

		private Integer primaryMemberId = null;

		private final String lastName;

		private final String firstName;

		private String middleInitial = null;

		private String suffix = null;

		private final String gender;

		private final LocalDate dateOfBirth;

		private LocalDate dateOfDeath = null;

		private String multiBirthCode = null;

		private String personCode = null;

		private final String relationshipCode;

		private String languageNameCode = null;

		private String reportingSubGroupId = null;

		private final LocalDate effectiveStartDate;

		private final LocalDate effectiveEndDate;

		private final OffsetDateTime deactivatedAt;

		private final OffsetDateTime activatedAt;

		private LocalDate eligibilityEffectiveStartDate;

		private LocalDate eligibilityEffectiveEndDate;

		public Builder(final Integer memberId, final Integer pbmId, final String lastName, final String firstName,
				final String gender,
				final LocalDate dateOfBirth, final String relationshipCode, final LocalDate effectiveStartDate,
				final LocalDate effectiveEndDate, final OffsetDateTime deactivatedAt,
				final OffsetDateTime activatedAt) {

			this.memberId = memberId;
			this.pbmId = pbmId;
			this.lastName = lastName;
			this.firstName = firstName;
			this.gender = gender;
			this.dateOfBirth = dateOfBirth;
			this.relationshipCode = relationshipCode;
			this.effectiveStartDate = effectiveStartDate;
			this.effectiveEndDate = effectiveEndDate;
			this.deactivatedAt = deactivatedAt;
			this.activatedAt = activatedAt;
		}

		public Builder middleInitial(final String val) {

			middleInitial = val;
			return this;
		}

		public Builder dateOfDeath(final LocalDate val) {

			dateOfDeath = val;
			return this;
		}

		public Builder multiBirthCode(final String val) {

			multiBirthCode = val;
			return this;
		}

		public Builder personCode(final String val) {

			personCode = val;
			return this;
		}

		public Builder languageNameCode(final String val) {

			languageNameCode = val;
			return this;
		}

		public Builder reportingSubGroupId(final String val) {

			reportingSubGroupId = val;
			return this;
		}

		public Builder primaryMemberId(final Integer val) {

			primaryMemberId = val;
			return this;
		}

		public Builder suffix(final String val) {

			suffix = val;
			return this;
		}

		public Builder eligibilityEffectiveStartDate(final LocalDate val) {

			eligibilityEffectiveStartDate = val;
			return this;
		}

		public Builder eligibilityEffectiveEndDate(final LocalDate val) {

			eligibilityEffectiveEndDate = val;
			return this;
		}

		public MemberProfile build() {

			return new MemberProfile(this);
		}

	}

	public Long getMemberProfileId() {

		return memberProfileId;
	}

	public void setMemberProfileId(final Long memberProfileId) {

		this.memberProfileId = memberProfileId;
	}

	public Integer getMemberId() {

		return memberId;
	}

	public void setMemberId(final Integer memberId) {

		this.memberId = memberId;
	}

	public Integer getPbmId() {

		return pbmId;
	}

	public void setPbmId(final Integer pbmId) {

		this.pbmId = pbmId;
	}

	public Integer getPrimaryMemberId() {

		return primaryMemberId;
	}

	public void setPrimaryMemberId(final Integer primaryMemberId) {

		this.primaryMemberId = primaryMemberId;
	}

	public String getLastName() {

		return lastName;
	}

	public void setLastName(final String lastName) {

		this.lastName = lastName;
	}

	public String getFirstName() {

		return firstName;
	}

	public void setFirstName(final String firstName) {

		this.firstName = firstName;
	}

	public String getMiddleInitial() {

		return middleInitial;
	}

	public void setMiddleInitial(final String middleInitial) {

		this.middleInitial = middleInitial;
	}

	public String getSuffix() {

		return suffix;
	}

	public void setSuffix(final String suffix) {

		this.suffix = suffix;
	}

	public String getGender() {

		return gender;
	}

	public void setGender(final String gender) {

		this.gender = gender;
	}

	public LocalDate getDateOfBirth() {

		return dateOfBirth;
	}

	public void setDateOfBirth(final LocalDate dateOfBirth) {

		this.dateOfBirth = dateOfBirth;
	}

	public LocalDate getDateOfDeath() {

		return dateOfDeath;
	}

	public void setDateOfDeath(final LocalDate dateOfDeath) {

		this.dateOfDeath = dateOfDeath;
	}

	public String getMultiBirthCode() {

		return multiBirthCode;
	}

	public void setMultiBirthCode(final String multiBirthCode) {

		this.multiBirthCode = multiBirthCode;
	}

	public String getPersonCode() {

		return personCode;
	}

	public void setPersonCode(final String personCode) {

		this.personCode = personCode;
	}

	public String getRelationshipCode() {

		return relationshipCode;
	}

	public void setRelationshipCode(final String relationshipCode) {

		this.relationshipCode = relationshipCode;
	}

	public String getLanguageNameCode() {

		return languageNameCode;
	}

	public void setLanguageNameCode(final String languageNameCode) {

		this.languageNameCode = languageNameCode;
	}

	public String getReportingSubGroupId() {

		return reportingSubGroupId;
	}

	public void setReportingSubGroupId(final String reportingSubGroupId) {

		this.reportingSubGroupId = reportingSubGroupId;
	}

	public LocalDate getEligibilityEffectiveStartDate() {

		return eligibilityEffectiveStartDate;
	}

	public void setEligibilityEffectiveStartDate(final LocalDate eligibilityEffectiveStartDate) {

		this.eligibilityEffectiveStartDate = eligibilityEffectiveStartDate;
	}

	public LocalDate getEligibilityEffectiveEndDate() {

		return eligibilityEffectiveEndDate;
	}

	public void setEligibilityEffectiveEndDate(final LocalDate eligibilityEffectiveEndDate) {

		this.eligibilityEffectiveEndDate = eligibilityEffectiveEndDate;
	}

	public Member getMember() {

		return member;
	}

	public void setMember(final Member member) {

		this.member = member;
	}

	public Member getCardholder() {

		return cardholder;
	}

	public void setCardholder(final Member cardholder) {

		this.cardholder = cardholder;
	}

	public List<Address> getAddress() {

		return address;
	}

	public void setAddress(final List<Address> address) {

		this.address = address;
	}

	public String getInputId() {

		return inputId;
	}

	public void setInputId(final String inputId) {

		this.inputId = inputId;
	}

	/**
	 * Checks the data so that no duplicate row is inserted in database. Only fields that will not be unique are added
	 * to this equals check!
	 */
	@Override
	public boolean itemEqualsRow(final Object other) {

		if (!(other instanceof MemberProfile)) {
			return false;
		}
		final MemberProfile castOther = (MemberProfile) other;
		return new EqualsBuilder().append(memberId, castOther.memberId).append(pbmId, castOther.pbmId)
				.append(lastName, castOther.lastName)
				.append(firstName, castOther.firstName).append(middleInitial, castOther.middleInitial)
				.append(gender, castOther.gender).append(dateOfBirth, castOther.dateOfBirth)
				.append(dateOfDeath, castOther.dateOfDeath).append(multiBirthCode, castOther.multiBirthCode)
				.append(personCode, castOther.personCode).append(relationshipCode, castOther.relationshipCode)
				.append(languageNameCode, castOther.languageNameCode)
				.append(reportingSubGroupId, castOther.reportingSubGroupId)
				.append(getEffectiveStartDate(), castOther.getEffectiveStartDate())
				.append(getEffectiveEndDate(), castOther.getEffectiveEndDate()).isEquals();
	}

	/**
	 * Note: Regenerating equals, hashCode, and toString may re-introduce purposely removed related entities which cause
	 * lazy load exceptions after session has been closed. Please exclude relationships from these methods.
	 */
	@Override
	public boolean equals(final Object obj) {

		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final MemberProfile other = (MemberProfile) obj;
		return Objects.equals(dateOfBirth, other.dateOfBirth) && Objects.equals(dateOfDeath, other.dateOfDeath)
				&& Objects.equals(eligibilityEffectiveEndDate, other.eligibilityEffectiveEndDate)
				&& Objects.equals(eligibilityEffectiveStartDate, other.eligibilityEffectiveStartDate)
				&& Objects.equals(firstName, other.firstName) && Objects.equals(gender, other.gender)
				&& Objects.equals(inputId, other.inputId) && Objects.equals(languageNameCode, other.languageNameCode)
				&& Objects.equals(lastName, other.lastName) && Objects.equals(memberId, other.memberId)
				&& Objects.equals(memberProfileId, other.memberProfileId)
				&& Objects.equals(middleInitial, other.middleInitial)
				&& Objects.equals(multiBirthCode, other.multiBirthCode) && Objects.equals(pbmId, other.pbmId)
				&& Objects.equals(personCode, other.personCode)
				&& Objects.equals(primaryMemberId, other.primaryMemberId)
				&& Objects.equals(relationshipCode, other.relationshipCode)
				&& Objects.equals(reportingSubGroupId, other.reportingSubGroupId)
				&& Objects.equals(suffix, other.suffix);
	}

	@Override
	public int hashCode() {

		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash(dateOfBirth, dateOfDeath, eligibilityEffectiveEndDate,
				eligibilityEffectiveStartDate, firstName, gender, inputId, languageNameCode, lastName, memberId,
				memberProfileId, middleInitial, multiBirthCode, pbmId, personCode, primaryMemberId, relationshipCode,
				reportingSubGroupId, suffix);
		return result;
	}

	@Override
	public String toString() {

		final ToStringBuilder builder2 = new ToStringBuilder(this);
		builder2.append("memberProfileId", memberProfileId).append("memberId", memberId).append("pbmId", pbmId)
				.append("primaryMemberId", primaryMemberId).append("lastName", lastName).append("firstName", firstName)
				.append("middleInitial", middleInitial).append("suffix", suffix).append("gender", gender)
				.append("dateOfBirth", dateOfBirth).append("dateOfDeath", dateOfDeath)
				.append("multiBirthCode", multiBirthCode).append("personCode", personCode)
				.append("relationshipCode", relationshipCode).append("languageNameCode", languageNameCode)
				.append("reportingSubGroupId", reportingSubGroupId)
				.append("eligibilityEffectiveStartDate", eligibilityEffectiveStartDate)
				.append("eligibilityEffectiveEndDate", eligibilityEffectiveEndDate).append("inputId", inputId);
		return builder2.toString();
	}

}
