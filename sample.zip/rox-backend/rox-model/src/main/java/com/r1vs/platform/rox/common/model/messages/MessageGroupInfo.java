package com.r1vs.platform.rox.common.model.messages;

public class MessageGroupInfo {

	private String message;

	private String messageGroupId;

	private String messageGroupVersionId;

	private Long metadataId;

	private Integer metadataCategoryId;

	public String getMessage() {

		return message;
	}

	public void setMessage(String message) {

		this.message = message;
	}

	public String getMessageGroupId() {

		return messageGroupId;
	}

	public void setMessageGroupId(String messageGroupId) {

		this.messageGroupId = messageGroupId;
	}

	public String getMessageGroupVersionId() {

		return messageGroupVersionId;
	}

	public void setMessageGroupVersionId(String messageGroupVersionId) {

		this.messageGroupVersionId = messageGroupVersionId;
	}

	public Long getMetadataId() {

		return metadataId;
	}

	public void setMetadataId(Long metadataId) {

		this.metadataId = metadataId;
	}

	public Integer getMetadataCategoryId() {

		return metadataCategoryId;
	}

	public void setMetadataCategoryId(Integer metadataCategoryId) {

		this.metadataCategoryId = metadataCategoryId;
	}

	@Override
	public String toString() {

		return "MessageGroupInfo{" +
				"message='" + message + '\'' +
				", messageGroupId='" + messageGroupId + '\'' +
				", messageGroupVersionId='" + messageGroupVersionId + '\'' +
				", metadataId=" + metadataId +
				", metadataCategoryId=" + metadataCategoryId +
				'}';
	}
}
