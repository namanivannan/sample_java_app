package com.r1vs.platform.rox.common.model.messages;

import com.r1vs.platform.rox.common.model.BitemporalEntity;
import com.r1vs.platform.rox.common.model.business.Status;
import com.r1vs.platform.rox.common.model.business.Client;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "message_group")
public class MessageGroup extends BitemporalEntity implements Serializable {

	@Id
	@Column(name = "id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(name = "message_group_id", nullable = false)
	private Integer messageGroupId;

	@Column(name = "client_id")
	private Integer clientId;

	@Column(name = "message_group_name", nullable = false)
	private String messageGroupName;

	@Column(name = "message_group_description")
	private String messageGroupDescription;

	@Column(name = "message_templates", nullable = false)
	private String messages;

	@Column(name = "privacy_setting")
	private String privacySetting;

	@Column(name = "privacy_level")
	private String privacyLevel;

	@Column(name = "status_id", nullable = false)
	@NotNull
	private Integer statusId;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "client_id", nullable = false, insertable = false, updatable = false)
	private Client client;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "status_id", nullable = false, insertable = false, updatable = false)
	private Status status;

	public Integer getId() {

		return id;
	}

	public void setId(Integer id) {

		this.id = id;
	}

	public Integer getMessageGroupId() {

		return messageGroupId;
	}

	public void setMessageGroupId(Integer messageGroupId) {

		this.messageGroupId = messageGroupId;
	}

	public Integer getClientId() {

		return clientId;
	}

	public void setClientId(Integer clientId) {

		this.clientId = clientId;
	}

	public String getMessageGroupName() {

		return messageGroupName;
	}

	public void setMessageGroupName(String messageGroupName) {

		this.messageGroupName = messageGroupName;
	}

	public String getMessageGroupDescription() {

		return messageGroupDescription;
	}

	public void setMessageGroupDescription(String messageGroupDescription) {

		this.messageGroupDescription = messageGroupDescription;
	}

	public String getMessages() {

		return messages;
	}

	public void setMessages(String messages) {

		this.messages = messages;
	}

	public String getPrivacySetting() {

		return privacySetting;
	}

	public void setPrivacySetting(String privacySetting) {

		this.privacySetting = privacySetting;
	}

	public String getPrivacyLevel() {

		return privacyLevel;
	}

	public void setPrivacyLevel(String privacyLevel) {

		this.privacyLevel = privacyLevel;
	}

	public Integer getStatusId() {

		return statusId;
	}

	public void setStatusId(Integer statusId) {

		this.statusId = statusId;
	}

	public Client getClient() {

		return client;
	}

	public void setClient(Client client) {

		this.client = client;
	}

	public Status getStatus() {

		return status;
	}

	public void setStatus(Status status) {

		this.status = status;
	}
}
