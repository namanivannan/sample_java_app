package com.r1vs.platform.rox.api.controller;

import com.r1vs.platform.rox.api.model.application.initiate.AccessGroupDTO;
import com.r1vs.platform.rox.api.service.AccessGroupService;
import com.r1vs.platform.rox.common.model.users.AccessGroup;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import static com.r1vs.platform.rox.api.util.InterceptorConstants.CLIENT_ID;

@RestController
@RequestMapping(value = "/v1", produces = { MediaType.APPLICATION_JSON_VALUE })
@Tag(name = "AccessGroup", description = "Access group contains a set of roles to an User")
public class AccessGroupController {

	@Autowired
	private AccessGroupService accessGroupService;

	@PostMapping("/accessGroup")
	@Operation(summary = "Creates an AccessGroup from a set of roles")
	public ResponseEntity<AccessGroupDTO> createAccessGroup(@RequestHeader(CLIENT_ID) String clientId,
			@RequestBody AccessGroupDTO accessGroupDTO) {

		return new ResponseEntity<>(accessGroupService.createAccessGroup(clientId, accessGroupDTO), HttpStatus.CREATED);
	}

}
