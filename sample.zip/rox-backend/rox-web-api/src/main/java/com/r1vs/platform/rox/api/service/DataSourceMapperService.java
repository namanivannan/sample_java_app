package com.r1vs.platform.rox.api.service;

import com.r1vs.platform.rox.api.model.application.ds.fcs.UCCSearchRequestDTO;
import com.r1vs.platform.rox.interaction.fcs.request.SearchRequest;
import org.modelmapper.ModelMapper;
import org.modelmapper.PropertyMap;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service
public class DataSourceMapperService implements InitializingBean {

	@Autowired
	@Qualifier("dataSourceModelMapper")
	private ModelMapper dataSourceModelMapper;

	@Override
	public void afterPropertiesSet() throws Exception {

		configureMappingRules(dataSourceModelMapper);
	}

	private void configureMappingRules(ModelMapper inputMapper) {

		inputMapper.addMappings(new PropertyMap<UCCSearchRequestDTO, SearchRequest>() {

			@Override
			protected void configure() {

				map(source.isIncludeInactiveFilings(), destination.getIncludeInactiveFilings());
			};
		});
	}

	public ModelMapper getDataSourceModelMapper() {

		return dataSourceModelMapper;
	}

}
