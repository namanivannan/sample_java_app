package com.r1vs.platform.rox.api.util;

import com.r1vs.platform.rox.api.model.common.CodeDescriptionDTO;
import com.r1vs.platform.rox.api.model.member.auth.*;
import com.r1vs.platform.rox.api.response.ResponseMessages;
import com.r1vs.platform.rox.common.model.memberenrollment.Member;
import com.r1vs.platform.rox.common.model.memberenrollment.MemberAuth;
import com.r1vs.platform.rox.common.model.rule.Criteria;
import com.r1vs.platform.rox.common.model.rule.Metadata;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class AuthorizationTestUtil {

	public static final Long MEMBER_PRIOR_AUTH_ID = 1L;

	public static final Integer PBM_ID = 1;

	public static final String AUTH_NAME = "DrugName-In Process";

	public static final Integer MEMBER_ID = 1;

	public static final String MEMBER_ID_NOT_AVAILABLE = "9";

	public static final Long MEMBER_ID_V1 = 1L;

	public static final Integer PROVIDER_ID = 1;

	public static final String COMMENT_LENGTH_EXCEEDED =
			"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA";

	public static final Long EDIT_ID = 1L;

	public static final String AUTH_TYPE_CODE = "PA";

	public static final String AUTH_LEVEL_CODE = "01";

	public static final Long VALID_CRITERIA_ID = 1L;

	public static final Long CRITERIA_ID_NOT_AVAILABLE = 123456L;

	public static final Integer VALID_CRITERIA_ROW_ID = 1;

	public static final String DRUG_LEVEL_VALUE = "NDCP-11";

	public static final String DRUG_LEVEL = "456123456";

	public static final String OUTCOME_CODE = "INP";

	public static final String OUTCOME_CODE_APP = "APP";

	public static final String OUTCOME_REASON_CODE = "SR";

	public static final String AUTH_REASON_CODE = "ALG";

	public static final String AUTH_BY_INFO = "luis";

	public static final String PRESCRIBER_INFO = "test";

	public static final String PA_TRACKING_NUMBER = "12345678901234567890";

	public static final boolean AUTO_ASSIGN_PA_TRACKING_NUMBER = true;

	public static final String EXTERNAL_TRACKING_NUMBER = "1010";

	public static final String AUTH_NUMBER_OF_FILLS = "1";

	public static final LocalDate AUTH_START_DATE = LocalDate.of(2021, 03, 15);

	public static final LocalDate AUTH_END_DATE = LocalDate.of(2022, 03, 15);

	public static final String AUTH_PRIORITY_CODE = "S";

	public static final OffsetDateTime AUTH_REQUEST_START_DATE_TIME = OffsetDateTime.of(LocalDate.of(2021, 03, 15),
			LocalTime.of(14, 30), ZoneOffset.UTC);

	public static final OffsetDateTime AUTH_REQUEST_END_DATE_TIME = OffsetDateTime.of(LocalDate.of(2022, 03, 15),
			LocalTime.of(14, 30), ZoneOffset.UTC);

	public static final Long CRITERIA_ID = 1L;

	public static final byte STATUS_ID = 0;

	public static final String COMMENTS = "Comments....";

	public static final boolean PA_TRACKING_NUMBER_ON_CLAIM_REQUIRED = true;

	public static final String PROVIDER_ACTION = "OVR";

	public static final String PRESCRIBER_ACTION = "OVR";

	public static final String PRESCRIBERS =
			"[{\\\"prescriberVersion\\\":\\\"1\\\",\\\"prescriberId\\\":\\\"1\\\"}]";

	public static final String CHANGE_FORMULARY_STATUS = "NO";

	public static final String CHANGE_PREFERRED_DRUG_STATUS = "XP";

	public static final String INVALID_AUTHORIZATION_ACTION = "INVALID_AUTHORIZATION_ACTION";

	public static final String INVALID_CRITERIA_ID = "INVALID_CRITERIA_ID";

	public static final String INVALID_AUTHORIZATION_LEVEL = "INVALID_AUTHORIZATION_LEVEL";

	public static final String INVALID_OUTCOME = "INVALID_OUTCOME";

	public static final String INVALID_REASON_FOR_OUTCOME = "INVALID_REASON_FOR_OUTCOME";

	public static final String INVALID_AUTHORIZATION_REASON = "INVALID_AUTHORIZATION_REASON";

	public static final String INVALID_AUTHORIZATION_PRIORITY = "INVALID_AUTHORIZATION_PRIORITY";

	public static final String INVALID_PROVIDER_ACTION = "INVALID_PROVIDER_ACTION";

	public static final String INVALID_PRESCRIBER_ACTION = "INVALID_PRESCRIBER_ACTION";

	public static final String INVALID_CHANGE_FORMULARY_STATUS = "INVALID_CHANGE_FORMULARY_STATUS";

	public static final String INVALID_CHANGE_PREFERRED_DRUG_STATUS = "INVALID_CHANGE_PREFERRED_DRUG_STATUS";

	public static final String EDITS =
			"[{\\\"bypassCategory\\\":false,\\\"editCategory\\\":\\\"Claim $ Min/Max\\\",\\\"edit\\\":{\\\"editVersion\\\":\\\"2\\\",\\\"editId\\\":\\\"1\\\"}}]";

	public CreateMemberAuthRequest setUpCreateAuthorizationRequest(final int type) {

		final CreateMemberAuthRequest createMemberAuthRequest = new CreateMemberAuthRequest();
		final BasicInfoAuth basicInfoAuth = new BasicInfoAuth();
		final AdvancedInfoAuth advancedInfoAuth = new AdvancedInfoAuth();
		switch (type) {
		case 1:
			basicInfoAuth.setDrugLevel("11");
			basicInfoAuth.setDrugLevelValue("Valium");
			break;
		case 2:
			basicInfoAuth.setCriteriaId(1L);
			basicInfoAuth.setCriteriaRowId(1);
			break;
		case 3:
			basicInfoAuth.setDrugLevel("11");
			basicInfoAuth.setDrugLevelValue("Valium");
			basicInfoAuth.setCriteriaId(1L);
			basicInfoAuth.setCriteriaRowId(1);
		case 4:
			break;
		}
		basicInfoAuth.setMemberId(String.valueOf(MEMBER_ID));
		basicInfoAuth.setAuthTypeCode(AUTH_TYPE_CODE);
		basicInfoAuth.setAuthLevelCode(AUTH_LEVEL_CODE);
		basicInfoAuth.setOutcomeCode(OUTCOME_CODE);
		basicInfoAuth.setOutcomeReasonCode(OUTCOME_REASON_CODE);
		basicInfoAuth.setAuthReasonCode(AUTH_REASON_CODE);
		basicInfoAuth.setAuthByInfo(AUTH_BY_INFO);
		basicInfoAuth.setPrescriberInfo(PRESCRIBER_INFO);
		basicInfoAuth.setPaTrackingNumber(PA_TRACKING_NUMBER);
		basicInfoAuth.setAutoAssignPaTrackingNumber(AUTO_ASSIGN_PA_TRACKING_NUMBER);
		basicInfoAuth.setExternalTrackingNumber(EXTERNAL_TRACKING_NUMBER);
		basicInfoAuth.setAuthNumberOfFills(AUTH_NUMBER_OF_FILLS);
		basicInfoAuth.setAuthStartDate(AUTH_START_DATE);
		basicInfoAuth.setAuthEndDate(AUTH_END_DATE);
		basicInfoAuth.setInlineCriteria(false);
		basicInfoAuth.setAuthPriorityCode(AUTH_PRIORITY_CODE);
		basicInfoAuth.setAuthRequestStartDateTime(AUTH_REQUEST_START_DATE_TIME);
		basicInfoAuth.setAuthRequestEndDateTime(AUTH_REQUEST_END_DATE_TIME);
		basicInfoAuth.setComments(COMMENTS);
		basicInfoAuth.setPaTrackingNumberOnClaimRequired(false);
		advancedInfoAuth.setProviderAction(PROVIDER_ACTION);
		advancedInfoAuth.setProviders(getProviders());
		advancedInfoAuth.setPrescriberAction(PRESCRIBER_ACTION);
		advancedInfoAuth.setPrescribers(getPrescribers());
		advancedInfoAuth.setAdjustOrUpdateOrOverride(new AdjustOrUpdateOrOverride("NO", "XP"));
		advancedInfoAuth.setEdits(getEdits());
		createMemberAuthRequest.setAdvanceInfo(advancedInfoAuth);
		createMemberAuthRequest.setBasicInfo(basicInfoAuth);

		return createMemberAuthRequest;
	}

	protected MemberAuthSearchRequest setUpMemberAuthSearchRequest() {

		final MemberAuthSearchRequest request = new MemberAuthSearchRequest();

		final List<String> reasonList = new ArrayList<>();
		reasonList.add(AUTH_REASON_CODE);
		request.setMemberId(String.valueOf(MEMBER_ID));
		request.setAuthorizationName(AUTH_NAME);
		request.setAuthorizationType(AUTH_TYPE_CODE);
		request.setPaTrackingNumber(PA_TRACKING_NUMBER);
		request.setOutcome(OUTCOME_CODE);
		request.setAuthorizationStartDate(AUTH_START_DATE);
		request.setAuthorizationEndDate(AUTH_END_DATE);
		request.setReasonForOutcome(OUTCOME_REASON_CODE);
		request.setAuthorizationReason(reasonList);
		request.setExternalTrackingNumber(EXTERNAL_TRACKING_NUMBER);
		request.setAuthorizationPriority(AUTH_PRIORITY_CODE);
		request.setAuthorizedBy(AUTH_BY_INFO);

		return request;
	}

	public Member setUpMember() {

		final Member member = new Member();
		member.setMemberId(1);
		return member;
	}

	public Optional<Criteria> setUpCriteria() {

		final Criteria criteria = new Criteria();
		criteria.setId(1);
		criteria.setCriteriaId(1L);
		return Optional.of(criteria);
	}

	public Optional<MemberAuth> setUpMemberAuthOptional() {

		final Optional<MemberAuth> memberAuthOptional = Optional.of(setupMemberAuth());
		memberAuthOptional.get().setMemberId(1);
		return memberAuthOptional;
	}

	public Optional<MemberAuth> setUpInvalidMemberAuthOptionalForUpdate() {

		final Optional<MemberAuth> memberAuthOptional = Optional.of(setupMemberAuth());
		memberAuthOptional.get().setMemberId(1);
		memberAuthOptional.get().setOutcomeCode("APP");
		return memberAuthOptional;
	}

	public Metadata setUpMetadata() {

		final Metadata metadata = new Metadata();
		metadata.setMetadataId(1L);
		return metadata;
	}

	public UpdateMemberAuthRequest setUpUpdateAuthorizationRequest() {

		final UpdateMemberAuthRequest updateMemberAuthRequest = new UpdateMemberAuthRequest();
		final BasicInfoAuth basicInfoAuth = new BasicInfoAuth();
		final AdvancedInfoAuth advancedInfoAuth = new AdvancedInfoAuth();

		basicInfoAuth.setMemberPriorAuthId(MEMBER_PRIOR_AUTH_ID);
		basicInfoAuth.setMemberId(String.valueOf(MEMBER_ID));
		basicInfoAuth.setAuthLevelCode(AUTH_LEVEL_CODE);
		basicInfoAuth.setCriteriaId(VALID_CRITERIA_ID);
		basicInfoAuth.setCriteriaRowId(VALID_CRITERIA_ROW_ID);
		basicInfoAuth.setOutcomeCode(OUTCOME_CODE);
		basicInfoAuth.setInlineCriteria(false);
		basicInfoAuth.setAuthTypeCode(AUTH_TYPE_CODE);
		basicInfoAuth.setOutcomeReasonCode(OUTCOME_REASON_CODE);
		basicInfoAuth.setAuthReasonCode(AUTH_REASON_CODE);
		basicInfoAuth.setAuthByInfo(AUTH_BY_INFO);
		basicInfoAuth.setPrescriberInfo(PRESCRIBER_INFO);
		basicInfoAuth.setPaTrackingNumber(PA_TRACKING_NUMBER);
		basicInfoAuth.setAutoAssignPaTrackingNumber(AUTO_ASSIGN_PA_TRACKING_NUMBER);
		basicInfoAuth.setExternalTrackingNumber(EXTERNAL_TRACKING_NUMBER);
		basicInfoAuth.setAuthNumberOfFills(AUTH_NUMBER_OF_FILLS);
		basicInfoAuth.setAuthStartDate(AUTH_START_DATE);
		basicInfoAuth.setAuthEndDate(AUTH_END_DATE);
		basicInfoAuth.setAuthPriorityCode(AUTH_PRIORITY_CODE);
		basicInfoAuth.setAuthRequestStartDateTime(AUTH_REQUEST_START_DATE_TIME);
		basicInfoAuth.setAuthRequestEndDateTime(AUTH_REQUEST_END_DATE_TIME);
		basicInfoAuth.setPaTrackingNumberOnClaimRequired(false);
		basicInfoAuth.setComments(COMMENTS);
		basicInfoAuth.setStatusId("0");
		advancedInfoAuth.setProviderAction(PROVIDER_ACTION);
		advancedInfoAuth.setProviders(getProviders());
		advancedInfoAuth.setPrescriberAction(PRESCRIBER_ACTION);
		advancedInfoAuth.setPrescribers(getPrescribers());
		advancedInfoAuth.setAdjustOrUpdateOrOverride(new AdjustOrUpdateOrOverride("NO", "XP"));
		advancedInfoAuth.setEdits(getEdits());
		updateMemberAuthRequest.setBasicInfo(basicInfoAuth);
		updateMemberAuthRequest.setAdvanceInfo(advancedInfoAuth);

		return updateMemberAuthRequest;
	}

	public MemberAuthResponse setUpAuthorizationResponse() {

		final MemberAuthResponse memberAuthResponse = new MemberAuthResponse();

		final BasicInfoAuth basicInfoAuth = new BasicInfoAuth();
		final AdvancedInfoAuth advancedInfoAuth = new AdvancedInfoAuth();

		basicInfoAuth.setMemberPriorAuthId(MEMBER_PRIOR_AUTH_ID);
		basicInfoAuth.setMemberId(String.valueOf(MEMBER_ID));
		basicInfoAuth.setAuthLevelCode(AUTH_LEVEL_CODE);
		basicInfoAuth.setOutcomeCode(OUTCOME_CODE);
		basicInfoAuth.setOutcomeReasonCode(OUTCOME_REASON_CODE);
		basicInfoAuth.setAuthReasonCode(AUTH_REASON_CODE);
		basicInfoAuth.setAuthByInfo(AUTH_BY_INFO);
		basicInfoAuth.setPrescriberInfo(PRESCRIBER_INFO);
		basicInfoAuth.setPaTrackingNumber(PA_TRACKING_NUMBER);
		basicInfoAuth.setAutoAssignPaTrackingNumber(AUTO_ASSIGN_PA_TRACKING_NUMBER);
		basicInfoAuth.setExternalTrackingNumber(EXTERNAL_TRACKING_NUMBER);
		basicInfoAuth.setAuthNumberOfFills(AUTH_NUMBER_OF_FILLS);
		basicInfoAuth.setAuthStartDate(AUTH_START_DATE);
		basicInfoAuth.setAuthEndDate(AUTH_END_DATE);
		basicInfoAuth.setAuthPriorityCode(AUTH_PRIORITY_CODE);
		basicInfoAuth.setAuthRequestStartDateTime(AUTH_REQUEST_START_DATE_TIME);
		basicInfoAuth.setAuthRequestEndDateTime(AUTH_REQUEST_END_DATE_TIME);
		basicInfoAuth.setComments(COMMENTS);
		advancedInfoAuth.setProviderAction(PROVIDER_ACTION);
		advancedInfoAuth.setPrescriberAction(PRESCRIBER_ACTION);
		return memberAuthResponse;
	}

	public MemberAuthSearchResponse setUpMemberAuthSearchResponse() {

		final MemberAuthSearchResponse memberAuthSearchResponse = new MemberAuthSearchResponse();
		memberAuthSearchResponse.setMemberPriorAuthId(String.valueOf(MEMBER_PRIOR_AUTH_ID));
		memberAuthSearchResponse.setAuthName("DrugName-In Process");
		memberAuthSearchResponse.setAuthorizationType(
				new CodeDescriptionDTO(AUTH_TYPE_CODE, "Prior Authorization"));
		memberAuthSearchResponse.setAuthorizationLevel(
				new CodeDescriptionDTO(AUTH_LEVEL_CODE, "Level 1"));
		memberAuthSearchResponse.setAuthorizationPriority(
				new CodeDescriptionDTO(AUTH_PRIORITY_CODE, "Standard Priority"));
		memberAuthSearchResponse.setPaTrackingNumber(PA_TRACKING_NUMBER);
		memberAuthSearchResponse.setAutoAssignPaTrackingNumber(AUTO_ASSIGN_PA_TRACKING_NUMBER);
		memberAuthSearchResponse.setAuthNumberOfFills(AUTH_NUMBER_OF_FILLS);
		memberAuthSearchResponse.setAuthStartDate(AUTH_START_DATE);
		memberAuthSearchResponse.setAuthEndDate(AUTH_END_DATE);
		memberAuthSearchResponse.setAuthRequestStartDateTime(AUTH_REQUEST_START_DATE_TIME);
		memberAuthSearchResponse.setAuthRequestEndDateTime(AUTH_REQUEST_END_DATE_TIME);
		memberAuthSearchResponse.setOutcome(new CodeDescriptionDTO("INP", "In Process"));
		memberAuthSearchResponse.setReasonForOutcome(new CodeDescriptionDTO("SR", "Special Request"));
		memberAuthSearchResponse.setAuthByInfo(AUTH_BY_INFO);
		memberAuthSearchResponse.setAuthorizationReason(new CodeDescriptionDTO("ALG", "Allergy"));
		memberAuthSearchResponse.setComments(COMMENTS);
		memberAuthSearchResponse.setPrescriberInfo(PRESCRIBER_INFO);
		memberAuthSearchResponse.setExternalTrackingNumber(EXTERNAL_TRACKING_NUMBER);
		memberAuthSearchResponse.setProviderAction(PROVIDER_ACTION);
		memberAuthSearchResponse.setPrescriberAction(PRESCRIBER_ACTION);

		//        memberAuthResponse.setProviders(getProviders());
		//        memberAuthResponse.setPrescribers(getPrescribers());
		//        memberAuthResponse.setAdjustOrUpdateOrOverride(new AdjustOrUpdateOrOverride("NO","XP"));
		//        memberAuthResponse.setEdits(getEdits());
		return memberAuthSearchResponse;
	}

	public MemberAuth setupMemberAuth() {

		final MemberAuth memberAuth = new MemberAuth();

		memberAuth.setMemberPriorAuthId(MEMBER_PRIOR_AUTH_ID);
		memberAuth.setPbmId(PBM_ID);
		memberAuth.setAuthName("DrugName-In Process");
		memberAuth.setMemberId(MEMBER_ID);
		memberAuth.setAuthTypeCode(AUTH_TYPE_CODE);
		memberAuth.setAuthLevelCode(AUTH_LEVEL_CODE);
		memberAuth.setOutcomeCode(OUTCOME_CODE);
		memberAuth.setOutcomeReasonCode(OUTCOME_REASON_CODE);
		memberAuth.setAuthReasonCode(AUTH_REASON_CODE);
		memberAuth.setAuthByInfo(AUTH_BY_INFO);
		memberAuth.setPrescriberInfo(PRESCRIBER_INFO);
		memberAuth.setPaTrackingNumber(PA_TRACKING_NUMBER);
		memberAuth.setAutoAssignPaTrackingNumber(AUTO_ASSIGN_PA_TRACKING_NUMBER);
		memberAuth.setExternalTrackingNumber(EXTERNAL_TRACKING_NUMBER);
		memberAuth.setAuthNumberOfFills(AUTH_NUMBER_OF_FILLS);
		memberAuth.setAuthStartDate(AUTH_START_DATE);
		memberAuth.setAuthEndDate(AUTH_END_DATE);
		memberAuth.setAuthPriorityCode(AUTH_PRIORITY_CODE);
		memberAuth.setAuthRequestStartDateTime(AUTH_REQUEST_START_DATE_TIME);
		memberAuth.setAuthRequestEndDateTime(AUTH_REQUEST_END_DATE_TIME);
		memberAuth.setCriteriaId(CRITERIA_ID);
		memberAuth.setComments(COMMENTS);
		memberAuth.setPaTrackingNumberOnClaimRequired(PA_TRACKING_NUMBER_ON_CLAIM_REQUIRED);
		memberAuth.setProviderAction(PROVIDER_ACTION);
		memberAuth.setProviders(String.valueOf(getProviders()));
		memberAuth.setPrescriberAction(PRESCRIBER_ACTION);
		memberAuth.setPrescribers(String.valueOf(getPrescribers()));
		memberAuth.setChangeFormularyStatus(CHANGE_FORMULARY_STATUS);
		memberAuth.setChangePreferredDrugStatus(CHANGE_PREFERRED_DRUG_STATUS);
		memberAuth.setEdits(String.valueOf(getEdits()));

		return memberAuth;
	}

	public List<MemberAuth> setUpMemberAuthList() {

		final List<MemberAuth> memberAuths = new ArrayList<>();
		memberAuths.add(setupMemberAuth());
		return memberAuths;
	}

	protected ResponseEntity<List<MemberAuthResponse>> expectedResponse() {

		final List<MemberAuthResponse> authorizationResponses = new ArrayList<>();
		authorizationResponses.add(setUpAuthorizationResponse());
		authorizationResponses.add(setUpAuthorizationResponse());
		final HttpHeaders httpHeader = new HttpHeaders();
		httpHeader.add(ResponseMessages.X_PAGINATION_LIMIT, String.valueOf(1));
		httpHeader.add(ResponseMessages.X_PAGINATION_TOTAL_PAGES, String.valueOf(1));
		httpHeader.add(ResponseMessages.X_PAGINATION_TOTAL_RECORDS, String.valueOf(1));
		httpHeader.add(ResponseMessages.X_PAGINATION_CURRENT_PAGE_NUM, String.valueOf(0));
		httpHeader.add(ResponseMessages.X_PAGINATION_NEXT_PAGE_NUM, String.valueOf(-1));
		httpHeader.add(ResponseMessages.X_PAGINATION_HAS_NEXT_PAGE, String.valueOf(false));
		return new ResponseEntity<>(authorizationResponses, httpHeader, HttpStatus.OK);
	}

	public List<ProviderForAuthorization> getProviders() {

		final List<ProviderForAuthorization> providers = new ArrayList<>();
		providers.add(new ProviderForAuthorization("1"));
		return providers;
	}

	public List<ProviderForAuthorization> getInvalidProviders() {

		final List<ProviderForAuthorization> providers = new ArrayList<>();
		providers.add(new ProviderForAuthorization("123456"));
		return providers;
	}

	public List<PrescriberForAuthorization> getPrescribers() {

		final List<PrescriberForAuthorization> prescribers = new ArrayList<>();
		prescribers.add(new PrescriberForAuthorization("1", "1"));
		return prescribers;
	}

	public List<EditForAuthorization> getEdits() {

		final List<EditForAuthorization> edits = new ArrayList<>();
		edits.add(new EditForAuthorization("Claim $ Min/Max", false, new EditsForAuthorization("1")));
		edits.add(new EditForAuthorization("Claim $ Min/Max", false, new EditsForAuthorization("1")));
		return edits;
	}

	public List<EditForAuthorization> getInvalidEdit() {

		final List<EditForAuthorization> edits = new ArrayList<>();
		edits.add(new EditForAuthorization("Claim $ Min/Max", false, new EditsForAuthorization("456")));
		return edits;
	}
}
