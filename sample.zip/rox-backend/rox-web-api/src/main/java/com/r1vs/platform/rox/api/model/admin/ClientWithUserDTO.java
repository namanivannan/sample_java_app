package com.r1vs.platform.rox.api.model.admin;

import com.r1vs.platform.rox.api.model.application.initiate.UserDTO;

import java.io.Serializable;

public class ClientWithUserDTO implements Serializable {

	private ClientDTO client;

	private UserDTO user;

	public ClientDTO getClient() {

		return client;
	}

	public void setClient(ClientDTO client) {

		this.client = client;
	}

	public UserDTO getUser() {

		return user;
	}

	public void setUser(UserDTO user) {

		this.user = user;
	}
}
