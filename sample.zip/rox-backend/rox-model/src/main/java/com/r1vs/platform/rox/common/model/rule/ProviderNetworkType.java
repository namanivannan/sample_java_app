package com.r1vs.platform.rox.common.model.rule;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@Entity
@Table(name = "provider_network_type")
public class ProviderNetworkType implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "provider_network_type_id", nullable = false)
	private Integer providerNetworkTypeId;

	@Column(name = "description", nullable = false)
	private String description;

	public Integer getProviderNetworkTypeId() {

		return providerNetworkTypeId;
	}

	public void setProviderNetworkTypeId(final Integer providerNetworkTypeId) {

		this.providerNetworkTypeId = providerNetworkTypeId;
	}

	public String getDescription() {

		return description;
	}

	public void setDescription(final String description) {

		this.description = description;
	}

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof ProviderNetworkType)) {
			return false;
		}
		final ProviderNetworkType castOther = (ProviderNetworkType) other;
		return new EqualsBuilder().append(providerNetworkTypeId, castOther.providerNetworkTypeId)
				.append(description, castOther.description).isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(providerNetworkTypeId).append(description).toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("providerNetworkTypeId", providerNetworkTypeId)
				.append("description", description).toString();
	}

}
