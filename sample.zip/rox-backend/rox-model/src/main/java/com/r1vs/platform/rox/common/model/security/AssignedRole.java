package com.r1vs.platform.rox.common.model.security;

import java.io.Serializable;
import java.util.Objects;

/**
 * This represents a role in the system. Normally it is assigned to a user as an association in the user_role table.
 */
public class AssignedRole implements Serializable {

	private static final long serialVersionUID = 6946861372795109092L;

	private String roleName;

	public AssignedRole() {

		super();
	}

	public AssignedRole(final String roleName) {

		super();
		this.roleName = roleName;
	}

	public String getRoleName() {

		return roleName;
	}

	public void setRoleName(final String roleName) {

		this.roleName = roleName;
	}

	@Override
	public int hashCode() {

		return Objects.hash(roleName);
	}

	@Override
	public boolean equals(final Object obj) {

		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final AssignedRole other = (AssignedRole) obj;
		return Objects.equals(roleName, other.roleName);
	}

	@Override
	public String toString() {

		return "AssignedRole [roleName=" + roleName + "]";
	}

}
