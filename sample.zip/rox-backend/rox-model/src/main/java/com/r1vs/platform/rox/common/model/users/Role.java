package com.r1vs.platform.rox.common.model.users;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.*;

import com.r1vs.platform.rox.common.model.AuditedEntity;
import com.r1vs.platform.rox.common.model.business.Status;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "role")
public class Role extends AuditedEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "role_id", nullable = false)
	private Integer roleId;

	@Column(name = "system_name", nullable = false, unique=true, updatable = false)
	private String systemName;

	@Column(name = "name", nullable = false)
	private String name;

	@ManyToMany(cascade = { CascadeType.ALL })
	@JoinTable(name = "role_privilege", joinColumns = { @JoinColumn(name = "role_id") }, inverseJoinColumns = {
			@JoinColumn(name = "privilege_id") })
	private Set<Privilege> privileges;

	@Column(name = "status_id")
	private Integer statusId;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "status_id", nullable = false, insertable = false, updatable = false)
	private Status status;

	public Integer getRoleId() {

		return roleId;
	}

	public void setRoleId(final Integer roleId) {

		this.roleId = roleId;
	}

	public String getSystemName() {

		return systemName;
	}

	public void setSystemName(final String systemName) {

		this.systemName = systemName;
	}

	public String getName() {

		return name;
	}

	public void setName(final String name) {

		this.name = name;
	}

	public Set<Privilege> getPrivileges() {

		return privileges;
	}

	public void setPrivileges(final Set<Privilege> privileges) {

		this.privileges = privileges;
	}

	public Integer getStatusId() {

		return statusId;
	}

	public void setStatusId(Integer statusId) {

		this.statusId = statusId;
	}

	public Status getStatus() {

		return status;
	}

	public void setStatus(Status status) {

		this.status = status;
	}

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof Role)) {
			return false;
		}
		final Role castOther = (Role) other;
		return new EqualsBuilder().append(roleId, castOther.roleId).append(systemName, castOther.systemName)
				.append(statusId, castOther.statusId)
				.append(name, castOther.name).isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(roleId).append(systemName).append(name).append(statusId).toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("roleId", roleId).append("systemName", systemName).append("name", name)
				.append("statusId", statusId)
				.toString();
	}

}
