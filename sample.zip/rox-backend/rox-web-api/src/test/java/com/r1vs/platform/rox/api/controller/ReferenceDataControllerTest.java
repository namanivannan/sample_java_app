package com.r1vs.platform.rox.api.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.r1vs.platform.rox.api.model.application.initiate.EmailDTO;
import com.r1vs.platform.rox.api.model.application.initiate.PhoneDTO;
import com.r1vs.platform.rox.api.model.application.initiate.UpdateBusinessDTO;
import com.r1vs.platform.rox.common.db.repository.business.ApplicationRepository;
import com.r1vs.platform.rox.common.util.StringUtil;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collections;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.is;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@Sql("fixture2.sql")
public class ReferenceDataControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private DBConnection dbConnection;

	private String token;

	@Before
	public void setUp() throws Exception {

		if (StringUtil.isNullOrEmpty(token)) {
			token = dbConnection.loginToDb();
		}
	}

	@Test
	public void givenBusinessTypesStoredInDB_whenListBusinessTypesEndpointIsHit_thenGetListOfBusinessTypesAndReturn200()
			throws Exception {

		mockMvc.perform(MockMvcRequestBuilders.get("/v1/businessType/list")
				.header("x-client-id", "11")
				.header("Authorization", token))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.[0].id", is(0)))
				.andExpect(jsonPath("$.[0].type", is("Corporations")))
				.andExpect(jsonPath("$.[1].id", is(1)))
				.andExpect(jsonPath("$.[1].type", is("S Corporations")))
				.andExpect(jsonPath("$.[2].id", is(2)))
				.andExpect(jsonPath("$.[2].type", is("Sole Proprietorships")))
				.andExpect(jsonPath("$.[3].id", is(3)))
				.andExpect(jsonPath("$.[3].type", is("Partnerships")))
				.andExpect(jsonPath("$.[4].id", is(4)))
				.andExpect(jsonPath("$.[4].type", is("Limited Liability Company (LLC)")))
				.andExpect(jsonPath("$.[5].id", is(5)))
				.andExpect(jsonPath("$.[5].type", is("Limited Liability Corporation")))
				.andDo(print());
	}

	@Test
	public void
			givenApplicationStatusStoredInDB_whenListApplicationStatusEndpointIsHit_thenGetListOfApplicationStatusAndReturn200()
					throws Exception {

		mockMvc.perform(MockMvcRequestBuilders.get("/v1/applicationStatus/list")
				.header("x-client-id", "11")
				.header("Authorization", token))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.[0].id", is(0)))
				.andExpect(jsonPath("$.[0].status", is("New")))
				.andExpect(jsonPath("$.[1].id", is(1)))
				.andExpect(jsonPath("$.[1].status", is("Under Review")))
				.andExpect(jsonPath("$.[2].id", is(2)))
				.andExpect(jsonPath("$.[2].status", is("Pending")))
				.andExpect(jsonPath("$.[3].id", is(3)))
				.andExpect(jsonPath("$.[3].status", is("Approved")))
				.andExpect(jsonPath("$.[4].id", is(4)))
				.andExpect(jsonPath("$.[4].status", is("Declined")))
				.andExpect(jsonPath("$.[5].id", is(5)))
				.andExpect(jsonPath("$.[5].status", is("Cancelled")))
				.andDo(print());
	}

	@Test
	public void givenIndustryTypesStoredInDB_whenListIndustryTypesEndpointIsHit_thenGetListOfIndustryTypesAndReturn200()
			throws Exception {

		mockMvc.perform(MockMvcRequestBuilders.get("/v1/industryType/list")
				.header("x-client-id", "11")
				.header("Authorization", token))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.[0].id", is(0)))
				.andExpect(jsonPath("$.[0].type", is("Transportation")))
				.andDo(print());
	}

	@Test
	public void givenStateAbbreviationStoredInDB_whenListStateAbbreviationEndpointIsHit_thenGetListOfStateAbbreviationAndReturn200()
			throws Exception {

		mockMvc.perform(MockMvcRequestBuilders.get("/v1/stateAbbreviation/list")
						.header("x-client-id", "11")
						.header("Authorization", token))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.[0].id", is(1)))
				.andExpect(jsonPath("$.[0].stateAbbreviation", is("AL")))
				.andExpect(jsonPath("$.[0].state", is("Alabama")))
				.andExpect(jsonPath("$.[1].id", is(2)))
				.andExpect(jsonPath("$.[1].stateAbbreviation", is("AK")))
				.andExpect(jsonPath("$.[1].state", is("Alaska")))
				.andExpect(jsonPath("$.[2].id", is(3)))
				.andExpect(jsonPath("$.[2].stateAbbreviation", is("AZ")))
				.andExpect(jsonPath("$.[2].state", is("Arizona")))
				.andExpect(jsonPath("$.[3].id", is(4)))
				.andExpect(jsonPath("$.[3].stateAbbreviation", is("AR")))
				.andExpect(jsonPath("$.[3].state", is("Arkansas")))
				.andDo(print());
	}
}