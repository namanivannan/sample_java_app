package com.r1vs.platform.rox.common.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@Entity
@Table(name = "reject_code")
public class RejectCodeForEdit implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "reject_code_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	@NotNull
	private Integer rejectCodeId;

	@Column(name = "external_reject_code_id")
	@NotNull
	@Size(min = 1, max = 4)
	private String externalRejectCodeId;

	@Column(name = "ncpdp_description")
	@Size(max = 255)
	@NotNull
	private String ncpdpDescription;

	@Column(name = "description")
	@Size(max = 255)
	private String description;

	public Integer getRejectCodeId() {

		return rejectCodeId;
	}

	public void setRejectCodeId(final Integer rejectCodeId) {

		this.rejectCodeId = rejectCodeId;
	}

	public String getExternalRejectCodeId() {

		return externalRejectCodeId;
	}

	public void setExternalRejectCodeId(final String externalRejectCodeId) {

		this.externalRejectCodeId = externalRejectCodeId;
	}

	/**
	 * General description for error (likely ambiguous).
	 *
	 * @return ncpdp description
	 */
	public String getNcpdpDescription() {

		return ncpdpDescription;
	}

	public void setNcpdpDescription(final String ncpdpDescription) {

		this.ncpdpDescription = ncpdpDescription;
	}

	/**
	 * Verbose description for error.
	 *
	 * @return description
	 */
	public String getDescription() {

		return description;
	}

	public void setDescription(final String description) {

		this.description = description;
	}

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof RejectCodeForEdit)) {
			return false;
		}
		final RejectCodeForEdit castOther = (RejectCodeForEdit) other;
		return new EqualsBuilder().append(rejectCodeId, castOther.rejectCodeId)
				.append(externalRejectCodeId, castOther.externalRejectCodeId)
				.append(ncpdpDescription, castOther.ncpdpDescription).append(description, castOther.description)
				.isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(rejectCodeId).append(externalRejectCodeId).append(ncpdpDescription)
				.append(description).toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("rejectCodeId", rejectCodeId)
				.append("externalRejectCodeId", externalRejectCodeId).append("ncpdpDescription", ncpdpDescription)
				.append("description", description).toString();
	}
}
