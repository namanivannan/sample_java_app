package com.r1vs.platform.rox.api.serialization;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.r1vs.platform.rox.common.util.DateUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.time.OffsetDateTime;
import java.time.format.DateTimeParseException;

public class OffsetDateTimeDeserializer extends StdDeserializer<OffsetDateTime> {

	private static final Logger LOGGER = LoggerFactory.getLogger(LocalDateTimeDeserializer.class);

	private static final long serialVersionUID = -2706085639361988373L;

	public OffsetDateTimeDeserializer() {

		this(null);
	}

	public OffsetDateTimeDeserializer(final Class<?> c) {

		super(c);
	}

	@Override
	public OffsetDateTime deserialize(final JsonParser parser, final DeserializationContext context)
			throws IOException, JsonProcessingException {

		final String input = parser.getText();
		try {
			return OffsetDateTime.parse(input, DateUtil.RESPONSE_DATE_TIME_FORMATTER);
		} catch (final DateTimeParseException e) {
			LOGGER.error(e.getLocalizedMessage());
			throw new IOException(e);
		}
	}

}
