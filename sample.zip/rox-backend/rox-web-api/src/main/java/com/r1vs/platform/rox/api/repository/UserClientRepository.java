package com.r1vs.platform.rox.api.repository;

import com.r1vs.platform.rox.common.model.users.UserClient;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserClientRepository extends JpaRepository<UserClient, Integer> {

	UserClient findByUserIdAndClientId(int userId, int clientId);
}
