package com.r1vs.platform.rox.common.model.users;

import com.r1vs.platform.rox.common.model.AuditedEntity;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "access_entity_privilege")
public class AccessEntityPrivilege extends AuditedEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "access_entity_privilege_id", nullable = false)
	private Integer accessEntityPrivilegeId;

	@Column(name = "domain_code", nullable = false)
	private String domainCode;

	@Column(name = "entity_code", nullable = false)
	private String entityCode;

	@Column(name = "action", nullable = false)
	private String action;

	@Column(name = "action_description", nullable = false)
	private String actionDescription;

	@Column(name = "access", nullable = false)
	private String access;

	@Column(name = "privilege_id", nullable = false)
	private Integer privilegeId;

	@Column(name = "access_entity_id", nullable = false)
	private Integer accessEntityId;

	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(updatable = false, insertable = false, name = "privilege_id", referencedColumnName = "privilege_id")
	private Privilege privilege;

	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(updatable = false, insertable = false, name = "access_entity_id",
			referencedColumnName = "access_entity_id")
	private AccessEntity accessEntity;

	public Integer getAccessEntityPrivilegeId() {

		return accessEntityPrivilegeId;
	}

	public void setAccessEntityPrivilegeId(Integer accessEntityPrivilegeId) {

		this.accessEntityPrivilegeId = accessEntityPrivilegeId;
	}

	public String getDomainCode() {

		return domainCode;
	}

	public void setDomainCode(String domainCode) {

		this.domainCode = domainCode;
	}

	public String getEntityCode() {

		return entityCode;
	}

	public void setEntityCode(String entityCode) {

		this.entityCode = entityCode;
	}

	public String getAction() {

		return action;
	}

	public void setAction(String action) {

		this.action = action;
	}

	public String getActionDescription() {

		return actionDescription;
	}

	public void setActionDescription(String actionDescription) {

		this.actionDescription = actionDescription;
	}

	public String getAccess() {

		return access;
	}

	public void setAccess(String access) {

		this.access = access;
	}

	public Integer getPrivilegeId() {

		return privilegeId;
	}

	public void setPrivilegeId(Integer privilegeId) {

		this.privilegeId = privilegeId;
	}

	public Integer getAccessEntityId() {

		return accessEntityId;
	}

	public void setAccessEntityId(Integer accessEntityId) {

		this.accessEntityId = accessEntityId;
	}

	public Privilege getPrivilege() {

		return privilege;
	}

	public void setPrivilege(Privilege privilege) {

		this.privilege = privilege;
	}

	public AccessEntity getAccessEntity() {

		return accessEntity;
	}

	public void setAccessEntity(AccessEntity accessEntity) {

		this.accessEntity = accessEntity;
	}
}
