package com.r1vs.platform.rox.api.repository;

import com.r1vs.platform.rox.common.model.users.UserAudit;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserAuditRepository extends JpaRepository<UserAudit, Long> {

}
