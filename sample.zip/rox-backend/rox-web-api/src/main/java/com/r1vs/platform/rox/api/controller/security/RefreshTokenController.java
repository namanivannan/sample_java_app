package com.r1vs.platform.rox.api.controller.security;

import com.r1vs.platform.rox.api.model.security.RefreshTokenRequest;
import com.r1vs.platform.rox.api.security.SecurityConstants;
import com.r1vs.platform.rox.api.util.TokenUtility;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;

@RestController
@RequestMapping(value = "/v1", produces = { MediaType.APPLICATION_JSON_VALUE })
@Tag(name = "token")
public class RefreshTokenController {

	@Value("${roxwrite.web_api.auth_token_expiration}")
	private Long authTokenExpiration;

	@PostMapping(value = "/token/refresh")
	@Operation(summary = "Refresh token Endpoint.")
	public ResponseEntity<String> getNewAuthToken(@RequestBody final RefreshTokenRequest refreshTokenRequest)
			throws Exception {

		String refreshToken = refreshTokenRequest.getToken();

		if (refreshToken == null) {
			return new ResponseEntity<String>("", HttpStatus.FORBIDDEN);
		}

		refreshToken = refreshToken.replace(SecurityConstants.TOKEN_PREFIX, "");
		final Claims claims =
				Jwts.parser().setSigningKey(SecurityConstants.SECRET.getBytes()).parseClaimsJws(refreshToken)
						.getBody();

		if (!TokenUtility.isRefreshToken(claims)) {
			return new ResponseEntity<String>("", HttpStatus.FORBIDDEN);
		}

		final String userName = claims.getSubject();

		final String authToken = TokenUtility.buildAuthToken(userName, authTokenExpiration);

		final HashMap<String, String> tokens = new HashMap<>();
		tokens.put(SecurityConstants.AUTH_STRING, authToken);

		final String newAuthToken = TokenUtility.createResponse(tokens);

		return new ResponseEntity<String>(newAuthToken, HttpStatus.OK);
	}

}
