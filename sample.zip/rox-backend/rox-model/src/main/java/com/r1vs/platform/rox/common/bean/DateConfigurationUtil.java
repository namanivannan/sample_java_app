package com.r1vs.platform.rox.common.bean;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;

import com.r1vs.platform.rox.common.util.FieldSetDateMapperFormatter;
import org.springframework.context.annotation.Bean;

public final class DateConfigurationUtil {

	public static final String MM_DD_YYYY_FORMAT = "MM-dd-yyyy";

	public static final String MM_DD_YYYY_HOUR_FORMAT = "MM-dd-yyyy hh:mm:ss";

	public static final String YYYYMMDD_FORMAT = "yyyyMMdd";

	public static final String YYYYMMDD_WITH_DASHES_FORMAT = "yyyy-MM-dd";

	public static final String MMDDYYYY_FORMAT = "MMddyyyy";

	public static final String FOREVER_DATE = "12-31-9999";

	private DateConfigurationUtil() {

	}

	@Bean
	public static DateTimeFormatter dateFormatter() {

		return DateTimeFormatter.ofPattern(MM_DD_YYYY_FORMAT);
	}

	@Bean
	public static DateTimeFormatter dateFormatterRoxLists() {

		return DateTimeFormatter.ofPattern(MM_DD_YYYY_HOUR_FORMAT);
	}

	@Bean
	public static DateTimeFormatter yyyyMMddDateFormatter() {

		return DateTimeFormatter.ofPattern(YYYYMMDD_FORMAT);

	}

	@Bean
	public static DateTimeFormatter yyyyMMddDateWithDashesFormatter() {

		return DateTimeFormatter.ofPattern(YYYYMMDD_WITH_DASHES_FORMAT);

	}

	@Bean
	public static FieldSetDateMapperFormatter mmddyyyyDateFormatter() {

		return new FieldSetDateMapperFormatter(MMDDYYYY_FORMAT);
	}

	@Bean
	public static FieldSetDateMapperFormatter yyyyMMddFieldSetDateMapperFormatter() {

		return new FieldSetDateMapperFormatter(YYYYMMDD_FORMAT);
	}

	@Bean
	public static FieldSetDateMapperFormatter yyyyMMddWithDashsesFieldSetDateMapperFormatter() {

		return new FieldSetDateMapperFormatter(YYYYMMDD_WITH_DASHES_FORMAT);
	}

	@Bean
	public static LocalDate foreverLocalDate() {

		return LocalDate.of(9999, Month.DECEMBER, 31);
	}

	@Bean
	public static LocalDateTime foreverLocalDateTime() {

		return LocalDateTime.of(9999, Month.DECEMBER, 31, 0, 0, 0);
	}

	@Bean
	public static OffsetDateTime foreverOffsetDateTime() {

		return OffsetDateTime
				.of(DateConfigurationUtil.foreverLocalDateTime(), ZoneOffset.UTC);
	}
}
