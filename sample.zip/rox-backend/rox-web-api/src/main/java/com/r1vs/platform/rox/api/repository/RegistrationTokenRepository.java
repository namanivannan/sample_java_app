package com.r1vs.platform.rox.api.repository;

import com.r1vs.platform.rox.common.model.users.RegistrationToken;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RegistrationTokenRepository extends JpaRepository<RegistrationToken, Long> {

	RegistrationToken findByUserId(final Integer userId);

	RegistrationToken findByToken(final String token);

	RegistrationToken findByUserIdAndToken(final Integer userId, String token);
}
