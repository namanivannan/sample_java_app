package com.r1vs.platform.rox.api.controller;

import com.r1vs.platform.rox.api.model.application.ds.InteractionHolderForTableDTO;
import com.r1vs.platform.rox.api.model.application.ds.InteractionResponseDTO;
import com.r1vs.platform.rox.api.model.interaction.InteractionResponseSearchParams;
import com.r1vs.platform.rox.api.processor.InteractionHolderForTableProcessor;
import com.r1vs.platform.rox.api.processor.InteractionResponseProcessor;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.UUID;

import static com.r1vs.platform.rox.api.constants.ControllerConstants.*;
import static com.r1vs.platform.rox.api.util.ControllerUtils.getPageableFromHeaderParams;
import static com.r1vs.platform.rox.api.util.InterceptorConstants.CLIENT_ID;

@CrossOrigin
@RestController
@RequestMapping(value = "/v1", produces = { MediaType.APPLICATION_JSON_VALUE })
@Tag(name = "Application", description = "Application Service")
public class InteractionResponsesController {

	@Autowired
	private InteractionResponseProcessor interactionResponseProcessor;

	@Autowired
	private InteractionHolderForTableProcessor interactionHolderForTableProcessor;

	private static final Logger LOGGER = LoggerFactory.getLogger(InteractionResponsesController.class);

	@GetMapping("/applications/{applicationId}/interactionResponses")
	public ResponseEntity<List<InteractionResponseDTO>> getInteractions(
			@RequestHeader(CLIENT_ID) String clientId,
			@RequestHeader(value = X_PAGINATION_LIMIT, defaultValue = "20") Integer pageLimit,
			@RequestHeader(value = X_PAGINATION_NUM, defaultValue = "0") Integer pageNumber,
			@RequestHeader(value = X_PAGINATION_SORT, defaultValue = "createdAt,desc") String sortingParam,
			@PathVariable UUID applicationId,
			@ModelAttribute @Valid InteractionResponseSearchParams searchRequest) {

		Pageable pageParams = getPageableFromHeaderParams(pageLimit, pageNumber, sortingParam);

		return interactionResponseProcessor.getInteractions(clientId, applicationId, searchRequest, pageParams);
	}

	/*@GetMapping("/applications/{applicationId}/interactionResponsesPerEntity")
	public ResponseEntity<List<InteractionHolderForTableDTO>> getInteractionsPerEntity(
			@RequestHeader(CLIENT_ID) String clientId,
			@RequestHeader(value = X_PAGINATION_LIMIT, defaultValue = "20") Integer pageLimit,
			@RequestHeader(value = X_PAGINATION_NUM, defaultValue = "0") Integer pageNumber,
			@RequestHeader(value = X_PAGINATION_SORT, defaultValue = "createdAt,desc") String sortingParam,
			@PathVariable UUID applicationId,
			@ModelAttribute @Valid InteractionResponseSearchParams searchRequest) {
	
		Pageable pageParams = getPageableFromHeaderParams(pageLimit, pageNumber, sortingParam);
	
		return interactionHolderForTableProcessor.getInteractionHolders(clientId, applicationId, searchRequest, pageParams);
	}*/
}
