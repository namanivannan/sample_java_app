package com.r1vs.platform.rox.common.model.systemhierarchy;

import com.r1vs.platform.rox.common.model.BitemporalEntity;
import com.r1vs.platform.rox.common.model.business.Client;
import com.r1vs.platform.rox.common.model.business.Status;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

@Entity
@Table(name = "client_config")
@EntityListeners(AuditingEntityListener.class)
public class ClientConfig extends BitemporalEntity implements Serializable, HierarchyConfig {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "client_config_id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer clientConfigId;

	@Column(name = "client_id")
	@NotNull
	private Integer clientId;

	// allow zero Usual and Customary
	@Column(name = "allow_zero_u_and_c")
	private Boolean allowZeroUAndC;

	@Column(name = "claim_history_window")
	private Integer claimHistoryWindow;

	@Column(name = "default_group_id")
	private Integer defaultGroupId;

	@Column(name = "pcn_usage")
	private Integer pcnUsage;

	@Column(name = "contact_json")
	private String contactJson;

	@Column(name = "require_group_id")
	@NotNull
	private boolean requireGroupId;

	@Column(name = "require_plan_id")
	@NotNull
	private boolean requirePlanId;

	@Column(name = "status_id", nullable = false)
	@NotNull
	private Integer statusId;

	@Column(name = "vendor_config")
	private String vendorConfig;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "client_id", nullable = false, insertable = false, updatable = false)
	private Client client;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "status_id", nullable = false, insertable = false, updatable = false)
	private Status status;

	public Integer getClientConfigId() {

		return clientConfigId;
	}

	public void setClientConfigId(final Integer clientConfigId) {

		this.clientConfigId = clientConfigId;
	}

	public Integer getClientId() {

		return clientId;
	}

	public void setClientId(final Integer clientId) {

		this.clientId = clientId;
	}

	public Boolean getAllowZeroUAndC() {

		return allowZeroUAndC;
	}

	public void setAllowZeroUAndC(final Boolean allowZeroUAndC) {

		this.allowZeroUAndC = allowZeroUAndC;
	}

	public Integer getDefaultGroupId() {

		return defaultGroupId;
	}

	public void setDefaultGroupId(final Integer defaultGroupId) {

		this.defaultGroupId = defaultGroupId;
	}

	public Integer getPcnUsage() {

		return pcnUsage;
	}

	public void setPcnUsage(final Integer pcnUsage) {

		this.pcnUsage = pcnUsage;
	}

	public String getContactJson() {

		return contactJson;
	}

	public void setContactJson(final String contactJson) {

		this.contactJson = contactJson;
	}

	public boolean getRequireGroupId() {

		return requireGroupId;
	}

	public void setRequireGroupId(final boolean requireGroupId) {

		this.requireGroupId = requireGroupId;
	}

	public boolean getRequirePlanId() {

		return requirePlanId;
	}

	public void setRequirePlanId(final boolean requirePlanId) {

		this.requirePlanId = requirePlanId;
	}

	public Integer getStatusId() {

		return statusId;
	}

	public void setStatusId(final Integer statusId) {

		this.statusId = statusId;
	}

	public Client getClient() {

		return client;
	}

	public void setClient(final Client client) {

		this.client = client;
	}

	public Status getStatus() {

		return status;
	}

	public void setStatus(final Status status) {

		this.status = status;
	}

	public String getVendorConfig() {

		return vendorConfig;
	}

	public void setVendorConfig(String vendorConfig) {

		this.vendorConfig = vendorConfig;
	}

	/**
	 * Get the number of months to look back when querying Claim History
	 *
	 * @return number of months
	 */
	public Integer getClaimHistoryWindow() {

		return claimHistoryWindow;
	}

	public void setClaimHistoryWindow(final Integer claimHistoryWindow) {

		this.claimHistoryWindow = claimHistoryWindow;
	}

	/**
	 * Note: Regenerating equals, hashCode, and toString may re-introduce purposely removed related entities which cause
	 * lazy load exceptions after session has been closed. Please exclude relationships from these methods.
	 */

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof ClientConfig)) {
			return false;
		}
		final ClientConfig castOther = (ClientConfig) other;
		return new EqualsBuilder().append(clientConfigId, castOther.clientConfigId).append(clientId, castOther.clientId)
				.append(allowZeroUAndC, castOther.allowZeroUAndC)
				.append(claimHistoryWindow, castOther.claimHistoryWindow)
				.append(defaultGroupId, castOther.defaultGroupId).append(pcnUsage, castOther.pcnUsage)
				.append(contactJson, castOther.contactJson).append(requireGroupId, castOther.requireGroupId)
				.append(requirePlanId, castOther.requirePlanId).append(statusId, castOther.statusId)
				.append(vendorConfig, castOther.vendorConfig).isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(clientConfigId).append(clientId).append(allowZeroUAndC)
				.append(claimHistoryWindow)
				.append(defaultGroupId).append(pcnUsage).append(contactJson).append(requireGroupId)
				.append(requirePlanId).append(statusId).append(vendorConfig).toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("clientConfigId", clientConfigId).append("clientId", clientId)
				.append("allowZeroUAndC", allowZeroUAndC).append("claimHistoryWindow", claimHistoryWindow)
				.append("defaultGroupId", defaultGroupId).append("pcnUsage", pcnUsage)
				.append("contactJson", contactJson).append("requireGroupId", requireGroupId)
				.append("requirePlanId", requirePlanId).append("statusId", statusId)
				.append("vendorConfig", vendorConfig).toString();
	}
}
