package com.r1vs.platform.rox.common.model.business;

import com.r1vs.platform.rox.common.model.AuditedEntity;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "business")
@EntityListeners(AuditingEntityListener.class)
public class Business extends AuditedEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@OneToOne
	@JoinColumn(name = "application_id", nullable = false)
	private Application application;

	@Column(name = "name")
	private String name;

	@Column(name = "website")
	private String website;

	@Column(name = "dba_name")
	private String dbaName;

	@OneToOne
	@JoinColumn(name = "business_type_id", nullable = false)
	private BusinessType businessType;

	@OneToOne
	@JoinColumn(name = "industry_type_id", nullable = false)
	private IndustryType industryType;

	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "business_address",
			joinColumns = @JoinColumn(name = "business_id"),
			inverseJoinColumns = @JoinColumn(name = "address_id"))
	private List<Address> addresses;

	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "business_email",
			joinColumns = @JoinColumn(name = "business_id"),
			inverseJoinColumns = @JoinColumn(name = "email_id"))
	private List<Email> emails;

	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "business_identification",
			joinColumns = @JoinColumn(name = "business_id"),
			inverseJoinColumns = @JoinColumn(name = "identification_id"))
	private List<Identification> identifications;

	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "business_phone",
			joinColumns = @JoinColumn(name = "business_id"),
			inverseJoinColumns = @JoinColumn(name = "phone_id"))
	@JoinColumn(name = "phone_id", nullable = false)
	private List<Phone> phones;

	@Column(name = "dot_number")
	private String dotNumber;

	@Column(name = "mc_number")
	private String mcNumber;

	@Column(name = "category_id")
	@Enumerated(EnumType.ORDINAL)
	private BusinessCategory categoryId;

	public Long getId() {

		return this.id;
	}

	public void setId(Long id) {

		this.id = id;
	}

	public Application getApplication() {

		return application;
	}

	public void setApplication(Application application) {

		this.application = application;
	}

	public String getName() {

		return this.name;
	}

	public void setName(String name) {

		this.name = name;
	}

	public String getWebsite() {

		return website;
	}

	public void setWebsite(String website) {

		this.website = website;
	}

	public String getDbaName() {

		return dbaName;
	}

	public void setDbaName(String dbaName) {

		this.dbaName = dbaName;
	}

	public BusinessType getBusinessType() {

		return businessType;
	}

	public void setBusinessType(BusinessType businessType) {

		this.businessType = businessType;
	}

	public IndustryType getIndustryType() {

		return industryType;
	}

	public void setIndustryType(IndustryType industryType) {

		this.industryType = industryType;
	}

	public List<Address> getAddresses() {

		return addresses;
	}

	public void setAddresses(List<Address> address) {

		this.addresses = address;
	}

	public List<Email> getEmails() {

		return emails;
	}

	public void setEmails(List<Email> email) {

		this.emails = email;
	}

	public List<Identification> getIdentifications() {

		return identifications;
	}

	public void setIdentifications(List<Identification> identification) {

		this.identifications = identification;
	}

	public List<Phone> getPhones() {

		return phones;
	}

	public void setPhones(List<Phone> phone) {

		this.phones = phone;
	}

	public String getDotNumber() {

		return this.dotNumber;
	}

	public void setDotNumber(String dotNumber) {

		this.dotNumber = dotNumber;
	}

	public String getMcNumber() {

		return this.mcNumber;
	}

	public void setMcNumber(String mcNumber) {

		this.mcNumber = mcNumber;
	}

	public BusinessCategory getCategoryId() {

		return this.categoryId;
	}

	public void setCategoryId(BusinessCategory categoryId) {

		this.categoryId = categoryId;
	}
}
