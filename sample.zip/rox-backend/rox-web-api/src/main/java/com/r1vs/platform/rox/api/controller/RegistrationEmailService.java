package com.r1vs.platform.rox.api.controller;

import com.r1vs.platform.rox.api.PropertiesConfig;
import com.r1vs.platform.rox.common.model.users.User;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;

import javax.mail.internet.MimeMessage;

@Component
public class RegistrationEmailService {

	private static final Logger LOGGER = LoggerFactory.getLogger(RegistrationEmailService.class);

	private static final String UTF8 = "UTF-8";

	@Autowired
	private PropertiesConfig propertiesConfig;

	@Value("${roxwrite.from-address}")
	private String fromAddress;

	@Value("${roxwrite.user-registration.email.confirmation-path}")
	private String confirmationPath;

	@Value("${roxwrite.user-registration.email.subject}")
	private String subject;

	@Autowired
	private JavaMailSender mailSender;

	public void sendEmail(final User user, final String token) {

		final String recipientAddress = user.getEmail();
		final String fullRegistrationUrl = propertiesConfig.getRoxwriteDomain() + confirmationPath + token;

		String htmlMsg = StringUtils.EMPTY;
		try {

			final MimeMessage message = mailSender.createMimeMessage();
			final MimeMessageHelper helper = new MimeMessageHelper(message, UTF8);

			helper.setFrom(fromAddress);
			helper.setTo(recipientAddress);
			helper.setSubject(subject);

			final StringBuilder builder = new StringBuilder();
			builder.append("<p>Hi " + user.getFirstName() + " " + user.getLastName() + ",</p>");
			builder.append("<p>Your user name is <b>" + user.getUsername() + "</b>.</p>");
			builder.append("<p>You are invited to join RoxWrite. <a href=\"");
			builder.append(fullRegistrationUrl);
			builder.append("\">Click here</a> to sign in.<p>");

			htmlMsg = builder.toString();

			helper.setText(htmlMsg, true);

			mailSender.send(message);

			LOGGER.info("Sending user registration e-mail from: {} to address: {} with body: {}", fromAddress,
					recipientAddress, htmlMsg);

		} catch (Exception e) {

			LOGGER.error("Could not send user registration e-mail from: {} to address: {} with body: {}", fromAddress,
					recipientAddress, htmlMsg, e);

		}
	}

}
