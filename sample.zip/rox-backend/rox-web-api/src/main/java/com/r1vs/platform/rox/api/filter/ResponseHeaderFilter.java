package com.r1vs.platform.rox.api.filter;

import com.r1vs.platform.rox.api.util.ApiVersionUtil;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@Component
public class ResponseHeaderFilter extends OncePerRequestFilter {

	private static final String API_VERSION_KEY = "X-API-VERSION";

	private static final String API_WHITELISTED_HEADERS = "X-PAGINATION-NUM, " + "X-PAGINATION-LIMIT, "
			+ "X-PAGINATION-TOTAL-RECORDS, " + "X-PAGINATION-TOTAL-PAGES, " + "X-PAGINATION-CURRENT-PAGE-NUM, "
			+ "X-PAGINATION-HAS-NEXT-PAGE, " + "X-PAGINATION-NEXT-PAGE-NUM";

	private static String apiVersionValue = null;

	static {

		// Loads the version only once during application start-up
		apiVersionValue = ApiVersionUtil.getModuleVersionNumber();

	}

	@Override
	protected void doFilterInternal(final HttpServletRequest request, final HttpServletResponse response,
			final FilterChain filterChain) throws ServletException, IOException {

		response.setHeader(API_VERSION_KEY, apiVersionValue);
		response.setHeader("Access-Control-Expose-Headers", API_WHITELISTED_HEADERS);
		filterChain.doFilter(request, response);
	}

}
