package com.r1vs.platform.rox.api.defaultvaluesetter.metadata;

import com.r1vs.platform.rox.api.defaultvaluesetter.RoxWriteWebApiDefaultValueSetter;
import com.r1vs.platform.rox.api.model.metadata.UpdateMetadataRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class UpdateMetadataDefaultValueSetter implements RoxWriteWebApiDefaultValueSetter<UpdateMetadataRequest> {

	@Autowired
	private MetadataDefaultValueSetterSuplier defaultValueSetterSuplier;

	private MetadataDefaultValueSetter defaultValueSetter;

	@Override
	public void setDefaultValues(final UpdateMetadataRequest createMetadataRequest) {

		defaultValueSetter = suplySetter(createMetadataRequest);
		defaultValueSetter.setDefaultValues(createMetadataRequest);
	}

	public MetadataDefaultValueSetter suplySetter(final UpdateMetadataRequest updateMetadataRequest) {

		return defaultValueSetterSuplier.supplyValidator(updateMetadataRequest.getMetadataCategoryId());
	}

	public void setDefaultValueSetterSuplier(final MetadataDefaultValueSetterSuplier defaultValueSetterSuplier) {

		this.defaultValueSetterSuplier = defaultValueSetterSuplier;
	}

}
