package com.r1vs.platform.rox.api.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.r1vs.platform.rox.api.exception.RoxApiException;
import com.r1vs.platform.rox.api.model.application.initiate.ApplicationDTO;
import com.r1vs.platform.rox.api.model.application.initiate.ApplicationStatusChangeDTO;
import com.r1vs.platform.rox.common.db.repository.business.*;
import com.r1vs.platform.rox.common.model.business.Application;
import com.r1vs.platform.rox.common.model.business.Business;
import com.r1vs.platform.rox.common.model.business.Client;
import com.r1vs.platform.rox.common.model.business.Owner;
import org.apache.commons.io.IOUtils;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.data.domain.AuditorAware;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.catchThrowable;
import static org.junit.jupiter.api.Assertions.assertEquals;

@SpringBootTest
@RunWith(SpringRunner.class)
@ActiveProfiles("test")
@AutoConfigureMockMvc
/*@Ignore("Tests not working due to audit and spring context setup missing")*/
public class ApplicationServiceTest {

	@Autowired
	private ApplicationStatusRepository applicationStatusRepository;

	@Autowired
	private ClientRepository clientRepository;

	@Autowired
	private ApplicationService applicationService;

	@Autowired
	private ApplicationRepository applicationRepository;

	@Autowired
	private OwnerRepository ownerRepository;

	@Autowired
	private BusinessRepository businessRepository;

	@Autowired
	private StateRepository stateRepository;

	@Autowired
	private ObjectMapper objectMapper;

	@TestConfiguration
	static class TestConfig {

		public TestConfig() {

		}

		private static final Logger LOGGER = LoggerFactory.getLogger(TestConfig.class);

		/**
		 * Provides a valid value for @CreatedBy and @UpdatedBy annotations
		 *
		 * @return Optional of 11L indicating the ID of the Client we have in seed data for testing.
		 */
		@Bean
		public AuditorAware<Long> auditorProvider() {

			LOGGER.debug("AUDITOR AWARE CALLED");
			return () -> Optional.ofNullable(Long.valueOf(11L));
		}
	}

	@Test
	@WithMockUser
	@Transactional
	public void givenValidApplicationDto_whenCreateApplication_thenAllRelatedEntitesAreStoredInDb() throws IOException {

		// given
		String sampleInputJson = getTextFileAsString("/payloads/new_application.json");
		ApplicationDTO input = objectMapper.readValue(sampleInputJson, ApplicationDTO.class);

		// when
		ApplicationDTO application = applicationService.createApplication("11", input);

		// then
		// Application is stored correctly in DB
		assertThat(application).isNotNull();
		UUID applicationUUID = UUID.fromString(application.getUuid());

		Optional<Application> applicationFromRepositoryOptional = applicationRepository.findByUuid(applicationUUID);
		assertThat(applicationFromRepositoryOptional).describedAs("Application is found in DB").isNotEmpty();
		Application applicationFromRepo = applicationFromRepositoryOptional.get();
		assertThat(applicationFromRepo.getStatus().getStatus()).describedAs("Application has set initial Status")
				.isEqualTo("New");

		// Business Asserts
		Optional<Business> businessFromApplication = businessRepository.findBusinessByApplication(applicationFromRepo);
		assertThat(businessFromApplication)
				.describedAs("Business is stored in DB").isNotEmpty();
		Business business = businessFromApplication.get();
		assertThat(business.getApplication()).isNotNull();
		assertThat(business.getBusinessType().getType()).isEqualTo("Limited Liability Corporation");
		assertThat(business.getIndustryType().getType()).isEqualTo("Transportation");

		// Business PII asserts
		assertThat(business.getAddresses()).hasSize(1);
		assertThat(business.getAddresses().get(0).getAddress1()).isEqualTo("273 E 26TH ST");
		assertThat(business.getAddresses().get(0).getAddress2()).isEqualTo("660-D");
		assertThat(business.getAddresses().get(0).getCity()).isEqualTo("PATERSON");
		assertThat(business.getAddresses().get(0).getState()).isEqualTo("New Jersey");
		assertThat(business.getAddresses().get(0).getZip5()).isEqualTo("07514");
		assertThat(business.getAddresses().get(0).getAddressType().getType()).isEqualTo("Home");

		assertThat(business.getEmails()).hasSize(1);
		assertThat(business.getEmails().get(0).getEmailType().getType())
				.describedAs("email type is mapped correctly").isEqualTo("Work");
		assertThat(business.getPhones()).hasSize(1);
		assertThat(business.getPhones().get(0).getPhoneType().getType())
				.describedAs("phone type is mapped correctly").isEqualTo("Work");
		assertThat(business.getIdentifications()).hasSize(1);
		assertThat(business.getIdentifications().get(0).getIdentificationType().getType())
				.describedAs("identification type is mapped correctly").isEqualTo("EIN");

		// Debtor assertions
		assertThat(businessRepository.findDebtorByApplication(applicationFromRepo)).isEmpty();

		// Owner assertions
		List<Owner> ownersForApplication = ownerRepository.findAllByApplication(applicationFromRepo);
		assertThat(ownersForApplication).describedAs("The owner is stored in DB").hasSize(1);
		Owner owner = ownersForApplication.get(0);
		assertThat(owner).isNotNull();
		assertThat(owner.getFirstName()).isEqualTo("Mickey");
		assertThat(owner.getLastName()).isEqualTo("Minne");

		// Owner PII Assertions
		assertThat(owner.getAddresses()).hasSize(1);
		assertThat(owner.getAddresses().get(0).getAddressType().getType()).isEqualTo("Home");
		assertThat(owner.getEmails()).hasSize(1);
		assertThat(owner.getEmails().get(0).getEmailType().getType())
				.describedAs("email type is mapped correctly").isEqualTo("Work");
		assertThat(owner.getPhones()).hasSize(1);
		assertThat(owner.getPhones().get(0).getPhoneType().getType())
				.describedAs("phone type is mapped correctly").isEqualTo("Work");
		assertThat(owner.getIdentifications()).hasSize(1);
		assertThat(owner.getIdentifications().get(0).getIdentificationType().getType())
				.describedAs("identification type is mapped correctly").isEqualTo("SSN");

		assertThat(applicationFromRepo.getClient()).isNotNull();

	}

	public String getTextFileAsString(String filePath) throws IOException {

		return IOUtils.toString(
				this.getClass().getResourceAsStream(filePath),
				"UTF-8");
	}

	@Test
	@Transactional
	public void givenValidApplication_whenApplicationStatusUpdate_ThenReturnApplicationUpdated() {

		//Arrange
		Application application = new Application();
		application.setUuid(UUID.fromString("e81ee7ad-25e3-4531-b71a-95b16d998cb1"));
		application.setState(stateRepository.getStateByName("Open"));
		application.setUpdatedById(11L);
		application.setCreatedById(11L);

		Client client = clientRepository.getById(11L);

		application.setClient(client);
		application.setStatus(applicationStatusRepository.getStatusByName("Under Review"));

		ApplicationStatusChangeDTO applicationStatusChangeDTO = new ApplicationStatusChangeDTO();
		applicationStatusChangeDTO.setStatus("Approved");

		//Act
		clientRepository.save(client);
		applicationRepository.save(application);

		String result = applicationService.changeStatus(applicationStatusChangeDTO,
				UUID.fromString("e81ee7ad-25e3-4531-b71a-95b16d998cb1"),
				"11").getStatus();

		//Assert
		assertEquals("Approved", result);
	}

	@Test
	@Transactional
	public void givenApplicationInDeclinedStatus_whenApplicationStatusUpdate_ThenThrowsException() {

		//Arrange
		Application application = new Application();
		application.setUuid(UUID.fromString("e81ee7ad-25e3-4531-b71a-95b16d998cb2"));
		application.setState(stateRepository.getStateByName("Open"));
		application.setUpdatedById(11L);
		application.setCreatedById(11L);

		Client client = clientRepository.getById(11L);

		application.setClient(client);
		application.setStatus(applicationStatusRepository.getStatusByName("Declined"));

		ApplicationStatusChangeDTO applicationStatusChangeDTO = new ApplicationStatusChangeDTO();
		applicationStatusChangeDTO.setStatus("Approved");

		clientRepository.save(client);
		applicationRepository.save(application);

		//Act
		Throwable result = catchThrowable(() -> applicationService.changeStatus(applicationStatusChangeDTO,
				UUID.fromString("e81ee7ad-25e3-4531-b71a-95b16d998cb2"),
				"11"));

		//Assert
		assertThat(result).isInstanceOf(RoxApiException.class)
				.hasMessageContaining("Application in status Declined is not able to set its status as Approved");
	}
}