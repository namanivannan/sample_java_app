package com.r1vs.platform.rox.api.validator.metadata;

import com.r1vs.platform.rox.api.exception.Error;
import com.r1vs.platform.rox.api.model.metadata.CreateMetadataRequest;
import com.r1vs.platform.rox.api.validator.RoxWriteWebApiValidator;
import com.r1vs.platform.rox.api.validator.ValidationMessages;
import com.r1vs.platform.rox.common.model.types.StatusType;
import org.springframework.stereotype.Component;

import static com.r1vs.platform.rox.api.util.MetadataConstants.STATUS;
import static com.r1vs.platform.rox.api.util.ValidationUtil.addError;
import static com.r1vs.platform.rox.api.util.ValidationUtil.handleException;

@Component
public class CreateMetadataValidator extends MetadataValidator
		implements
		RoxWriteWebApiValidator<CreateMetadataRequest> {

	@Override
	public void validate(final CreateMetadataRequest createMetadataRequest) {

		final Error error = new Error();

		validateMetadataStatus(error, createMetadataRequest.getStatusId());
		handleException(error);
		validateJson(createMetadataRequest.getMetadataCategoryId(), createMetadataRequest.getJson(),
				createMetadataRequest.getStatusId());

	}

	/**
	 * Validate metadata status
	 *
	 * @param error error
	 * @param status status
	 */
	public void validateMetadataStatus(final Error error, final Integer status) {

		if (!StatusType.getStatusTypeMap().containsKey(status)) {
			addError(error, STATUS, ValidationMessages.INVALID_STATUS, String.valueOf(status));
		}

		if (status != null && StatusType.DELETED.key().equals(status) || StatusType.INACTIVE.key().equals(status)) {
			addError(error, STATUS, ValidationMessages.INVALID_EDIT_STATUS + StatusType.getStatusTypeMap().get(status),
					String.valueOf(status));
		}
	}

}
