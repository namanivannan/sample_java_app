package com.r1vs.platform.rox.api.service;

import com.r1vs.platform.rox.common.db.repository.business.ApplicationStatusRepository;
import com.r1vs.platform.rox.common.model.business.ApplicationStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ApplicationStatusService {

	@Autowired
	private ApplicationStatusRepository applicationStatusRepository;

	public ApplicationStatus getStatusByName(String status) {

		return applicationStatusRepository.getStatusByName(status);

	}
}
