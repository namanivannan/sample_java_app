package com.r1vs.platform.rox.common.model.rule;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@Entity
@Table(name = "metadata_category")
public class MetadataCategory implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "metadata_category_id", nullable = false)
	private Integer metadataCategoryId;

	@Column(name = "metadata_category_name", nullable = false)
	private String metadataCategoryName;

	@Column(name = "abbreviation", nullable = false)
	private String abbreviation;

	public Integer getMetadataCategoryId() {

		return metadataCategoryId;
	}

	public void setMetadataCategoryId(final Integer metadataCategoryId) {

		this.metadataCategoryId = metadataCategoryId;
	}

	public String getMetadataCategoryName() {

		return metadataCategoryName;
	}

	public void setMetadataCategoryName(final String metadataCategoryName) {

		this.metadataCategoryName = metadataCategoryName;
	}

	public String getAbbreviation() {

		return abbreviation;
	}

	public void setAbbreviation(final String abbreviation) {

		this.abbreviation = abbreviation;
	}

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof MetadataCategory)) {
			return false;
		}
		final MetadataCategory castOther = (MetadataCategory) other;
		return new EqualsBuilder().append(metadataCategoryId, castOther.metadataCategoryId)
				.append(metadataCategoryName, castOther.metadataCategoryName)
				.append(abbreviation, castOther.abbreviation).isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(metadataCategoryId).append(metadataCategoryName).append(abbreviation)
				.toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("metadataCategoryId", metadataCategoryId)
				.append("metadataCategoryName", metadataCategoryName).append("abbreviation", abbreviation).toString();
	}

}
