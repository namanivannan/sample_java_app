package com.r1vs.platform.rox.api.response;

public final class ResponseMessages {

	public static final String NUMBER_OF_RECORDS = "Number of Records: ";

	public static final String X_PAGINATION_NUM = "X-PAGINATION-NUM";

	public static final String X_PAGINATION_LIMIT = "X-PAGINATION-LIMIT";

	public static final String X_PAGINATION_TOTAL_RECORDS = "X-PAGINATION-TOTAL-RECORDS";

	public static final String X_PAGINATION_TOTAL_PAGES = "X-PAGINATION-TOTAL-PAGES";

	public static final String X_PAGINATION_CURRENT_PAGE_NUM = "X-PAGINATION-CURRENT-PAGE-NUM";

	public static final String X_PAGINATION_HAS_NEXT_PAGE = "X-PAGINATION-HAS-NEXT-PAGE";

	public static final String X_PAGINATION_NEXT_PAGE_NUM = "X-PAGINATION-NEXT-PAGE-NUM";

	public static final String DATE_OF_SERVICE_CANNOT_BE_NULL = "Date of service cannot be null.";

	public static final String PLAN_ID_EXISTS = "Plan already exists for planId: ";

	public static final String NO_PLAN_ID_EXISTS = "No plan exists for planId: ";

	public static final String PLAN_NAME_EXISTS = "Plan already exists for planName: ";

	public static final String NO_PLAN_NAME_EXISTS = "No plan exists for planName: ";

	public static final String METADATA_CATEGORY_CANNOT_BE_NULL = "Metadata category cannot be null.";

	public static final String NO_ACTIVE_PLAN_EXISTS = "No active plans exist. ";

	public static final String NO_METADATA_EXISTS = "No metadata exists";

	public static final String NO_ACTIVE_RULES_EXISTS = "No active rules exist. ";

	public static final String ID_CANNOT_BE_NULL = "Id cannot be null.";

	public static final String USER = "User ";

	public static final String PASSWORD = "Password ";

	public static final String UPDATED_SUCCESSFULLY = " updated successfully.";

	public static final String DOES_NOT_EXIST = " does not exist.";

	public static final String TOKEN_NOT_VALID = "Token not valid.";

	public static final String CREATED_SUCCESSFULLY = " created successfully.";

	public static final String ROLE = "Role ";

	public static final String USER_EXISTS = "User already exists with username: ";

	public static final String USERNAME_NOT_MATCH =
			"Username does not match existing username of the same email address.";

	public static final String USER_EMAIL_EXISTS = "User already exists with email: ";

	public static final String EMAIL = "Email: ";

	public static final String IS_AVAILABLE = " is available";

	public static final String ERROR_PROCESSING_API_VERSION = "Error processing version for API. No version found.";

	public static final String INVALID_USER_CREDENTIALS = "Invalid user credentials";

	public static final String EXTERNAL_REJECT_CODE_CANNOT_BE_NULL = "External Reject Code cannot be null.";

	public static final String FORGOT_PASSWORD = "Password reset link successfully sent to your email id.";

}
