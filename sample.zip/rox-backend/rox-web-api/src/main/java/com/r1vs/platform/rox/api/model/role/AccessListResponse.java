package com.r1vs.platform.rox.api.model.role;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.List;

public class AccessListResponse {

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private List<SubdomainResponse> subdomains;

	public List<SubdomainResponse> getSubdomains() {

		return subdomains;
	}

	public void setSubdomains(final List<SubdomainResponse> subdomains) {

		this.subdomains = subdomains;
	}
}
