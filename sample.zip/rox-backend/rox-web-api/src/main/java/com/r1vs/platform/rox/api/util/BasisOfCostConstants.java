package com.r1vs.platform.rox.api.util;

public class BasisOfCostConstants {

	public static final String BASIS_OF_COST_CODE = "basisOfCostCode";

	public static final String BASIS_OF_COST_CODE_STATUS = "basisOfCostCodeStatus";

	public static final String BASIS_OF_COST_CODE_REIMBURSEMENT_ASSIGNMENT = "basisOfCostCodeReimbursementAssignment";

	public static final String BASIS_OF_COST_CODE_DESCRIPTION = "basisOfCostCodeDescription";

}
