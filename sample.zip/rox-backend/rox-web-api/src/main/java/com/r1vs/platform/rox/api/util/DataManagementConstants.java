package com.r1vs.platform.rox.api.util;

/**
 * This class contains common constants that will be used in the job management module.
 */
public class DataManagementConstants {

	public static final String EQUALS = "==";

	public static final String LIKE = "%%";

	public static final String GREATER_THAN = ">=";

	public static final String LESS_THAN = "<=";

	public static final String ACTIVE_FILTER = "!!";

	public static final String PBM_ID = "pbmId";

	public static final String JOB_NAME = "jobName";

	public static final String JOB_ID = "jobConfigId";

	public static final String EFFECTIVE_START_DATE = "effectiveStartDate";

	public static final String EFFECTIVE_END_DATE = "effectiveEndDate";

	public static final String STATUS_ID = "statusId";

	public static final String DEACTIVATED_AT = "deactivatedAt";

	public static final String JOB_CRITERIA = "jobCriteria";

	public static final String JOB_TYPE = "jobType";

	public static final String JOB_FREQUENCY_TYPE = "jobFrequencyType";

	public static final String CLAIM_STATUS = "claimStatus";

	public static final String DAILY_INTERVAL = "0";

	public static final String WEEKLY_INTERVAL = "7";

	public static final String MONTHLY_INTERVAL = "30";

	public static final String YEARLY_INTERVAL = "365";

	public static final String ERROR_WHILE_PROCESSING_JOB_MANAGEMENT = "ERROR_WHILE_PROCESSING_JOB_MANAGEMENT";

	public static final String INVALID_JOB_CONFIG_ID = "INVALID_JOB_CONFIG_ID";

	public static final String SPRING_BATCH_EXECUTION_CONFIG = "spring-batch-execution-config";

	public static final String CLAIM_EXTRACTION_JOB_NAME = "claimExtractionFileExportBatchJob";

	public static final String CLAIM_EXTRACTION_ROLLBACK_JOB_NAME = null;

	public static final String JOB_RUN_TIME_DAYS = "jobRunTimeDays";

	public static final String BIN_VALUES = "binValues";

	public static final String INVALID_JOB_NAME = "INVALID_JOB_NAME";

	public static final String INVALID_DESCRIPTION = "INVALID_DESCRIPTION";

	public static final String DESCRIPTION = "description";

	public static final String INVALID_JOB_TYPE = "INVALID_JOB_TYPE";

	public static final String INVALID_JOB_FREQUENCY_TYPE = "INVALID_JOB_FREQUENCY_TYPE";

	public static final String INVALID_JOB_RUN_TIME_DAYS = "INVALID_JOB_RUN_TIME_DAYS";

	public static final String EMAIL = "Email";

	public static final String INVALID_EMAIL = "INVALID_EMAIL";

	public static final String EMAIL_ID_SHOULD_NOT_BE_NULL = "EMAIL_ID_SHOULD_NOT_BE_NULL";

	public static final String INVALID_CLAIM_STATUS = "INVALID_CLAIM_STATUS";

	public static final String REGISTRATION_CODE = "registrationCode";

	public static final String START_AT = "startAt";

	public static final String END_AT = "endAt";

	public static final String STATE = "state";

	public static final String ALL = "ALL";

	public static final String JOB_NAME_ALREADY_EXISTS = "JOB_NAME_ALREADY_EXISTS";
}
