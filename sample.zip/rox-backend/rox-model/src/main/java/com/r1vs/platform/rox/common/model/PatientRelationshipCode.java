package com.r1vs.platform.rox.common.model;

public enum PatientRelationshipCode {

	NOT_SPECIFIED(0),
	CARDHOLDER(1),
	SPOUSE(2),
	CHILD(3),
	OTHER(4),
	STUDENT(5),
	DISABLED_DEPENDENT(6),
	ADULT_DEPENDENT(
			7),
	SIGNIFICANT_OTHER(8);

	private Integer value;

	PatientRelationshipCode(final Integer value) {

		this.value = value;
	}

	/**
	 * Get value of the patient relationship code
	 *
	 * @return value
	 */
	public Integer getValue() {

		return value;
	}

	/**
	 * Get PatientRelationshipCode from value
	 *
	 * @param value the code value
	 * @return code the patientRelationShipCode
	 */
	public static PatientRelationshipCode fromValue(final Integer value) {

		for (final PatientRelationshipCode code : PatientRelationshipCode.values()) {
			if (code.value.equals(value)) {
				return code;
			}
		}

		return null;
	}
}
