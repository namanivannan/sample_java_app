package com.r1vs.platform.rox.api.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

import java.util.List;

@ResponseStatus(value = HttpStatus.BAD_REQUEST)
public class InvalidDataException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	private final List<ErrorResponse> errorResponses;

	public InvalidDataException(final List<ErrorResponse> errorResponses) {

		super();
		this.errorResponses = errorResponses;
	}

	public List<ErrorResponse> getErrorResponses() {

		return errorResponses;
	}

}
