package com.r1vs.platform.rox.api.model.admin;

import com.r1vs.platform.rox.api.model.UserRequest;

import java.io.Serializable;

public class CreateClientDTO implements Serializable {

	private ClientDTO client;

	private UserRequest user;

	public ClientDTO getClient() {

		return client;
	}

	public void setClient(ClientDTO client) {

		this.client = client;
	}

	public UserRequest getUser() {

		return user;
	}

	public void setUser(UserRequest user) {

		this.user = user;
	}
}
