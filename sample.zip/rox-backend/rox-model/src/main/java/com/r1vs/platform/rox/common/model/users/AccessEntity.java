package com.r1vs.platform.rox.common.model.users;

import com.r1vs.platform.rox.common.model.AuditedEntity;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "access_entity")
public class AccessEntity extends AuditedEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "access_entity_id", nullable = false)
	private Integer accessEntityId;

	@Column(name = "domain_code", nullable = false)
	private String domainCode;

	@Column(name = "entity_code", nullable = false)
	private String entityCode;

	@Column(name = "entity_description", nullable = false)
	private String entityDescription;

	@Column(name = "domain_entity_id", nullable = false)
	private Integer accessDomainId;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "domain_entity_id", nullable = false, insertable = false, updatable = false)
	private AccessDomain accessDomain;

	@OneToOne(mappedBy = "accessEntity")
	private AccessEntityPrivilege accessEntityPrivilege;

	public Integer getAccessEntityId() {

		return accessEntityId;
	}

	public void setAccessEntityId(Integer accessEntityId) {

		this.accessEntityId = accessEntityId;
	}

	public String getDomainCode() {

		return domainCode;
	}

	public void setDomainCode(String domainCode) {

		this.domainCode = domainCode;
	}

	public String getEntityCode() {

		return entityCode;
	}

	public void setEntityCode(String entityCode) {

		this.entityCode = entityCode;
	}

	public String getEntityDescription() {

		return entityDescription;
	}

	public void setEntityDescription(String entityDescription) {

		this.entityDescription = entityDescription;
	}

	public Integer getAccessDomainId() {

		return accessDomainId;
	}

	public void setAccessDomainId(Integer accessDomainId) {

		this.accessDomainId = accessDomainId;
	}

	public AccessDomain getAccessDomain() {

		return accessDomain;
	}

	public void setAccessDomain(AccessDomain accessDomain) {

		this.accessDomain = accessDomain;
	}

	public AccessEntityPrivilege getAccessEntityPrivilege() {

		return accessEntityPrivilege;
	}

	public void setAccessEntityPrivilege(AccessEntityPrivilege accessEntityPrivilege) {

		this.accessEntityPrivilege = accessEntityPrivilege;
	}
}
