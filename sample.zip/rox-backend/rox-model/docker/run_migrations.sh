#!/usr/bin/env bash

echo "running liquibase for ${ENVIRONMENT_NAME} environment with context ${LIQUIBASE_MIGRATIONS}"

mvn resources:resources liquibase:update

sleep infinity
