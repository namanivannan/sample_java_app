package com.r1vs.platform.rox.common.model.dp;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Version;

import com.r1vs.platform.rox.common.model.AuditedEntity;

@Entity
@Table(name = "dp_data_processing_config")
public class DataProcessingConfig extends AuditedEntity implements Serializable {

	private static final long serialVersionUID = 2628233015010123904L;

	@Id
	@Column(name = "id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Version
	private Integer version;

	@Column(name = "pbm_id")
	private Integer pbmId;

	@Column(name = "registration_id", updatable = false, insertable = false)
	private Integer registrationId;

	@Column(name = "landing_zone_url")
	private String landingZoneUrl;

	@Column(name = "processing_zone_url")
	private String processingZoneUrl;

	@Column(name = "configuration")
	private String configuration;

	@Column(name = "input_type")
	private String inputType;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "registration_id", referencedColumnName = "id")
	private DataInputRegistration dataInputRegistration;

	public Integer getId() {

		return id;
	}

	public void setId(final Integer id) {

		this.id = id;
	}

	public String getLandingZoneUrl() {

		return landingZoneUrl;
	}

	public void setLandingZoneUrl(final String landingZoneUrl) {

		this.landingZoneUrl = landingZoneUrl;
	}

	public String getProcessingZoneUrl() {

		return processingZoneUrl;
	}

	public void setProcessingZoneUrl(final String processingZoneUrl) {

		this.processingZoneUrl = processingZoneUrl;
	}

	public String getConfiguration() {

		return configuration;
	}

	public void setConfiguration(final String configuration) {

		this.configuration = configuration;
	}

	public String getInputType() {

		return inputType;
	}

	public void setInputType(final String inputType) {

		this.inputType = inputType;
	}

	public DataInputRegistration getDataInputRegistration() {

		return dataInputRegistration;
	}

	public void setDataInputRegistration(final DataInputRegistration dataInputRegistration) {

		this.dataInputRegistration = dataInputRegistration;
	}

	public Integer getRegistrationId() {

		return registrationId;
	}

	public void setRegistrationId(final Integer registrationId) {

		this.registrationId = registrationId;
	}

	public Integer getVersion() {

		return version;
	}

	public void setVersion(final Integer version) {

		this.version = version;
	}

	public Integer getPbmId() {

		return pbmId;
	}

	public void setPbmId(final Integer pbmId) {

		this.pbmId = pbmId;
	}
}
