package com.r1vs.platform.rox.api.model.role;

public class CreateRoleRequest extends RoleRequest {

}
