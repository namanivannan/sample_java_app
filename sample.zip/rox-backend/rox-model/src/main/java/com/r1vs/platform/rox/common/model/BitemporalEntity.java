package com.r1vs.platform.rox.common.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.OffsetDateTime;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@MappedSuperclass
public class BitemporalEntity extends AuditedEntity implements Serializable {

	private static final long serialVersionUID = 2966895098986638738L;

	@Column(name = "activated_at", nullable = false)
	protected OffsetDateTime activatedAt;

	@Column(name = "deactivated_at", nullable = false)
	protected OffsetDateTime deactivatedAt;

	@Column(name = "effective_start_date", nullable = false)
	protected LocalDate effectiveStartDate;

	@Column(name = "effective_end_date", nullable = false)
	protected LocalDate effectiveEndDate;

	public OffsetDateTime getActivatedAt() {

		return activatedAt;
	}

	public void setActivatedAt(final OffsetDateTime activatedAt) {

		this.activatedAt = activatedAt;
	}

	public OffsetDateTime getDeactivatedAt() {

		return deactivatedAt;
	}

	public void setDeactivatedAt(final OffsetDateTime deactivatedAt) {

		this.deactivatedAt = deactivatedAt;
	}

	public LocalDate getEffectiveStartDate() {

		return effectiveStartDate;
	}

	public void setEffectiveStartDate(final LocalDate effectiveStartDate) {

		this.effectiveStartDate = effectiveStartDate;
	}

	public LocalDate getEffectiveEndDate() {

		return effectiveEndDate;
	}

	public void setEffectiveEndDate(final LocalDate effectiveEndDate) {

		this.effectiveEndDate = effectiveEndDate;
	}

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof BitemporalEntity)) {
			return false;
		}
		final BitemporalEntity castOther = (BitemporalEntity) other;
		return new EqualsBuilder().append(activatedAt, castOther.activatedAt)
				.append(deactivatedAt, castOther.deactivatedAt).append(effectiveStartDate, castOther.effectiveStartDate)
				.append(effectiveEndDate, castOther.effectiveEndDate).isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(activatedAt).append(deactivatedAt).append(effectiveStartDate)
				.append(effectiveEndDate).toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("activatedAt", activatedAt).append("deactivatedAt", deactivatedAt)
				.append("effectiveStartDate", effectiveStartDate).append("effectiveEndDate", effectiveEndDate)
				.toString();
	}

	public boolean itemEqualsRow(final Object other) {

		return false;

	}
}
