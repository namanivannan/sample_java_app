package com.r1vs.platform.rox.common.model.users;

import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.r1vs.platform.rox.common.model.AuditedEntity;
import com.r1vs.platform.rox.common.model.Code;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "user_audit")
public class UserAudit extends AuditedEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", nullable = false)
	private Integer id;

	@Column(name = "user_id")
	private Integer userId;

	@Column(name = "username", nullable = false)
	private String username;

	@Column(name = "first_name", nullable = false)
	private String firstName;

	@Column(name = "last_name", nullable = false)
	private String lastName;

	@Column(name = "password")
	private String password;

	//@Column(name = "password_updated")
	//private Boolean passwordUpdated;

	@Column(name = "email")
	private String email;

	@Column(name = "phone_type_id")
	private Integer phoneTypeId;

	@Column(name = "phone")
	private String phone;

	@Column(name = "registered")
	private Boolean registered;

	@Column(name = "registered_date")
	private OffsetDateTime registeredDate;

	//@Column(name = "termination_date")
	//private OffsetDateTime terminationDate;

	@Column(name = "version")
	private Integer version;

	@Column(name = "user_role_version")
	private Integer userRoleVersion;

	@ManyToMany(fetch = FetchType.LAZY)
	@JoinTable(name = "user_role_audit", joinColumns = {
			@JoinColumn(name = "user_id", referencedColumnName = "user_id", insertable = false, updatable = false),
			@JoinColumn(name = "user_role_version", referencedColumnName = "user_role_version", insertable = false,
					updatable = false) },
			inverseJoinColumns = {
					@JoinColumn(name = "role_id", referencedColumnName = "role_id", insertable = false,
							updatable = false) })
	private List<Role> roles;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "phone_type_id", referencedColumnName = "code_id", insertable = false, updatable = false)
	private Code code;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "updated_by", referencedColumnName = "user_id", insertable = false, updatable = false)
	private User updatedUser;

	public Integer getId() {

		return id;
	}

	public void setId(final Integer id) {

		this.id = id;
	}

	public Integer getUserId() {

		return userId;
	}

	public void setUserId(final Integer userId) {

		this.userId = userId;
	}

	public String getUsername() {

		return username;
	}

	public void setUsername(final String username) {

		this.username = username;
	}

	public String getFirstName() {

		return firstName;
	}

	public void setFirstName(final String firstName) {

		this.firstName = firstName;
	}

	public String getLastName() {

		return lastName;
	}

	public void setLastName(final String lastName) {

		this.lastName = lastName;
	}

	public String getPassword() {

		return password;
	}

	public void setPassword(final String password) {

		this.password = password;
	}

	/*public Boolean isPasswordUpdated() {
	
		return passwordUpdated;
	}
	
	public void setPasswordUpdated(final Boolean passwordUpdated) {
	
		this.passwordUpdated = passwordUpdated;
	}*/

	public String getEmail() {

		return email;
	}

	public void setEmail(final String email) {

		this.email = email;
	}

	public Integer getPhoneTypeId() {

		return phoneTypeId;
	}

	public void setPhoneTypeId(final Integer phoneTypeCodeId) {

		this.phoneTypeId = phoneTypeCodeId;
	}

	public String getPhone() {

		return phone;
	}

	public void setPhone(final String phone) {

		this.phone = phone;
	}

	public Boolean isRegistered() {

		return registered;
	}

	public void setIsRegistered(final Boolean registered) {

		this.registered = registered;
	}

	public OffsetDateTime getRegisteredDate() {

		return registeredDate;
	}

	public void setRegisteredDate(final OffsetDateTime registeredDate) {

		this.registeredDate = registeredDate;
	}

	/*public OffsetDateTime getTerminationDate() {
	
		return terminationDate;
	}
	
	public void setTerminationDate(final OffsetDateTime terminationDate) {
	
		this.terminationDate = terminationDate;
	}*/

	public Integer getVersion() {

		return version;
	}

	public void setVersion(final Integer version) {

		this.version = version;
	}

	public Integer getUserRoleVersion() {

		return userRoleVersion;
	}

	public void setUserRoleVersion(final Integer userRoleVersion) {

		this.userRoleVersion = userRoleVersion;
	}

	public List<Role> getRoles() {

		return roles;
	}

	public void setRoles(final List<Role> roles) {

		this.roles = roles;
	}

	public Code getCode() {

		return code;
	}

	public void setCode(final Code code) {

		this.code = code;
	}

	public User getUpdatedUser() {

		return updatedUser;
	}

	public void setUpdatedUser(final User updatedUser) {

		this.updatedUser = updatedUser;
	}

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof UserAudit)) {
			return false;
		}
		final UserAudit castOther = (UserAudit) other;
		return new EqualsBuilder().append(id, castOther.id).append(userId, castOther.userId)
				.append(username, castOther.username).append(firstName, castOther.firstName)
				.append(lastName, castOther.lastName).append(password, castOther.password)
				./*append(passwordUpdated, castOther.passwordUpdated).*/append(email, castOther.email)
				.append(phoneTypeId, castOther.phoneTypeId).append(phone, castOther.phone)
				.append(registered, castOther.registered).append(registeredDate, castOther.registeredDate)
				./*append(terminationDate, castOther.terminationDate).*/append(version, castOther.version)
				.append(userRoleVersion, castOther.userRoleVersion).isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(id).append(userId).append(username).append(firstName).append(lastName)
				.append(password)/*.append(passwordUpdated)*/.append(email).append(phoneTypeId).append(phone)
				.append(registered).append(registeredDate)./*append(terminationDate).*/append(version)
				.append(userRoleVersion).toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("id", id).append("userId", userId).append("username", username)
				.append("firstName", firstName).append("lastName", lastName).append("password", password)
				./*append("passwordUpdated", passwordUpdated).*/append("email", email)
				.append("phoneTypeId", phoneTypeId).append("phone", phone).append("registered", registered)
				.append("registeredDate", registeredDate)/*.append("terminationDate", terminationDate)*/
				.append("version", version).append("userRoleVersion", userRoleVersion).toString();
	}

}
