package com.r1vs.platform.rox.common.db.responses;

public interface DashboardTotalApplications {

	String getState();

	Integer getTotalApplications();

	Integer getTotalAmount();

	String getStatus();
}
