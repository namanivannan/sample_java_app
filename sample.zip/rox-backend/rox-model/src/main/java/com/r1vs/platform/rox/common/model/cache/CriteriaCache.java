package com.r1vs.platform.rox.common.model.cache;

import java.io.Serializable;
import java.util.List;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

public class CriteriaCache implements Serializable {

	private static final long serialVersionUID = 7250134680754569391L;

	private Long criteriaId;

	private List<ConditionCache> conditions;

	public Long getCriteriaId() {

		return criteriaId;
	}

	public void setCriteriaId(final Long criteriaId) {

		this.criteriaId = criteriaId;
	}

	public List<ConditionCache> getConditions() {

		return conditions;
	}

	public void setConditions(final List<ConditionCache> conditions) {

		this.conditions = conditions;
	}

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof CriteriaCache)) {
			return false;
		}
		final CriteriaCache castOther = (CriteriaCache) other;
		return new EqualsBuilder().append(criteriaId, castOther.criteriaId).append(conditions, castOther.conditions)
				.isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(criteriaId).append(conditions).toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("criteriaId", criteriaId).append("conditions", conditions).toString();
	}
}
