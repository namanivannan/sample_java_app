package com.r1vs.platform.rox.api.util;

import java.time.format.DateTimeFormatter;

public class DSConstants {

	public static final String FCS_CLIENT_REFERENCE = "Client Reference";
    public static final DateTimeFormatter formatterForFcsDates = DateTimeFormatter.ISO_DATE_TIME;


}
