package com.r1vs.platform.rox.common.security.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class DecryptionParams implements Serializable {

    @JsonProperty("v")
    private int encryptionVersion;

    public int getEncryptionVersion() {
        return encryptionVersion;
    }

    public void setEncryptionVersion(int encryptionVersion) {
        this.encryptionVersion = encryptionVersion;
    }
}
