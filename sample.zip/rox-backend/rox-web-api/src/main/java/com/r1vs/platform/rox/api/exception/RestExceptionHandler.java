package com.r1vs.platform.rox.api.exception;

import com.r1vs.platform.rox.api.util.ValidationUtil;
import com.r1vs.platform.rox.interaction.exception.DSConnectorException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.multipart.MaxUploadSizeExceededException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintViolationException;
import java.util.*;
import java.util.stream.Collectors;

import static com.r1vs.platform.rox.api.util.BenefitCoverageAlternativeConstants.ERROR_WHILE_UPLOADING_FILE;

@ControllerAdvice()
@Order(Ordered.HIGHEST_PRECEDENCE)
public class RestExceptionHandler extends ResponseEntityExceptionHandler {

	private static final String GENERIC_ERROR_MESSAGE = "The application has encountered an unknown error.";

	@Value("${roxwrite.web_api.show_full_stacktrace}")
	private String showFullStacktrace;

	@Value("${spring.servlet.multipart.max-file-size}")
	private String maxFileSize;

	@Autowired
	private MessageSource messageSource;

	private static final Logger LOGGER = LoggerFactory.getLogger(RestExceptionHandler.class);

	@Override
	protected ResponseEntity<Object> handleMissingServletRequestParameter(
			final MissingServletRequestParameterException exception, final HttpHeaders headers, final HttpStatus status,
			final WebRequest request) {

		final List<ErrorResponse> details = new ArrayList<>();
		final ErrorResponse errorResponse = new ErrorResponse();

		if ("true".equals(showFullStacktrace)) {
			errorResponse.setMessage(exception.getParameterName() + " parameter is missing.");
		} else {
			errorResponse.setMessage(GENERIC_ERROR_MESSAGE);
		}

		details.add(errorResponse);
		return new ResponseEntity<>(details, HttpStatus.BAD_REQUEST);
	}

	/**
	 * Exception thrown when {@link org.springframework.validation.annotation.Validated} is used in controller.
	 *
	 * @param exception exception
	 * @param request request
	 * 
	 * @return response
	 */
	@ExceptionHandler(ConstraintViolationException.class)
	protected ResponseEntity<?> handleConstraintViolationException(final ConstraintViolationException exception,
			final HttpServletRequest request) {

		final List<ErrorResponse> details = new ArrayList<>();

		try {
			final ErrorResponse errorResponse = new ErrorResponse();

			if ("true".equals(showFullStacktrace)) {
				errorResponse.setMessage(exception.getLocalizedMessage());
			} else {
				errorResponse.setMessage(GENERIC_ERROR_MESSAGE);
			}

			details.add(errorResponse);
			return new ResponseEntity<>(details, HttpStatus.BAD_REQUEST);

		} catch (final Exception e) {
			return new ResponseEntity<>(details, HttpStatus.BAD_REQUEST);
		}
	}

	/**
	 * Exception thrown when {@link org.springframework.validation.annotation.Validated} is used in controller.
	 *
	 * @param exception exception
	 * @param request request
	 * 
	 * @return response
	 */
	@ExceptionHandler(Exception.class)
	public final ResponseEntity<?> handleAllExceptions(final Exception exception, final WebRequest request) {

		LOGGER.error("Unknown issue occured!  Cause:", exception);
		final List<ErrorResponse> details = new ArrayList<>();
		final ErrorResponse errorResponse = new ErrorResponse();

		if ("true".equals(showFullStacktrace)) {
			errorResponse.setMessage(exception.getLocalizedMessage());
		} else {
			errorResponse.setMessage(GENERIC_ERROR_MESSAGE);
		}

		details.add(errorResponse);
		return new ResponseEntity<>(details, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(DSConnectorException.class)
	public final ResponseEntity<?> handleConnectorExceptions(final DSConnectorException exception,
															 final WebRequest request) {

		LOGGER.error("Unknown issue occured!  Cause:", exception);
		final List<ErrorResponse> details = new ArrayList<>();
		final ErrorResponse errorResponse = new ErrorResponse();

		errorResponse.setMessage(exception.getLocalizedMessage());

		details.add(errorResponse);
		return new ResponseEntity<>(details, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(RoxApiException.class)
	public final ResponseEntity<?> handleAllRoxApiExceptions(final RoxApiException exception,
															 final WebRequest request) {

		LOGGER.error("Unknown issue occured!  Cause:", exception);
		final List<ErrorResponse> details = new ArrayList<>();
		final ErrorResponse errorResponse = new ErrorResponse();

		errorResponse.setMessage(exception.getLocalizedMessage());

		details.add(errorResponse);
		return new ResponseEntity<>(details, exception.getHttpStatus());
	}

	/**
	 * Exception thrown when {@link org.springframework.validation.annotation.Validated} is used in controller.
	 *
	 * @param exception exception
	 * @param request request
	 * 
	 * @return response
	 */
	@ExceptionHandler(ValidationException.class)
	public final ResponseEntity<Object> handleValidationException(final ValidationException exception,
			final WebRequest request) {

		final List<ErrorResponse> details = new ArrayList<>();
		final ErrorResponse errorResponse = new ErrorResponse();

		errorResponse.setMessage(exception.getLocalizedMessage());

		details.add(errorResponse);
		return new ResponseEntity<>(details, HttpStatus.BAD_REQUEST);
	}

	/**
	 * Exception thrown when {@link org.springframework.validation.annotation.Validated} is used in controller.
	 *
	 * @param exception exception
	 * @param request request
	 * 
	 * @return response
	 */
	@ExceptionHandler(InvalidDataException.class)
	public final ResponseEntity<Object> handleInvalidDataException(final InvalidDataException exception,
			final WebRequest request) {

		return new ResponseEntity<>(exception.getErrorResponses(), HttpStatus.BAD_REQUEST);
	}

	/**
	 * Exception thrown when {@link org.springframework.validation.annotation.Validated} is used in controller.
	 *
	 * @param exception exception
	 * @param request request
	 * 
	 * @return response
	 */
	@ExceptionHandler(InvalidFormDataException.class)
	public final ResponseEntity<Object> handleInvalidDataException(final InvalidFormDataException exception,
			final WebRequest request) {

		return new ResponseEntity<>(exception.getErrorResponses(), HttpStatus.BAD_REQUEST);
	}

	/**
	 * Exception thrown when the user does not have access to some resource.
	 *
	 * @param exception exception
	 * @param request request
	 *
	 * @return response
	 */
	@ExceptionHandler(AccessException.class)
	public final ResponseEntity<Object> handleAccessException(final AccessException exception,
			final WebRequest request) {

		final Map<String, String> errorMap = new HashMap<>();
		errorMap.put("statusCode", String.valueOf(exception.getHttpStatus().value()));
		errorMap.put("error", String.valueOf(exception.getHttpStatus().getReasonPhrase()));
		errorMap.put("errorDetail", exception.getMessage());
		return new ResponseEntity<>(errorMap, exception.getHttpStatus());
	}

	/**
	 * Exception thrown when user uploads the file whose size exceeds a certain threshold as specified in the
	 * configuration.
	 * 
	 * @param exception
	 * @param request
	 * @return ResponseEntity<Object>
	 */
	@ExceptionHandler(MaxUploadSizeExceededException.class)
	public ResponseEntity<Object> handleMaxUploadSizeExceededException(final MaxUploadSizeExceededException exception,
			final WebRequest request) {

		Error error = new Error();
		LOGGER.error("Error while uploading the file ", exception);
		ValidationUtil.addError(error, "ERROR",
				messageSource.getMessage(ERROR_WHILE_UPLOADING_FILE, new Object[] { maxFileSize }, Locale.getDefault()),
				maxFileSize);
		return new ResponseEntity<>(error.getErrorResponses(), HttpStatus.BAD_REQUEST);
	}

	@Override
	public final ResponseEntity<Object> handleMethodArgumentNotValid(
			final org.springframework.web.bind.MethodArgumentNotValidException exception, final HttpHeaders headers,
			final HttpStatus status, final WebRequest request) {

		final BindingResult bindingResult = exception.getBindingResult();

		final List<ErrorResponse> errorResponses = bindingResult
				.getFieldErrors().stream().map(errorResponse -> new ErrorResponse(errorResponse.getField(),
						errorResponse.getDefaultMessage(), errorResponse.getRejectedValue()))
				.collect(Collectors.toList());

		final List<String> details = new ArrayList<>();
		for (final ObjectError error : exception.getBindingResult().getAllErrors()) {
			details.add(error.getDefaultMessage());
		}
		return new ResponseEntity<>(errorResponses, HttpStatus.BAD_REQUEST);

	}

}
