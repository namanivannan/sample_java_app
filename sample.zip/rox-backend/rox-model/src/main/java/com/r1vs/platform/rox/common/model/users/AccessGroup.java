package com.r1vs.platform.rox.common.model.users;

import com.r1vs.platform.rox.common.model.AuditedEntity;
import com.r1vs.platform.rox.common.model.business.Status;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "access_group")
public class AccessGroup extends AuditedEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "access_group_id", nullable = false)
	private Integer accessGroupId;

	@Column(name = "group_name", nullable = false)
	private String groupName;

	@Column(name = "group_description", nullable = true)
	private String groupDescription;

	@Column(name = "status_id")
	private Integer statusId;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "status_id", nullable = false, insertable = false, updatable = false)
	private Status status;

	@OneToMany(fetch = FetchType.LAZY)
	@JoinColumn(name = "access_group_id", referencedColumnName = "access_group_id", insertable = false,
			updatable = false)
	private List<GroupRole> groupRoles;

	@Column(name = "pbm_id", nullable = false)
	private Integer pbmId;

	public Integer getAccessGroupId() {

		return accessGroupId;
	}

	public void setAccessGroupId(Integer accessGroupId) {

		this.accessGroupId = accessGroupId;
	}

	public String getGroupName() {

		return groupName;
	}

	public void setGroupName(String groupName) {

		this.groupName = groupName;
	}

	public Integer getStatusId() {

		return statusId;
	}

	public void setStatusId(Integer statusId) {

		this.statusId = statusId;
	}

	public Status getStatus() {

		return status;
	}

	public void setStatus(Status status) {

		this.status = status;
	}

	public List<GroupRole> getGroupRoles() {

		return groupRoles;
	}

	public void setGroupRoles(List<GroupRole> groupRoles) {

		this.groupRoles = groupRoles;
	}

	public String getGroupDescription() {

		return groupDescription;
	}

	public void setGroupDescription(String groupDescription) {

		this.groupDescription = groupDescription;
	}

	public Integer getPbmId() {

		return pbmId;
	}

	public void setPbmId(Integer pbmId) {

		this.pbmId = pbmId;
	}
}
