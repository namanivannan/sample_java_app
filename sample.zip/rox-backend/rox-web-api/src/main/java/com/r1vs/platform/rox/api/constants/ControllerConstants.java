package com.r1vs.platform.rox.api.constants;

public class ControllerConstants {

	public static final String X_PAGINATION_LIMIT = "X-Pagination-Limit";

	public static final String X_PAGINATION_NUM = "X-Pagination-Num";

	public static final String X_PAGINATION_SORT = "X-Pagination-Sort";

}
