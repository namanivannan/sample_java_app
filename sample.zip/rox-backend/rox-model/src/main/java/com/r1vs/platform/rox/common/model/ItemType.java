package com.r1vs.platform.rox.common.model;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public enum ItemType {

	NDC11("NDC11", "NDC11"),
	NDC9("NDC9", "NDC9"),
	GPI14("GPI14", "GPI14");

	private String key;

	private String value;

	ItemType(final String key, final String value) {

		this.value = value;
		this.key = key;
	}

	public String key() {

		return this.key;
	}

	public String value() {

		return this.value;
	}

	/**
	 * Get map object of enum
	 *
	 * @return actionCodeMap
	 */
	public static Map<String, String> getItemTypeMap() {

		return Arrays.stream(ItemType.values()).collect(Collectors.toMap(ItemType::key, ItemType::value));
	}

	/**
	 * Get list of enum keys
	 *
	 * @return actionCodeList
	 */
	public static List<String> getItemTypeKeyList() {

		return Stream.of(values()).map(ItemType::key).collect(Collectors.toList());
	}

}
