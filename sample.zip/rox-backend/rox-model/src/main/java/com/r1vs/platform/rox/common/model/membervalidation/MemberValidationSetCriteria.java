package com.r1vs.platform.rox.common.model.membervalidation;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.persistence.*;
import java.io.Serializable;

/**
 * This class serves to ensure efficient lookups of member_validation_criteria_id values to determine if they are being
 * used. This table should have an entry for every member_validation_criteria_id which exists within
 * member_validation_set.validation_categories_json field. If records are deactivated or deleted they should likewise be
 * removed from here.
 *
 * The entire purpose of this table is to avoid full text columns and searching varchar or longtext fields.
 */
@Entity
@Table(name = "member_validation_set_criteria")
public class MemberValidationSetCriteria implements Serializable {

	private static final long serialVersionUID = -638687809340694552L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "member_validation_set_criteria_id", nullable = false)
	private Long memberValidationSetCriteriaId;

	@Column(name = "member_validation_set_id", nullable = false)
	private Integer memberValidationSetId;

	@Column(name = "member_validation_set_row_id", nullable = false)
	private Long memberValidationSetRowId;

	@Column(name = "member_validation_criteria_id", nullable = false)
	private Long memberValidationCriteriaId;

	public Long getMemberValidationSetCriteriaId() {

		return memberValidationSetCriteriaId;
	}

	public void setMemberValidationSetCriteriaId(final Long memberValidationSetCriteriaId) {

		this.memberValidationSetCriteriaId = memberValidationSetCriteriaId;
	}

	public Integer getMemberValidationSetId() {

		return memberValidationSetId;
	}

	public void setMemberValidationSetId(final Integer memberValidationSetId) {

		this.memberValidationSetId = memberValidationSetId;
	}

	public Long getMemberValidationSetRowId() {

		return memberValidationSetRowId;
	}

	public void setMemberValidationSetRowId(final Long memberValidationSetRowId) {

		this.memberValidationSetRowId = memberValidationSetRowId;
	}

	public Long getMemberValidationCriteriaId() {

		return memberValidationCriteriaId;
	}

	public void setMemberValidationCriteriaId(final Long memberValidationCriteriaId) {

		this.memberValidationCriteriaId = memberValidationCriteriaId;
	}

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof MemberValidationSetCriteria)) {
			return false;
		}
		final MemberValidationSetCriteria castOther = (MemberValidationSetCriteria) other;
		return new EqualsBuilder().append(memberValidationSetCriteriaId, castOther.memberValidationSetCriteriaId)
				.append(memberValidationSetId, castOther.memberValidationSetId)
				.append(memberValidationSetRowId, castOther.memberValidationSetRowId)
				.append(memberValidationCriteriaId, castOther.memberValidationCriteriaId).isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(memberValidationSetCriteriaId).append(memberValidationSetId)
				.append(memberValidationSetRowId).append(memberValidationCriteriaId).toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("memberValidationSetCriteriaId", memberValidationSetCriteriaId)
				.append("memberValidationSetId", memberValidationSetId)
				.append("memberValidationSetRowId", memberValidationSetRowId)
				.append("memberValidationCriteriaId", memberValidationCriteriaId).toString();
	}

}
