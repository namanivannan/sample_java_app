package com.r1vs.platform.rox.api.service;

import com.r1vs.platform.rox.common.db.repository.business.StatusRepository;
import com.r1vs.platform.rox.common.model.business.Status;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Service
public class StatusService {

	@Autowired
	StatusRepository statusRepository;

	public Status getStatusByName(String status) {

		return statusRepository.getStatusByName(status);

	}

}
