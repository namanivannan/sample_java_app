package com.r1vs.platform.rox.api.controller.ds;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.junit.WireMockRule;
import com.r1vs.platform.rox.api.controller.DBConnection;
import com.r1vs.platform.rox.common.util.StringUtil;
import com.r1vs.platform.rox.interaction.fcs.connector.FCSConnector;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


@SpringBootTest
@RunWith(SpringRunner.class)
@AutoConfigureMockMvc
@Sql("/com/r1vs/platform/rox/api/controller/ds/fixture-for-interactions.sql")
@ActiveProfiles("test")
public class FMCSAControllerTest {


    @Autowired
    private MockMvc mockMvc;


    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private DBConnection dbConnection;

    private String token;

    private String token_user_1;

    private String token_user_2;

    @Rule
    public WireMockRule fcsServer = new WireMockRule(8100);

    @Before
    public void setUp() throws Exception {

        if (StringUtil.isNullOrEmpty(token)) {
            token = dbConnection.loginToDb();
        }
    }

    @Test
    @Ignore("investigating how to intercept datasource call to test error handling")
    public void test() throws Exception {


        stubFor(post(urlPathMatching("/qc/services/carriers/3177400?webKey=testkey/"))
                .willReturn(
                        aResponse().withStatus(500)));

        mockMvc.perform(MockMvcRequestBuilders.get("/v1/fmcsa/search?carrierName%3Afuzzy=&codeType=DOT&codeValue=3177400")
                .header("x-client-id", "11")
                .header("Authorization", token))
                .andExpect(status().isOk());



    }





}
