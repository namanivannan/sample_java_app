package com.r1vs.platform.rox.api.model;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;

public class ForgotPasswordRequest {

	@NotNull
	@Email
	private String email;

	public String getEmail() {

		return email;
	}

	public void setEmail(final String email) {

		this.email = email;
	}

}
