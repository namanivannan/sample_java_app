package com.r1vs.platform.rox.common.util;

import java.time.Clock;
import java.time.OffsetDateTime;

import com.r1vs.platform.rox.common.bean.DateConfigurationUtil;
import com.r1vs.platform.rox.common.util.DateUtil;
import org.junit.Assert;
import org.junit.Test;

public class DateUtilTest {

	public static final String VALID_DATE = "20210801";

	public static final String INVALID_DATE = "2021080100";

	public static final String EXPECTED_STRING_DATE = "08/01/2021";

	@Test
	public void testGetDeactivatedAtReturnsDate() {

		final OffsetDateTime date = OffsetDateTime.now(Clock.systemUTC());

		final OffsetDateTime result = DateUtil.getDeactivatedAtIfNotForeverDate(date);

		Assert.assertEquals(date, result);
	}

	@Test
	public void testGetDeactivatedAtReturnsNull() {

		final OffsetDateTime date = DateConfigurationUtil.foreverOffsetDateTime();

		final OffsetDateTime result = DateUtil.getDeactivatedAtIfNotForeverDate(date);

		Assert.assertNull(result);
	}

	@Test
	public void testIsNotForeverLocalDateReturnsTrue() {

		final OffsetDateTime date = OffsetDateTime.now(Clock.systemUTC());

		final boolean result = DateUtil.isNotForeverLocalDate(date);

		Assert.assertTrue(result);
	}

	@Test
	public void testIsNotForeverLocalDateReturnsFalse() {

		final OffsetDateTime date = DateConfigurationUtil.foreverOffsetDateTime();

		final boolean result = DateUtil.isNotForeverLocalDate(date);

		Assert.assertFalse(result);
	}

	@Test
	public void testValidStringToLocalDateWithFormat() {

		final String resultDateString =
				DateUtil.stringToLocalDateWithFormat(VALID_DATE, DateUtil.REQUEST_SLASH_DATE_FORMATTER);
		Assert.assertEquals(EXPECTED_STRING_DATE, resultDateString);

	}

	@Test
	public void testInvalidNullStringToLocalDateWithFormat() {

		final String resultDateString =
				DateUtil.stringToLocalDateWithFormat(null, DateUtil.REQUEST_SLASH_DATE_FORMATTER);
		Assert.assertNull(resultDateString);

	}

	@Test
	public void testInvalidEmptyStringToLocalDateWithFormat() {

		final String resultDateString =
				DateUtil.stringToLocalDateWithFormat(INVALID_DATE, DateUtil.REQUEST_SLASH_DATE_FORMATTER);
		Assert.assertNull(resultDateString);

	}

}
