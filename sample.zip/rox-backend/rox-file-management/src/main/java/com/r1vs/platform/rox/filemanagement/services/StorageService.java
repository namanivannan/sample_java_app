package com.r1vs.platform.rox.filemanagement.services;

import com.r1vs.platform.rox.common.db.repository.business.storage.RoxFileRepository;
import com.r1vs.platform.rox.common.model.business.Application;
import com.r1vs.platform.rox.common.model.business.storage.RoxFile;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

/**
 * The purpose of this service is to create a connection between RoxFileController and the S3Storage Service and
 * RoxFileRepository
 */
@Service
public class StorageService {

	public static final String YYYY_MM_DD_HOUR_FORMAT = "yyyyMMdd-hhmmss";

	private static final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern(YYYY_MM_DD_HOUR_FORMAT);

	@Autowired
	private S3Storage s3Storage;

	@Autowired
	private AmazonS3Config amazonS3Config;

	@Autowired
	private RoxFileRepository roxFileRepository;

	public RoxFile uploadFile(String clientId, MultipartFile file, String purpose, Application application)
			throws IOException {

		RoxFile roxFile = new RoxFile();
		roxFile.setUuid(UUID.randomUUID());
		roxFile.setFileName(truncateFileName(file.getOriginalFilename(), 50));
		roxFile.setFileType(file.getContentType());
		roxFile.setFileSize(file.getSize());
		roxFile.setPurpose(purpose);
		roxFile.setApplication(application);
		roxFile.setBucket(amazonS3Config.getBucketName());
		roxFile.setKey(generateKeyS3(clientId, application, roxFile));
		s3Storage.storeFile(roxFile, file.getInputStream());

		roxFileRepository.save(roxFile);

		return roxFile;
	}

	private String generateKeyS3(String clientId, Application application, RoxFile roxFile) {

		String s3FileName = truncateFileName(roxFile.getFileName(), 10);

		String key = LocalDateTime.now().format(dateFormatter) + "-" + s3FileName;
		key = key.replaceAll(" ", "-");
		return clientId + "/" + application.getUuid() + "/" + key;
	}

	private String truncateFileName(String fileName, int maxNameLength) {
		// truncates filename to max 10 and keeps the extension
		String[] tokens = fileName.split("\\.(?=[^\\.]+$)");
		String truncatedFileName = StringUtils.truncate(tokens[0], maxNameLength);
		return truncatedFileName + "." + tokens[1];
	}

	public String getFileURL(RoxFile roxFile) {

		return s3Storage.getFileURL(roxFile);
	}

	public Resource getFile(RoxFile roxFile) {

		return s3Storage.getFile(roxFile);
	}

	public void deleteFile(RoxFile roxFile) {

		s3Storage.deleteFile(roxFile);
		roxFileRepository.delete(roxFile);
	}
}