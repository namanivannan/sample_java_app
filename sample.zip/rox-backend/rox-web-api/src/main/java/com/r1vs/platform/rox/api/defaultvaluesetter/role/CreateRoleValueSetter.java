package com.r1vs.platform.rox.api.defaultvaluesetter.role;

import com.r1vs.platform.rox.api.defaultvaluesetter.RoxWriteWebApiDefaultValueSetter;
import com.r1vs.platform.rox.api.model.role.CreateRoleRequest;
import org.springframework.stereotype.Component;

@Component
public class CreateRoleValueSetter extends BaseRoleDefaultValueSetter
		implements RoxWriteWebApiDefaultValueSetter<CreateRoleRequest> {

	@Override
	public void setDefaultValues(final CreateRoleRequest createRoleRequest) {

		setDefaultRoleSystemName(createRoleRequest);
	}
}
