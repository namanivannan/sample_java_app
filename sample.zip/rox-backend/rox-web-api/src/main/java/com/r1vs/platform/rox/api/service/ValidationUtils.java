package com.r1vs.platform.rox.api.service;

import com.r1vs.platform.rox.api.exception.RoxApiException;
import com.r1vs.platform.rox.api.model.application.initiate.NotesDTO;
import com.r1vs.platform.rox.common.db.repository.business.ApplicationRepository;
import com.r1vs.platform.rox.common.db.repository.business.BusinessRepository;
import com.r1vs.platform.rox.common.db.repository.business.ClientRepository;
import com.r1vs.platform.rox.common.db.repository.business.OwnerRepository;
import com.r1vs.platform.rox.common.db.repository.core.UserRepository;
import com.r1vs.platform.rox.common.db.repository.ds.InteractionResponseRepository;
import com.r1vs.platform.rox.common.db.repository.business.storage.RoxFileRepository;
import com.r1vs.platform.rox.common.db.repository.note.NotesRepository;
import com.r1vs.platform.rox.common.db.repository.role.PrivilegeRepository;
import com.r1vs.platform.rox.common.model.business.*;
import com.r1vs.platform.rox.common.model.ds.InteractionName;
import com.r1vs.platform.rox.common.model.ds.InteractionResponse;
import com.r1vs.platform.rox.common.model.business.storage.RoxFile;
import com.r1vs.platform.rox.common.model.notes.Notes;
import com.r1vs.platform.rox.common.model.users.Privilege;
import com.r1vs.platform.rox.common.model.users.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.UUID;

/**
 * Provides Utility Methods to validate requests.
 */
@Service
public class ValidationUtils {

	private static final Logger LOGGER = LoggerFactory.getLogger(ValidationUtils.class);

	@Autowired
	private ClientRepository clientRepository;

	@Autowired
	private ApplicationRepository applicationRepository;

	@Autowired
	private OwnerRepository ownerRepository;

	@Autowired
	private NotesRepository notesRepository;

	@Autowired
	private PrivilegeRepository privilegeRepository;

	@Autowired
	private InteractionResponseRepository interactionResponseRepository;

	@Autowired
	private RoxFileRepository roxFileRepository;

	@Autowired
	private BusinessRepository businessRepository;

	@Autowired
	private UserRepository userRepository;

	/**
	 * Requires a Client object and throws Exception if not found.
	 * 
	 * @param clientId
	 * @return
	 */
	public Client requireClient(String clientId) {
		return requireClient(Long.valueOf(clientId));
	}
    /**
     * Requires a Client object and throws Exception if not found.
     *
     * @param clientId
     * @return
     */
    public Client requireClient(Integer clientId) {
        return requireClient(Long.valueOf(clientId));
    }
    /**
     * Requires a Client object and throws Exception if not found.
     *
     * @param clientId
     * @return
     */
    public Client requireClient(Long clientId) {
        return clientRepository.getClientById(clientId)
                .orElseThrow(() -> {
                    LOGGER.error("No client found with clientId: {}", clientId);
                    return new RoxApiException("Invalid clientId", HttpStatus.BAD_REQUEST);
                });
    }

	public Client requireClient(UUID clientId) {

		return clientRepository.findClientByUuid(clientId)
				.orElseThrow(() -> {
					LOGGER.error("No client found with clientId: {}", clientId);
					return new RoxApiException("Invalid clientId", HttpStatus.BAD_REQUEST);
				});
	}

	public Application requireApplication(UUID id, Client client) {

		return applicationRepository.getApplicationByUuidAndClient(id, client)
				.orElseThrow(() -> new RoxApiException("Application not found", HttpStatus.NOT_FOUND));
	}

	public Application requireApplication(UUID id) {

		return applicationRepository.getApplicationByUuid(id)
				.orElseThrow(() -> new RoxApiException("Application not found", HttpStatus.NOT_FOUND));
	}

	public RoxFile requireRoxFile(UUID id, Application application) {

		return roxFileRepository.getRoxFileByApplicationAndUuid(application, id)
				.orElseThrow(() -> new RoxApiException("File not found", HttpStatus.NOT_FOUND));
	}

	/**
	 * Requires Owner based on already instantiated Application and Client, to save requests to DB. Fails if not found.
	 * 
	 * @param client already instantiated Client
	 * @param application already instantiated Client
	 * @param ownerId UUID of Owner to retrieve.
	 * @return Owner object
	 */
	public Owner requireOwner(Client client, Application application, UUID ownerId) {

		return ownerRepository.findOwnerByApplicationAndApplicationClientAndUuid(application, client, ownerId)
				.orElseThrow(() -> new RoxApiException("Owner not found", HttpStatus.NOT_FOUND));
	}

	public Owner requireOwner(String clientId, UUID applicationId, UUID ownerId) {

		Client client = requireClient(clientId);
		Application application = requireApplication(applicationId, client);
		return ownerRepository.findOwnerByApplicationAndApplicationClientAndUuid(application, client, ownerId)
				.orElseThrow(() -> new RoxApiException("Owner not found", HttpStatus.NOT_FOUND));
	}

	public Notes requireApplicationNote(UUID notesId, Application application) {

		return notesRepository.findNotesByApplicationAndUuid(application, notesId)
				.orElseThrow(() -> new RoxApiException("Note not found", HttpStatus.BAD_REQUEST));
	}

	public Notes requireAttachmentNote(Application application, UUID notesId, RoxFile roxFile) {

		return notesRepository.findNotesByApplicationAndRoxFileAndUuid(application, roxFile, notesId)
				.orElseThrow(() -> new RoxApiException("Note not found", HttpStatus.BAD_REQUEST));
	}

	public Notes requireNote(String clientId, UUID applicationId, UUID noteId) {

		Client client = requireClient(clientId);
		Application application = requireApplication(applicationId, client);
		return notesRepository.findNotesByApplicationAndUuid(application, noteId)
				.orElseThrow(() -> new RoxApiException("Note not found", HttpStatus.NOT_FOUND));
	}

	public InteractionResponse requireInteractionResponse(UUID id, Client client) {

		return interactionResponseRepository.getInteractionResponseByUuidAndClient(id, client)
				.orElseThrow(() -> new RoxApiException("Interaction Response not found", HttpStatus.NOT_FOUND));
	}

	public InteractionResponse requireInteractionResponse(Client client, Application application, String name) {

		return interactionResponseRepository
				.findByApplicationAndClientAndName(application, client, InteractionName.valueOf(name))
				.orElseThrow(() -> new RoxApiException("Interaction Response not found", HttpStatus.NOT_FOUND));
	}

	public InteractionResponse requireInteractionResponse(Application application, UUID uuid) {

		return interactionResponseRepository
				.findByApplicationAndUuid(application, uuid)
				.orElseThrow(() -> new RoxApiException("Interaction Response not found", HttpStatus.NOT_FOUND));
	}

	public Business requireBusiness(Application application, BusinessCategory businessCategory) {

		return businessRepository.findByApplicationAndCategoryId(application, businessCategory)
				.orElseThrow(() -> new RoxApiException("Business not found", HttpStatus.INTERNAL_SERVER_ERROR));
	}

	public Privilege requirePrivilege(String systemName){
		return privilegeRepository.findBySystemName(systemName)
				.orElseThrow(() -> new RoxApiException(systemName+" privilege not found", HttpStatus.NOT_FOUND));
	}

	public User requireUser(Long userId){
		return userRepository.findById(userId)
				.orElseThrow(() -> new RoxApiException("User not found", HttpStatus.NOT_FOUND));
	}

}
