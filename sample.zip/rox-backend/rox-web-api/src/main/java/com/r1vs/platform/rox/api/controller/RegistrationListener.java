package com.r1vs.platform.rox.api.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

@Component
public class RegistrationListener implements ApplicationListener<OnRegistrationCompleteEvent> {

	@Autowired
	private RegistrationEmailService registrationEmailService;

	@Override
	public void onApplicationEvent(final OnRegistrationCompleteEvent event) {

		registrationEmailService.sendEmail(event.getUser(), event.getToken());

	}

}
