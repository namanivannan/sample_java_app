package com.r1vs.platform.rox.common.model.business;

import javax.persistence.*;

@Entity
@Table(name = "state")
public class State {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;

	@Column(name = "state")
	private String state;

	public int getId() {

		return this.id;
	}

	public void setId(int id) {

		this.id = id;
	}

	public String getState() {

		return state;
	}

	public void setState(String state) {

		this.state = state;
	}
}
