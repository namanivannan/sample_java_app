# rox-backend documentation
##

## Docker Services

You can use docker to run the following services:

- postgresql
- redis
- activemq
- localstack

### Ports

- PostgreSQL: 5656
- Redis: 6379
- ActiveMQ: 61616 
- LocalStack: 4566

To avoid conflicts with an active instance of postgresql, the docker container is set up to run postgresql internally 
on 5432 but expose it to your host machine on port 5656.

To access postgresql from outside the docker container use port 5656.  All rox services are already mapped to the 
port of 5656 for local development.

Additional tools such as DBeaver, pgAdmin, etc, should also use the exposed port of 5656 to access postgresql.


### Prerequisites

1. First install docker.
2. Install Python (Python 3.6 up to 3.9 is supported)
3. Install Pip (Python package manager)
4. Install AWS CLI
5. Make sure docker is running

You can check to see if docker was installed and running by checking for the version:

```bash
docker -v
```

You can install AWS CLI via pip:
```bash
pip install awscli
```
Setting up credentials for AWS S3
```bash
export AWS_ACCESS_KEY_ID="test"
export AWS_SECRET_ACCESS_KEY="test"
export AWS_DEFAULT_REGION="us-east-1"
```
Setting up encrypted properties password:
(Password for testing purposes is held by devs also, not documented anywhere)
```bash
export JASYPT_ENCRYPTOR_PASSWORD="XXXXXXX"
```
### Running the docker services

From the main repo directory e.g. rox-backend run the following command

```bash
docker-compose up -d
```
Create S3 Bucket
```bash
aws --endpoint-url=http://localhost:4566 s3 mb s3://roxbucket
```
Now that docker is up and running you can run your backend services

---

## Maven

### Useful maven commands

Running a build

```bash
mvn clean install -Dformatter.skip=true -Dspotbugs.skip=true -Dpmd.skip=true -Dfindbugs.skip=true -Dmaven.test.skip=true -Dmaven.gitcommitid.skip=true
```

Running a database migration

```bash
mvn liquibase:update -f ./rox-model/pom.xml -Dliquibase.contexts=qa
```

Additional parameters for a migration if you want to customize it (note the port is 5432 in this example - 
change it to the port postgresql is running on if needed)

Drop All

```bash
mvn liquibase:dropAll -f ./rox-model  -Dliquibase.username=roxwrite  -Dliquibase.password=roxwrite   -Dliquibase.url=jdbc:postgresql://localhost:5656/rox_local  
```

Running Integration Tests

```bash
mvn clean test -Dcheckstyle.skip=true -Dformatter.skip=true -Dspotbugs.skip=true -Dpmd.skip=true -Dfindbugs.skip=true -Dmaven.gitcommitid.skip=true 
```

Running Integration Tests

```bash
mvn clean install -P integration-test
```

Running Integration Tests with a Fail Fast (end tests when the first one fails)

```bash
mvn clean install -P integration-test -Dsurefire.skipAfterFailureCount=1
```

Running Api locally

```bash
mvn spring-boot:run -f ./rox-web-api/pom.xml -Dspring-boot.run.profiles=local -Dmaven.test.skip=true -Dformatter.skip=true -Dspotbugs.skip=true -Dpmd.skip=true -Dfindbugs.skip=true -Dcheckstyle.skip=true
```

Encrypting properties to use:

_(Password for testing purposes is held by devs also, not documented anywhere)_
```bash
# run this inside a module folder, it doesn't work on root folder!
mvn jasypt:encrypt-value -Djasypt.encryptor.password="PASSWORD TO USE" -Djasypt.plugin.value="theValueYouWantToEncrypt"
```

Creating a Hotfix environment.
```
Create a new roxwrite-backend branch from the currently deployed master branch git sha naming it hotfix*
e.g. hotfix-testing
Push the new branch
Create a hotfix* branch from the roxwrite-web repo and push.
That's it...
```
# Kubernetes commands



Configure your kubectl
```
aws eks update-kubeconfig --region us-east-1 --name roxwrite-eks-dev
```
