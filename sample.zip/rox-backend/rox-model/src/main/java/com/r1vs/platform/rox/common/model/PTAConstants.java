package com.r1vs.platform.rox.common.model;

public class PTAConstants {

	public static final String DEACTIVATED_AT = "deactivatedAt";

	public static final String EFFECTIVE_START_DATE = "effectiveStartDate";

	public static final String EFFECTIVE_END_DATE = "effectiveEndDate";

	public static final String ACTIVATED_AT = "activatedAt";
}
