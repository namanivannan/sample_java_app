package com.r1vs.platform.rox.common.model.rule;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

public class RulePriorityAssignmentGroup {

	private final List<RulePriority> rulePriorities = new ArrayList<>();

	public List<RulePriority> getRulePriorities() {

		return rulePriorities;
	}

	public void addRulePriority(final RulePriority rulePriority) {

		rulePriorities.add(rulePriority);
	}

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof RulePriorityAssignmentGroup)) {
			return false;
		}
		final RulePriorityAssignmentGroup castOther = (RulePriorityAssignmentGroup) other;
		return new EqualsBuilder().append(rulePriorities, castOther.rulePriorities).isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(rulePriorities).toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("rulePriorities", rulePriorities).toString();
	}

}
