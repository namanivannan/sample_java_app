package com.r1vs.platform.rox.common.model.rulesengine;

public enum RuleConditionFlag {

	INCLUDE("I"),
	EXCLUDE("E");

	private String name;

	RuleConditionFlag(final String name) {

		this.name = name;
	}

	/**
	 * Get string representation of rule condition flag.
	 *
	 * @return condition inclusion or exclusion flag
	 */
	public String value() {

		return name;
	}

}
