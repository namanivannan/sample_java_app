package com.r1vs.platform.rox.common.model.membervalidation;

import com.fasterxml.jackson.annotation.JsonProperty;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.Objects;

/**
 * The DTO for member validation set.
 */
public class MemberValidationSetDTO implements Serializable {

	private static final long serialVersionUID = 4685991200426920863L;

	@JsonProperty(value = "id")
	private String id;

	@JsonProperty(value = "memberValidationSetId")
	private String memberValidationSetId;

	/**
	 * One of the enum keys defined in StatusType.
	 */
	@JsonProperty(value = "status")
	private String status;

	@JsonProperty(value = "pbmId")
	private String pbmId;

	@JsonProperty(value = "name")
	private String name;

	@JsonProperty(value = "description")
	private String description;

	@JsonProperty(value = "pbmDefault")
	private Boolean pbmDefault;

	/**
	 * One of the enum keys defined in MemberValidationEnrollmentAuthenticationFailAction
	 */
	@JsonProperty(value = "enrollmentAuthenticationFailAction")
	private String enrollmentAuthenticationFailAction;

	@JsonProperty(value = "disableAuthenticationOnEnrollmentUpdate")
	private Boolean disableAuthenticationOnEnrollmentUpdate;

	@JsonProperty(value = "memberValidationCategories")
	private MemberValidationCategoryCriteriaIds memberValidationCategories;

	@JsonProperty(value = "effectiveStartDate")
	private LocalDate effectiveStartDate;

	@JsonProperty(value = "effectiveEndDate")
	private LocalDate effectiveEndDate;

	@JsonProperty(value = "createdAt")
	private OffsetDateTime createdAt;

	@JsonProperty(value = "deactivatedAt")
	private OffsetDateTime deactivatedAt;

	public String getId() {

		return id;
	}

	public void setId(final String id) {

		this.id = id;
	}

	public String getMemberValidationSetId() {

		return memberValidationSetId;
	}

	public void setMemberValidationSetId(final String memberValidationSetId) {

		this.memberValidationSetId = memberValidationSetId;
	}

	public String getStatus() {

		return status;
	}

	public void setStatus(final String status) {

		this.status = status;
	}

	public String getPbmId() {

		return pbmId;
	}

	public void setPbmId(final String pbmId) {

		this.pbmId = pbmId;
	}

	public String getName() {

		return name;
	}

	public void setName(final String name) {

		this.name = name;
	}

	public String getDescription() {

		return description;
	}

	public void setDescription(final String description) {

		this.description = description;
	}

	public Boolean getPbmDefault() {

		return pbmDefault;
	}

	public void setPbmDefault(final Boolean pbmDefault) {

		this.pbmDefault = pbmDefault;
	}

	public String getEnrollmentAuthenticationFailAction() {

		return enrollmentAuthenticationFailAction;
	}

	public void setEnrollmentAuthenticationFailAction(final String enrollmentAuthenticationFailAction) {

		this.enrollmentAuthenticationFailAction = enrollmentAuthenticationFailAction;
	}

	public Boolean getDisableAuthenticationOnEnrollmentUpdate() {

		return disableAuthenticationOnEnrollmentUpdate;
	}

	public void setDisableAuthenticationOnEnrollmentUpdate(final Boolean disableAuthenticationOnEnrollmentUpdate) {

		this.disableAuthenticationOnEnrollmentUpdate = disableAuthenticationOnEnrollmentUpdate;
	}

	public MemberValidationCategoryCriteriaIds getMemberValidationCategories() {

		return memberValidationCategories;
	}

	public void setMemberValidationCategories(final MemberValidationCategoryCriteriaIds memberValidationCategories) {

		this.memberValidationCategories = memberValidationCategories;
	}

	public LocalDate getEffectiveStartDate() {

		return effectiveStartDate;
	}

	public void setEffectiveStartDate(final LocalDate effectiveStartDate) {

		this.effectiveStartDate = effectiveStartDate;
	}

	public LocalDate getEffectiveEndDate() {

		return effectiveEndDate;
	}

	public void setEffectiveEndDate(final LocalDate effectiveEndDate) {

		this.effectiveEndDate = effectiveEndDate;
	}

	public OffsetDateTime getCreatedAt() {

		return createdAt;
	}

	public void setCreatedAt(final OffsetDateTime createdAt) {

		this.createdAt = createdAt;
	}

	public OffsetDateTime getDeactivatedAt() {

		return deactivatedAt;
	}

	public void setDeactivatedAt(final OffsetDateTime deactivatedAt) {

		this.deactivatedAt = deactivatedAt;
	}

	@Override
	public int hashCode() {

		return Objects.hash(createdAt, deactivatedAt, description, disableAuthenticationOnEnrollmentUpdate,
				effectiveEndDate, effectiveStartDate, enrollmentAuthenticationFailAction, id,
				memberValidationCategories, memberValidationSetId, name, pbmId, status);
	}

	@Override
	public boolean equals(final Object obj) {

		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final MemberValidationSetDTO other = (MemberValidationSetDTO) obj;
		return Objects.equals(createdAt, other.createdAt) && Objects.equals(deactivatedAt, other.deactivatedAt)
				&& Objects.equals(description, other.description)
				&& Objects.equals(disableAuthenticationOnEnrollmentUpdate,
						other.disableAuthenticationOnEnrollmentUpdate)
				&& Objects.equals(effectiveEndDate, other.effectiveEndDate)
				&& Objects.equals(effectiveStartDate, other.effectiveStartDate)
				&& Objects.equals(enrollmentAuthenticationFailAction, other.enrollmentAuthenticationFailAction)
				&& Objects.equals(id, other.id)
				&& Objects.equals(memberValidationCategories, other.memberValidationCategories)
				&& Objects.equals(memberValidationSetId, other.memberValidationSetId)
				&& Objects.equals(name, other.name) && Objects.equals(pbmId, other.pbmId)
				&& Objects.equals(status, other.status);
	}

	@Override
	public String toString() {

		final ToStringBuilder builder = new ToStringBuilder(this);
		builder.append("id", id).append("memberValidationSetId", memberValidationSetId).append("status", status)
				.append("pbmId", pbmId).append("name", name).append("description", description)
				.append("enrollmentAuthenticationFailAction", enrollmentAuthenticationFailAction)
				.append("disableAuthenticationOnEnrollmentUpdate", disableAuthenticationOnEnrollmentUpdate)
				.append("memberValidationCategories", memberValidationCategories)
				.append("effectiveStartDate", effectiveStartDate).append("effectiveEndDate", effectiveEndDate)
				.append("createdAt", createdAt).append("deactivatedAt", deactivatedAt);
		return builder.toString();
	}

}
