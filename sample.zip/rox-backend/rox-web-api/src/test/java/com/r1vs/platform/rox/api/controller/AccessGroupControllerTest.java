package com.r1vs.platform.rox.api.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.r1vs.platform.rox.api.model.application.initiate.AccessGroupDTO;
import com.r1vs.platform.rox.api.model.application.initiate.ApplicationDTO;
import com.r1vs.platform.rox.common.db.repository.business.ApplicationRepository;
import com.r1vs.platform.rox.common.model.business.Application;
import com.r1vs.platform.rox.common.util.StringUtil;
import org.apache.commons.io.IOUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Optional;
import java.util.UUID;

import static com.r1vs.platform.rox.api.controller.DBConnection.TEST_USER_1;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.*;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@Sql("fixture2.sql")
public class AccessGroupControllerTest {

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private DBConnection dbConnection;

	private String token;

	private String token_user_1;

	private String token_user_2;

	@Before
	public void setUp() throws Exception {

		if (StringUtil.isNullOrEmpty(token)) {
			token = dbConnection.loginToDb();
			token_user_1 = dbConnection.loginToDb(TEST_USER_1);
			token_user_2 = token;
		}
	}

	@Test
	public void givenValidSetOfRoles_whenCreateAccessGroupEndpointIsHit_thenCreateAccessGroupAndReturn201()
			throws Exception {

		AccessGroupDTO accessGroupDTO = new AccessGroupDTO();
		accessGroupDTO.setName("Access Group Test");
		accessGroupDTO.setRoles(new ArrayList<>());
		accessGroupDTO.getRoles().add("CLIENT_ADMIN");
		accessGroupDTO.getRoles().add("TEST_ROLE");

		mockMvc.perform(post("/v1/accessGroup")
				.header(AUTHORIZATION, token)
				.header("x-client-id", "11")
				.contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(accessGroupDTO)))
				.andExpect(status().isCreated())
				.andExpect(jsonPath("$.name", is("Access Group Test")))
				.andExpect(jsonPath("$.roles[0]", is("CLIENT_ADMIN")))
				.andExpect(jsonPath("$.roles[1]", is("TEST_ROLE")))
				.andDo(print());
	}
}