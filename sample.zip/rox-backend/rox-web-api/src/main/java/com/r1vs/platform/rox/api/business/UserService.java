package com.r1vs.platform.rox.api.business;

import com.r1vs.platform.rox.api.model.UserStatus;
import com.r1vs.platform.rox.api.model.application.initiate.UserResponseDTO;
import com.r1vs.platform.rox.api.repository.*;
import com.r1vs.platform.rox.api.service.MapperService;
import com.r1vs.platform.rox.api.util.InterceptorConstants;
import com.r1vs.platform.rox.common.db.repository.core.UserRepository;
import com.r1vs.platform.rox.common.db.service.core.QueryService;
import com.r1vs.platform.rox.common.model.business.Client;
import com.r1vs.platform.rox.common.model.users.*;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.Hibernate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.servlet.http.HttpServletRequest;
import java.time.Clock;
import java.time.OffsetDateTime;
import java.util.*;
import java.util.stream.Collectors;

import static com.r1vs.platform.rox.api.util.InterceptorConstants.CLIENT_ID;

@Component
public class UserService extends QueryService implements UserDetailsService {

    private static final Logger LOGGER = LoggerFactory.getLogger(UserService.class);
	private static final Integer INSTANCE_ADMIN_ROLE_ID = 1;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private UserAuditRepository userAuditRepository;

	@Autowired
	private UserRoleRepository userRoleRepository;

	@Autowired
	private RoleRepository roleRepository;

	@Autowired
	private UserRoleAuditRepository userRoleAuditRepository;

	@Autowired
	private RegistrationTokenRepository registrationTokenRepository;

	@Autowired
	private UserClientRepository userClientRepository;

	@Autowired
	private MapperService mapperService;

	/**
	 * Find User by username
	 *
	 * @param username the user's username
	 * @return the User
	 */
	@Transactional(readOnly = true)
	public Optional<User> findByUsername(final String username) {

		final Optional<User> userOptional = userRepository.findByUsername(username);
		userOptional.ifPresent(user -> Hibernate.initialize(user.getClient()));
		return userOptional;
	}

	/**
	 * Find User by id
	 *
	 * @param id the user's id
	 * @return the User
	 */
	public Optional<User> findById(final Long id) {

		return userRepository.findById(id);

	}

	public Optional<User> doesUserEmailAlreadyExist(final Long userId, final String email) {

		return userRepository.findByUserIdNotAndEmailIgnoreCase(userId, email);
	}

	/**
	 * Find existing user
	 *
	 * @param user user
	 * @return user
	 */
	public Optional<User> findExistingUser(final User user) {

		return userRepository.findByEmailIgnoreCase(user.getEmail());
	}

	/**
	 * Find existing user for mail and clientId
	 *
	 * @param email email
	 * @param clientId clientId
	 * @return user
	 */
	public Optional<User> findExistingUserForEmailAndClientId(final String email, final Integer clientId) {

		return this.findExistingUser(email, clientId);
	}

	/**
	 * Find existing user for clientId
	 *
	 * @param user user
	 * @param clientId clientId
	 * @return user
	 */
	public Optional<User> findExistingUserForClient(final User user, final Integer clientId) {

		return this.findExistingUser(user.getEmail(), clientId);
	}

	/**
	 *
	 * Find existing user for a given email and clientId
	 *
	 * @param email
	 * @param clientId
	 * @return
	 */
	private Optional<User> findExistingUser(final String email, final Integer clientId) {

		final CriteriaBuilder cb = getEntityManager().getCriteriaBuilder();
		final CriteriaQuery<User> cq = cb.createQuery(User.class);
		final Root<User> root = cq.from(User.class);

		final List<Predicate> predicates = new ArrayList<>();
		predicates.add(cb.equal(cb.upper(root.get(User_.email.getName())), email.toUpperCase()));
		//predicates.add(cb.equal(root.join(User_.client.getName()).get(Client_.clientId.getName()), clientId));

		cq.where(predicates.toArray(new Predicate[predicates.size()]));

		return getEntityManager().createQuery(cq).getResultList().stream().findFirst();
	}

	@Override
	@Transactional
	public UserDetails loadUserByUsername(final String userName) throws UsernameNotFoundException {

		Optional<User> userOptional = userRepository.findByUsername(userName);
		User user = userOptional.orElseThrow(() -> new UsernameNotFoundException(userName));
		Optional<Integer> clientId = getClientIdForRequest();

		List<UserRole> userRoleList = userRoleRepository.findByUserId(user.getUserId());

		return new org.springframework.security.core.userdetails.User(user.getUsername(),
				userOptional.get().getPassword(),
				getAuthorities(clientId, userRoleList));

	}

	private Collection<? extends GrantedAuthority> getAuthorities(Optional<Integer> clientId,
			List<UserRole> userRoleList) {

		List<Integer> roleIds = getRoleIdsListFromUserRoleList(userRoleList);

		List<Role> roleList = new ArrayList();
		//		clientId.ifPresent(integer -> roleList.addAll(roleRepository.findByRoleIdIn(roleIds)));
		roleList.addAll(roleRepository.findByRoleIdIn(roleIds));

		return getAuthorities(roleList);
	}

	private List<Integer> getRoleIdsListFromUserRoleList(List<UserRole> userRoleList) {

		return userRoleList.stream().map(UserRole::getRoleId).collect(Collectors.toList());
	}

	/**
	 * Create a new registration token for a user
	 *
	 * @param user the user
	 * @param token the user's token
	 * @return RegistrationToken
	 */
	public RegistrationToken createUserRegistrationToken(final User user, final String token) {

		return registrationTokenRepository.save(new RegistrationToken(user, token));
	}

	/**
	 * Refresh a user's registration token
	 *
	 * @param user the user
	 * @return tokenString the new token String
	 */
	public String updateUserRegistrationToken(final User user) {

		RegistrationToken registrationToken = user.getRegistrationToken();

		final String newToken = UUID.randomUUID().toString();

		if (registrationToken == null) {
			registrationToken = new RegistrationToken(user, newToken);
		} else {
			registrationToken.setToken(newToken);
			registrationToken.setExpiryDate(RegistrationToken.calculateExpiryDate(RegistrationToken.EXPIRATION));
		}

		registrationTokenRepository.save(registrationToken);

		return newToken;
	}

	/**
	 * Verify that a token is valid, return the user if valid
	 *
	 * @param token the registration token
	 *
	 * @return the User associated with the active token
	 */
	public User getUserFromToken(final String token) {

		final RegistrationToken registrationToken = registrationTokenRepository.findByToken(token);

		if (!isValidToken(registrationToken)) {
			return null;
		}

		return registrationToken.getUser();
	}

	/**
	 * Get RegistrationToken for userId and token String
	 *
	 * @param userId id of user
	 * @param token token String
	 * @return {@link RegistrationToken}
	 */
	public RegistrationToken getTokenByUserIdAndToken(final Integer userId, final String token) {

		final RegistrationToken registrationToken = registrationTokenRepository.findByUserIdAndToken(userId, token);

		if (!isValidToken(registrationToken)) {
			return null;
		}

		return registrationToken;
	}

	/**
	 * Expires registration token (sets expiry date to now)
	 *
	 * @param registrationToken {@link RegistrationToken}
	 */
	public void expireRegistrationToken(final RegistrationToken registrationToken) {

		if (registrationToken == null) {
			return;
		}
		registrationToken.setExpiryDate(OffsetDateTime.now(Clock.systemUTC()));

		registrationTokenRepository.save(registrationToken);
	}

	/**
	 *
	 * Verifies that a token exists and that is is valid (not expired).
	 *
	 * @param token the registration token
	 * @return <code>true</code> if token is valid <code>false</code> otherwise
	 */
	private boolean isValidToken(final RegistrationToken token) {

		if (token == null) {
			return false;
		}

		final OffsetDateTime tokenExpirationDateTime = token.getExpiryDate();
		final OffsetDateTime now = OffsetDateTime.now(Clock.systemUTC());

		if (tokenExpirationDateTime.isBefore(now) || tokenExpirationDateTime.isEqual(now)) {
			return false;
		}

		return true;
	}

	public Long findUsersTotalCount(final Integer clientId, final String username, final String email,
			final Integer roleId, final Integer userStatus, final Integer accessGroupId,
			final Boolean isNotInstanceAdmin) {

		final CriteriaBuilder cb = getEntityManager().getCriteriaBuilder();
		final CriteriaQuery<Long> cq = cb.createQuery(Long.class);
		final Root<User> root = cq.from(User.class);
		cq.select(cb.count(root));

		final List<Predicate> predicates = new ArrayList<>();
		predicates.addAll(
				createPredicatesForFilteringUsers(cb, root, clientId, username, email, roleId, userStatus,
						accessGroupId));
		predicates.addAll(createPredicatesForExcludingInstanceAdmin(cb, root, isNotInstanceAdmin));

		cq.where(predicates.toArray(new Predicate[predicates.size()]));

		final List<Long> resultList = getEntityManager().createQuery(cq).setMaxResults(1).getResultList();
		if (CollectionUtils.isEmpty(resultList)) {
			return 0L;
		}

		return resultList.get(0);
	}

	private List<Predicate> createPredicatesForFilteringUsers(final CriteriaBuilder cb, final Root<User> root,
			final Integer clientId, final String username, final String email, final Integer roleId,
			final Integer userStatus, final Integer accessGroupId) {

		final List<Predicate> predicates = new ArrayList<>();

		//Optional.ofNullable(clientId).ifPresent(
		//		role -> predicates
		//				.add(cb.equal(root.join(User_.client.getName()).get(Client_.clientId.getName()), clientId)));

		Optional.ofNullable(username).ifPresent(
				name -> predicates.add(cb.like(root.get(User_.username.getName()), prepareWildCardSearchString(name))));

		Optional.ofNullable(email).ifPresent(
				mail -> predicates.add(cb.like(root.get(User_.email.getName()), prepareWildCardSearchString(mail))));

		Optional.ofNullable(roleId).ifPresent(
				role -> predicates.add(cb.equal(root.join(User_.userRoles).get(UserRole_.roleId.getName()), role)));
		/*
				Optional.ofNullable(accessGroupId).ifPresent(
						accessGroup -> predicates.add(cb.equal(
								root.join(User_.accessGroups.getName()).get(UserGroup_.accessGroupId.getName()), accessGroup)));
		*/
		if (userStatus != null) {
			if (UserStatus.PENDING.key().equals(userStatus)) {
				predicates.add(cb.isFalse(root.get(User_.registered.getName())));
			} else if (UserStatus.ACTIVE.key().equals(userStatus)) {
				predicates.add(cb.isTrue(root.get(User_.registered.getName())));
				predicates.add(cb.or(cb.isNull(root.get(User_.active.getName())), cb
						.greaterThan(root.get(User_.active.getName()),
								OffsetDateTime.now(Clock.systemUTC()))));
			} else if (UserStatus.INACTIVE.key().equals(userStatus)) {
				predicates.add(cb.and(cb.isNotNull(root.get(User_.active.getName())), cb.lessThanOrEqualTo(
						root.get(User_.active.getName()), OffsetDateTime.now(Clock.systemUTC()))));
			}
		}

		return predicates;
	}

	public List<User> findUsersWithPagination(final Integer clientId, final String username, final String email,
			final Integer roleId, final Integer userStatus, final Integer accessGroupId,
			final Boolean isNotInstanceAdmin, final Integer pageNum,
			final Integer pageLimit) {

		final CriteriaBuilder cb = getEntityManager().getCriteriaBuilder();
		final CriteriaQuery<User> cq = cb.createQuery(User.class).distinct(true);
		final Root<User> root = cq.from(User.class);

		final List<Predicate> predicates = new ArrayList<>();
		predicates.addAll(
				createPredicatesForFilteringUsers(cb, root, clientId, username, email, roleId, userStatus,
						accessGroupId));
		predicates.addAll(createPredicatesForExcludingInstanceAdmin(cb, root, isNotInstanceAdmin));
		cq.orderBy(cb.desc(root.get(User_.UPDATED_AT)));
		cq.where(predicates.toArray(new Predicate[predicates.size()]));

		final TypedQuery<User> typedQuery = getEntityManager().createQuery(cq);
		typedQuery.setFirstResult(pageNum * pageLimit);
		typedQuery.setMaxResults(pageLimit);

		return typedQuery.getResultList();

	}

	/**
	 * Creates predicate that excludes INSTANCE_ADMIN users
	 *
	 * @param cb cb
	 * @param root root
	 * @param isNotInstanceAdmin isNotInstanceAdmin
	 * @return predicates
	 */
	private List<Predicate> createPredicatesForExcludingInstanceAdmin(final CriteriaBuilder cb, final Root<User> root,
			final Boolean isNotInstanceAdmin) {

		final List<Predicate> predicates = new ArrayList<>();
		if (Boolean.TRUE.equals(isNotInstanceAdmin)) {
			predicates.add(
					cb.notEqual(root.join(User_.userRoles).get(UserRole_.roleId.getName()), INSTANCE_ADMIN_ROLE_ID));

		}

		return predicates;
	}

	/**
	 * Get user ids of all instance admins
	 *
	 * @return list of ids
	 */
	public List<Integer> getInstanceAdminIds() {

		final CriteriaBuilder cb = getEntityManager().getCriteriaBuilder();
		final CriteriaQuery<Integer> cq = cb.createQuery(Integer.class);
		final Root<User> root = cq.from(User.class);

		cq.select(root.get(User_.userId.getName())).distinct(true);

		final List<Predicate> predicates = new ArrayList<>();

		predicates.add(cb.equal(root.join(User_.userRoles).get(UserRole_.roleId.getName()), INSTANCE_ADMIN_ROLE_ID));
		cq.where(predicates.toArray(new Predicate[predicates.size()]));

		return getEntityManager().createQuery(cq).getResultList();
	}

	public User saveUser(final User user) {

		return userRepository.save(user);

	}

	public List<UserRole> getRolesForUser(final Long userId) {

		return userRoleRepository.findByUserId(userId);
	}

	public void deleteUserRole(final UserRole userRole) {

		userRoleRepository.delete(userRole);

	}

	public void saveUserRole(final UserRole userRole) {

		userRoleRepository.save(userRole);

	}

	public void saveUserRoleAudit(final UserRoleAudit userRoleAudit) {

		userRoleAuditRepository.save(userRoleAudit);

	}

	public void saveUserAudit(final UserAudit userAudit) {

		userAuditRepository.save(userAudit);

	}

	public void saveUserClient(final UserClient userClient) {

		userClientRepository.save(userClient);
	}

	public void saveUserClients(final List<UserClient> userClients) {

		userClientRepository.saveAll(userClients);
	}

	private Collection<? extends GrantedAuthority> getAuthorities(final Collection<Role> roles) {

		return getGrantedAuthorities(getPrivileges(roles));
	}

	private Set<String> getPrivileges(final Collection<Role> roles) {

		final Set<String> privileges = new HashSet<>();
		final List<Privilege> fullPrivilegeList = new ArrayList<>();
		for (final Role role : roles) {
			fullPrivilegeList.addAll(role.getPrivileges());
		}
		for (final Privilege privilege : fullPrivilegeList) {
			privileges.add(privilege.getSystemName());
		}
		return privileges;
	}

	/**
	 * get a list of privileges from a given set
	 *
	 * @param privileges Set
	 * @return privileges List
	 */
	private List<GrantedAuthority> getGrantedAuthorities(final Set<String> privileges) {

		final List<GrantedAuthority> authorities = new ArrayList<>();
		for (final String privilege : privileges) {
			authorities.add(new SimpleGrantedAuthority(privilege));
		}
		return authorities;
	}

	private Optional<Integer> getClientIdForRequest() {

		final ServletRequestAttributes requestAttributes = (ServletRequestAttributes) RequestContextHolder
				.currentRequestAttributes();
		final HttpServletRequest request = requestAttributes.getRequest();
        if (StringUtils.isNumeric(request.getHeader(CLIENT_ID))) {
            return Optional.ofNullable(Integer.valueOf(request.getHeader(InterceptorConstants.CLIENT_ID)));
        }
        return Optional.empty();

	}

	public List<UserRole> getUserRoleByUserIdAndRoleId(final Integer userId, final Integer roleId) {

		return userRoleRepository.findAllByUserIdAndRoleId(userId, roleId);
	}

	/**
	 * Find existing user using Email Id
	 *
	 * @param email email
	 * @return user
	 */
	public Optional<User> findExistingUserByEmailId(final String email) {

		return userRepository.findByEmailIgnoreCase(email);
	}

	public Optional<String> findIfEmailIsRegistered(Client client, String email){
		return userRepository.findIfEmailIsRegistered(client, email);
	}


	public Page<UserResponseDTO> getAllUserPage(Long clientId, Pageable pageParams) {
		Page<UserResponseDTO> results = userRepository.findAllByClientId(clientId, pageParams)
				.map(user -> mapperService.getDTOFromEntity(user));

		return results;
	}
}
