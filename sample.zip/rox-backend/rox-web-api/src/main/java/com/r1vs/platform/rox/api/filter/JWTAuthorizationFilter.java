package com.r1vs.platform.rox.api.filter;

import com.r1vs.platform.rox.api.security.SecurityConstants;
import com.r1vs.platform.rox.api.util.TokenUtility;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class JWTAuthorizationFilter extends BasicAuthenticationFilter {

	private final UserDetailsService userDetailsService;

	public JWTAuthorizationFilter(final AuthenticationManager authManager,
			final UserDetailsService userDetailsService) {

		super(authManager);

		this.userDetailsService = userDetailsService;
	}

	@Override
	protected void doFilterInternal(final HttpServletRequest request, final HttpServletResponse response,
			final FilterChain chain) throws IOException, ServletException {

		final String header = request.getHeader(SecurityConstants.AUTH_STRING);

		if (header == null || !header.startsWith(SecurityConstants.TOKEN_PREFIX)) {
			chain.doFilter(request, response);
			return;
		}

		final UsernamePasswordAuthenticationToken authentication = getAuthentication(request);
		SecurityContextHolder.getContext().setAuthentication(authentication);
		chain.doFilter(request, response);
	}

	private UsernamePasswordAuthenticationToken getAuthentication(final HttpServletRequest request) {

		String token = request.getHeader(SecurityConstants.AUTH_STRING);

		if (token != null) {

			token = token.replace(SecurityConstants.TOKEN_PREFIX, "");

			final Claims claims = Jwts.parser().setSigningKey(SecurityConstants.SECRET.getBytes()).parseClaimsJws(token)
					.getBody();

			if (!TokenUtility.isAuthToken(claims)) {
				return null;
			}

			final String user = claims.getSubject();

			if (user != null) {
				final UserDetails userDetails = userDetailsService.loadUserByUsername(user);
				return new UsernamePasswordAuthenticationToken(user, null, userDetails.getAuthorities());
			}
		}
		return null;
	}
}
