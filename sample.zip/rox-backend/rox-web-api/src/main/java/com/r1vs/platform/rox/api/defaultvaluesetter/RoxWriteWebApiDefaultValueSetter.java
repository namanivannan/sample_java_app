package com.r1vs.platform.rox.api.defaultvaluesetter;

public interface RoxWriteWebApiDefaultValueSetter<T> {

	void setDefaultValues(T t);

}
