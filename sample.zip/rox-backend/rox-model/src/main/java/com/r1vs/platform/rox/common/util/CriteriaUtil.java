package com.r1vs.platform.rox.common.util;

import java.util.ArrayList;
import java.util.List;

public final class CriteriaUtil {

	private static final String COMMA = ",";

	private CriteriaUtil() {

	}

	/**
	 * Convert embedded criteria_ids string (CSVs) to list.
	 *
	 * @param embeddedCriteriaIds string of criteriaIds
	 * @return list of criteriaIds
	 */
	public static List<Long> getEmbeddedCriteriaIdsList(final String embeddedCriteriaIds) {

		final List<Long> criteriaIds = new ArrayList<>();

		for (final String criteriaId : embeddedCriteriaIds.split(COMMA)) {

			if (StringUtil.isNotNullOrEmpty(criteriaId)) {
				criteriaIds.add(Long.parseLong(criteriaId));
			}
		}
		return criteriaIds;
	}
}
