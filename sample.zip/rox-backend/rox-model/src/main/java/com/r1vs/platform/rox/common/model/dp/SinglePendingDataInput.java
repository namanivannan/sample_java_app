package com.r1vs.platform.rox.common.model.dp;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * Used to capture data input for the data registration where only one PENDING data input is allowed per registration.
 *
 */
@Entity
@Table(name = "dp_single_pending_data_input")
public class SinglePendingDataInput extends DataInput implements Serializable {

	private static final long serialVersionUID = 2628233015010123904L;

	@Column(name = "reg_code")
	private String regCode;

	@Column(name = "file_count")
	private Integer fileCount;

	/**
	 * Only set to 1 when state is PENDING to make sure for one registrationCode there is only one PENDING data input
	 * record.
	 */
	@Column(name = "pending_flag", nullable = true)
	private String pendingFlag;

	/**
	 * TODO: Check what cascade type to be used Change EAGER back to LAZY
	 */
	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL, mappedBy = "dataInput", orphanRemoval = true)
	private List<DataInputFile> dataInputFiles = new ArrayList<>();

	public String getRegCode() {

		return regCode;
	}

	public void setRegCode(final String regCode) {

		this.regCode = regCode;
	}

	public List<DataInputFile> getDataInputFiles() {

		return dataInputFiles;
	}

	public void setDataInputFiles(final List<DataInputFile> dataInputFiles) {

		this.dataInputFiles = dataInputFiles;
	}

	public String getPendingFlag() {

		return pendingFlag;
	}

	public void setPendingFlag(final String pendingFlag) {

		this.pendingFlag = pendingFlag;
	}

	public Integer getFileCount() {

		return fileCount;
	}

	public void setFileCount(final Integer fileCount) {

		this.fileCount = fileCount;
	}

}
