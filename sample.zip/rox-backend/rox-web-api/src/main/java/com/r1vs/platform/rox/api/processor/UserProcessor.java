package com.r1vs.platform.rox.api.processor;

import com.r1vs.platform.rox.api.business.RoleService;
import com.r1vs.platform.rox.api.business.UserService;
import com.r1vs.platform.rox.api.controller.ForgotPasswordEmailService;
import com.r1vs.platform.rox.api.controller.OnRegistrationCompleteEvent;
import com.r1vs.platform.rox.api.exception.RoxApiException;
import com.r1vs.platform.rox.api.exception.ValidationException;
import com.r1vs.platform.rox.api.model.*;
import com.r1vs.platform.rox.api.model.application.initiate.ChangePasswordDTO;
import com.r1vs.platform.rox.api.model.application.initiate.CheckEmailResponseDTO;
import com.r1vs.platform.rox.api.model.application.initiate.UpdateUserDTO;
import com.r1vs.platform.rox.api.model.application.initiate.UserResponseDTO;
import com.r1vs.platform.rox.api.repository.RoleRepository;
import com.r1vs.platform.rox.api.repository.UserRoleRepository;
import com.r1vs.platform.rox.api.service.AuditUtilsService;
import com.r1vs.platform.rox.api.service.MapperService;
import com.r1vs.platform.rox.api.service.ValidationUtils;
import com.r1vs.platform.rox.common.db.repository.application.EmailRepository;
import com.r1vs.platform.rox.common.model.business.Client;
import com.r1vs.platform.rox.common.model.security.AssignedClient;
import com.r1vs.platform.rox.common.model.security.AssignedPrivilege;
import com.r1vs.platform.rox.common.model.security.AssignedRole;
import com.r1vs.platform.rox.common.model.security.AssignedSecurityContext;
import com.r1vs.platform.rox.common.model.users.*;
import com.r1vs.platform.rox.common.util.StringUtil;
import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.converter.builtin.PassThroughConverter;
import ma.glasnost.orika.impl.DefaultMapperFactory;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.validation.Valid;
import java.time.Clock;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.*;
import java.util.stream.Collectors;

import static com.r1vs.platform.rox.api.response.ResponseMessages.*;

@Component
public class UserProcessor extends CommonProcessor<UserResponseDTO> {

	public static final String ROX_ADMIN = "ROX_ADMIN";

    @Autowired
    private ValidationUtils validationUtils;

	@Autowired
	private MapperService mapperService;

    @Autowired
	private UserService userService;

	@Autowired
	private RoleService roleService;

	@Autowired
	private AuditUtilsService auditUtilsService;

	@Autowired
	private ApplicationEventPublisher eventPublisher;

	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;

	@Autowired
	private UserRoleRepository userRoleRepository;

	@Autowired
	private RoleRepository roleRepository;

	@Autowired
	private ForgotPasswordEmailService forgotPasswordEmailService;

	@Autowired
	private EmailRepository emailRepository;

	MapperFactory mapperFactory = new DefaultMapperFactory.Builder().build();

	public static final Integer VERSION_ONE = 1;

	private static MapperFacade mapperFacade = null;

	static {

		final MapperFactory mapperFactory = new DefaultMapperFactory.Builder().mapNulls(false).build();
		mapperFactory.getConverterFactory().registerConverter(new PassThroughConverter(LocalDate.class));
		mapperFactory.getConverterFactory().registerConverter(new PassThroughConverter(LocalDateTime.class));
		mapperFacade = mapperFactory.getMapperFacade();
	}

	/**
	 * Processes getting all Users with optional filters
	 *
	 * @param username username filter
	 * @param email email filter
	 * @param roleId roleId filter
	 * @param userStatus status filter
	 * @param pageNum page number
	 * @param pageLimit page limit
	 *
	 * @return list of Users matching filters (if any)
	 */
	@Transactional
	public ResponseEntity<List<UserResponse>> processGetAllUsers(final String username, final String email,
			final Integer roleId, final Integer userStatus, final Integer accessGroupId, final Integer pageNum,
			final Integer pageLimit) {

		final Long currentUserId = getUserIdForRequest();
		final Boolean isNotInstanceAdmin = true;
		/*
				final Boolean isNotInstanceAdmin = userService.findById(currentUserId)
						.map(user -> !isInstanceAdmin(
								userGroupService.getAllRoleByUserIdAndPbmId(user.getUserId(), getPbmIdForRequest())))
						.orElseThrow(() -> new ValidationException(USER + currentUserId + DOES_NOT_EXIST));
		*/

		final Long userCount = userService.findUsersTotalCount(getClientIdForRequest(), username, email, roleId,
				userStatus, accessGroupId, isNotInstanceAdmin);

		final List<User> users = userService.findUsersWithPagination(getClientIdForRequest(), username, email, roleId,
				userStatus, accessGroupId, isNotInstanceAdmin, pageNum, pageLimit);

		final List<UserResponse> userResponses = new ArrayList<>();

		final OffsetDateTime now = OffsetDateTime.now(Clock.systemUTC());

		for (final User user : users) {

			userResponses.add(buildUserResponse(user, now));
		}

		return null;
	}

	/**
	 * Processes getting the current logged in user
	 *
	 * @return User object for logged in user
	 */
	@Transactional
	public ResponseEntity<UserResponse> processGetCurrentUser() {

		final Optional<User> user = userService.findById(getUserIdForRequest());

		if (user.isPresent()) {
			return new ResponseEntity<>(buildUserResponse(user.get(), OffsetDateTime.now(Clock.systemUTC()), true),
					HttpStatus.OK);
		}

		return new ResponseEntity<>(new UserResponse(), HttpStatus.NOT_FOUND);
	}

	private UserResponse buildUserResponse(final User user, final OffsetDateTime now) {

		return buildUserResponse(user, now, false);
	}

	private UserResponse buildUserResponse(final User user, final OffsetDateTime now,
			final boolean buildSecurityContext) {

		final Integer clientId = getClientIdForTheCurrentRequest();

		final UserResponse userResponse = mapperFacade.map(user, UserResponse.class);

		if (clientId != null) {
			getAccessGroupByUserId(user.getUserId()).ifPresent(accessGroup -> {
				userResponse.setAccessGroupId(accessGroup.getAccessGroupId());
				userResponse.setAccessGroupName(accessGroup.getGroupName());
			});
		}

		List<UserRole> roleList = userRoleRepository.findByUserId(user.getUserId());

		//TODO: Revisit this since it won't work when supporting multiple roles
		for (final UserRole userRole : roleList) {
			userResponse.setRoleDescription(userRole.getRole().getName());
		}

		if (buildSecurityContext) {
			final Set<AssignedRole> assignedRoles = new HashSet<>();
			final Set<AssignedPrivilege> assignedPrivileges = new HashSet<>();

			for (final UserRole userRole : roleList) {
				assignedRoles.add(new AssignedRole(userRole.getRole().getSystemName()));
				for (final Privilege privilege : userRole.getRole().getPrivileges()) {
					assignedPrivileges.add(new AssignedPrivilege(privilege.getSystemName()));
				}
			}
			final AssignedSecurityContext securityContext = new AssignedSecurityContext();
			securityContext.setPrivileges(new ArrayList<>(assignedPrivileges));
			securityContext.setRoles(new ArrayList<>(assignedRoles));
			if (user.getClient() != null) {
				securityContext.setClient(new AssignedClient(Math.toIntExact(user.getClient().getId()),
						user.getClient().getName()));
			}
			userResponse.setSecurityContext(securityContext);
		}
		/*
				if (user.getCode() != null) {
					userResponse.setPhoneTypeDescription(user.getCode().getCodeValue());
				}
		*/
		setStatus(userResponse, user, now, true);

		userResponse.setCreatedByFirstName(user.getCreatedBy().getFirstName());
		userResponse.setCreatedByLastName(user.getCreatedBy().getLastName());
		return userResponse;
	}

	private void setStatus(final UserResponse userResponse, final User user, final OffsetDateTime now,
			final boolean isAllUserView) {

		if (user.isRegistered()) {

			if (user.isActive() != null
					&& (!user.isActive())) {
				userResponse.setStatus(UserStatus.INACTIVE.value());
			} else {
				userResponse.setStatus(UserStatus.ACTIVE.value());
			}

		} else {

			userResponse.setStatus(UserStatus.PENDING.value());

			if (user.getRegistrationToken() == null) {
				// no token for a user, allow token to be created/re-sent
				userResponse.setCanBeResent(true);
				return;
			}

			final OffsetDateTime tokenExpiration = user.getRegistrationToken().getExpiryDate();

			if (isAllUserView) {

				// if getAllUserView, then only want to be able to resend if the token has
				// expired

				if (now.isAfter(tokenExpiration) || now.isEqual(tokenExpiration)) {
					userResponse.setCanBeResent(true);
				}
			} else {

				userResponse.setCanBeResent(true);

			}
		}

	}

	/**
	 * Process getting a specific User
	 *
	 * @param user the specific User to retrieve
	 * @return the User
	 */
	public ResponseEntity<UserResponse> processGetUser(final User user) {

		final UserResponse userResponse = mapUserToResponse(user);

		getAccessGroupByUserId(user.getUserId()).ifPresent(accessGroup -> {
			userResponse.setAccessGroupId(accessGroup.getAccessGroupId());
			userResponse.setAccessGroupName(accessGroup.getGroupName());
		});

		final OffsetDateTime now = OffsetDateTime.now(Clock.systemUTC());
		setStatus(userResponse, user, now, false);
		return new ResponseEntity<>(userResponse, HttpStatus.OK);
	}

	private Optional<AccessGroup> getAccessGroupByUserId(final Long userId) {

		/*
				final Optional<UserGroup> userGroup =
						userGroupService.getUserGroupByUserIdAndPbmId(userId, getPbmIdForRequest());
				if (userGroup.isPresent()) {
					return accessGroupService.getById(userGroup.get().getAccessGroupId());
				}
		*/
		return Optional.empty();
	}

	/**
	 * Map user to user response
	 *
	 * @param user user
	 * @return user response
	 */
	private UserResponse mapUserToResponse(final User user) {

		final UserResponse userResponse = mapperFacade.map(user, UserResponse.class);

		final List<Integer> roleIds = null;
		/*
				final List<Integer> roleIds =
						userGroupService.getAllRoleByUserIdAndClientId(user.getUserId(), getPbmIdForRequest()).stream()
								.map(r -> r.getRoleId()).collect(Collectors.toList());
		*/

		userResponse.setRoleIds(roleIds);

		userResponse.setCreatedByFirstName(user.getCreatedBy().getFirstName());
		userResponse.setCreatedByLastName(user.getCreatedBy().getLastName());

		return userResponse;
	}

	public void processSaveCurrentUserPassword(final ChangePasswordDTO changePasswordDTO) {
        final Optional<User> userOptional = userService.findById(getUserIdForRequest());
        if (userOptional.isPresent()) {
            User user = userOptional.get();
            if (!bCryptPasswordEncoder.matches(changePasswordDTO.oldPassword, user.getPassword())) {
                throw new RoxApiException("Wrong old password", HttpStatus.BAD_REQUEST);
            }
            user.setPassword(bCryptPasswordEncoder.encode(changePasswordDTO.newPassword));
            userService.saveUser(user);
        }
	}

	public void processAdminSavePassword(Long userId, final ChangePasswordDTO changePasswordDTO) {
		User user = validationUtils.requireUser(userId);
		user.setPassword(bCryptPasswordEncoder.encode(changePasswordDTO.newPassword));
		userService.saveUser(user);
	}

	/**
	 * Process Updating a User
	 *
	 * @param updateUserRequest the updateUser request
	 * @param user the User to update
	 * @param roles the User's role
	 * @return the MessageResponse
	 */
	public ResponseEntity<MessageResponse> processUpdateUser(final UpdateUserRequest updateUserRequest, final User user,
			final List<Role> roles) {

		if (!user.isRegistered()) {

			processResendUserToken(user);
		}

		user.setUserId(updateUserRequest.getUserId());
		user.setFirstName(updateUserRequest.getFirstName());
		user.setLastName(updateUserRequest.getLastName());
		user.setEmail(updateUserRequest.getEmail());
		//user.setPhoneTypeId(updateUserRequest.getPhoneTypeCodeId());
		//user.setPhone(updateUserRequest.getPhone());
		// if termination date is sent as null, that should effectively make a user
		// active again
		user.setActive(updateUserRequest.isActive());

		boolean passwordChanged = false;

		if (StringUtil.isNotNullOrEmpty(updateUserRequest.getPassword())) {

			// password has been updated
			user.setPassword(bCryptPasswordEncoder.encode(updateUserRequest.getPassword()));

			passwordChanged = true;
		}

		updateUser(user, roles, passwordChanged);

		final MessageResponse messageResponse = new MessageResponse();
		messageResponse.setMessage(USER + user.getUsername() + " updated.");
		return new ResponseEntity<>(messageResponse, HttpStatus.OK);
	}

	/**
	 * Process terminating a User DEPRECATED
	 * 
	 * @param user the User to terminate
	 * @return the MessageResponse
	 */
	public ResponseEntity<MessageResponse> processDisableUserProcella(final User user) {

		user.setActive(false);

		updateUser(user);

		final MessageResponse messageResponse = new MessageResponse();
		messageResponse.setMessage(USER + user.getUsername() + " updated.");
		return new ResponseEntity<>(messageResponse, HttpStatus.OK);
	}

	/**
	 * Process getting User's history
	 *
	 * @param user the User
	 * @param results pre-processed User's history
	 * @return the User's history
	 */
	public List<UserAuditResponse> processUserAudit(final User user, final List<UserAudit> results) {

		final List<UserAuditResponse> auditResponses = new ArrayList<>();

		for (final UserAudit result : results) {

			final UserAuditResponse auditResponse = mapperFacade.map(result, UserAuditResponse.class);
			auditResponse.setInvitedAt(user.getCreatedAt());

			if (user.getCreatedBy() != null) {
				auditResponse.setInvitedBy(user.getCreatedBy().getUsername());
			}

			if (result.getCode() != null) {
				auditResponse.setPhoneTypeDescription(result.getCode().getCodeValue());
			}

			if (!result.getRoles().isEmpty()) {

				final Role role = result.getRoles().get(0);

				if (role != null) {
					auditResponse.setRoleDescription(role.getName());
				}
			}

			auditResponse.setUpdatedByFirstName(result.getUpdatedUser().getFirstName());
			auditResponse.setUpdatedByLastName(result.getUpdatedUser().getLastName());

			auditResponses.add(auditResponse);
		}

		return auditResponses;
	}

	/**
	 * Process re-sending a User's token
	 *
	 * @param user the User
	 *
	 * @return the MessageResponse
	 */
	public ResponseEntity<MessageResponse> processResendUserToken(final User user) {

		final String newToken = userService.updateUserRegistrationToken(user);

		eventPublisher.publishEvent(new OnRegistrationCompleteEvent(user, newToken));

		final MessageResponse messageResponse = new MessageResponse();
		messageResponse.setMessage(USER + user.getUsername() + " token resent updated.");
		return new ResponseEntity<>(messageResponse, HttpStatus.OK);
	}

	/**
	 * Create a User and create the UserRole relationship
	 *
	 * @param user the new user //* @param roles the new user's role
	 * @return the new user
	 */
	private User createUser(final User user, final List<Role> roles) {

		user.setVersion(VERSION_ONE);
		final User createdUser = userService.saveUser(user);

		final UserAudit userAudit = mapperFacade.map(user, UserAudit.class);

		userAudit.setUserRoleVersion(VERSION_ONE);
		userService.saveUserAudit(userAudit);

		persistUserRole(roles, createdUser);
		return createdUser;
	}

	public void persistUserRole(List<Role> roles, User createdUser) {

		for (final Role role : roles) {
			final UserRole userRole = new UserRole();
			userRole.setUserId(createdUser.getUserId());
			userRole.setRoleId(role.getRoleId());
			userRole.setVersion(VERSION_ONE);

			createUserRole(userRole);
		}
	}

	/**
	 * Save a new UserRole relationship and also its associated UserRoleAudit entity
	 *
	 * @param userRole the new UserRole relationship
	 */
	private void createUserRole(final UserRole userRole) {

		userService.saveUserRole(userRole);

		final UserRoleAudit userRoleAudit = mapperFacade.map(userRole, UserRoleAudit.class);

		userService.saveUserRoleAudit(userRoleAudit);
	}

	/**
	 * Update a user
	 *
	 * @param user the user to update
	 * @return the updated user
	 */
	private User updateUser(final User user) {

		return updateUser(user, null, false);
	}

	/**
	 * Update a user with role information
	 *
	 * @param user the user to update
	 * @param roles the role of the user
	 * @param passwordChanged <code>true</code> if the user password has changed <code>false</code> otherwise
	 * @return the updated user
	 */
	private User updateUser(final User user, final List<Role> roles, final boolean passwordChanged) {

		final Integer newVersion = user.getVersion() + 1;
		user.setVersion(newVersion);
		//as long as the role list is not empty and the lists are different
		final Set<Role> newRoles = roles == null ? new HashSet<>() : new HashSet<>(roles);
		final boolean needToProcessRoles = false;
		/*
				final boolean needToProcessRoles =
						newRoles.isEmpty() == false && notSame(
								userGroupService.getAllRoleByUserIdAndPbmId(user.getUserId(), getPbmIdForRequest()), newRoles);
		*/

		userService.saveUser(user);

		if (needToProcessRoles) {
			final List<UserRole> userRoleList = userRoleRepository.findByUserId(user.getUserId()).stream()
					.collect(Collectors.toList());
			userRoleRepository.deleteAll(userRoleList);
			final List<UserRole> newUserRoleList = newRoles.stream().map(role -> {
				UserRole userRole = new UserRole();
				userRole.setUserId(user.getUserId());
				userRole.setRoleId(role.getRoleId());
				userRole.setVersion(VERSION_ONE);
				return userRole;
			}).collect(Collectors.toList());
			userRoleRepository.saveAll(newUserRoleList);
		}

		saveUserAudit(user, needToProcessRoles ? newRoles : null, passwordChanged);

		return user;
	}

	private boolean notSame(final List<Role> existingRoles, final Set<Role> newRoles) {

		return !new HashSet<>(existingRoles).equals(newRoles);
	}

	/**
	 * Saves the updated version of the user to the UserAudit table
	 *
	 * @param user the updated user
	 * @param newRoles the user's role
	 * @param passwordChanged <code>true</code> if the user password has changed <code>false</code> otherwise
	 */
	private void saveUserAudit(final User user, final Set<Role> newRoles, final boolean passwordChanged) {

		final UserAudit userAudit = mapperFacade.map(user, UserAudit.class);
		//userAudit.setPasswordUpdated(passwordChanged);
		if (userAudit.getRoles() != null) {
			userAudit.getRoles().clear();
		}
		//TODO: remove the user role version completely and store a number of roles instead
		userAudit.setUserRoleVersion(VERSION_ONE);

		if (!CollectionUtils.isEmpty(newRoles)) {
			auditUserRoles(user.getUserId(), newRoles);
		}

		userService.saveUserAudit(userAudit);
	}

	/**
	 * For each of the role assigned, we create the user role audit.
	 *
	 * @param userId
	 * @param roles
	 */
	private void auditUserRoles(final Long userId, final Set<Role> roles) {

		for (final Role role : roles) {

			final UserRole newUserRole = new UserRole();
			newUserRole.setUserId(userId);
			newUserRole.setRoleId(role.getRoleId());
			//TODO: remove the version
			newUserRole.setVersion(VERSION_ONE);

			final UserRoleAudit userRoleAudit = mapperFacade.map(newUserRole, UserRoleAudit.class);
			userService.saveUserRoleAudit(userRoleAudit);
		}
	}

    /**
     * Process user sign up request
     *
     * @param userRequest {@link CreateUserRequest}
     * @return {@link User}
     */
    public User processCreateUserAssociate(@Valid final CreateUserRequest userRequest, String clientId) {
        Client client = validationUtils.requireClient(clientId);
        final User createdUser = processCreateUser(userRequest);
        createdUser.setClient(client);
        userService.saveUser(createdUser);
        return createdUser;
    }
	/**
	 * Process user sign up request
	 *
	 * @param userRequest {@link CreateUserRequest}
	 * @return {@link User}
	 */
	public User processCreateUser(@Valid final CreateUserRequest userRequest) {

		final User user = mapUserRequestToUser(userRequest);
		user.setPassword(bCryptPasswordEncoder.encode(user.getPassword()));
		user.setActive(true);
        // we should not allow creating new with superuser flag true
        user.setSuperuser(false);

		validateUniqueUsername(user);

		final List<Role> roles = fetchAndValidateRoles(userRequest.getUserRoles(), new ArrayList<>());

		final User createdUser = createUser(user, roles);

		/*

		final String token = userService.updateUserRegistrationToken(user);
		eventPublisher.publishEvent(new OnRegistrationCompleteEvent(createdUser, token));

		 */
		return createdUser;
	}

	public CheckEmailResponseDTO validateUniqueEmail(String clientId, String email) {

		CheckEmailResponseDTO checkEmailResponseDTO = new CheckEmailResponseDTO();

		checkEmailResponseDTO.setExists(userService.findIfEmailIsRegistered(
				validationUtils.requireClient(clientId), email).isPresent());

		return checkEmailResponseDTO;
	}

	private void persistUserGroupOfUser(@Valid CreateUserRequest userRequest, User createdUser) {

		/*
				final UserGroup userGroupForSave = new UserGroup();
				userGroupForSave.setUserId(createdUser.getUserId());
				userGroupForSave.setAccessGroupId(userRequest.getAccessGroupId());
				userGroupForSave.setPbmId(getPbmIdForRequest());
				userGroupService.create(userGroupForSave);
		*/
	}

	private User mapUserRequestToUser(final UserRequest userRequest) {

		return mapperFacade.map(userRequest, User.class);
	}

	/**
	 * Fetch the roles given the roleId list and apply validation.
	 *
	 * @param roleNames
	 * @param existingRoles
	 * @return
	 */
	public List<Role> fetchAndValidateRoles(/*final List<Integer> roleIds,*/
			final List<String> roleNames,
			final List<Role> existingRoles) {

		if (CollectionUtils.isEmpty(roleNames)) {
			return Collections.emptyList();
		}
		//		final List<Role> roles = roleService.findByRoleIdIn(roleIds);
		final List<Role> roles = roleService.findByRoleName(roleNames);
		if (CollectionUtils.isEmpty(roles)) {
			throw new ValidationException("No roles found");
		}
		if (roles.size() != roleNames.size()) {
			throw new ValidationException("Number of roles found does not match the number of input ids");
		}
		if (isInstanceAdmin(roles) && !isInstanceAdmin(existingRoles)) {
			throw new ValidationException("Invalid roles found in the input ids");
		}
		return roles;
	}

	/**
	 * Validate roleId
	 *
	 * @param roleId roleId
	 * @param existingRoles existingRoles
	 * @return {@link Role}
	 */
	public Role validateRole(final Integer roleId, final Set<Role> existingRoles) {

		final Role role = roleService.getRoleByRoleId(roleId);

		if (role == null) {

			throw new ValidationException(ROLE + DOES_NOT_EXIST);
		}

		if (UserReferenceProcessor.ROX_ADMIN.equals(role.getSystemName()) && !isInstanceAdmin(existingRoles)) {

			throw new ValidationException("Invalid role");
		}

		return role;
	}

	private boolean isInstanceAdmin(final Collection<Role> roles) {

		return roles.stream().map(Role::getSystemName).anyMatch(UserReferenceProcessor.ROX_ADMIN::equals);
	}

	private User processAddUserToClient(final User existingUser, final User newUser) {

		validateUniqueUserForClient(newUser);
		validateUsernameMatches(existingUser, newUser);

		final UserClient userClient = new UserClient();
		userClient.setUserId(existingUser.getUserId());
		userClient.setClientId(getClientIdForRequest());
		userService.saveUserClient(userClient);

		return existingUser;
	}

	private void validateUniqueUserForClient(final User user) {

		final Optional<User> existingUser = userService.findExistingUserForClient(user, getClientIdForRequest());
		if (existingUser.isPresent()) {
			throw new ValidationException(USER_EMAIL_EXISTS + user.getEmail());
		}
	}

	private void validateUsernameMatches(final User existingUser, final User newUser) {

		if (!existingUser.getUsername().equalsIgnoreCase(newUser.getUsername())) {
			throw new ValidationException(USERNAME_NOT_MATCH);
		}
	}

	private void validateUniqueUsername(final User user) {

		final Optional<User> existingUser = userService.findByUsername(user.getUsername());
		if (existingUser.isPresent()) {
			throw new ValidationException(USER_EXISTS + user.getUsername());
		}
	}

	public ResponseEntity<MessageResponse> processUpdateUser(final UpdateUserRequest updateUserRequest) {

		/*
				if (updateUserRequest.getAccessGroupId() != null) {
		
					final User user = userService.findById(updateUserRequest.getUserId())
							.orElseThrow(() -> new ValidationException(USER + updateUserRequest.getUserId() + DOES_NOT_EXIST));
		
					final AccessGroup accessGroup = accessGroupService.getById(updateUserRequest.getAccessGroupId())
							.orElseThrow(() -> new RuntimeException("Invalid Access group"));
		
					final Optional<UserGroup> userGroup =
							userGroupService.getUserGroupByUserIdAndPbmId(user.getUserId(), getPbmIdForRequest());
					if (userGroup.isPresent()) {
						userGroup.get().setAccessGroupId(updateUserRequest.getAccessGroupId());
						userGroup.get().setPbmId(getPbmIdForRequest());
						userGroupService.update(userGroup.get());
					} else {
						final UserGroup userGroupForSave = new UserGroup();
						userGroupForSave.setPbmId(getPbmIdForRequest());
						userGroupForSave.setUserId(user.getUserId());
						userGroupForSave.setAccessGroupId(accessGroup.getAccessGroupId());
						userGroupService.create(userGroupForSave);
					}
		
					final List<Role> roles =
							accessGroupService.getRoleListByAccessGroupId(updateUserRequest.getAccessGroupId());
		
					return processUpdateUser(updateUserRequest, user, roles);
				} else {
					return userService.findById(updateUserRequest.getUserId()).map(registeredUser -> {
						final List<Role> roles = fetchAndValidateRoles(updateUserRequest.getRoleIds(),
								userGroupService.getAllRoleByUserIdAndPbmId(registeredUser.getUserId(), getPbmIdForRequest()));
						userGroupService.removeUserGroupByUserId(updateUserRequest.getUserId());
		
						return processUpdateUser(updateUserRequest, registeredUser, roles);
					}).orElseThrow(() -> new ValidationException(USER + updateUserRequest.getUserId() + DOES_NOT_EXIST));
				}
		*/
		return null;
	}

	public ResponseEntity<ForgotPasswordResponse>
			processForgotPassword(final ForgotPasswordRequest forgotPasswordRequest) {

		Optional<User> user = userService.findExistingUserByEmailId(forgotPasswordRequest.getEmail());
		ForgotPasswordResponse forgotPasswordResponse = new ForgotPasswordResponse();
		forgotPasswordResponse.setEmailId(forgotPasswordRequest.getEmail());
		/*
				if (user.isEmpty() || user.get().isActive() != null) {
					forgotPasswordResponse.setResponseMessage(FORGOT_PASSWORD);
					return new ResponseEntity<>(forgotPasswordResponse, HttpStatus.OK);
				}*/

		final String token = userService.updateUserRegistrationToken(user.get());

		forgotPasswordEmailService.sendEmail(user.get(), token);

		forgotPasswordResponse.setResponseMessage(FORGOT_PASSWORD);
		return new ResponseEntity<>(forgotPasswordResponse, HttpStatus.OK);

	}

	/**
	 *
	 * @param clientId
	 * @param pageParams
	 * @return
	 */
	public ResponseEntity<List<UserResponseDTO>> processGetAllUsersPage(Long clientId, Pageable pageParams) {
		Page<UserResponseDTO> userResponseDTOS = userService.getAllUserPage(clientId, pageParams);

		return buildResponseAsListWithPagination(
				userResponseDTOS.getTotalElements(),
				userResponseDTOS.getNumber(),
				userResponseDTOS.getPageable().getPageSize(),
				userResponseDTOS.get().collect(Collectors.toList()));
	}

	public ResponseEntity<MessageResponse> processDisableUser(User user) {

		ResponseEntity<MessageResponse> response;
		final MessageResponse messageResponse = new MessageResponse();
		if (user.isActive()) {
			user.setActive(false);

			userService.saveUser(user);

			messageResponse.setMessage(USER + user.getUsername() + " set to inactive.");
			response = new ResponseEntity<>(messageResponse, HttpStatus.OK);
		} else {
			messageResponse.setMessage(USER + user.getUsername() + " is already inactive.");
			response = new ResponseEntity<>(messageResponse, HttpStatus.BAD_REQUEST);
		}
		return response;
	}

	public ResponseEntity<MessageResponse> processEnableUser(User user) {

		ResponseEntity<MessageResponse> response;
		final MessageResponse messageResponse = new MessageResponse();
		if (user.isActive()) {
			messageResponse.setMessage(USER + user.getUsername() + " is already active.");
			response = new ResponseEntity<>(messageResponse, HttpStatus.BAD_REQUEST);
		} else {
			user.setActive(true);
			userService.saveUser(user);
			messageResponse.setMessage(USER + user.getUsername() + " set to active.");
			response = new ResponseEntity<>(messageResponse, HttpStatus.OK);
		}
		return response;
	}

	@Transactional
	public User processUpdateUser(UpdateUserDTO updateUserDTO, Long userId) {
		User user = userService.findById(userId)
				.orElseThrow(() -> new RoxApiException("User not found", HttpStatus.NOT_FOUND));
		mapperService.patchExistingData(user, updateUserDTO);
		userService.saveUser(user).getUserId();
		auditUtilsService.recoverAuditObjects(user);
		if (null!=updateUserDTO.getRoles()){
			if (updateUserDTO.getRoles().contains(ROX_ADMIN)){
				throw new RoxApiException("ROX_ADMIN CANNOT BE ASSIGNED", HttpStatus.FORBIDDEN);
			}
			userRoleRepository.deleteAllByUserId(userId);
			for (String role: updateUserDTO.getRoles()){
				Role roleFromRepo = roleRepository.findRoleBySystemName(role);
				UserRole userRole = new UserRole();
				userRole.setRoleId(roleFromRepo.getRoleId());
				userRole.setUserId(userId);
				userRole.setVersion(1);
				createUserRole(userRole);
			}
		}
		return user;
	}
    public void processUpdateCurrentUser(UpdateUserDTO updateUserDTO) {
        final Optional<User> userOptional = userService.findById(getUserIdForRequest());
        if (userOptional.isPresent()) {
            User user = userOptional.get();
            mapperService.patchExistingData(user, updateUserDTO);
            userService.saveUser(user).getUserId();
            auditUtilsService.recoverAuditObjects(user);
        }
    }
}
