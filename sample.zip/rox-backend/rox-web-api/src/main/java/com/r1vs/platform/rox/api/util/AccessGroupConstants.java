package com.r1vs.platform.rox.api.util;

public class AccessGroupConstants {

	public static final String STATUS = "statusId";

	public static final String INVALID_STATUS = "INVALID_STATUS";

	public static final String INVALID_STATUS_TRANSITION = "INVALID_STATUS_TRANSITION";

	public static final String INVALID_STATUS_FOR_CREATE = "INVALID_STATUS_FOR_CREATE";

	public static final String ACCESS_GROUP_ID = "accessGroupId";

	public static final String NONEXISTENT_ACCESS_GROUP = "NONEXISTENT_ACCESS_GROUP";

	public static final String ROLE_ID = "roleId";

	public static final String INVALID_ROLE = "INVALID_ROLE";

	public static final String GROUP_NAME = "groupName";

	public static final String GROUP_NAME_IS_ALREADY_IN_USE = "GROUP_NAME_IS_ALREADY_IN_USE";

	public static final String GROUP_NAME_IT_IS_REQUIRED = "GROUP_NAME_IT_IS_REQUIRED";

	public static final String INVALID_GROUP_NAME_LENGTH = "INVALID_GROUP_NAME_LENGTH";

	public static final String GROUP_DESCRIPTION = "groupDescription";

	public static final String INVALID_GROUP_DESCRIPTION_LENGTH = "INVALID_GROUP_DESCRIPTION_LENGTH";
}
