package com.r1vs.platform.rox.api.controller.role;

import com.r1vs.platform.rox.api.model.application.initiate.PrivilegeDTO;
import com.r1vs.platform.rox.api.service.PrivilegeService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static com.r1vs.platform.rox.api.util.InterceptorConstants.CLIENT_ID;

@RestController
@RequestMapping(value = "/v1", produces = { MediaType.APPLICATION_JSON_VALUE })
@Tag(name = "privilege", description = "Privilege Service")
@Validated
public class PrivilegeController {

	@Autowired
	private PrivilegeService privilegeService;

	@PostMapping("/privileges")
	@Operation(summary = "Creates privilege")
	public ResponseEntity<PrivilegeDTO> createPrivilege(@RequestHeader(CLIENT_ID) String clientId,
												  @RequestBody PrivilegeDTO privilegeDTO){
		return new ResponseEntity<>(privilegeService.createPrivilege(clientId, privilegeDTO), HttpStatus.CREATED);
	}

	@PatchMapping("/privileges/{systemName}")
	@Operation(summary = "Modifies a Privilege name")
	public ResponseEntity<PrivilegeDTO> editPrivilege(@RequestHeader(CLIENT_ID) String clientId,
													  @PathVariable String systemName,
													  @RequestBody PrivilegeDTO privilegeDTO){
		return new ResponseEntity<>(privilegeService.updatePrivilege(clientId, systemName, privilegeDTO), HttpStatus.OK);
	}

	@GetMapping("/privileges")
	@Operation(summary = "Get a list of all the privileges stored in DB")
	public ResponseEntity<List<PrivilegeDTO>> getAllPrivileges(@RequestHeader(CLIENT_ID) String clientId) {

		return new ResponseEntity<>(privilegeService.getAllPrivileges(clientId), HttpStatus.OK);
	}
}
