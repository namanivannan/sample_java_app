package com.r1vs.platform.rox.api.util;

import ma.glasnost.orika.MappingContext;
import ma.glasnost.orika.NullFilter;
import ma.glasnost.orika.metadata.Type;
import org.hibernate.collection.spi.PersistentCollection;
import org.springframework.stereotype.Component;

@Component
public class DetachableEntityFilter<A extends PersistentCollection, B> extends NullFilter<A, B> {

	@Override
	public <S extends A, D extends B> boolean shouldMap(final Type<S> sourceType, final String sourceName,
			final S source, final Type<D> destType, final String destName, final D dest,
			final MappingContext mappingContext) {

		// Prevents mapping lazy loaded entities
		return false;
	}

	@Override
	public <D extends B> D filterDestination(final D destinationValue, final Type<?> sourceType,
			final String sourceName, final Type<D> destType, final String destName,
			final MappingContext mappingContext) {

		return null;
	}

	@Override
	public <S extends A> S filterSource(final S sourceValue, final Type<S> sourceType, final String sourceName,
			final Type<?> destType, final String destName, final MappingContext mappingContext) {

		return null;
	}

}
