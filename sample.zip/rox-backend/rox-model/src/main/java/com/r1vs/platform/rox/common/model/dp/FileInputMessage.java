package com.r1vs.platform.rox.common.model.dp;

import java.io.Serializable;
import java.time.OffsetDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.r1vs.platform.rox.common.model.AuditedEntity;

@Entity
@Table(name = "dp_file_input_message")
public class FileInputMessage extends AuditedEntity implements Serializable {

	private static final long serialVersionUID = 2628233015010123904L;

	@Id
	@Column(name = "id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(name = "pbm_id")
	private Integer pbmId;

	@Column(name = "message_uuid")
	private String messageUUID;

	/**
	 * Used to help translate the message content JSON to Java class
	 */
	@Column(name = "message_type")
	private String messageType;

	/**
	 * Typically it is a JSON
	 */
	@Column(name = "message_content")
	private String messageContent;

	@Column(name = "source_event_time")
	private OffsetDateTime sourceEventTime;

	@Column(name = "source_event_id")
	private String sourceEventId;

	/**
	 * In Cloud this is a bucket name. Does NOT end with '/'.
	 */
	@Column(name = "root_path")
	private String rootPath;

	@Column(name = "file_path")
	private String filePath;

	@Column(name = "stage_file_path")
	private String stageFilePath;

	@Column(name = "file_name")
	private String fileName;

	@Column(name = "file_hash")
	private String fileHash;

	@Column(name = "data_type")
	private String dataType;

	@Column(name = "stage_file_hash")
	private String stageFileHash;

	@Column(name = "file_size")
	private Long fileSize;

	@Column(name = "received_at", nullable = false)
	private OffsetDateTime receivedAt;

	@Column(name = "registration_code")
	private String registrationCode;

	@Column(name = "file_meta")
	private String fileMeta;

	@Column(name = "state", nullable = false)
	private String state;

	@Column(name = "error_code")
	private String errorCode;

	@Column(name = "error_message")
	private String errorMessage;

	@Column(name = "move_counter")
	private Integer moveCounter;

	@Column(name = "move_duration")
	private Long moveDuration;

	@Column(name = "match_counter")
	private Integer matchCounter;

	@Column(name = "file_uuid")
	private String fileUUID;

	@Column(name = "correlation_id")
	private String correlationId;

	public Integer getId() {

		return id;
	}

	public void setId(final Integer id) {

		this.id = id;
	}

	public Integer getPbmId() {

		return pbmId;
	}

	public void setPbmId(final Integer pbmId) {

		this.pbmId = pbmId;
	}

	public String getMessageUUID() {

		return messageUUID;
	}

	public void setMessageUUID(final String messageUUID) {

		this.messageUUID = messageUUID;
	}

	public String getMessageType() {

		return messageType;
	}

	public void setMessageType(final String messageType) {

		this.messageType = messageType;
	}

	public String getMessageContent() {

		return messageContent;
	}

	public void setMessageContent(final String messageContent) {

		this.messageContent = messageContent;
	}

	public OffsetDateTime getReceivedAt() {

		return receivedAt;
	}

	public void setReceivedAt(final OffsetDateTime receivedAt) {

		this.receivedAt = receivedAt;
	}

	public OffsetDateTime getSourceEventTime() {

		return sourceEventTime;
	}

	public void setSourceEventTime(final OffsetDateTime sourceEventTime) {

		this.sourceEventTime = sourceEventTime;
	}

	public String getSourceEventId() {

		return sourceEventId;
	}

	public void setSourceEventId(final String sourceEventId) {

		this.sourceEventId = sourceEventId;
	}

	public String getFileUUID() {

		return fileUUID;
	}

	public void setFileUUID(final String fileUUID) {

		this.fileUUID = fileUUID;
	}

	public String getCorrelationId() {

		return correlationId;
	}

	public void setCorrelationId(final String correlationId) {

		this.correlationId = correlationId;
	}

	public String getFilePath() {

		return filePath;
	}

	public void setFilePath(final String filePath) {

		this.filePath = filePath;
	}

	public String getFileName() {

		return fileName;
	}

	public void setFileName(final String fileName) {

		this.fileName = fileName;
	}

	public String getFileHash() {

		return fileHash;
	}

	public void setFileHash(final String fileHash) {

		this.fileHash = fileHash;
	}

	public Long getFileSize() {

		return fileSize;
	}

	public void setFileSize(final Long fileSize) {

		this.fileSize = fileSize;
	}

	public String getRootPath() {

		return rootPath;
	}

	public void setRootPath(final String rootPath) {

		this.rootPath = rootPath;
	}

	public String getState() {

		return state;
	}

	public void setState(final String state) {

		this.state = state;
	}

	public Integer getMoveCounter() {

		return moveCounter;
	}

	public void setMoveCounter(final Integer moveCounter) {

		this.moveCounter = moveCounter;
	}

	public Integer getMatchCounter() {

		return matchCounter;
	}

	public void setMatchCounter(final Integer matchCounter) {

		this.matchCounter = matchCounter;
	}

	public String getRegistrationCode() {

		return registrationCode;
	}

	public void setRegistrationCode(final String registrationCode) {

		this.registrationCode = registrationCode;
	}

	public String getFileMeta() {

		return fileMeta;
	}

	public void setFileMeta(final String fileMeta) {

		this.fileMeta = fileMeta;
	}

	public String getStageFilePath() {

		return stageFilePath;
	}

	public void setStageFilePath(final String stageFilePath) {

		this.stageFilePath = stageFilePath;
	}

	public String getErrorCode() {

		return errorCode;
	}

	public void setErrorCode(final String errorCode) {

		this.errorCode = errorCode;
	}

	public String getErrorMessage() {

		return errorMessage;
	}

	public void setErrorMessage(final String errorMessage) {

		this.errorMessage = errorMessage;
	}

	public String getStageFileHash() {

		return stageFileHash;
	}

	public void setStageFileHash(final String stageFileHash) {

		this.stageFileHash = stageFileHash;
	}

	public Long getMoveDuration() {

		return moveDuration;
	}

	public void setMoveDuration(final Long moveDuration) {

		this.moveDuration = moveDuration;
	}

	public String getDataType() {

		return dataType;
	}

	public void setDataType(final String dataType) {

		this.dataType = dataType;
	}

}
