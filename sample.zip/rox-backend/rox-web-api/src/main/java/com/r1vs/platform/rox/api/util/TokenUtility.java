package com.r1vs.platform.rox.api.util;

import com.r1vs.platform.rox.api.security.SecurityConstants;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Date;
import java.util.HashMap;

public final class TokenUtility {

	private static final Logger LOGGER = LoggerFactory.getLogger(TokenUtility.class);

	private static final String REFRESH_TOKEN_TYPE = "refresh";

	private static final String AUTH_TOKEN_TYPE = "authorization";

	public static HashMap<String, String> generateAppTokens(final String userName, final long authTokenExpiration,
			final long refreshTokenExpiration) {

		final HashMap<String, String> tokens = new HashMap<>();

		final String authToken = buildAuthToken(userName, authTokenExpiration);
		final String refreshToken = buildRefreshToken(userName, refreshTokenExpiration);

		tokens.put(SecurityConstants.AUTH_STRING, authToken);
		tokens.put(SecurityConstants.REFRESH_STRING, refreshToken);

		return tokens;
	}

	public static String buildRefreshToken(final String userName, final long refreshTokenExpiration) {

		return SecurityConstants.TOKEN_PREFIX + buildToken(userName, refreshTokenExpiration, REFRESH_TOKEN_TYPE);
	}

	public static String buildAuthToken(final String userName, final long authTokenExpiration) {

		return SecurityConstants.TOKEN_PREFIX + buildToken(userName, authTokenExpiration, AUTH_TOKEN_TYPE);
	}

	public static String buildToken(final String userName, final Long expiration, final String type) {

		final Date tokenExpiration = new Date(System.currentTimeMillis() + expiration);

		final Claims claims = Jwts.claims().setSubject(userName);
		claims.setExpiration(tokenExpiration);
		claims.put("type", type);

		return Jwts.builder().signWith(SignatureAlgorithm.HS512, SecurityConstants.SECRET.getBytes())
				.setClaims(claims).compact();
	}

	public static String createResponse(final HashMap<String, String> map) {

		final JSONObject json = new JSONObject();

		try {
			map.forEach((k, v) -> {
				json.put(k, v);
			});
		} catch (final JSONException e) {
			LOGGER.error("Error adding values to json");
		}
		return json.toString();
	}

	public static boolean isAuthToken(final Claims claims) {

		if (!claims.containsKey("type")) {
			return false;
		}

		final String type = claims.get("type").toString();

		if (!type.equals(AUTH_TOKEN_TYPE)) {
			return false;
		}

		return true;
	}

	public static boolean isRefreshToken(final Claims claims) {

		if (!claims.containsKey("type")) {
			return false;
		}

		final String type = claims.get("type").toString();

		if (!type.equals(REFRESH_TOKEN_TYPE)) {
			return false;
		}

		return true;
	}

}
