package com.r1vs.platform.rox.api.util;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class MetadataConstants {

	public static final String METADATA_ID = "metadataId";

	public static final String METADATA_NAME = "metadataName";

	public static final String METADATA_CATEGORY_ID = "metadataCategoryId";

	public static final String STATUS = "status";

	public static final String JSON = "json";

	public static final String MINIMUM_AGE = "minimumAgeLimit";

	public static final String MAXIMUM_AGE = "maximumAgeLimit";

	public static final Integer MINIMUM_AGE_DEFAULT = 0;

	public static final Integer MAXIMUM_AGE_DEFAULT = 999;

	public static final String ONLINE_CLAIM_LIMIT = "onlineClaimLimit";

	public static final String OFFLINE_CLAIM_LIMIT = "offlineClaimLimit";

	public static final String ONLINE_REVERSAL_LIMIT = "onlineReversalLimit";

	public static final String OFFLINE_REVERSAL_LIMIT = "offlineReversalLimit";

	public static final String DAYS_PRESCRIPTION_FILLED = "daysOfPrescriptionFilled";

	public static final String INVALID_AGE = "invalidAge";

	public static final String MINIMUM_COST = "minimumCost";

	public static final String MAXIMUM_COST = "maximumCost";

	public static final String INVALID_COST = "invalidCost";

	public static final String MIN_DAYS_SUPPLY = "minimumDaysSupply";

	public static final String MAX_DAYS_SUPPY = "maximumDaysSupply";

	public static final String INVALID_DAY_SUPPLY = "invalidDaysSupply";

	public static final String FLAT_AMOUNT = "flatAmount";

	public static final String PERCENT_AMOUNT = "percent";

	public static final String MIN_ADJUSTMENT = "minAdjustment";

	public static final String MAX_ADJUSTMENT = "maxAdjustment";

	public static final String INVALID_ADJUSTMENT = "invalidAdjustment";

	public static final String CLAIM_SUBMISSION = "claimSubmissionMethods";

	public static final String DAY_SUPPLY_RANGES = "daySupplyRanges";

	public static final String RANGE = "range";

	public static final String RANGE_START = "rangeStart";

	public static final String RANGE_END = "rangeEnd";

	public static final String RANGE_INVALID = "invalid";

	public static final String BRAND_CLASS = "brandClasses";

	public static final String SUBSETS = "subsets";

	public static final String RATE_RULES = "rateRules";

	public static final String RATE_RULE_TYPE = "rateRuleType";

	public static final String BASIS_OF_COST_TYPE = "basisOfCostType";

	public static final String N0_OF_OCCURRENCES = "numberOfOccurrences";

	public static final String EVERY_X_DAYS = "everyXDays";

	public static final String MIN_POS_REBATE = "minPOSRebate";

	public static final String MAX_POS_REBATE = "maxPOSRebate";

	public static final String INVALID_POS_REBATE = "invalidPOSRebate";

	public static final String MIN_QUANTITY_LIMIT = "minQuantityLimit";

	public static final String MAX_QUANTITY_LIMIT = "maxQuantityLimit";

	public static final String INVALID_QUANTITY_LIMIT = "invalidQuantityLimit";

	public static final String MIN_QUANTITY_DAY = "minQuantityDay";

	public static final String MAX_QUANTITY_DAY = "maxQuantityDay";

	public static final String INVALID_QUANTITY_DAY = "invalidQuantityDays";

	public static final String CLAIM_MIN_MAX = "claimMinMaxAction";

	public static final String RESPONSE_CODE = "responseCode";

	//overrides
	public static final int MAX_OVERRIDE_TAG_LENGTH = 20;

	public static final int MAX_PRIOR_AUTH_PER_CLARIFICATION = 1;

	public static final int MAX_SUBMISSION_CODES_PER_CLARIFICATION = 3;

	public static final int MAX_PROFESSIONAL_SERVICE_CODE_PER_CLARIFICATION = 1;

	public static final int MAX_RESULT_OF_SERVICE_CODE_PER_CLARIFICATION = 1;

	public static final int MAX_REASON_OF_SERVICE_CODE_PER_CLARIFICATION = 1;

	public static final int MAX_ELIGIBILITY_CODE_PER_CLARIFICATION = 1;

	public static final String EXTERNAL_REJECT_CODE = "rejectCode";

	public static final String INTERNAL_REJECT_CODE = "internalRejectCode";

	public static final String TAGS = "tags";

	public static final String CLARIFICATIONS = "clarifications";

	public static final String DENY_OVERRIDE = "denyOverride";

	public static final String SYSTEM_ERROR_CODE = "systemErrorCode"; //must deprecate

	public static final String REASON_FOR_SERVICE = "reasonForService";

	public static final String PRIOR_AUTH_TYPE = "priorAuthType";

	public static final String SUBMISSION_CLARIFICATION = "submissionClarification";

	public static final String ELIGIBILITY_CLARIFICATION = "eligibilityClarification";

	public static final String PROFESSIONAL_SERVICE_CODE = "professionalServiceCode";

	public static final String RESULT_OF_SERVICE_CODE = "resultOfServiceCode";

	public static final String REASON_FOR_SERVICE_CODE = "reasonForServiceCode";

	public static final String INCENTIVE_LIMITATION = "incentiveLimitation";

	public static final String POS_REBATE_METHOD = "rebateMethod";

	public static final String COST_SHARING_METHOD = "costSharingMethod";

	public static final String OTHER_SERVICES_COST_SHARING_METHOD = "otherServicesCostSharingMethod";

	public static final String INCENTIVE_FEE_COST_SHARING_METHOD = "incentiveFeeCostSharingMethod";

	public static final String UC_METHOD = "ucOffsetMethod";

	public static final String UC_MINIMUM = "ucMinimum";

	public static final String CLAIM_RESPONSE_FIELD = "claimResponseField";

	public static final String OTHER_SERVICES_LIMITATIONS = "limitations";

	public static final String CLAIM_TYPE = "claimType";

	public static final String FEE_TYPE = "feeType";

	public static final String FEE_BASIS = "feeBasis";

	public static final String FEE_METHOD = "feeMethod";

	public static final String COST_OPTION_SUBSET = "costOptionSubset";

	public static final String COST_OPTION_RATE_RULE = "costOptionRateRule";

	public static final String OPERATOR = "operator";

	public static final String CALCULATION_TYPE = "calculationType";

	public static final String APPLICABLE_CLAIM_TYPE = "applicableClaimType";

	public static final String BRAND_CLASS_TYPE = "brandClassType";

	public static final String COST_SHARE_TYPE = "costShareType";

	public static final String BASIS_OF_CALCULATION_TYPE = "basisOfCalculationType";

	public static final String FIXED_SHARING_BASIS_TYPE = "fixedSharingBasisType";

	public static final String INCREMENTAL_SHARING_BASIS_TYPE = "incrementalSharingBasisType";

	public static final String ACCUMULATION_SHARING_BASIS_TYPE = "accumulationSharingBasisType";

	public static final String SHARING_BASIS = "sharingBasis";

	public static final String ACCUMULATIONS = "accumulations";

	public static final String RANGES = "ranges";

	public static final String NETWORK_TYPE = "networkType";

	public static final String PROCESS_METHOD_TYPE = "processMethodType";

	public static final String TIERED_FILLS_PERIOD_TYPE = "tieredFillsPeriodType";

	public static final String TIERED_FILLS_SHARING_BASIS_TYPE = "tieredFillsSharingBasisType";

	public static final String TIERED_SHARING_BASIS_TYPE = "tieredSharingBasisType";

	public static final String NETWORK_CLASSIFICATION_TYPE = "networkClassificationType";

	public static final String ACCUMULATION_METHOD = "accumulationMethod";

	public static final String ACCUMULATION_PERIOD_TYPE = "accumulationPeriodType";

	public static final String PERIOD_TYPE = "periodType";

	public static final String PERCENT = "percent";

	public static final String PERCENT_OPERATOR = "percentOperator";

	public static final String FLAT_OPERATOR = "flatOperator";

	public static final String DISPENSE_FEE_CALCULATION_TYPE = "dispenseFeeCalculationType";

	public static final String SUBSET_NAME = "subsetName";

	public static final String STATE = "state";

	public static final String DAY_SUPPLY_MULTIPLE = "daySupplyMultiple";

	public static final String STATE_ABBREVIATION_TYPE = "stateAbbreviation";

	public static final String OFFSET_DOLLAR = "offsetDollar";

	public static final String OFFSET_PERCENT = "offsetPercent";

	public static final String OFFSET_PERCENT_MIN_DOLLAR = "minOffsetPercentage";

	public static final String OFFSET_PERCENT_MAX_DOLLAR = "maxOffsetPercentage";

	public static final String PROGRAM_FEE = "programFee";

	public static final String LOOKBACK_PERIOD_START = "lookbackPeriodStart";

	public static final String LOOKBACK_PERIOD_END = "lookbackPeriodEnd";

	public static final String REFILL_TOO_SOON_RANGES = "refillTooSoonRanges";

	public static final String REFILL_TOO_SOON_ACTION_REQUIRED = "actionRequired";

	public static final String REFILL_TOO_SOON_MINIMUM_TYPE = "minimumType";

	public static final String REFILL_TOO_SOON_FROM_DAY = "fromDay";

	public static final String REFILL_TOO_SOON_TO_DAY = "toDay";

	public static final String REFILL_TOO_SOON_FROM_DAY_TO_DAY = "fromDay, toDay";

	public static final String REFILL_TOO_SOON_MINIMUM_DAYS_USED = "minimumDaysUsed";

	public static final String REFILL_TOO_SOON_MINIMUM_PERCENT_USED = "minimumPercentOfDrugUsed";

	// Deductible Edit
	public static final String DEDUCTIBLE_PERIOD_TYPE_CODE = "deductiblePeriodTypeCode";

	public static final String DEDUCTIBLE_METHOD_TYPE_CODE = "deductibleMethod";

	public static final String DEDUCTIBLE_PROCESSING_TYPE_CODE = "deductibleProcessingMethod";

	public static final String MIDDLE_INITIAL = "middleInitial";

	// Max Accumulation Edits
	public static final String ACCUMULATION_METHOD_TYPE = "accumulationMethodType";

	public static final String PROCESSING_METHOD = "processingMethod";

	public static final String BENEFIT_AMOUNT = "benefitAmount";

	public static final String MAXIMUM_LIMITATION = "maximumLimitation";

	public static final String MIN_AGE = "minAge";

	public static final String MAX_AGE = "maxAge";

	public static final String DMR_PROCESSING = "dmrProcessing";

	public static final String REJECT_MESSAGE_ID = "rejectMessageId";

	public static final String DRUG_LEVEL = "drugLevel";

	public static final String START_PERIOD = "startPeriod";

	public static final String DURATION_PERIOD_TYPE = "durationPeriodType";

	public static final String DURATION_PERIOD_LENGTH = "durationPeriodLength";

	public static final String REFILL_MARGIN_TYPE = "refillMarginType";

	public static final String REFILL_MARGIN_DAY = "refillMarginDay";

	public static final String REFILL_MARGIN_PERCENT = "refillMarginPercent";

	// Daw Edit
	public static final String PRODUCTION_SELECTION_CODE = "code";

	public static final String PROCESSING_OPTION_TYPE = "processingOption";

	public static final String DIFFERENCE_TYPE = "differenceType";

	public static final String BASIS_OF_COST = "basisOfCost";

	public static final String ALTERNATE_BASIS_OF_COST = "alternateBasisOfCost";

	public static final String PRIMARY_BRAND_CLASS = "brandClassPrimary";

	public static final String SECONDARY_BRAND_CLASS = "brandClassSecondary";

	public static final String FLAT_ADJUSTMENT_AMOUNT = "flatAdjustmentAmt";

	public static final String PERCENT_ADJUSTMENT_AMOUNT = "percentAdjustmentAmt";

	// Plan stop loss
	public static final String MEMBER_MAXIMUM = "memberMaximum";

	public static final String FAMILY_MAXIMUM = "familyMaximum";

	public static final String MEMBER_TO_MEET = "memberToMeet";

	public static final String INCLUDE_DAW = "includeDAW";

	public static final String PERCENT_ROLLOVER = "percentRollover";

	public static final String MAX_ROLLOVER = "maxRollover";

	public static final String ROLLOVER_OPTION = "roleoverOption";

	public static final String EXCEED_MAXIMUM = "exceedMaximum";

	public static final String GLOBAL_OVERRIDE_SETTINGS = "globalOverrideSettings";

	// Safety Edits
	public static final String LOOKBACK = "lookback";

	public static final String SEVERITY_LEVEL_TYPE = "severityLevelType";

	public static final String ACTION_TYPE = "actionType";

	public static final String DOCUMENTATION_LEVEL_TYPE = "documentationLevelType";

	public static final String MANAGEMENT_LEVEL_TYPE = "managementLevelType";

	public static final String LABELED_AVOIDANCE_LEVEL_TYPE = "labeledAvoidanceLevelType";

	public static final String SHOW_INTERACTED_INGREDIENTS_TYPE = "showInteractedIngredientsType";

	public static final String EFFECT_TYPE_TYPE = "effectType";

	public static final String INCIDENCE_TYPE = "incidenceType";

	public static final String ONSET_TYPE = "onsetType";

	public static final String INSIGNIFICANT_INACTIVE_INGREDIENTS_TYPE = "insignificantInactiveIngredientsType";

	public static final String STRUCTURALLY_RELATED_DRUGS_TYPE = "structurallyRelatedDrugsType";

	public static final String DRUG_USAGE_LEVEL_SEVERITY_TYPE = "DrugUsageLevellSeverityType";

	public static final String MIN_PRICE = "minPrice";

	public static final String MAX_PRICE = "maxPrice";

	public static final String MESSAGE_METADATA = "messageMetadata";

	public static final String MEMBER_DEDUCTIBLE = "memberDeductible";

	public static final String FAMILY_DEDUCTIBLE = "familyDeductible";

	public static final String DEDUCTIBLE_MEMBER_TO_MEET = "memberToMeet";

	public static final String PERIOD_ROLL_OVER_MONTHS = "periodRollOverMonths";

	public static final String PRIOR_ROLL_OVER_MONTHS = "priorRollOverMonths";

	public static final String CURRENT_ROLL_OVER_MONTHS = "currentRollOverMonths";

	public static final String INVALID_MESSAGE_GROUP = "INVALID_MESSAGE_GROUP_ON_EDIT";

	public static final String DRUG_TO_DRUG_INTERACTION_SECTION = "drugToDrugInteraction";

	public static final String DUPLICATE_THERAPY_SECTION = "duplicateTherapy";

	public static final String ADVERSE_DRUG_EFFECTS_SECTION = "adverseDrugEffects";

	public static final String DRUG_ALLERGY_SECTION = "drugAllergy";

	public static final String DRUG_DISEASE_SECTION = "drugDisease";

	public static final String DOSE_SCREENING_SECTION = "doseScreening";

	public static final String PREGNANCY_SECTION = "pregnancy";

	public static final String LACTATION_SECTION = "lactation";

	public static final String AGE_SECTION = "age";

	public static final String GENDER_SECTION = "gender";

	public static Map<Integer, Class> editCategoryToEditClassMap = new HashMap<>();
	static {
		editCategoryToEditClassMap = Collections.unmodifiableMap(editCategoryToEditClassMap);
	}
}
