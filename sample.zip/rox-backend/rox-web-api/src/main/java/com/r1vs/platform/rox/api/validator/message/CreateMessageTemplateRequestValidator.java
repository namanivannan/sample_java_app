package com.r1vs.platform.rox.api.validator.message;

import com.r1vs.platform.rox.api.exception.Error;
import com.r1vs.platform.rox.api.model.message.CreateMessageTemplateRequest;
import com.r1vs.platform.rox.api.validator.RoxWriteWebApiValidator;
import org.springframework.stereotype.Component;

import static com.r1vs.platform.rox.api.util.ValidationUtil.handleException;

@Component
public class CreateMessageTemplateRequestValidator extends MessageTemplateRequestValidator
		implements RoxWriteWebApiValidator<CreateMessageTemplateRequest> {

	@Override
	public void validate(final CreateMessageTemplateRequest messageTemplateRequest) {

		final Error error = new Error();

		validateMessageName(error, messageTemplateRequest.getMessageName(), getClientIdForRequest());
		validateMessageType(error, messageTemplateRequest.getMessageType());
		validatePrivacyLevel(error, messageTemplateRequest.getPrivacyLevel());
		validatePrivacySetting(error, messageTemplateRequest.getPrivacySetting());
		validateStatus(error, messageTemplateRequest.getStatusId());
		handleException(error);
	}
}
