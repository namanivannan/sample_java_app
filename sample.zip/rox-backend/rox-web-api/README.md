# roxwrite-web-api README
## Getting started
This project is contains API's used for CRUD operations

* Database setup:
	* see roxwrite-parent-pom README for database connection configuration
* Prepare build:
    * project dependencies:
        * roxwrite-parent-pom
        * roxwrite-model
        * run migrations as part of roxwrite-model project
        * To drop all tables: mvn liquibase:dropAll
        * To update the tables: mvn liquibase:update
    * run: ```mvn clean install``` from project root
* To run vagrant for database on machine:
	* git pull metis-local
	* vagrant up
	* vagrant provision
* roxwrite-model �> this contains database scripts (git pull) mvn clean install (Also check roxwrite-parent-pom..)
* Run mvn clean install on roxwrite-web-api
* To run roxwrite-web-api from eclipse the right on --> RoxWriteWebApiApplication.java --> Run as Java application
* In case tables are updated... run mvn liquidate:dropAll. And then mvn liquidate:update from roxwrite-model
* To run roxwrite-web-api on local from command line
	From command line -->  goto roxwrite-web-api
	Then run --> java -jar target/roxwrite-web-api-0.0.1-SNAPSHOT.jar
* Swagger URL:
	http://localhost:8080/swagger-ui.html#/
	
	

