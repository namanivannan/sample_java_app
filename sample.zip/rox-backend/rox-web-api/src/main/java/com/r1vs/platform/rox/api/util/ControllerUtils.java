package com.r1vs.platform.rox.api.util;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

public class ControllerUtils {

	public static Pageable getPageableFromHeaderParams(Integer pageLimit, Integer pageNumber, String sortingSetting) {

		Sort sort = getSortParamFromString(sortingSetting);
		return PageRequest.of(pageNumber, pageLimit, sort);
	}

	private static Sort getSortParamFromString(String sortingSetting) {

		String[] sortCoordinates = sortingSetting.split(",", 2);
		Sort sort;
		if (sortCoordinates.length == 2) {
			sort = Sort.by(sortCoordinates[0]);
			if (sortCoordinates[1].equalsIgnoreCase("ASC")) {
				sort = sort.ascending();
			} else {
				sort = sort.descending();
			}
		} else {
			sort = Sort.by("createdAt").descending();
		}
		return sort;
	}

}
