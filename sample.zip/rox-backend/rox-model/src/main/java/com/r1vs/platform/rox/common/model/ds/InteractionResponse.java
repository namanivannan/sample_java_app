package com.r1vs.platform.rox.common.model.ds;

import com.r1vs.platform.rox.common.model.AuditedEntity;
import com.r1vs.platform.rox.common.model.business.Application;
import com.r1vs.platform.rox.common.model.business.Business;
import com.r1vs.platform.rox.common.model.business.Client;
import com.r1vs.platform.rox.common.model.business.Owner;
import com.r1vs.platform.rox.common.model.users.User;
import com.r1vs.platform.rox.common.security.annotations.Encrypted;
import org.hibernate.annotations.Type;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.time.OffsetDateTime;
import java.util.UUID;

@Entity
@Table(name = "interaction_responses")
@EntityListeners(AuditingEntityListener.class)
public class InteractionResponse extends AuditedEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@Column(name = "uuid", nullable = false, updatable = false)
	private UUID uuid;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "parent_interaction", referencedColumnName = "id")
	private InteractionResponse interactionResponseParent;

	@OneToOne
	@JoinColumn(name = "client_id", nullable = false)
	private Client client;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "application_id")
	private Application application;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "business_id")
	private Business business;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "owner_id")
	private Owner owner;

	@Column(name = "reference")
	private String reference;

//	@NotNull
	@Column(name = "started_at", updatable = false)
	private OffsetDateTime startedAt;

//	@NotNull
	@Column(name = "ended_at", updatable = false)
	private OffsetDateTime endedAt;

	/**
	 * Duration of interaction in milliseconds
	 */
	@Column(name = "duration")
	private Long duration;

	@Column(name = "code")
	@Enumerated(EnumType.STRING)
	private InteractionResponseCode code;

	@Column(name = "data_type")
	@Enumerated(EnumType.STRING)
	private InteractionResponseDataType dataType;

	@Column(name = "provider")
	@Enumerated(EnumType.STRING)
	private InteractionProviders provider;

	@Column(name = "name")
	@Enumerated(EnumType.STRING)
	private InteractionName name;

	@Column(name = "payload")
	@Encrypted
	private String payload;

	/**
	 * Used only in case of error
	 */
	@Column(name = "message")
	private String message;

	@Lob
	@Column(name = "response")
	@Type(type = "org.hibernate.type.BinaryType")
	@Encrypted
	private byte[] response;

	@Column(name = "run")
	private Integer run;

	@Column(name = "type")
	@Enumerated(EnumType.STRING)
	private InteractionType type;

	public Long getId() {

		return this.id;
	}

	public void setId(Long id) {

		this.id = id;
	}

	public UUID getUuid() {

		return uuid;
	}

	public void setUuid(UUID uuid) {

		this.uuid = uuid;
	}

	public Client getClient() {

		return client;
	}

	public void setClient(Client client) {

		this.client = client;
	}

	public Application getApplication() {

		return application;
	}

	public void setApplication(Application application) {

		this.application = application;
	}

	public Business getBusiness() {

		return business;
	}

	public void setBusiness(Business business) {

		this.business = business;
	}

	public Owner getOwner() {

		return owner;
	}

	public void setOwner(Owner owner) {

		this.owner = owner;
	}

	public String getReference() {

		return reference;
	}

	public void setReference(String reference) {

		this.reference = reference;
	}

	public OffsetDateTime getStartedAt() {

		return startedAt;
	}

	public void setStartedAt(OffsetDateTime startedAt) {

		this.startedAt = startedAt;
	}

	public OffsetDateTime getEndedAt() {

		return endedAt;
	}

	public void setEndedAt(OffsetDateTime endedAt) {

		this.endedAt = endedAt;
	}

	public Long getDuration() {

		return duration;
	}

	public void setDuration(Long duration) {

		this.duration = duration;
	}

	public InteractionResponseCode getCode() {

		return code;
	}

	public void setCode(InteractionResponseCode code) {

		this.code = code;
	}

	public InteractionResponseDataType getDataType() {

		return dataType;
	}

	public void setDataType(InteractionResponseDataType dataType) {

		this.dataType = dataType;
	}

	public InteractionProviders getProvider() {

		return provider;
	}

	public void setProvider(InteractionProviders provider) {

		this.provider = provider;
	}

	public InteractionName getName() {

		return name;
	}

	public void setName(InteractionName name) {

		this.name = name;
	}

	public String getPayload() {

		return payload;
	}

	public void setPayload(String payload) {

		this.payload = payload;
	}

	public String getMessage() {

		return message;
	}

	public void setMessage(String message) {

		this.message = message;
	}

	public byte[] getResponse() {

		return response;
	}

	public void setResponse(byte[] response) {

		this.response = response;
	}

	public Integer getRun() {

		return run;
	}

	public void setRun(Integer run) {

		this.run = run;
	}

	public InteractionType getType() {

		return type;
	}

	public void setType(InteractionType type) {

		this.type = type;
	}

	public InteractionResponse getInteractionResponseParent() {
		return interactionResponseParent;
	}

	public void setInteractionResponseParent(InteractionResponse interactionResponseParent) {
		this.interactionResponseParent = interactionResponseParent;
	}
}
