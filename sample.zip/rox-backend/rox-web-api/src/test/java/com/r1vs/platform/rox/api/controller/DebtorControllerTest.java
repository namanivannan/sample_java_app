package com.r1vs.platform.rox.api.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.r1vs.platform.rox.api.model.application.initiate.BusinessDTO;
import com.r1vs.platform.rox.api.model.application.initiate.EmailDTO;
import com.r1vs.platform.rox.api.model.application.initiate.PhoneDTO;
import com.r1vs.platform.rox.api.model.application.initiate.UpdateBusinessDTO;
import com.r1vs.platform.rox.common.db.repository.business.ApplicationRepository;
import com.r1vs.platform.rox.common.model.business.Application;
import com.r1vs.platform.rox.common.util.StringUtil;
import org.apache.commons.io.IOUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.util.Collections;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.is;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@Sql("fixture2.sql")
public class DebtorControllerTest {

	@Autowired
	private ApplicationRepository applicationRepository;

	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private DBConnection dbConnection;

	private String token;

	@Before
	public void setUp() throws Exception {

		if (StringUtil.isNullOrEmpty(token)) {
			token = dbConnection.loginToDb();
		}
	}

	@Test
	public void givenValidApplicationAndDebtor_WhenCreateDebtorEndpointIsHit_thenCreateDebtorAndReturn201()
			throws Exception {

		mockMvc.perform(MockMvcRequestBuilders.post("/v1/applications/839e72fc-6433-46fd-a259-5dbb50b913d6/debtors")
				.contentType(MediaType.APPLICATION_JSON)
				.content(getTextFileAsString("/payloads/new_debtor.json"))
				.header("x-client-id", "11")
				.header("Authorization", token))
				.andExpect(status().isCreated())
				.andExpect(jsonPath("$.name", is("Debtor")))
				.andExpect(jsonPath("$.businessType", is("Limited Liability Corporation")))
				.andExpect(jsonPath("$.industryType", is("Transportation")))
				.andExpect(jsonPath("$.mcNumber", is("654321")))
				.andExpect(jsonPath("$.dotNumber", is("3177401")))
				.andExpect(jsonPath("$.website", is("debtor.com")))
				.andExpect(jsonPath("$.addresses[0].city", is("PATERSON")))
				.andExpect(jsonPath("$.emails[0].email", is("info@pinktransportation.com")))
				.andExpect(jsonPath("$.identifications[0].identification", is("*********892")))
				.andExpect(jsonPath("$.phones[0].number", is("4049097501")))
				.andDo(print());

		mockMvc.perform(MockMvcRequestBuilders.get("/v1/applications/839e72fc-6433-46fd-a259-5dbb50b913d6")
				.contentType(MediaType.APPLICATION_JSON)
				.header("x-client-id", "11")
				.header("Authorization", token))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.debtor.name", is("Debtor")))
				.andExpect(jsonPath("$.debtor.businessType", is("Limited Liability Corporation")))
				.andExpect(jsonPath("$.debtor.industryType", is("Transportation")))
				.andExpect(jsonPath("$.debtor.mcNumber", is("654321")))
				.andExpect(jsonPath("$.debtor.dotNumber", is("3177401")))
				.andExpect(jsonPath("$.debtor.website", is("debtor.com")))
				.andExpect(jsonPath("$.debtor.addresses[0].city", is("PATERSON")))
				.andExpect(jsonPath("$.debtor.emails[0].email", is("info@pinktransportation.com")))
				.andExpect(jsonPath("$.debtor.identifications[0].identification", is("*********892")))
				.andExpect(jsonPath("$.debtor.phones[0].number", is("4049097501")))
				.andDo(print());

	}

	@Test
	public void givenNotValidApplication_WhenCreateDebtorEndpointIsHit_thenReturn404() throws Exception {

		mockMvc.perform(MockMvcRequestBuilders.post("/v1/applications/839e72fc-6433-46fd-a259-5dbb50b913d7/debtor")
				.contentType(MediaType.APPLICATION_JSON)
				.content(getTextFileAsString("/payloads/new_debtor.json"))
				.header("x-client-id", "11")
				.header("Authorization", token))
				.andExpect(status().isNotFound())
				.andDo(print());

	}

	@Test
	@Transactional
	public void givenValidApplicationAndDebtor_whenUpdateDebtorEndpointIsHit_thenUpdateDebtorAndReturn200()
			throws Exception {

		UpdateBusinessDTO businessDTO = new UpdateBusinessDTO();

		businessDTO.setName("Test Name");
		EmailDTO emailDTO = new EmailDTO();
		emailDTO.setEmail("testemail@gmail.com");
		emailDTO.setEmailType("Home");
		PhoneDTO phoneDTO = new PhoneDTO();
		phoneDTO.setPhoneType("Work");
		phoneDTO.setNumber("1313131313");

		businessDTO.setEmails(Collections.singletonList(emailDTO));
		businessDTO.setPhones(Collections.singletonList(phoneDTO));
		businessDTO.setContractAmount("20000");

		mockMvc.perform(MockMvcRequestBuilders.patch("/v1/applications/382b9037-5842-43e8-b99b-2f4611784cd6/debtors")
				.contentType(MediaType.APPLICATION_JSON)
				.header("x-client-id", "11")
				.header("Authorization", token)
				.content(objectMapper.writeValueAsString(businessDTO)))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.phones[0].number", is("1313131313")))
				.andExpect(jsonPath("$.phones[0].phoneType", is("Work")))
				.andExpect(jsonPath("$.emails[0].email", is("testemail@gmail.com")))
				.andExpect(jsonPath("$.emails[0].emailType", is("Home")))
				.andExpect(jsonPath("$.name", is("Test Name")))
				.andDo(print());

		assertThat(applicationRepository.findByUuid(UUID.fromString("382b9037-5842-43e8-b99b-2f4611784cd6"))
				.get().getContractAmount()).as("Contract amount shouldn't change when debtor is being updated")
						.isEqualTo(10000);
	}

	@Test
	@Transactional
	public void givenNotExistingApplication_whenUpdateDebtorEndpointIsHit_thenReturn404() throws Exception {

		UpdateBusinessDTO businessDTO = new UpdateBusinessDTO();

		mockMvc.perform(MockMvcRequestBuilders.patch("/v1/applications/382b9037-5842-43e8-b99b-2f4611784cd1/debtor")
				.contentType(MediaType.APPLICATION_JSON)
				.header("x-client-id", "11")
				.header("Authorization", token)
				.content(objectMapper.writeValueAsString(businessDTO)))
				.andExpect(status().isNotFound())
				.andDo(print());
	}

	@Test
	@Transactional
	public void givenNotValidClientId_whenUpdateDebtorEndpointIsHit_thenReturn400() throws Exception {

		UpdateBusinessDTO businessDTO = new UpdateBusinessDTO();

		mockMvc.perform(MockMvcRequestBuilders.patch("/v1/applications/382b9037-5842-43e8-b99b-2f4611784cd6/business")
				.contentType(MediaType.APPLICATION_JSON)
				.header("x-client-id", "0")
				.header("Authorization", token)
				.content(objectMapper.writeValueAsString(businessDTO)))
				.andExpect(status().isBadRequest())
				.andDo(print());
	}

	@Test
	@Transactional
	public void
			givenApplicationNotAuthorizedToBeModified_whenUpdateBusinessEndpointIsHit_thenUpdateBusinessAndReturn401()
					throws Exception {

		BusinessDTO businessDTO = new BusinessDTO();

		mockMvc.perform(MockMvcRequestBuilders.patch("/v1/applications/4d61f5c0-bca0-4388-bb02-8693d298ffd5/business")
				.contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(businessDTO))
				.header("x-client-id", "11")
				.header("Authorization", token))
				.andExpect(status().isBadRequest())
				.andDo(print());
	}

	public String getTextFileAsString(String filePath) throws IOException {

		return IOUtils.toString(
				this.getClass().getResourceAsStream(filePath),
				"UTF-8");
	}
}