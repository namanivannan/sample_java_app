package com.r1vs.platform.rox.api.serialization;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;
import com.r1vs.platform.rox.common.util.DateUtil;

import java.io.IOException;
import java.time.OffsetDateTime;

public class OffsetDateTimeSerializer extends StdSerializer<OffsetDateTime> {

	private static final long serialVersionUID = 1849929595634974765L;

	public OffsetDateTimeSerializer() {

		this(OffsetDateTime.class);
	}

	public OffsetDateTimeSerializer(final Class<OffsetDateTime> t) {

		super(t);
	}

	@Override
	public void serialize(final OffsetDateTime value, final JsonGenerator generator, final SerializerProvider provider)
			throws IOException {

		generator.writeString(value.format(DateUtil.RESPONSE_DATE_TIME_FORMATTER));
	}
}
