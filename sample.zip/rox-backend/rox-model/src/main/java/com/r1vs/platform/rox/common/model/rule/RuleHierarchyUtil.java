package com.r1vs.platform.rox.common.model.rule;

public final class RuleHierarchyUtil {

	private RuleHierarchyUtil() {

	}

	public static Boolean isDefaultLevel(final Integer ruleHierarchyLevelId) {

		return RuleHierarchyLevel.PRESCRIBER_NETWORK_DEFAULT.key().equals(ruleHierarchyLevelId)
				|| RuleHierarchyLevel.PLAN_DEFAULT.key().equals(ruleHierarchyLevelId);
	}

	public static Boolean isMemberLevel(final Integer ruleHierarchyLevelId) {

		return RuleHierarchyLevel.MEMBER_COMPLEX.key().equals(ruleHierarchyLevelId)
				|| RuleHierarchyLevel.MEMBER_EXCEPTION.key().equals(ruleHierarchyLevelId);
	}

	public static Boolean isProviderLevel(final Integer ruleHierarchyLevelId) {

		return RuleHierarchyLevel.PROVIDER_COMPLEX.key().equals(ruleHierarchyLevelId)
				|| RuleHierarchyLevel.PROVIDER_NETWORK_EXCEPTION.key().equals(ruleHierarchyLevelId)
				|| RuleHierarchyLevel.PROVIDER_NETWORK_DEFAULT.key().equals(ruleHierarchyLevelId);
	}

	public static Boolean isPrescriberLevel(final Integer ruleHierarchyLevelId) {

		return RuleHierarchyLevel.PRESCRIBER_COMPLEX.key().equals(ruleHierarchyLevelId)
				|| RuleHierarchyLevel.PRESCRIBER_NETWORK_EXCEPTION.key().equals(ruleHierarchyLevelId)
				|| RuleHierarchyLevel.PRESCRIBER_NETWORK_DEFAULT.key().equals(ruleHierarchyLevelId);
	}
}
