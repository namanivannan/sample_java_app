package com.r1vs.platform.rox.common.model.systemhierarchy;

import java.util.*;

import static com.r1vs.platform.rox.common.model.metadatacategories.MetadataCategoryConstants.*;

public class ClientInitializationConstants {

	private static List<MetadataInfo> pbmSeededMetadata;

	private static List<CriteriaInfo> pbmSeededCriteria;

	private static Map<String, CodeInfo> pbmSeededBasisOfCostCodes;

	private static List<Integer> pbmSeededHierarchyCodes;

	private static final Integer NPI_CODE = 5;

	private static final Integer BILLING_CODE = 6;

	private static final Integer VERSION_CODE = 8;

	private static final Integer DEA_CODE = 793;

	private static final Integer STATE_CODE = 794;

	public static synchronized List<MetadataInfo> getPbmSeededMetadata() {

		if (pbmSeededMetadata != null) {
			return pbmSeededMetadata;
		}

		pbmSeededMetadata = new ArrayList<>();
		pbmSeededMetadata.add(
				new MetadataInfo(BRAND_CLASS_EDIT_CATEGORY_ID, "Generic SS", "{\"name\":\"Generic Single-Source\"}"));
		pbmSeededMetadata.add(
				new MetadataInfo(BRAND_CLASS_EDIT_CATEGORY_ID, "Generic MS", "{\"name\":\"Generic Multi-Source\"}"));
		pbmSeededMetadata
				.add(new MetadataInfo(BRAND_CLASS_EDIT_CATEGORY_ID, "Brand SS", "{\"name\":\"Brand Single-Source\"}"));
		pbmSeededMetadata
				.add(new MetadataInfo(BRAND_CLASS_EDIT_CATEGORY_ID, "Brand MS", "{\"name\":\"Brand Multi-Source\"}"));
		pbmSeededMetadata.add(new MetadataInfo(FORMULARY_OPEN_FLAG_TYPE_ID, "Open", "{\"message\" :\"Test Message\"}"));
		pbmSeededMetadata
				.add(new MetadataInfo(FORMULARY_CLOSED_FLAG_TYPE_ID, "Closed", "{\"message\" :\"Test Message\"}"));
		pbmSeededMetadata.add(new MetadataInfo(BENEFIT_COVERAGE_FLAG_TYPE_ID, "Z - Covered Drug",
				"{\"name\":\"Z - Covered Drug\",\"messageMetadata\":{\"message\":\"test\"}}"));
		pbmSeededMetadata.add(new MetadataInfo(BENEFIT_COVERAGE_FLAG_TYPE_ID, "C - Part D Covered Drugs",
				"{\"name\":\"C - Part D Covered Drugs\",\"messageMetadata\":{\"message\":\"test\"}}"));
		pbmSeededMetadata.add(new MetadataInfo(BENEFIT_COVERAGE_FLAG_TYPE_ID, "E - Enhanced Drugs",
				"{\"name\":\"E - Enhanced Drugs\",\"messageMetadata\":{\"message\":\"test\"}}"));
		pbmSeededMetadata.add(new MetadataInfo(BENEFIT_COVERAGE_FLAG_TYPE_ID, "O - OTCs",
				"{\"name\":\"O - OTCs\",\"messageMetadata\":{\"message\":\"test\"}}"));
		pbmSeededMetadata.add(new MetadataInfo(BENEFIT_COVERAGE_FLAG_TYPE_ID, "A - Administrative",
				"{\"name\":\"A - Administrative\",\"messageMetadata\":{\"message\":\"test\"}}"));
		pbmSeededMetadata.add(new MetadataInfo(BENEFIT_COVERAGE_FLAG_TYPE_ID, "B - Part B Covered Drugs",
				"{\"name\":\"B - Part B Covered Drugs\",\"messageMetadata\":{\"message\":\"test\"}}"));
		pbmSeededMetadata.add(new MetadataInfo(BENEFIT_COVERAGE_FLAG_TYPE_ID, "S - Specialty",
				"{\"name\":\"S - Specialty\",\"messageMetadata\":{\"message\":\"test\"}}"));

		pbmSeededMetadata.add(new MetadataInfo(PREFERRED_DRUG_FLAG_TYPE_ID, "Tier0",
				"{\"tier\":\"Tier 0\",\"messageMetadata\":{\"message\":\"Tier 0\"}}"));
		pbmSeededMetadata.add(new MetadataInfo(PREFERRED_DRUG_FLAG_TYPE_ID, "Tier1",
				"{\"tier\":\"Tier 1\",\"messageMetadata\":{\"message\":\"Tier 1\"}}"));
		pbmSeededMetadata.add(new MetadataInfo(PREFERRED_DRUG_FLAG_TYPE_ID, "Tier2",
				"{\"tier\":\"Tier 2\",\"messageMetadata\":{\"message\":\"Tier 2\"}}"));
		pbmSeededMetadata.add(new MetadataInfo(PREFERRED_DRUG_FLAG_TYPE_ID, "Tier3",
				"{\"tier\":\"Tier 3\",\"messageMetadata\":{\"message\":\"Tier 3\"}}"));
		pbmSeededMetadata.add(new MetadataInfo(PREFERRED_DRUG_FLAG_TYPE_ID, "Tier4",
				"{\"tier\":\"Tier 4\",\"messageMetadata\":{\"message\":\"Tier 4\"}}"));
		pbmSeededMetadata.add(new MetadataInfo(PREFERRED_DRUG_FLAG_TYPE_ID, "Tier5",
				"{\"tier\":\"Tier 5\",\"messageMetadata\":{\"message\":\"Tier 5\"}}"));
		pbmSeededMetadata.add(new MetadataInfo(PREFERRED_DRUG_FLAG_TYPE_ID, "Tier6",
				"{\"tier\":\"Tier 6\",\"messageMetadata\":{\"message\":\"Tier 6\"}}"));
		pbmSeededMetadata.add(new MetadataInfo(PREFERRED_DRUG_FLAG_TYPE_ID, "Tier7",
				"{\"tier\":\"Tier 7\",\"messageMetadata\":{\"message\":\"Tier 7\"}}"));
		pbmSeededMetadata.add(new MetadataInfo(PREFERRED_DRUG_FLAG_TYPE_ID, "Tier8",
				"{\"tier\":\"Tier 8\",\"messageMetadata\":{\"message\":\"Tier 8\"}}"));
		pbmSeededMetadata.add(new MetadataInfo(PREFERRED_DRUG_FLAG_TYPE_ID, "Tier9",
				"{\"tier\":\"Tier 9\",\"messageMetadata\":{\"message\":\"Tier 9\"}}"));

		pbmSeededMetadata.add(new MetadataInfo(PRIOR_AUTHORIZATION_FLAG_TYPE_ID, "P - Standard Prior Authorization",
				"{\"message\":\"P - Standard Prior Authorization\",\"messageMetadata\":{\"message\":\"P - Standard Prior Authorization\"}}"));
		pbmSeededMetadata.add(new MetadataInfo(PRIOR_AUTHORIZATION_FLAG_TYPE_ID,
				"S - Specialty Drug Prior Authorization",
				"{\"message\":\"S - Specialty Drug Prior Authorization\",\"messageMetadata\":{\"message\":\"S - Specialty Drug Prior Authorization\"}}"));
		pbmSeededMetadata.add(new MetadataInfo(PRIOR_AUTHORIZATION_FLAG_TYPE_ID,
				"P1 - Standard Prior Authorization, Level 1",
				"{\"message\":\"P1 - Standard Prior Authorization, Level 1\",\"messageMetadata\":{\"message\":\"P1 - Standard Prior Authorization, Level 1\"}}"));
		pbmSeededMetadata.add(new MetadataInfo(PRIOR_AUTHORIZATION_FLAG_TYPE_ID,
				"P2 - Standard Prior Authorization, Level 2",
				"{\"message\":\"P2 - Standard Prior Authorization, Level 2\",\"messageMetadata\":{\"message\":\"P2 - Standard Prior Authorization, Level 2\"}}"));

		return pbmSeededMetadata;
	}

	public static synchronized List<CriteriaInfo> getPbmSeededCriteria() {

		if (pbmSeededCriteria != null) {
			return pbmSeededCriteria;
		}
		pbmSeededCriteria = new ArrayList<>();
		pbmSeededCriteria.add(new CriteriaInfo("All Drugs", "[{\"includeOrExclude\":\"I\",\"conditions\":[" +
				"{\"leftParen\":\"\",\"attributeId\":\"Drug.rxOtcId\",\"operator\":\"=\",\"attributeValue\":\"O\",\"rightParen\":\"\",\"conditionOperator\":\"||\"},"
				+
				"{\"leftParen\":\"\",\"attributeId\":\"Drug.rxOtcId\",\"operator\":\"=\",\"attributeValue\":\"P\",\"rightParen\":\"\",\"conditionOperator\":\"||\"},"
				+
				"{\"leftParen\":\"\",\"attributeId\":\"Drug.rxOtcId\",\"operator\":\"=\",\"attributeValue\":\"R\",\"rightParen\":\"\",\"conditionOperator\":\"||\"},"
				+
				"{\"leftParen\":\"\",\"attributeId\":\"Drug.rxOtcId\",\"operator\":\"=\",\"attributeValue\":\"S\",\"rightParen\":\"\",\"conditionOperator\":\"\"}]}]",
				true, false, false, 1, 1, "1", 0));
		return pbmSeededCriteria;
	}

	public static synchronized Map<String, CodeInfo> getPbmSeededBasisOfCostCodes() {

		if (pbmSeededBasisOfCostCodes != null) {
			return pbmSeededBasisOfCostCodes;
		}

		pbmSeededBasisOfCostCodes = new HashMap<>();
		pbmSeededBasisOfCostCodes.put("A", new CodeInfo("AWP", "8"));
		pbmSeededBasisOfCostCodes.put("D", new CodeInfo("DP", "18"));
		pbmSeededBasisOfCostCodes.put("H", new CodeInfo("HCFA FFP", "24"));
		pbmSeededBasisOfCostCodes.put("U", new CodeInfo("HCFA FFP for unit dose items", "24"));
		pbmSeededBasisOfCostCodes.put("W", new CodeInfo("WAC", "13"));
		pbmSeededBasisOfCostCodes.put("UC", new CodeInfo("U&C", "4"));
		pbmSeededBasisOfCostCodes.put("GAD", new CodeInfo("GAD", "8"));
		pbmSeededBasisOfCostCodes.put("SBMING", new CodeInfo("Submitted Ingredient Cost", "1"));

		return pbmSeededBasisOfCostCodes;
	}

	public static synchronized List<Integer> getPbmSeededHierarchyCodes() {

		if (pbmSeededHierarchyCodes != null) {
			return pbmSeededHierarchyCodes;
		}

		pbmSeededHierarchyCodes =
				new ArrayList<>(Arrays.asList(NPI_CODE, BILLING_CODE, VERSION_CODE, DEA_CODE, STATE_CODE));
		return pbmSeededHierarchyCodes;
	}

	public static class CodeInfo {

		private String description;

		private String reimbursementCode;

		CodeInfo() {

		}

		CodeInfo(final String description, final String reimbursementCode) {

			this.description = description;
			this.reimbursementCode = reimbursementCode;
		}

		public String getDescription() {

			return description;
		}

		public String getReimbursementCode() {

			return reimbursementCode;
		}

	}

	public static class MetadataInfo {

		private final Integer categoryId;

		private final String name;

		private final String json;

		MetadataInfo(Integer categoryId, String name, String json) {

			this.categoryId = categoryId;
			this.name = name;
			this.json = json;
		}

		public Integer getCategoryId() {

			return categoryId;
		}

		public String getName() {

			return name;
		}

		public String getJson() {

			return json;
		}
	}

	public static class CriteriaInfo {

		private final String name;

		private final String json;

		private final Boolean isSingleDomain;

		private final Boolean containsNestedCriteria;

		private final Boolean inlineCriteria;

		private final Integer categoryId;

		private final Integer formatId;

		private final String domains;

		private final Integer statusId;

		public CriteriaInfo(String name, String json, Boolean isSingleDomain, Boolean containsNestedCriteria,
				Boolean inlineCriteria, Integer categoryId, Integer formatId,
				String domains, Integer statusId) {

			this.name = name;
			this.json = json;
			this.isSingleDomain = isSingleDomain;
			this.containsNestedCriteria = containsNestedCriteria;
			this.inlineCriteria = inlineCriteria;
			this.categoryId = categoryId;
			this.formatId = formatId;
			this.domains = domains;
			this.statusId = statusId;
		}

		public String getName() {

			return name;
		}

		public String getJson() {

			return json;
		}

		public Boolean getSingleDomain() {

			return isSingleDomain;
		}

		public Boolean getContainsNestedCriteria() {

			return containsNestedCriteria;
		}

		public Boolean getInlineCriteria() {

			return inlineCriteria;
		}

		public Integer getCategoryId() {

			return categoryId;
		}

		public Integer getFormatId() {

			return formatId;
		}

		public String getDomains() {

			return domains;
		}

		public Integer getStatusId() {

			return statusId;
		}
	}

}
