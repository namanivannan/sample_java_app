package com.r1vs.platform.rox.common.model.rule;

public interface Sortable {

	Integer getPriority();
}
