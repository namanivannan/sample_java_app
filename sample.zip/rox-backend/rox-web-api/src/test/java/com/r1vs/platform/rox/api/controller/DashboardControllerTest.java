package com.r1vs.platform.rox.api.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.r1vs.platform.rox.api.service.ApplicationService;
import com.r1vs.platform.rox.common.util.StringUtil;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@Sql("fixture2.sql")
public class DashboardControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private DBConnection dbConnection;

	private String token;

	@Before
	public void setUp() throws Exception {

		if (StringUtil.isNullOrEmpty(token)) {
			token = dbConnection.loginToDb();
		}
	}

	@Test
	public void givenValidClientId_whenDashboardPortFolioGrowthEndpointIsHit_thenReturnDashboardPortFolioGrowthAnd200()
			throws Exception {

		mockMvc.perform(get("/v1/dashboard/portFolioGrowth")
				.header(AUTHORIZATION, token)
				.header("x-client-id", "11"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.portFolioGrowth.[1].feb.new", is(2)))
				.andExpect(jsonPath("$.portFolioGrowth.[1].feb.completed", is(0)))
				.andExpect(jsonPath("$.portFolioGrowth.[2].mar.new", is(1)))
				.andExpect(jsonPath("$.portFolioGrowth.[2].mar.completed", is(1)))
				.andDo(print());
	}

	@Test
	public void givenValidClientId_whenDashboardOverviewEndpointIsHit_thenReturnDashboardOverviewAnd200()
			throws Exception {

		mockMvc.perform(get("/v1/dashboard/overview")
				.header(AUTHORIZATION, token)
				.header("x-client-id", "11"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.overview.[0].name", is("Completed Applications")))
				.andExpect(jsonPath("$.overview.[0].value", is(30000)))
				.andExpect(jsonPath("$.overview.[1].name", is("No of Completed Applications")))
				.andExpect(jsonPath("$.overview.[1].value", is(1)))
				.andExpect(jsonPath("$.overview.[2].name", is("Open Applications")))
				.andExpect(jsonPath("$.overview.[2].value", is(30000)))
				.andExpect(jsonPath("$.overview.[3].name", is("No of Open Applications")))
				.andExpect(jsonPath("$.overview.[3].value", is(2)))
				.andExpect(jsonPath("$.overview.[4].duration", isA(Number.class)))
				.andDo(print());
	}

	@Test
	public void givenValidClientId_whenDashboardApplicationsEndpointIsHit_thenReturnDashboardApplicationsAnd200()
			throws Exception {

		mockMvc.perform(get("/v1/dashboard/applications")
				.header(AUTHORIZATION, token)
				.header("x-client-id", "11"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.applications.openApplications.[0].Approved", is(1)))
				.andExpect(jsonPath("$.applications.openApplications.[1].New", is(2)))
				.andExpect(jsonPath("$.applications.applicationsValue.[0].Approved", is(30000)))
				.andExpect(jsonPath("$.applications.applicationsValue.[1].New", is(30000)))
				.andDo(print());
	}

	@Test
	public void givenAdminUser_whenDashboardPortFolioGrowthEndpointIsHit_thenReturnDashboardPortFolioGrowthAnd200()
			throws Exception {

		mockMvc.perform(get("/v1/dashboard/rox/portFolioGrowth")
						.header(AUTHORIZATION, token)
						.header("x-client-id", "11"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.portFolioGrowth.[1].feb.new", is(5)))
				.andExpect(jsonPath("$.portFolioGrowth.[1].feb.completed", is(0)))
				.andExpect(jsonPath("$.portFolioGrowth.[2].mar.new", is(1)))
				.andExpect(jsonPath("$.portFolioGrowth.[2].mar.completed", is(1)))
				.andDo(print());
	}

	@Test
	public void givenAdminUser_whenDashboardOverviewEndpointIsHit_thenReturnDashboardOverviewAnd200()
			throws Exception {

		mockMvc.perform(get("/v1/dashboard/rox/overview")
						.header(AUTHORIZATION, token)
						.header("x-client-id", "11"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.overview.[0].name", is("Completed Applications")))
				.andExpect(jsonPath("$.overview.[0].value", is(30000)))
				.andExpect(jsonPath("$.overview.[1].name", is("No of Completed Applications")))
				.andExpect(jsonPath("$.overview.[1].value", is(1)))
				.andExpect(jsonPath("$.overview.[2].name", is("Open Applications")))
				.andExpect(jsonPath("$.overview.[2].value", is(180000)))
				.andExpect(jsonPath("$.overview.[3].name", is("No of Open Applications")))
				.andExpect(jsonPath("$.overview.[3].value", is(5)))
				.andExpect(jsonPath("$.overview.[4].duration", isA(Number.class)))
				.andDo(print());
	}

	@Test
	public void givenAdminUser_whenDashboardApplicationsEndpointIsHit_thenReturnDashboardApplicationsAnd200()
			throws Exception {

		mockMvc.perform(get("/v1/dashboard/rox/applications")
						.header(AUTHORIZATION, token)
						.header("x-client-id", "11"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.applications.openApplications.[0].Approved", is(1)))
				.andExpect(jsonPath("$.applications.openApplications.[1].New", is(2)))
				.andExpect(jsonPath("$.applications.openApplications.[2].['Under Review']", is(3)))
				.andExpect(jsonPath("$.applications.applicationsValue.[0].Approved", is(30000)))
				.andExpect(jsonPath("$.applications.applicationsValue.[1].New", is(30000)))
				.andExpect(jsonPath("$.applications.applicationsValue.[2].['Under Review']", is(150000)))
				.andDo(print());
	}
}
