package com.r1vs.platform.rox.common.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "xref_type")
public class XrefType extends AuditedEntity implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = -5200020922721120579L;

	@Id
	@Column(name = "xref_type_id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer xrefTypeId;

	@Column(name = "name")
	private String name;

	public Integer getXrefTypeId() {

		return xrefTypeId;
	}

	public void setXrefTypeId(final Integer xrefTypeId) {

		this.xrefTypeId = xrefTypeId;
	}

	public String getName() {

		return name;
	}

	public void setName(final String name) {

		this.name = name;
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(xrefTypeId).append(name).toHashCode();
	}

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof XrefType)) {
			return false;
		}

		final XrefType castOther = (XrefType) other;
		return new EqualsBuilder().append(xrefTypeId, castOther.xrefTypeId).append(name, castOther.name).isEquals();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("xrefTypeId", xrefTypeId).append("name", name).toString();
	}

}
