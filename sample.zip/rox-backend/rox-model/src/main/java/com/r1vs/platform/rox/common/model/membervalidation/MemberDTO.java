package com.r1vs.platform.rox.common.model.membervalidation;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.r1vs.platform.rox.common.model.memberenrollment.MemberProfile;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.io.Serializable;
import java.util.Objects;

public class MemberDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	@JsonProperty(value = "enrollmentAuthenticationFailAction")
	private String enrollmentAuthenticationFailAction;

	@JsonProperty(value = "memberId")
	private Integer memberId;

	@JsonProperty(value = "subscriberMemberId")
	private Integer subscriberMemberId;

	@JsonProperty(value = "memberProfile")
	private MemberProfile memberProfile;

	@JsonProperty(value = "message")
	private String message;

	public String getEnrollmentAuthenticationFailAction() {

		return enrollmentAuthenticationFailAction;
	}

	public void setEnrollmentAuthenticationFailAction(final String enrollmentAuthenticationFailAction) {

		this.enrollmentAuthenticationFailAction = enrollmentAuthenticationFailAction;
	}

	public Integer getMemberId() {

		return memberId;
	}

	public void setMemberId(final Integer memberId) {

		this.memberId = memberId;
	}

	public Integer getSubscriberMemberId() {

		return subscriberMemberId;
	}

	public void setSubscriberMemberId(final Integer subscriberMemberId) {

		this.subscriberMemberId = subscriberMemberId;
	}

	public MemberProfile getMemberProfile() {

		return memberProfile;
	}

	public void setMemberProfile(final MemberProfile memberProfile) {

		this.memberProfile = memberProfile;
	}

	public String getMessage() {

		return message;
	}

	public void setMessage(final String message) {

		this.message = message;
	}

	@Override
	public boolean equals(final Object obj) {

		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final MemberDTO other = (MemberDTO) obj;
		return Objects.equals(enrollmentAuthenticationFailAction, other.enrollmentAuthenticationFailAction)
				&& Objects.equals(memberId, other.memberId) && Objects.equals(memberProfile, other.memberProfile)
				&& Objects.equals(message, other.message)
				&& Objects.equals(subscriberMemberId, other.subscriberMemberId);
	}

	@Override
	public int hashCode() {

		return Objects.hash(enrollmentAuthenticationFailAction, memberId, memberProfile, message, subscriberMemberId);
	}

	@Override
	public String toString() {

		final ToStringBuilder builder = new ToStringBuilder(this);
		builder.append("enrollmentAuthenticationFailAction", enrollmentAuthenticationFailAction)
				.append("memberId", memberId).append("subscriberMemberId", subscriberMemberId)
				.append("memberProfile", memberProfile).append("message", message);
		return builder.toString();
	}

}
