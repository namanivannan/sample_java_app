package com.r1vs.platform.rox.common.util;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.List;

import com.r1vs.platform.rox.common.util.StringUtil;
import org.junit.Test;

public class StringUtilTest {

	@Test
	public void testInvalidZipCodesEvaluateCorrectly() {

		final List<String> invalidZips = Arrays.asList("zipcode", "1234", "12345678", "12345.678", "ninechars",
				"1234\n56789", "12asb", "1234{");

		for (final String zip : invalidZips) {
			assertFalse(StringUtil.isZipCode(zip));
		}
	}

	@Test
	public void testValidZipCodesEvaluateCorrectly() {

		final List<String> validZips = Arrays.asList("00000", "12345", "123456789", "000000000", "00100", "92108",
				"92109");

		for (final String zip : validZips) {
			assertTrue(StringUtil.isZipCode(zip));
		}
	}
}
