package com.r1vs.platform.rox.api.validator.role;

import com.r1vs.platform.rox.api.exception.Error;
import com.r1vs.platform.rox.api.model.role.UpdateRoleRequest;
import com.r1vs.platform.rox.api.validator.RoxWriteWebApiValidator;
import org.springframework.stereotype.Component;

import static com.r1vs.platform.rox.api.util.ValidationUtil.handleException;

@Component
public class UpdateRoleValidator extends RoleRequestValidator
		implements RoxWriteWebApiValidator<UpdateRoleRequest> {

	@Override
	public void validate(final UpdateRoleRequest updateRoleRequest) {

		final Error error = new Error();

		validateRoleName(error, updateRoleRequest);

		validateRoleSystemNameForUpdate(error, updateRoleRequest, getClientIdForRequest());

		validateStatusCode(error, updateRoleRequest.getStatusId());

		validateStatusFlowForUpdate(error, updateRoleRequest.getRoleId(), updateRoleRequest.getStatusId());

		validateAccessType(error, updateRoleRequest);

		handleException(error);
	}

}
