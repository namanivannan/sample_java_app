package com.r1vs.platform.rox.api.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.r1vs.platform.rox.api.model.application.initiate.OwnerDTO;
import com.r1vs.platform.rox.common.db.repository.business.ApplicationRepository;
import com.r1vs.platform.rox.common.db.repository.business.OwnerRepository;
import com.r1vs.platform.rox.common.util.StringUtil;
import org.apache.commons.io.IOUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.io.IOException;

import static org.hamcrest.Matchers.*;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@Sql("fixture2.sql")
public class OwnerControllerTest {

	@Autowired
	private DBConnection dbConnection;

	@Autowired
	private MockMvc mockMvc;

	private String token;

	private String token_user_2;

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private OwnerRepository ownerRepository;

	@Autowired
	private ApplicationRepository applicationRepository;

	@Before
	public void setUp() throws Exception {

		if (StringUtil.isNullOrEmpty(token)) {
			token = dbConnection.loginToDb();
		}
		token_user_2 = dbConnection.loginToDb(DBConnection.TEST_USER_1);
	}

	@Test
	public void givenExistingApplication_whenCreateOwner_thenOwnerIsAddedToExistingOnesInApplication()
			throws Exception {

		//when
		MvcResult result = mockMvc
				.perform(MockMvcRequestBuilders.post("/v1/applications/84ec6f35-f861-406c-a4ec-b9d33ccb88dc/owners")
						.contentType(MediaType.APPLICATION_JSON)
						.content(getTextFileAsString("/payloads/new_owner_payload.json"))
						.header("x-client-id", "12")
						.header("Authorization", token_user_2))
				.andDo(print())
				.andExpect(status().isCreated())
				.andExpect(jsonPath("$.uuid", not(emptyOrNullString())))
				.andExpect(jsonPath("$.dateOfBirth", is("1990-12-31")))
				.andReturn();

		String contentAsString = result.getResponse().getContentAsString();
		OwnerDTO createdOwnerDTO = objectMapper.readValue(contentAsString, OwnerDTO.class);
		String createdOwnerDTOUuid = createdOwnerDTO.getUuid();

		// then
		mockMvc.perform(MockMvcRequestBuilders.get("/v1/applications/84ec6f35-f861-406c-a4ec-b9d33ccb88dc")
				.accept(MediaType.APPLICATION_JSON)
				.header("x-client-id", "12")
				.header("Authorization", token_user_2))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.owners", hasSize(2)))
				.andExpect(jsonPath("$.owners[1].firstName", is("New Owner")))
				.andExpect(jsonPath("$.owners[1].uuid", is(createdOwnerDTOUuid)));

		mockMvc.perform(MockMvcRequestBuilders
				.get("/v1/applications/84ec6f35-f861-406c-a4ec-b9d33ccb88dc/owners/" + createdOwnerDTOUuid)
				.accept(MediaType.APPLICATION_JSON)
				.header("x-client-id", "12")
				.header("Authorization", token_user_2))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.firstName", is("New Owner")))
				.andExpect(jsonPath("$.uuid", is(createdOwnerDTOUuid)));
	}

	@Test
	public void givenExistingApplication_whenPatchOwner_thenOwnerIsModifiedCorrectly() throws Exception {

		MvcResult result = mockMvc.perform(MockMvcRequestBuilders.patch(
				"/v1/applications/84ec6f35-f861-406c-a4ec-b9d33ccb88dc/owners/bc5fbaf0-0be3-437d-9fec-ae9344fefc52")
				.contentType(MediaType.APPLICATION_JSON)
				.content(getTextFileAsString("/payloads/new_owner_payload.json"))
				.header("x-client-id", "12")
				.header("Authorization", token_user_2))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.uuid", is("bc5fbaf0-0be3-437d-9fec-ae9344fefc52")))
				.andExpect(jsonPath("$.firstName", is("New Owner")))
				.andExpect(jsonPath("$.addresses[0].address1", is("273 E 26TH ST, modified")))
				.andExpect(jsonPath("$.emails[0].email", is("modifiedMickey@pinktransportation.com")))
				.andExpect(jsonPath("$.identifications[0].identification", is("*313")))
				.andExpect(jsonPath("$.phones[0].number", is("13131313")))
				.andReturn();

		mockMvc.perform(MockMvcRequestBuilders.get("/v1/applications/84ec6f35-f861-406c-a4ec-b9d33ccb88dc")
				.accept(MediaType.APPLICATION_JSON)
				.header("x-client-id", "12")
				.header("Authorization", token_user_2))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.owners", hasSize(1)))
				.andExpect(jsonPath("$.owners[0].firstName", is("New Owner")))
				.andExpect(jsonPath("$.owners[0].uuid", is("bc5fbaf0-0be3-437d-9fec-ae9344fefc52")))
				.andExpect(jsonPath("$.owners[0].firstName", is("New Owner")))
				.andExpect(jsonPath("$.owners[0].addresses[0].address1", is("273 E 26TH ST, modified")))
				.andExpect(jsonPath("$.owners[0].emails[0].email", is("modifiedMickey@pinktransportation.com")))
				.andExpect(jsonPath("$.owners[0].identifications[0].identification", is("*313")))
				.andExpect(jsonPath("$.owners[0].phones[0].number", is("13131313")));
	}

	@Test
	public void
			givenASetOfOwnersPersisted_whenCallEndpointToGetOwnersFromApplication_thenOwnersBelongingToThatApplicationAreReturned()
					throws Exception {

		mockMvc.perform(MockMvcRequestBuilders.get("/v1/applications/382b9037-5842-43e8-b99b-2f4611784cd6/notes")
				.contentType(MediaType.APPLICATION_JSON)
				.header("x-client-id", "11")
				.header("Authorization", token))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.content", iterableWithSize(3)));
	}

	public String getTextFileAsString(String filePath) throws IOException {

		return IOUtils.toString(
				this.getClass().getResourceAsStream(filePath),
				"UTF-8");
	}

	@Test
	public void givenStoredOwner_whenDeleteOwnerEndpointIsHit_thenDeleteOwnerSuccessfully() throws Exception{

		mockMvc.perform(MockMvcRequestBuilders.delete("/v1/applications/382b9037-5842-43e8-b99b-2f4611784cd6/owners/17bd8e27-8228-40ac-afbb-ea6894e55d17")
						.contentType(MediaType.APPLICATION_JSON)
						.header("x-client-id", "11")
						.header("Authorization", token))
				.andExpect(status().isOk())
				.andDo(print());

		assertThat(ownerRepository.findById(1L).isPresent()).isFalse();

	}

	@Test
	public void givenStoredOwners_whenDeleteOwnerEndpointIsHit_thenDeleteAllOwnersSuccessfully() throws Exception{


		assertThat(ownerRepository.findAllByApplication(applicationRepository.getById(11L)).size()).isEqualTo(3);

		mockMvc.perform(MockMvcRequestBuilders.delete("/v1/applications/382b9037-5842-43e8-b99b-2f4611784cd6/owners/17bd8e27-8228-40ac-afbb-ea6894e55d17")
						.contentType(MediaType.APPLICATION_JSON)
						.header("x-client-id", "11")
						.header("Authorization", token))
				.andExpect(status().isOk())
				.andDo(print());

		mockMvc.perform(MockMvcRequestBuilders.delete("/v1/applications/382b9037-5842-43e8-b99b-2f4611784cd6/owners/17bd8e27-8228-40ac-afbb-ea6894e55d18")
						.contentType(MediaType.APPLICATION_JSON)
						.header("x-client-id", "11")
						.header("Authorization", token))
				.andExpect(status().isOk())
				.andDo(print());

		mockMvc.perform(MockMvcRequestBuilders.delete("/v1/applications/382b9037-5842-43e8-b99b-2f4611784cd6/owners/17bd8e27-8228-40ac-afbb-ea6894e55d19")
						.contentType(MediaType.APPLICATION_JSON)
						.header("x-client-id", "11")
						.header("Authorization", token))
				.andExpect(status().isOk())
				.andDo(print());

		assertThat(ownerRepository.findById(1L).isPresent()).isFalse();

		assertThat(ownerRepository.findById(7L).isPresent()).isFalse();

		assertThat(ownerRepository.findById(8L).isPresent()).isFalse();

		assertThat(applicationRepository.findById(11L).isPresent()).isTrue();

		assertThat(ownerRepository.findAllByApplication(applicationRepository.getById(11L)).size()).isEqualTo(0);

	}


	@Test
	public void givenExistingApplicationWithMaxAmountOfOwners_whenCreateOwner_thenThrow400()
			throws Exception {

		mockMvc.perform(MockMvcRequestBuilders.post("/v1/applications/382b9037-5842-43e8-b99b-2f4611784cd6/owners")
						.contentType(MediaType.APPLICATION_JSON)
						.content(getTextFileAsString("/payloads/new_owner_payload.json"))
						.header("x-client-id", "11")
						.header("Authorization", token))
				.andExpect(status().isBadRequest())
				.andDo(print());
	}
}