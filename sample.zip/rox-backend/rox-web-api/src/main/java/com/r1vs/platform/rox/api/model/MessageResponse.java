package com.r1vs.platform.rox.api.model;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

public class MessageResponse {

	private String message;

	public String getMessage() {

		return message;
	}

	public void setMessage(final String message) {

		this.message = message;
	}

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof MessageResponse)) {
			return false;
		}
		final MessageResponse castOther = (MessageResponse) other;
		return new EqualsBuilder().append(message, castOther.message).isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(message).toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("message", message).toString();
	}

}
