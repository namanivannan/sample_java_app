package com.r1vs.platform.rox.api.defaultvaluesetter.role;

import com.r1vs.platform.rox.api.model.role.RoleRequest;

public class BaseRoleDefaultValueSetter {

	protected void setDefaultRoleSystemName(final RoleRequest roleRequest) {

		if (roleRequest.getRoleName() != null) {
			final String roleSystemName = roleRequest.getRoleName().toUpperCase().replace(' ', '_');
			roleRequest.setRoleSystemName(roleSystemName);
		}
	}
}
