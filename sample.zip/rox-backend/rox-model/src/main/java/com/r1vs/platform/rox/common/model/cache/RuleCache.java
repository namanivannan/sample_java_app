package com.r1vs.platform.rox.common.model.cache;

import java.io.Serializable;
import java.util.List;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

public class RuleCache implements Serializable {

	private static final long serialVersionUID = 6050882609619856846L;

	private Long ruleId;

	private Integer ruleHierarchyId;

	private CriteriaCache parentCriteria;

	private CriteriaCache criteria;

	private List<MetadataCache> metadataList;

	private Integer ruleTypeId;

	private Integer pbmId;

	/**
	 * Empty constructor for regular instantiation
	 *
	 */
	public RuleCache() {

		// The explicit constructor is here, so that it is possible to provide Javadoc.
	}

	/**
	 * Copy Constructor for RuleCacheUtil.filterRulesByMetadataCategoryId()
	 *
	 * @param ruleCacheToCopy ruleCacheToCopy
	 */
	public RuleCache(final RuleCache ruleCacheToCopy) {

		this.ruleId = ruleCacheToCopy.ruleId;
		this.ruleHierarchyId = ruleCacheToCopy.ruleHierarchyId;
		this.parentCriteria = ruleCacheToCopy.parentCriteria;
		this.criteria = ruleCacheToCopy.criteria;
		this.metadataList = ruleCacheToCopy.metadataList;
		this.ruleTypeId = ruleCacheToCopy.ruleTypeId;
		this.pbmId = ruleCacheToCopy.pbmId;
	}

	public Long getRuleId() {

		return ruleId;
	}

	public void setRuleId(final Long ruleId) {

		this.ruleId = ruleId;
	}

	public Integer getRuleHierarchyId() {

		return ruleHierarchyId;
	}

	public void setRuleHierarchyId(final Integer ruleHierarchyId) {

		this.ruleHierarchyId = ruleHierarchyId;
	}

	public CriteriaCache getParentCriteria() {

		return parentCriteria;
	}

	public void setParentCriteria(final CriteriaCache parentCriteria) {

		this.parentCriteria = parentCriteria;
	}

	public CriteriaCache getCriteria() {

		return criteria;
	}

	public void setCriteria(final CriteriaCache criteria) {

		this.criteria = criteria;
	}

	public List<MetadataCache> getMetadataList() {

		return metadataList;
	}

	public void setMetadataList(final List<MetadataCache> metadataList) {

		this.metadataList = metadataList;
	}

	public Integer getRuleTypeId() {

		return ruleTypeId;
	}

	public void setRuleTypeId(final Integer ruleTypeId) {

		this.ruleTypeId = ruleTypeId;
	}

	public Integer getPbmId() {

		return pbmId;
	}

	public void setPbmId(final Integer pbmId) {

		this.pbmId = pbmId;
	}

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof RuleCache)) {
			return false;
		}
		final RuleCache castOther = (RuleCache) other;
		return new EqualsBuilder().append(ruleId, castOther.ruleId).append(ruleHierarchyId, castOther.ruleHierarchyId)
				.append(parentCriteria, castOther.parentCriteria).append(criteria, castOther.criteria)
				.append(metadataList, castOther.metadataList).append(ruleTypeId, castOther.ruleTypeId)
				.append(pbmId, castOther.pbmId).isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(ruleId).append(ruleHierarchyId).append(parentCriteria).append(criteria)
				.append(metadataList).append(ruleTypeId).append(pbmId).toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("ruleId", ruleId).append("ruleHierarchyId", ruleHierarchyId)
				.append("parentCriteria", parentCriteria).append("criteria", criteria)
				.append("metadataList", metadataList).append("ruleTypeId", ruleTypeId).append("pbmId", pbmId)
				.toString();
	}
}
