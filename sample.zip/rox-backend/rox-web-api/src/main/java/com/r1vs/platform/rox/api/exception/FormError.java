package com.r1vs.platform.rox.api.exception;

public class FormError {

	public FormErrorResponse errorResponse;

	public void addFormErrorResponse(final FormErrorResponse errorResponse) {

		this.errorResponse = errorResponse;
	}

	public FormErrorResponse getErrorResponse() {

		return errorResponse;
	}

}
