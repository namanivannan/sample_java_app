package com.r1vs.platform.rox.common.model.users;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.r1vs.platform.rox.common.model.AuditedEntity;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "user_role_audit")
public class UserRoleAudit extends AuditedEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", nullable = false)
	private Integer id;

	@Column(name = "user_id")
	@NotNull
	private Integer userId;

	@Column(name = "role_id")
	@NotNull
	private Integer roleId;

	@Column(name = "user_role_version")
	@NotNull
	private Integer version;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "role_id", nullable = false, insertable = false, updatable = false)
	private Role role;

	public Integer getId() {

		return id;
	}

	public void setId(final Integer id) {

		this.id = id;
	}

	public Integer getUserId() {

		return userId;
	}

	public void setUserId(final Integer userId) {

		this.userId = userId;
	}

	public Integer getRoleId() {

		return roleId;
	}

	public void setRoleId(final Integer roleId) {

		this.roleId = roleId;
	}

	public Integer getVersion() {

		return version;
	}

	public void setVersion(final Integer version) {

		this.version = version;
	}

	public Role getRole() {

		return role;
	}

	public void setRole(final Role role) {

		this.role = role;
	}

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof UserRoleAudit)) {
			return false;
		}
		final UserRoleAudit castOther = (UserRoleAudit) other;
		return new EqualsBuilder().append(id, castOther.id).append(userId, castOther.userId)
				.append(roleId, castOther.roleId).append(version, castOther.version).isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(id).append(userId).append(roleId).append(version).toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("id", id).append("userId", userId).append("roleId", roleId)
				.append("version", version).toString();
	}

}
