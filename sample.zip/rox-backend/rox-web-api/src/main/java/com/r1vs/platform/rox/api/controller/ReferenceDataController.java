package com.r1vs.platform.rox.api.controller;

import com.r1vs.platform.rox.api.service.ReferenceDataService;
import com.r1vs.platform.rox.common.model.StateAbbreviation;
import com.r1vs.platform.rox.common.model.business.ApplicationStatus;
import com.r1vs.platform.rox.common.model.business.BusinessType;
import com.r1vs.platform.rox.common.model.business.IndustryType;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static com.r1vs.platform.rox.api.util.InterceptorConstants.CLIENT_ID;

@RestController
@RequestMapping(value = "/v1")
@Tag(name = "ReferenceData",
		description = "Reference data for consulting and creating entities, such as Business Types, Industry Types, Application Statuses, etc.")
public class ReferenceDataController {

	@Autowired
	private ReferenceDataService referenceDataService;

	@GetMapping("/businessType/list")
	@Operation(summary = "Get a list of all the business Types stored in DB")
	public ResponseEntity<List<BusinessType>> getAllBusinessTypes(@RequestHeader(CLIENT_ID) String clientId) {

		return new ResponseEntity<>(referenceDataService.getAllBusinessTypes(), HttpStatus.OK);
	}

	@GetMapping("/applicationStatus/list")
	@Operation(summary = "Get a list of all the Application Statuses stored in DB")
	public ResponseEntity<List<ApplicationStatus>> getAllApplicationStatus(@RequestHeader(CLIENT_ID) String clientId) {

		return new ResponseEntity<>(referenceDataService.getAllApplicationStatus(), HttpStatus.OK);
	}

	@GetMapping("/industryType/list")
	@Operation(summary = "Get a list of all the Industry Types stored in DB")
	public ResponseEntity<List<IndustryType>> getAllIndustryTypes(@RequestHeader(CLIENT_ID) String clientId) {

		return new ResponseEntity<>(referenceDataService.getAllIndustryType(), HttpStatus.OK);
	}

	@GetMapping("/stateAbbreviation/list")
	@Operation(summary = "Get a list of all the State Abbreviation stored in DB")
	public ResponseEntity<List<StateAbbreviation>> getAllStateAbbreviation(@RequestHeader(CLIENT_ID) String clientId) {

		return new ResponseEntity<>(referenceDataService.getAllStateAbbreviation(), HttpStatus.OK);
	}

}
