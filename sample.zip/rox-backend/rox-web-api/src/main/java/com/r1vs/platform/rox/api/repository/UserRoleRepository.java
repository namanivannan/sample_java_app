package com.r1vs.platform.rox.api.repository;

import com.r1vs.platform.rox.common.model.users.UserRole;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface UserRoleRepository extends JpaRepository<UserRole, Long> {

	List<UserRole> findByUserId(final Long userId);

	List<UserRole> findAllByUserIdAndRoleId(Integer userId, Integer roleId);

	void deleteAllByUserId(Long userId);
}
