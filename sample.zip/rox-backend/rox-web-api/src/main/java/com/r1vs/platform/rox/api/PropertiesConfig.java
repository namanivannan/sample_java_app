package com.r1vs.platform.rox.api;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class PropertiesConfig {

	@Value("${roxwrite.web_api.default_page_num}")
	private Integer defaultPageNum;

	@Value("${roxwrite.web_api.default_page_limit}")
	private Integer defaultPageLimit;

	@Value("${roxwrite.domain}")
	private String roxwriteDomain;

	public Integer getDefaultPageNum() {

		return defaultPageNum;
	}

	public Integer getDefaultPageLimit() {

		return defaultPageLimit;
	}

	public String getRoxwriteDomain() {

		return roxwriteDomain;
	}

}
