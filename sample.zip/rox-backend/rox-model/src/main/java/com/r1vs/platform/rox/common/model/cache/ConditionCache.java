package com.r1vs.platform.rox.common.model.cache;

import java.io.Serializable;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

public class ConditionCache implements Serializable {

	private static final long serialVersionUID = -7436756678047023462L;

	private Integer priority;

	private String expression;

	private String includeExcludeFlag;

	public Integer getPriority() {

		return priority;
	}

	public void setPriority(final Integer priority) {

		this.priority = priority;
	}

	public String getExpression() {

		return expression;
	}

	public void setExpression(final String expression) {

		this.expression = expression;
	}

	public String getIncludeExcludeFlag() {

		return includeExcludeFlag;
	}

	public void setIncludeExcludeFlag(final String includeExcludeFlag) {

		this.includeExcludeFlag = includeExcludeFlag;
	}

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof ConditionCache)) {
			return false;
		}
		final ConditionCache castOther = (ConditionCache) other;
		return new EqualsBuilder().append(priority, castOther.priority).append(expression, castOther.expression)
				.append(includeExcludeFlag, castOther.includeExcludeFlag).isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(priority).append(expression).append(includeExcludeFlag).toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("priority", priority).append("expression", expression)
				.append("includeExcludeFlag", includeExcludeFlag).toString();
	}
}
