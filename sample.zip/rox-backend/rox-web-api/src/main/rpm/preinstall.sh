/usr/bin/getent group roxwrite || /usr/sbin/groupadd -r roxwrite
/usr/bin/getent passwd roxwrite || /usr/sbin/useradd -r -d /opt/roxwrite -s /sbin/nologin -g roxwrite roxwrite
/bin/mkdir -p /var/log/roxwrite && chown roxwrite:roxwrite /var/log/roxwrite
