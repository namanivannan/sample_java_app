package com.r1vs.platform.rox.common.model.types;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import com.r1vs.platform.rox.common.db.repository.core.LanguageCodeRepository;
import com.r1vs.platform.rox.common.model.LanguageCode;
import com.r1vs.platform.rox.common.util.UIConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class LanguageCodeType {

	@Autowired
	private LanguageCodeRepository languageCodeRepository;

	private final Map<String, String> languageCodeMap = new HashMap<>();

	private final Map<String, String> languageCodeNameMap = new HashMap<>();

	@PostConstruct
	public void init() {

		final List<LanguageCode> languageCodes = languageCodeRepository.findAll();

		for (final LanguageCode languageCode : languageCodes) {
			languageCodeMap.put(languageCode.getIsoCode(),
					languageCode.getIsoCode() + UIConstants.KEY_VALUE_DELIMITER + languageCode.getLanguage());
		}

		for (final LanguageCode languageCode : languageCodes) {
			languageCodeNameMap.put(languageCode.getIsoCode(), languageCode.getLanguage());
		}
	}

	public Map<String, String> getLanguageCodeMap() {

		return languageCodeMap;
	}

	public LanguageCodeRepository getLanguageCodeRepository() {

		return languageCodeRepository;
	}

	public void setLanguageCodeRepository(final LanguageCodeRepository languageCodeRepository) {

		this.languageCodeRepository = languageCodeRepository;
	}

	public Map<String, String> getLanguageCodeNameMap() {

		return languageCodeNameMap;
	}

}
