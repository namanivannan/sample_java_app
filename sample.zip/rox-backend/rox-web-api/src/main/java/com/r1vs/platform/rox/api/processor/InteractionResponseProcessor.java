package com.r1vs.platform.rox.api.processor;

import com.r1vs.platform.rox.api.model.application.ds.InteractionHolderForTableDTO;
import com.r1vs.platform.rox.api.model.application.ds.InteractionResponseDTO;
import com.r1vs.platform.rox.api.model.interaction.InteractionResponseSearchParams;
import com.r1vs.platform.rox.api.service.MapperService;
import com.r1vs.platform.rox.api.service.ValidationUtils;
import com.r1vs.platform.rox.api.service.ds.EntityType;
import com.r1vs.platform.rox.api.service.ds.InteractionResponseService;
import com.r1vs.platform.rox.common.model.business.Application;
import com.r1vs.platform.rox.common.model.business.Client;
import com.r1vs.platform.rox.common.model.ds.InteractionResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Component
public class InteractionResponseProcessor extends CommonProcessor<InteractionResponseDTO> {

	private static final Logger LOGGER = LoggerFactory.getLogger(InteractionResponseProcessor.class);

	@Autowired
	private InteractionResponseService interactionResponseService;

	@Autowired
	private ValidationUtils validationUtils;

	@Autowired
	private MapperService mapperService;

	public ResponseEntity<List<InteractionResponseDTO>> getInteractions(String clientId, UUID applicationId,
			InteractionResponseSearchParams searchRequest, Pageable pageParams) {

		Client client = validationUtils.requireClient(clientId);
		Application application = validationUtils.requireApplication(applicationId, client);
		Page<InteractionResponse> results =
				interactionResponseService.getInteractionResponses(client, application, searchRequest, pageParams);
		Page<InteractionResponseDTO> dtoMap = results.map(mapperService::getDtoFromInteraction);
		LOGGER.debug("searchRequest {}", searchRequest);
		if (searchRequest.isRecordForNoData()) {
			LOGGER.debug("performing getNoDataInteractionResponse");
			return new ResponseEntity<>(
					interactionResponseService.getNoDataInteractionResponse(client, application, dtoMap, searchRequest),
					HttpStatus.OK);
		}
		return buildResponseAsListWithPagination(dtoMap);
	}

}
