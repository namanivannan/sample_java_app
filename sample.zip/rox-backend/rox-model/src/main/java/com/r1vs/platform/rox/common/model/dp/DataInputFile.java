package com.r1vs.platform.rox.common.model.dp;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Version;

import com.r1vs.platform.rox.common.model.AuditedEntity;

@Entity
@Table(name = "dp_data_input_file")
public class DataInputFile extends AuditedEntity implements Serializable {

	private static final long serialVersionUID = 2628233015010123904L;

	@Id
	@Column(name = "id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Version
	private Integer version;

	@Column(name = "pbm_id")
	private Integer pbmId;

	@Column(name = "input_id", insertable = false, updatable = false)
	private Integer inputId;

	@Column(name = "registration_code")
	private String registrationCode;

	@Column(name = "file_uuid")
	private String fileUUID;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "input_id", referencedColumnName = "id")
	private DataInput dataInput;

	public Integer getId() {

		return id;
	}

	public void setId(final Integer id) {

		this.id = id;
	}

	public Integer getVersion() {

		return version;
	}

	public void setVersion(final Integer version) {

		this.version = version;
	}

	public Integer getPbmId() {

		return pbmId;
	}

	public void setPbmId(final Integer pbmId) {

		this.pbmId = pbmId;
	}

	public String getRegistrationCode() {

		return registrationCode;
	}

	public void setRegistrationCode(final String registrationCode) {

		this.registrationCode = registrationCode;
	}

	public String getFileUUID() {

		return fileUUID;
	}

	public void setFileUUID(final String fileUUID) {

		this.fileUUID = fileUUID;
	}

	public DataInput getDataInput() {

		return dataInput;
	}

	public void setDataInput(final DataInput dataInput) {

		this.dataInput = dataInput;
	}

	public Integer getInputId() {

		return inputId;
	}

	public void setInputId(final Integer inputId) {

		this.inputId = inputId;
	}

}
