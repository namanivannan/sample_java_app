package com.r1vs.platform.rox.api.model;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;

import java.util.Properties;

@Configuration
public class MailConfiguration {

	@Value("${spring.mail.host}")
	private String mailHost;

	@Value("${spring.mail.properties.mail.smtp.port}")
	private Integer port;

	@Value("${spring.mail.username}")
	private String username;

	@Value("${spring.mail.password}")
	private String password;

	@Value("${spring.mail.properties.mail.transport.protocol}")
	private String protocol;

	@Value("${spring.mail.properties.mail.smtp.auth}")
	private String auth;

	@Value("${spring.mail.properties.mail.smtp.starttls.enable}")
	private String startTlsEnable;

	@Value("${spring.mail.properties.mail.smtp.starttls.required}")
	private String startTlsRequired;

	@Value("${spring.mail.properties.mail.debug}")
	private String debug;

	private static final String MAIL_TRANSPORT_PROTOCOL = "mail.transport.protocol";

	private static final String MAIL_SMTP_AUTH = "mail.smtp.auth";

	private static final String MAIL_SMTP_STARTTLS_ENABLE = "mail.smtp.starttls.enable";

	private static final String MAIL_SMTP_STARTTLS_REQUIRED = "mail.smtp.starttls.required";

	private static final String MAIL_DEBUG = "mail.debug";

	@Bean
	public JavaMailSender getJavaMailSender() {

		final JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
		mailSender.setHost(mailHost);
		mailSender.setPort(port);

		mailSender.setUsername(username);
		mailSender.setPassword(password);

		final Properties props = mailSender.getJavaMailProperties();
		props.put(MAIL_TRANSPORT_PROTOCOL, protocol);
		props.put(MAIL_SMTP_AUTH, auth);
		props.put(MAIL_SMTP_STARTTLS_ENABLE, startTlsEnable);
		props.put(MAIL_SMTP_STARTTLS_REQUIRED, startTlsRequired);
		props.put(MAIL_DEBUG, debug);

		return mailSender;
	}

}
