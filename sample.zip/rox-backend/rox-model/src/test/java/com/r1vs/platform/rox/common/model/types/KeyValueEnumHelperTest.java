package com.r1vs.platform.rox.common.model.types;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

import com.r1vs.platform.rox.common.model.types.KeyValueEnumHelper;
import org.junit.Test;

/**
 * This class provides tests for the KeyValueEnumHelper.
 *
 */
public class KeyValueEnumHelperTest {

	public static enum BadEnumWithDuplicateKeys {

		ENUM1("KEY1", "V1"),
		ENUM2("KEY1", "V2");

		private String key;

		private String value;

		BadEnumWithDuplicateKeys(final String key, final String value) {

			this.key = key;
			this.value = value;
		}

		public String key() {

			return this.key;
		}

		public String value() {

			return this.value;
		}
	}

	public static enum BadEnumWithDuplicateValues {

		ENUM1("KEY1", "V1"),
		ENUM2("KEY2", "V1");

		private String key;

		private String value;

		BadEnumWithDuplicateValues(final String key, final String value) {

			this.key = key;
			this.value = value;
		}

		public String key() {

			return this.key;
		}

		public String value() {

			return this.value;
		}
	}

	public static enum BadEnumWithNullKey {

		ENUM1(null, "V1"),
		ENUM2("KEY1", "V2");

		private String key;

		private String value;

		BadEnumWithNullKey(final String key, final String value) {

			this.key = key;
			this.value = value;
		}

		public String key() {

			return this.key;
		}

		public String value() {

			return this.value;
		}
	}

	public static enum BadEnumWithTwoNullKeys {

		ENUM1(null, "V1"),
		ENUM2(null, "V2");

		private String key;

		private String value;

		BadEnumWithTwoNullKeys(final String key, final String value) {

			this.key = key;
			this.value = value;
		}

		public String key() {

			return this.key;
		}

		public String value() {

			return this.value;
		}
	}

	public static enum BadEnumWithNullValue {

		ENUM1("KEY2", null),
		ENUM2("KEY1", "V2");

		private String key;

		private String value;

		BadEnumWithNullValue(final String key, final String value) {

			this.key = key;
			this.value = value;
		}

		public String key() {

			return this.key;
		}

		public String value() {

			return this.value;
		}
	}

	public static enum BadEnumWithTwoNullValues {

		ENUM1("KEY2", null),
		ENUM2("KEY1", null);

		private String key;

		private String value;

		BadEnumWithTwoNullValues(final String key, final String value) {

			this.key = key;
			this.value = value;
		}

		public String key() {

			return this.key;
		}

		public String value() {

			return this.value;
		}
	}

	public static enum GoodEnum {

		//intentionally reorder them to verify the key and value list order
		ENUM2("KEY2", "V2"),
		ENUM1("KEY1", "V1");

		private String key;

		private String value;

		GoodEnum(final String key, final String value) {

			this.key = key;
			this.value = value;
		}

		public String key() {

			return this.key;
		}

		public String value() {

			return this.value;
		}
	}

	public static enum GoodCasedEnum {

		//intentionally reorder them to verify the key and value list order
		ENUM2("Key2", "v2"),
		ENUM1("Key1", "v1");

		private String key;

		private String value;

		GoodCasedEnum(final String key, final String value) {

			this.key = key;
			this.value = value;
		}

		public String key() {

			return this.key;
		}

		public String value() {

			return this.value;
		}
	}

	/**
	 * Test enum with one null key
	 */
	@Test
	public void testBadEnumWithNullKey() {

		try {
			KeyValueEnumHelper.adapt(BadEnumWithNullKey::key, BadEnumWithNullKey::value, BadEnumWithNullKey.values());
		} catch (Exception t) {
			fail("The adapt method should have not failed with " + t);
		}
	}

	/**
	 * Test enum with duplicate null keys
	 */
	@Test
	public void testBadEnumWithTwoNullKeys() {

		try {
			KeyValueEnumHelper.adapt(BadEnumWithTwoNullKeys::key, BadEnumWithTwoNullKeys::value,
					BadEnumWithTwoNullKeys.values());
			fail("The adapt method should have failed");
		} catch (Exception t) {
			assertEquals("The exception should be an IllegalStateException", IllegalStateException.class, t.getClass());
			assertEquals("Enums ENUM1, ENUM2 have the same key", t.getMessage());
		}
	}

	/**
	 * Test enum with one null value
	 */
	@Test
	public void testBadEnumWithNullValue() {

		try {
			KeyValueEnumHelper.adapt(BadEnumWithNullValue::key, BadEnumWithNullValue::value,
					BadEnumWithNullValue.values());
		} catch (Exception t) {
			fail("The adapt method should have not failed with " + t);
		}
	}

	/**
	 * Test enum with duplicate null keys
	 */
	@Test
	public void testBadEnumWithTwoNullValues() {

		try {
			KeyValueEnumHelper.adapt(BadEnumWithTwoNullValues::key, BadEnumWithTwoNullValues::value,
					BadEnumWithTwoNullValues.values());
			fail("The adapt method should have failed");
		} catch (Exception t) {
			assertEquals("The exception should be an IllegalStateException", IllegalStateException.class, t.getClass());
			assertEquals("Enums ENUM1, ENUM2 have the same value", t.getMessage());
		}
	}

	/**
	 * Test enum with duplicate keys
	 */
	@Test
	public void testBadEnumWithDuplicateKeys() {

		try {
			KeyValueEnumHelper.adapt(BadEnumWithDuplicateKeys::key, BadEnumWithDuplicateKeys::value,
					BadEnumWithDuplicateKeys.values());
			fail("The adapt method should have failed");
		} catch (Exception t) {
			assertEquals("The exception should be an IllegalStateException", IllegalStateException.class, t.getClass());
			assertEquals("Enums ENUM1, ENUM2 have the same key", t.getMessage());
		}
	}

	/**
	 * Test enum with duplicate values
	 */
	@Test
	public void testBadEnumWithDuplicateValues() {

		try {
			KeyValueEnumHelper.adapt(BadEnumWithDuplicateValues::key, BadEnumWithDuplicateValues::value,
					BadEnumWithDuplicateValues.values());
			fail("The adapt method should have failed");
		} catch (Exception t) {
			assertEquals("The exception should be an IllegalStateException", IllegalStateException.class, t.getClass());
			assertEquals("Enums ENUM1, ENUM2 have the same value", t.getMessage());
		}
	}

	@Test
	public void testGoodEnum() {

		KeyValueEnumHelper<GoodEnum, String, String> helper =
				KeyValueEnumHelper.adapt(GoodEnum::key, GoodEnum::value, GoodEnum.values());
		Map<String, String> keyValueMap = Map.of("KEY1", "V1", "KEY2", "V2");
		assertEquals(keyValueMap, helper.getKeyValueMap());
		Map<String, String> valueKeyMap = Map.of("V1", "KEY1", "V2", "KEY2");
		assertEquals(valueKeyMap, helper.getValueKeyMap());
		List<String> keyList = Arrays.asList("KEY2", "KEY1");
		assertEquals(keyList, helper.getKeyList());
		assertEquals(new LinkedHashSet<>(keyList), helper.getKeySet());
		List<String> valueList = Arrays.asList("V2", "V1");
		assertEquals(valueList, helper.getValueList());
		assertEquals(new HashSet<>(valueList), helper.getValueSet());
		//hashset can give different order
		assertFalse("The two arrays should not be identical",
				Arrays.equals(new HashSet<>(valueList).toArray(), helper.getValueSet().toArray()));
		assertTrue("The two arrays should be identical",
				Arrays.equals(new LinkedHashSet<>(valueList).toArray(), helper.getValueSet().toArray()));
		assertEquals(GoodEnum.ENUM2, helper.getEnumByKey("KEY2"));
		assertEquals(GoodEnum.ENUM2, helper.getEnumByValue("V2"));
		assertEquals("KEY1", helper.getKeyByValue("V1"));
		assertEquals("V1", helper.getValueByKey("KEY1"));
		assertTrue("The helper should contain KEY1", helper.containsKey("KEY1"));
		assertTrue("The helper should contain V1", helper.containsValue("V1"));
		assertFalse("The helper should not contain null value", helper.containsValue(null));
		assertFalse("The helper should not contain null key", helper.containsKey(null));
		try {
			helper.getEnumByKeyWithException(null);
		} catch (Exception e) {
			assertEquals("The exception should be an IllegalArgumentException", IllegalArgumentException.class,
					e.getClass());
			assertEquals("No enum found in GoodEnum for key: null", e.getMessage());
		}
		try {
			helper.getEnumByKeyWithException("notexist");
		} catch (Exception e) {
			assertEquals("The exception should be an IllegalArgumentException", IllegalArgumentException.class,
					e.getClass());
			assertEquals("No enum found in GoodEnum for key: notexist", e.getMessage());
		}
		try {
			helper.getEnumByValueWithException(null);
		} catch (Exception e) {
			assertEquals("The exception should be an IllegalArgumentException", IllegalArgumentException.class,
					e.getClass());
			assertEquals("No enum found in GoodEnum for value: null", e.getMessage());
		}
		try {
			helper.getEnumByValueWithException("notexist");
		} catch (Exception e) {
			assertEquals("The exception should be an IllegalArgumentException", IllegalArgumentException.class,
					e.getClass());
			assertEquals("No enum found in GoodEnum for value: notexist", e.getMessage());
		}

	}

	@Test
	public void testGoodCasedEnum() {

		KeyValueEnumHelper<GoodCasedEnum, String, String> helper =
				KeyValueEnumHelper.adapt(GoodCasedEnum::key, GoodCasedEnum::value, GoodCasedEnum.values());
		GoodCasedEnum entry = helper.getEnumByNonCasedKey("key1");
		assertEquals(entry, GoodCasedEnum.ENUM1);
		entry = helper.getEnumByNonCasedValue("v1");
		assertEquals(entry, GoodCasedEnum.ENUM1);
		try {
			helper.getEnumByNonCasedKeyWithException(null);
		} catch (Exception e) {
			assertEquals("The exception should be an IllegalArgumentException", IllegalArgumentException.class,
					e.getClass());
			assertEquals("No enum found in GoodCasedEnum for key: null", e.getMessage());
		}
		try {
			helper.getEnumByNonCasedKeyWithException("notexist");
		} catch (Exception e) {
			assertEquals("The exception should be an IllegalArgumentException", IllegalArgumentException.class,
					e.getClass());
			assertEquals("No enum found in GoodCasedEnum for key: notexist", e.getMessage());
		}
		try {
			helper.getEnumByNonCasedValueWithException(null);
		} catch (Exception e) {
			assertEquals("The exception should be an IllegalArgumentException", IllegalArgumentException.class,
					e.getClass());
			assertEquals("No enum found in GoodCasedEnum for value: null", e.getMessage());
		}
		try {
			helper.getEnumByNonCasedValueWithException("notexist");
		} catch (Exception e) {
			assertEquals("The exception should be an IllegalArgumentException", IllegalArgumentException.class,
					e.getClass());
			assertEquals("No enum found in GoodCasedEnum for value: notexist", e.getMessage());
		}

	}
}
