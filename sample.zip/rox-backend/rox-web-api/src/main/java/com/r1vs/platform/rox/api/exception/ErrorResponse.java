package com.r1vs.platform.rox.api.exception;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class ErrorResponse {

	private String field;

	private String message;

	private Object rejectedValue;

	public ErrorResponse() {

		super();
	}

	public ErrorResponse(final String field, final String message, final Object rejectedValue) {

		this.field = field;
		this.message = message;
		this.rejectedValue = rejectedValue;
	}

	public String getField() {

		return field;
	}

	public void setField(final String field) {

		this.field = field;
	}

	public String getMessage() {

		return message;
	}

	public void setMessage(final String message) {

		this.message = message;
	}

	public Object getRejectedValue() {

		return rejectedValue;
	}

	public void setRejectedValue(final Object rejectedValue) {

		this.rejectedValue = rejectedValue;
	}

}
