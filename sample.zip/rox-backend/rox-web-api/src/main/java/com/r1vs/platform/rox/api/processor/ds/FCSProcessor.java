package com.r1vs.platform.rox.api.processor.ds;

import com.r1vs.platform.rox.api.exception.RoxApiException;
import com.r1vs.platform.rox.api.model.application.ds.InteractionResponseDTO;
import com.r1vs.platform.rox.api.model.application.ds.fcs.UCCFilingDetailsRequestDTO;
import com.r1vs.platform.rox.api.model.application.ds.fcs.UCCSearchRequestDTO;
import com.r1vs.platform.rox.api.service.ds.InteractionResponseService;
import com.r1vs.platform.rox.api.util.DSConstants;
import com.r1vs.platform.rox.common.db.repository.core.StateAbbreviationRepository;
import com.r1vs.platform.rox.common.model.StateAbbreviation;
import com.r1vs.platform.rox.common.model.business.*;
import com.r1vs.platform.rox.common.model.ds.InteractionResponse;
import com.r1vs.platform.rox.interaction.fcs.request.FilingDetailRequest;
import com.r1vs.platform.rox.interaction.fcs.request.Reference;
import com.r1vs.platform.rox.interaction.fcs.request.SearchRequest;
import com.r1vs.platform.rox.interaction.fcs.response.StateInfoAndMetrics;
import com.r1vs.platform.rox.interaction.fcs.response.filinginfo.FilingInfoAndMetrics;
import com.r1vs.platform.rox.interaction.fcs.response.search.SearchInfoAndMetrics;
import com.r1vs.platform.rox.interaction.fcs.service.FCSService;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class FCSProcessor extends InteractionResponseService {

	private static final Logger LOGGER = LoggerFactory.getLogger(FCSProcessor.class);

	@Autowired
	private FCSService fcsService;

	@Autowired
	private StateAbbreviationRepository stateAbbreviationRepo;


    public InteractionResponseDTO performUCCSearchByState(String clientId,String stateCode) {
        Client client = validationUtils.requireClient(clientId);
        return performUCCSearchByState(client,null,stateCode);
    }
    public InteractionResponseDTO performUCCSearchByState(Client client, Application application,String stateCode) {
        StateInfoAndMetrics stateInfoAndMetrics = fcsService.searchByCode(stateCode);
        InteractionResponse interactionResponse = generateInteractionResponse(client,application, stateInfoAndMetrics::getStateInfo,
                stateInfoAndMetrics.getMetrics());
        interactionResponseRepository.save(interactionResponse);
        return mapperService.getDtoFromInteraction(interactionResponse);
    }

	public List<InteractionResponseDTO> performUCCSearch(UUID applicationId, String clientId,
			UCCSearchRequestDTO uccSearchDTO) {

        Client client = validationUtils.requireClient(clientId);
        Application application = validationUtils.requireApplication(applicationId, client);

        Business business = businessRepository.findBusinessByApplication(application).orElseThrow(
                () -> new RoxApiException("Business not found", HttpStatus.INTERNAL_SERVER_ERROR));

		List<InteractionResponse> interactionsToReturn = new ArrayList<>();
		if (uccSearchDTO.getBusinessId() != null) {
			SearchRequest businessSearchRequest = generateSearchRequest(applicationId, business, uccSearchDTO);
			SearchInfoAndMetrics infoAndMetrics = fcsService.searchDebtorName(businessSearchRequest);
            InteractionResponse interactionResponse =
                    generateInteractionResponse(client, application,
                            infoAndMetrics::getSearchInfo, infoAndMetrics.getMetrics());
            interactionResponse.setBusiness(business);
			interactionsToReturn.add(interactionResponse);
		}
		if (uccSearchDTO.getOwnerId() != null) {
			Owner owner = validationUtils.requireOwner(client, application, uccSearchDTO.getOwnerId());
			SearchRequest ownerSearchRequest = generateSearchRequest(applicationId, owner, uccSearchDTO);
			SearchInfoAndMetrics infoAndMetrics = fcsService.searchDebtorName(ownerSearchRequest);
            InteractionResponse interactionResponse =
                    generateInteractionResponse(client, application,
                            infoAndMetrics::getSearchInfo, infoAndMetrics.getMetrics());
            interactionResponse.setOwner(owner);
			interactionsToReturn.add(interactionResponse);
		}

		interactionResponseRepository.saveAll(interactionsToReturn);
		return interactionsToReturn.stream().map(mapperService::getDtoFromInteraction).collect(Collectors.toList());
	}

    public InteractionResponseDTO getUCCFilingDetails(UUID applicationId, String clientId,
                                                            UCCFilingDetailsRequestDTO uccFilingDetailsDTO) {
        Client client = validationUtils.requireClient(clientId);
        Application application = validationUtils.requireApplication(applicationId, client);

        FilingDetailRequest filingDetailRequest = getUCCFilingDetailsRequest(applicationId,
                uccFilingDetailsDTO);
        FilingInfoAndMetrics infoAndMetrics = fcsService.filingDetails(filingDetailRequest);
        InteractionResponse interactionResponse =
                generateInteractionResponse(client, application,
                        infoAndMetrics::getFilingInfo, infoAndMetrics.getMetrics());
        if(uccFilingDetailsDTO.getOwnerId() != null) {
            Owner owner = validationUtils.requireOwner(client, application, uccFilingDetailsDTO.getOwnerId());
            interactionResponse.setOwner(owner);
        } else {
            Business business = businessRepository.findBusinessByApplication(application).orElseThrow(
                    () -> new RoxApiException("Business not found", HttpStatus.INTERNAL_SERVER_ERROR));
            interactionResponse.setBusiness(business);
        }
        interactionResponseRepository.save(interactionResponse);
        return mapperService.getDtoFromInteraction(interactionResponse);
    }

    private FilingDetailRequest getUCCFilingDetailsRequest(UUID applicationId,UCCFilingDetailsRequestDTO uccFilingDetailsDTO) {
        FilingDetailRequest request = new FilingDetailRequest();
        request.setTransactionID(uccFilingDetailsDTO.getTransactionID());
        request.setFilingNumber(uccFilingDetailsDTO.getFilingNumbers());
        request.setPassThrough(applicationId.toString());
        return request;
    }

    private SearchRequest generateSearchRequest(UUID applicationId, Owner owner, UCCSearchRequestDTO uccSearchDTO) {

		SearchRequest request = new SearchRequest();
		request.setSearchOrganizationName("");
		request.setSearchFirstName(owner.getFirstName());
		request.setSearchLastName(owner.getLastName());
		Address ownerAddress = null;
		if (owner.getAddresses() != null && !owner.getAddresses().isEmpty()) {
			ownerAddress = owner.getAddresses().get(0);
		}
		return handleSearchRequest(applicationId, request, uccSearchDTO, ownerAddress);
	}

	private SearchRequest generateSearchRequest(UUID applicationId, Business business,
			UCCSearchRequestDTO uccSearchDTO) {

		SearchRequest request = new SearchRequest();
		request.setSearchOrganizationName(business.getName());
		request.setSearchFirstName("");
		request.setSearchLastName("");
		Address businessAddress = null;
		if (business.getAddresses() != null && !business.getAddresses().isEmpty()) {
			businessAddress = business.getAddresses().get(0);
		}
		return handleSearchRequest(applicationId, request, uccSearchDTO, businessAddress);
	}

	private SearchRequest handleSearchRequest(UUID applicationId, SearchRequest request,
			UCCSearchRequestDTO uccSearchDTO,
			Address entityAddress) {

		request.setIncludeInactiveFilings(uccSearchDTO.isIncludeInactiveFilings());

		if (entityAddress != null) {
			String stateFromAddress = entityAddress.getState();
			if (StringUtils.isNotBlank(stateFromAddress)) {
				if (stateFromAddress.length() > 2) {
					StateAbbreviation state = stateAbbreviationRepo.getByState(stateFromAddress);
					if (state == null) {
						throw new RoxApiException(
								String.format("State abbreviation not defined for %s", stateFromAddress),
								HttpStatus.INTERNAL_SERVER_ERROR);
					}
					stateFromAddress = state.getStateAbbreviation();
				}
				request.setStateCode(stateFromAddress);
			}
		}

		String dateValueForSearch = null;
		if (uccSearchDTO.getDate() != null) {
			dateValueForSearch = uccSearchDTO.getDate().atStartOfDay().format(DSConstants.formatterForFcsDates);
		}

		request.setUpdatedSearchFrom(dateValueForSearch);

		// TODO - we may need to finalize what we can send in these two fields
		request.setReferences(getReference(applicationId));
		request.setPassThrough(applicationId.toString());

		return request;
	}

	private List<Reference> getReference(UUID applicationId) {

		List<Reference> referenceList = new ArrayList<Reference>();
		Reference reference = new Reference();
		reference.setName(DSConstants.FCS_CLIENT_REFERENCE);
		reference.setValue(applicationId.toString());
		referenceList.add(reference);
		return referenceList;
	}

}
