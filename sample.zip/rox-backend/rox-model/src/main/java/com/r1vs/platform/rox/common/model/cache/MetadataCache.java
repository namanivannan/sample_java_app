package com.r1vs.platform.rox.common.model.cache;

import java.io.Serializable;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

public class MetadataCache implements Serializable {

	private static final long serialVersionUID = -8789893877955497640L;

	private Long metadataId;

	private Integer metadataCategoryId;

	private String metadataJson;

	public Long getMetadataId() {

		return metadataId;
	}

	public void setMetadataId(final Long metadataId) {

		this.metadataId = metadataId;
	}

	public Integer getMetadataCategoryId() {

		return metadataCategoryId;
	}

	public void setMetadataCategoryId(final Integer metadataCategoryId) {

		this.metadataCategoryId = metadataCategoryId;
	}

	public String getMetadataJson() {

		return metadataJson;
	}

	public void setMetadataJson(final String metadataJson) {

		this.metadataJson = metadataJson;
	}

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof MetadataCache)) {
			return false;
		}
		final MetadataCache castOther = (MetadataCache) other;
		return new EqualsBuilder().append(metadataId, castOther.metadataId)
				.append(metadataCategoryId, castOther.metadataCategoryId).append(metadataJson, castOther.metadataJson)
				.isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(metadataId).append(metadataCategoryId).append(metadataJson).toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("metadataId", metadataId)
				.append("metadataCategoryId", metadataCategoryId).append("metadataJson", metadataJson).toString();
	}
}
