package com.r1vs.platform.rox.common.util;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;

import com.r1vs.platform.rox.common.bean.DateConfigurationUtil;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static com.r1vs.platform.rox.common.bean.DateConfigurationUtil.MM_DD_YYYY_HOUR_FORMAT;

public final class DateUtil {

	private static final Logger LOGGER = LoggerFactory.getLogger(DateUtil.class);

	// This is duplication of using FieldSetDateMapper; however, want to avoid using
	// injection for a Util class
	// TODO figure out way to avoid duplication
	public static final DateTimeFormatter REQUEST_DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyyMMdd");

	public static final DateTimeFormatter REQUEST_HYPHENATED_DATE_FORMATTER = DateTimeFormatter
			.ofPattern("yyyy-MM-dd");

	public static final String ZONE_ID_UTC = "UTC";

	public static final DateTimeFormatter REQUEST_SLASH_DATE_FORMATTER = DateTimeFormatter
			.ofPattern("MM/dd/yyyy");

	public static final DateTimeFormatter RESPONSE_DATE_TIME_FORMATTER = DateTimeFormatter
			.ofPattern("yyyy-MM-dd'T'HH:mm:ss[.SSS]X");

	private DateUtil() {

	}

	public static Long calculateDayDifference(final LocalDate date1, final LocalDate date2) {

		return Math.abs(ChronoUnit.DAYS.between(date1, date2));
	}

	public static Long calculateYearDifference(final LocalDate date1, final LocalDate date2) {

		return Math.abs(ChronoUnit.YEARS.between(date1, date2));
	}

	/**
	 * Parses string and returns a LocalDate object.
	 *
	 * @param dateOfService date string in the form of yyyyMMdd.
	 * @return LocalDate instance from parsed date string
	 */
	public static LocalDate parseLocalDate(final String dateOfService) {

		if (StringUtil.isNullOrEmpty(dateOfService)) {
			return null;
		}

		try {
			if (dateOfService.contains("-")) {
				return LocalDate.parse(dateOfService, REQUEST_HYPHENATED_DATE_FORMATTER);
			} else {
				return LocalDate.parse(dateOfService, REQUEST_DATE_FORMATTER);
			}
		} catch (final DateTimeParseException e) {
			LOGGER.error("LocalDate parse exception", e);
		}
		return null;
	}

	/**
	 * Returns a String given a localDate object.
	 *
	 * @param localDate date object
	 * @return string in format of yyyyMMdd
	 */
	public static String getDateStringFromLocalDate(final LocalDate localDate) {

		return localDate.format(REQUEST_DATE_FORMATTER);
	}

	/**
	 * Returns true if isBetweenDate is &ge; startDate AND &le; endDate.
	 *
	 * @param isBetweenDate date that needs to be between startDate and endDate
	 * @param startDate date which is lower bound for between check
	 * @param endDate date which is upper bound for between check
	 * @return boolean indicating if isBetweenDate falls within dates
	 */
	public static Boolean between(final LocalDate isBetweenDate, final LocalDate startDate, final LocalDate endDate) {

		return isAfterOrEqual(isBetweenDate, startDate) && isBeforeOrEqual(isBetweenDate, endDate);
	}

	/**
	 * Verify date1 &le; date2.
	 *
	 * @param date1 first date in comparison
	 * @param date2 second date in comparison
	 * @return boolean result of &le; comparison
	 */
	private static Boolean isBeforeOrEqual(final LocalDate date1, final LocalDate date2) {

		return date1.equals(date2) || date1.isBefore(date2);
	}

	/**
	 * Verify date1 &ge; date2.
	 *
	 * @param date1 first date in comparison
	 * @param date2 second date in comparison
	 * @return boolean result of &ge; comparison
	 */
	private static Boolean isAfterOrEqual(final LocalDate date1, final LocalDate date2) {

		return date1.equals(date2) || date1.isAfter(date2);
	}

	/**
	 * Convert the local date time from one timezone to another
	 *
	 * @param systemZone systemZone
	 * @param zoneToBeConverted zoneToBeConverted
	 * @param dateTime dateTime
	 * @return converted dateTime
	 */
	public static OffsetDateTime convertDateTimeBetweenZones(final String systemZone, final String zoneToBeConverted,
			final OffsetDateTime dateTime) {

		if (dateTime == null) {
			return null;
		}

		final ZonedDateTime systemZonedTime = dateTime.atZoneSameInstant(ZoneId.of(systemZone));
		final ZonedDateTime desiredZoneTime = systemZonedTime.withZoneSameInstant(ZoneId.of(zoneToBeConverted));
		return desiredZoneTime.toOffsetDateTime();

	}

	public static OffsetDateTime convertUtcLocalDateTime(final LocalDateTime localDateTime) {

		return OffsetDateTime.of(localDateTime, ZoneOffset.UTC);
	}

	/**
	 * Returns deactivatedAt if not set to foreverDate, otherwise returns null.
	 *
	 * @param deactivatedAt deactivatedAt
	 * @return deactivatedAt or null
	 */
	public static OffsetDateTime getDeactivatedAtIfNotForeverDate(final OffsetDateTime deactivatedAt) {

		if (isNotForeverLocalDate(deactivatedAt)) {
			return deactivatedAt;
		}
		return null;
	}

	/**
	 * Returns true if date is not null and is not foreverLocalDate
	 *
	 * @param date date
	 * @return boolean
	 */
	public static boolean isNotForeverLocalDate(final OffsetDateTime date) {

		return date != null && !DateConfigurationUtil.foreverLocalDate().equals(date.toLocalDate());
	}

	/**
	 * Returns a LocalDate if date is not blank and can be parsed by yyyy-MM-dd format.
	 * 
	 * @param date
	 * @return
	 */
	public static LocalDate asDateYYYYMMDDWithDash(final String date) {

		//fail fast
		if (StringUtils.isBlank(date) || date.indexOf('-') <= 0) {
			return null;
		}
		try {
			return LocalDate.parse(date, REQUEST_HYPHENATED_DATE_FORMATTER);
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * Returns a Date with the a given format for a given String with a date in format YYYYMMDD.
	 *
	 * @param date date in format string to be parsed
	 * @param format format for the parsed date
	 * @return parsed date or exception
	 */
	public static String stringToLocalDateWithFormat(final String date, final DateTimeFormatter format) {

		if (StringUtils.isBlank(date)) {
			return null;
		}
		try {
			return LocalDate.parse(
					date,
					REQUEST_DATE_FORMATTER).format(format);
		} catch (DateTimeParseException e) {
			LOGGER.error("Error when parsing date: {}", date, e);
		}
		return null;
	}
}
