package com.r1vs.platform.rox.api.exception;

import org.springframework.http.HttpStatus;

public class RoxApiException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	private final HttpStatus httpStatus;

	public RoxApiException(final String message, final HttpStatus httpStatus) {

		super(message);
		this.httpStatus = httpStatus;
	}

	public HttpStatus getHttpStatus() {

		return httpStatus;
	}

}
