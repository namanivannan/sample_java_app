package com.r1vs.platform.rox.api.controller.admin;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.r1vs.platform.rox.api.controller.DBConnection;
import com.r1vs.platform.rox.api.utils.BaseTest;
import com.r1vs.platform.rox.common.util.StringUtil;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static com.r1vs.platform.rox.api.controller.DBConnection.TEST_USER_1;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@Sql("/com/r1vs/platform/rox/api/controller/fixture2.sql")
public class ClientControllerTest extends BaseTest {

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private DBConnection dbConnection;

	private String token;

	private String token_user_1;

	private String token_user_2;

	@Before
	public void setUp() throws Exception {

		if (StringUtil.isNullOrEmpty(token)) {
			token = dbConnection.loginToDb();
			token_user_1 = dbConnection.loginToDb(TEST_USER_1);
			token_user_2 = token;
		}
	}

	@Test
	public void givenValidLogin_whenCreateClientEndpointIsHit_thenCreatesItSuccessfully() throws Exception {

		mockMvc.perform(MockMvcRequestBuilders.post("/v1/clients")
				.contentType(MediaType.APPLICATION_JSON)
				.content(getTextFileAsString("/payloads/new_client_with_user.json"))
				.header("Authorization", token))
				.andExpect(status().isCreated())
				.andExpect(jsonPath("$.client.code", is("321")))
				.andExpect(jsonPath("$.client.name", is("ClientName")))
				.andExpect(jsonPath("$.client.address1", is("address1")))
				.andExpect(jsonPath("$.client.address2", is("address2")))
				.andExpect(jsonPath("$.client.phone", is("1234567890")))
				.andExpect(jsonPath("$.client.ein", is("ein")))
				.andExpect(jsonPath("$.client.website", is("website")))
				.andExpect(jsonPath("$.user.firstName", is("FirstName C")))
				.andExpect(jsonPath("$.user.lastName", is("LastName C")))
				.andDo(print());
	}

	@Test
	public void givenExistingClient_whenPatchClient_thenOwnerIsModifiedCorrectly() throws Exception {

		mockMvc.perform(MockMvcRequestBuilders.patch("/v1/clients/a920004b-e1aa-4a6d-85f1-10863e61363E")
				.contentType(MediaType.APPLICATION_JSON)
				.content(getTextFileAsString("/payloads/new_client.json"))
				.header("Authorization", token_user_2))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.code", is("321")))
				.andExpect(jsonPath("$.name", is("ClientName")))
				.andExpect(jsonPath("$.address1", is("address1")))
				.andExpect(jsonPath("$.address2", is("address2")))
				.andExpect(jsonPath("$.phone", is("1234567890")))
				.andExpect(jsonPath("$.ein", is("ein")))
				.andExpect(jsonPath("$.website", is("website")))
				.andDo(print());

		mockMvc.perform(MockMvcRequestBuilders.get("/v1/clients/a920004b-e1aa-4a6d-85f1-10863e61363E")
				.accept(MediaType.APPLICATION_JSON)
				.header("Authorization", token_user_2))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.code", is("321")))
				.andExpect(jsonPath("$.name", is("ClientName")))
				.andExpect(jsonPath("$.address1", is("address1")))
				.andExpect(jsonPath("$.address2", is("address2")))
				.andExpect(jsonPath("$.phone", is("1234567890")))
				.andExpect(jsonPath("$.ein", is("ein")))
				.andExpect(jsonPath("$.website", is("website")))
				.andDo(print());
	}

	@Test
	public void givenUnauthorizedUser_whenCreateClientEndpointIsHit_thenThrows403() throws Exception {

		mockMvc.perform(MockMvcRequestBuilders.post("/v1/clients")
				.contentType(MediaType.APPLICATION_JSON)
				.header("Authorization", token_user_1))
				.andExpect(status().isForbidden())
				.andDo(print());
	}

	@Test
	public void givenValidLogin_whenGetListOfClientsEndpointIsHit_thenListAllClients() throws Exception{
		mockMvc.perform(MockMvcRequestBuilders.get("/v1/clients")
				.contentType(MediaType.APPLICATION_JSON)
				.header("Authorization", token))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.[0].clientId", is(13)))
				.andExpect(jsonPath("$.[0].name", is("RoxWriteAdmin Cl3")))
				.andExpect(jsonPath("$.[0].code", is("testCode3")))
				.andExpect(jsonPath("$.[0].businessType", is("Limited Liability Company (LLC)")))
				.andExpect(jsonPath("$.[0].address1", is("testAddr1")))
				.andExpect(jsonPath("$.[0].address2", is("testAddr2")))
				.andExpect(jsonPath("$.[0].city", is("testCity")))
				.andExpect(jsonPath("$.[0].state", is("GA")))
				.andExpect(jsonPath("$.[0].county", is("testCounty")))
				.andExpect(jsonPath("$.[0].phone", is("5555555555")))
//				.andExpect(jsonPath("$.[1].clientId", is(11)))
//				.andExpect(jsonPath("$.[1].name", is("RoxWriteAdmin Client")))
//				.andExpect(jsonPath("$.[1].code", is("testCode")))
//				.andExpect(jsonPath("$.[1].businessType", is("Limited Liability Company (LLC)")))
//				.andExpect(jsonPath("$.[1].address1", is("testAddr1")))
//				.andExpect(jsonPath("$.[1].address2", is("testAddr2")))
//				.andExpect(jsonPath("$.[1].city", is("testCity")))
//				.andExpect(jsonPath("$.[1].state", is("GA")))
//				.andExpect(jsonPath("$.[1].county", is("testCounty")))
//				.andExpect(jsonPath("$.[1].phone", is("5555555555")))
				.andDo(print());
	}
}
