package com.r1vs.platform.rox.common.model.rule;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.r1vs.platform.rox.common.model.BitemporalEntity;
import com.r1vs.platform.rox.common.model.business.Status;
import com.r1vs.platform.rox.common.model.business.Client;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "criteria")
public class Criteria extends BitemporalEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(name = "criteria_id", nullable = false)
	private Long criteriaId;

	@Column(name = "client_id")
	private Integer clientId;

	@Column(name = "name", nullable = false)
	private String name;

	@Column(name = "status_id", nullable = false)
	@NotNull
	private Integer statusId;

	@Column(name = "json", nullable = false)
	private String json;

	@Column(name = "contains_nested_criteria", nullable = false)
	private Boolean containsNestedCriteria;

	@Column(name = "criteria_category_id")
	private Integer criteriaCategoryId;

	@Column(name = "criteria_format_id")
	private Integer criteriaFormatId;

	@Column(name = "is_single_domain", nullable = false)
	private Boolean isSingleDomain;

	@Column(name = "embedded_criteria_ids")
	private String embeddedCriteriaIds;

	@Column(name = "inline_criteria", nullable = false)
	private boolean inlineCriteria;

	@Column(name = "comments")
	private String comments;

	@Column(name = "domains")
	private String domains;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "client_id", nullable = false, insertable = false, updatable = false)
	private Client client;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "status_id", nullable = false, insertable = false, updatable = false)
	private Status status;

	public Integer getId() {

		return id;
	}

	public void setId(final Integer id) {

		this.id = id;
	}

	public Long getCriteriaId() {

		return criteriaId;
	}

	public void setCriteriaId(final Long criteriaId) {

		this.criteriaId = criteriaId;
	}

	public Integer getClientId() {

		return clientId;
	}

	public void setClientId(final Integer clientId) {

		this.clientId = clientId;
	}

	public String getName() {

		return name;
	}

	public void setName(final String name) {

		this.name = name;
	}

	public Integer getStatusId() {

		return statusId;
	}

	public void setStatusId(final Integer statusId) {

		this.statusId = statusId;
	}

	public String getJson() {

		return json;
	}

	public void setJson(final String json) {

		this.json = json;
	}

	public Boolean getContainsNestedCriteria() {

		return containsNestedCriteria;
	}

	public void setContainsNestedCriteria(final Boolean containsNestedCriteria) {

		this.containsNestedCriteria = containsNestedCriteria;
	}

	public Integer getCriteriaCategoryId() {

		return criteriaCategoryId;
	}

	public void setCriteriaCategoryId(final Integer criteriaCategoryId) {

		this.criteriaCategoryId = criteriaCategoryId;
	}

	public Integer getCriteriaFormatId() {

		return criteriaFormatId;
	}

	public void setCriteriaFormatId(final Integer criteriaFormatId) {

		this.criteriaFormatId = criteriaFormatId;
	}

	public Boolean getIsSingleDomain() {

		return isSingleDomain;
	}

	public void setIsSingleDomain(final Boolean singleDomain) {

		isSingleDomain = singleDomain;
	}

	public String getEmbeddedCriteriaIds() {

		return embeddedCriteriaIds;
	}

	public void setEmbeddedCriteriaIds(final String embeddedCriteriaIds) {

		this.embeddedCriteriaIds = embeddedCriteriaIds;
	}

	public boolean isInlineCriteria() {

		return inlineCriteria;
	}

	public void setInlineCriteria(final boolean inlineCriteria) {

		this.inlineCriteria = inlineCriteria;
	}

	public String getComments() {

		return comments;
	}

	public void setComments(final String comments) {

		this.comments = comments;
	}

	public String getDomains() {

		return domains;
	}

	public void setDomains(final String domains) {

		this.domains = domains;
	}

	public Client getClient() {

		return client;
	}

	public void setClient(final Client client) {

		this.client = client;
	}

	public Status getStatus() {

		return status;
	}

	public void setStatus(final Status status) {

		this.status = status;
	}

	/**
	 * Note: Regenerating equals, hashCode, and toString may re-introduce purposely removed related entities which cause
	 * lazy load exceptions after session has been closed. Please exclude relationships from these methods.
	 */

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof Criteria)) {
			return false;
		}
		final Criteria castOther = (Criteria) other;
		return new EqualsBuilder().append(inlineCriteria, castOther.inlineCriteria).append(id, castOther.id)
				.append(criteriaId, castOther.criteriaId).append(clientId, castOther.clientId)
				.append(name, castOther.name)
				.append(statusId, castOther.statusId).append(json, castOther.json)
				.append(containsNestedCriteria, castOther.containsNestedCriteria)
				.append(criteriaCategoryId, castOther.criteriaCategoryId)
				.append(criteriaFormatId, castOther.criteriaFormatId).append(isSingleDomain, castOther.isSingleDomain)
				.append(embeddedCriteriaIds, castOther.embeddedCriteriaIds).append(comments, castOther.comments)
				.append(domains, castOther.domains).isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(id).append(criteriaId).append(clientId).append(name).append(statusId)
				.append(json).append(containsNestedCriteria).append(criteriaCategoryId).append(criteriaFormatId)
				.append(isSingleDomain).append(embeddedCriteriaIds).append(inlineCriteria).append(comments)
				.append(domains).toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("id", id).append("criteriaId", criteriaId).append("clientId", clientId)
				.append("name", name).append("statusId", statusId).append("json", json)
				.append("containsNestedCriteria", containsNestedCriteria)
				.append("criteriaCategoryId", criteriaCategoryId).append("criteriaFormatId", criteriaFormatId)
				.append("isSingleDomain", isSingleDomain).append("embeddedCriteriaIds", embeddedCriteriaIds)
				.append("inlineCriteria", inlineCriteria).append("comments", comments).append("domains", domains)
				.toString();
	}
}
