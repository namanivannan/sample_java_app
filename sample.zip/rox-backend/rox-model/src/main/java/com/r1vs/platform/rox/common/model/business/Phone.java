package com.r1vs.platform.rox.common.model.business;

import com.r1vs.platform.rox.common.model.AuditedEntity;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;

@Entity
@Table(name = "phone")
@EntityListeners(AuditingEntityListener.class)
public class Phone extends AuditedEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@OneToOne
	@JoinColumn(name = "phone_type_id", nullable = false)
	private PhoneType phoneType;

	@Column(name = "phone_type_id", insertable = false, updatable = false)
	private Long phoneTypeId;

	@Column(name = "description")
	private String description;

	@Column(name = "xref_id")
	private Long xrefId;

	@Column(name = "xref_type_id")
	private Long xrefTypeId;

	@Column(name = "is_primary")
	private Boolean isPrimary;

	@Column(name = "number")
	private String number;

	@Column(name = "extension")
	private Long extension;

	public Long getId() {

		return this.id;
	}

	public void setId(Long id) {

		this.id = id;
	}

	public Long getPhoneTypeId() {

		return this.phoneTypeId;
	}

	public void setPhoneTypeId(Long phoneTypeId) {

		this.phoneTypeId = phoneTypeId;
	}

	public String getDescription() {

		return this.description;
	}

	public void setDescription(String description) {

		this.description = description;
	}

	public Long getXrefId() {

		return this.xrefId;
	}

	public void setXrefId(Long xrefId) {

		this.xrefId = xrefId;
	}

	public Long getXrefTypeId() {

		return this.xrefTypeId;
	}

	public void setXrefTypeId(Long xrefTypeId) {

		this.xrefTypeId = xrefTypeId;
	}

	public Boolean getIsPrimary() {

		return this.isPrimary;
	}

	public void setIsPrimary(Boolean isPrimary) {

		this.isPrimary = isPrimary;
	}

	public String getNumber() {

		return this.number;
	}

	public void setNumber(String number) {

		this.number = number;
	}

	public Long getExtension() {

		return this.extension;
	}

	public void setExtension(Long extension) {

		this.extension = extension;
	}

	public PhoneType getPhoneType() {

		return phoneType;
	}

	public void setPhoneType(PhoneType phoneType) {

		this.phoneType = phoneType;
	}
}
