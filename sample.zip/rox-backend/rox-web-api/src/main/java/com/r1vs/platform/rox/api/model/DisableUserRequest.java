package com.r1vs.platform.rox.api.model;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.time.OffsetDateTime;

public class DisableUserRequest implements Serializable {

	private static final long serialVersionUID = 1L;

	@NotNull
	private Long userId;

	@NotNull
	private Boolean active;

	public Long getUserId() {

		return userId;
	}

	public void setUserId(final Long userId) {

		this.userId = userId;
	}

	public Boolean isActive() {

		return active;
	}

	public void setActive(final Boolean active) {

		this.active = active;
	}

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof DisableUserRequest)) {
			return false;
		}
		final DisableUserRequest castOther = (DisableUserRequest) other;
		return new EqualsBuilder().append(userId, castOther.userId).append(active, castOther.active)
				.isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(userId).append(active).toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("userId", userId).append("active", active).toString();
	}

}
