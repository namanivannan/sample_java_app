package com.r1vs.platform.rox.api.controller.ds;

import com.r1vs.platform.rox.api.model.application.ds.InteractionResponseDTO;
import com.r1vs.platform.rox.api.model.application.ds.FCSDocumentInteractionResponseDTO;
import com.r1vs.platform.rox.api.model.application.ds.fcs.FCSResponseDTO;
import com.r1vs.platform.rox.api.model.application.ds.fcs.UCCFilingDetailsRequestDTO;
import com.r1vs.platform.rox.api.model.application.ds.fcs.UCCSearchRequestDTO;
import com.r1vs.platform.rox.api.processor.ds.FCSProcessor;
import com.r1vs.platform.rox.api.service.ds.InteractionResponseService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

import static com.r1vs.platform.rox.api.util.InterceptorConstants.CLIENT_ID;

@RestController
@RequestMapping(value = "/v1", produces = { MediaType.APPLICATION_JSON_VALUE })
@Tag(name = "FCS UCC SearchInfo/Filling")
public class FCSController {

	private static final Logger LOGGER = LoggerFactory.getLogger(FCSController.class);

	@Autowired
	private FCSProcessor fcsProcessor;

	@Autowired
	private InteractionResponseService interactionResponseService;

	@GetMapping(value = "/fcs/UCCSearch/GetStateInfo")
	@Operation(summary = "Get FMCSA SearchInfo Data.")
	public ResponseEntity<InteractionResponseDTO> search(@RequestHeader(CLIENT_ID) String clientId,
			@RequestParam(required = true, name = "stateCode") String stateCode) {

		LOGGER.debug("Get FCS UCC SearchInfo GetStateInfo with stateCode {} ", stateCode);
		return new ResponseEntity<>(fcsProcessor.performUCCSearchByState(clientId,stateCode),
				HttpStatus.OK);
	}

	@PostMapping("/applications/{applicationId}/ucc/search")
	@Operation(summary = "Perform ucc search on the application")
	public ResponseEntity<List<InteractionResponseDTO>> performUCCSearch(@PathVariable UUID applicationId,
			@RequestHeader(CLIENT_ID) String clientId,
			@RequestBody @Valid UCCSearchRequestDTO uccSearchDTO) {

		List<InteractionResponseDTO> interactionResponse =
				fcsProcessor.performUCCSearch(applicationId, clientId, uccSearchDTO);
		return new ResponseEntity<>(interactionResponse, HttpStatus.OK);
	}

    @PostMapping("/applications/{applicationId}/ucc/filingDetails")
    @Operation(summary = "Get the selected filing details on the application")
    public ResponseEntity<InteractionResponseDTO> getFilingDetails(@PathVariable UUID applicationId,
                                                                       @RequestHeader(CLIENT_ID) String clientId,
                                                                       @RequestBody @Valid UCCFilingDetailsRequestDTO uccFilingDetailsDTO) {

        InteractionResponseDTO interactionResponse =
                fcsProcessor.getUCCFilingDetails(applicationId, clientId, uccFilingDetailsDTO);
        return new ResponseEntity<>(interactionResponse, HttpStatus.OK);
    }

	@PostMapping("/fcs/{applicationId}/{interaction_uuid}/document")
	@Operation(summary = "Get response from FCS")
	public ResponseEntity<FCSDocumentInteractionResponseDTO> getFCSResponse(@PathVariable UUID applicationId,
																			@PathVariable UUID interaction_uuid,
																			@RequestBody FCSResponseDTO fcsResponseDTO) throws IOException {

		return new ResponseEntity<>(interactionResponseService.acceptFCSResponse(applicationId, interaction_uuid, fcsResponseDTO), HttpStatus.OK);
	}
}
