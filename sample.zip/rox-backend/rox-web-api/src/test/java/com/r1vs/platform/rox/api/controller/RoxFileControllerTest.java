package com.r1vs.platform.rox.api.controller;

import com.jayway.jsonpath.JsonPath;
import com.r1vs.platform.rox.common.util.StringUtil;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@Sql("fixture2.sql")
public class RoxFileControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private DBConnection dbConnection;

	private String token;

	@Before
	public void setUp() throws Exception {

		if (StringUtil.isNullOrEmpty(token)) {
			token = dbConnection.loginToDb();
		}
	}

	@Test
	public void givenValidMultipartFile_whenUploadFileEndpointIsHit_thenUploadFileToS3AndReturn200() throws Exception {

		MockMultipartFile file = new MockMultipartFile(
				"file",
				"testFile.txt",
				MediaType.TEXT_PLAIN_VALUE,
				"Test Upload File".getBytes());

		mockMvc.perform(MockMvcRequestBuilders.multipart("/v1/applications/839e72fc-6433-46fd-a259-5dbb50b913d6/files")
				.file(file)
				.contentType(MediaType.APPLICATION_JSON)
				.header("x-client-id", "11")
				.header("Authorization", token)
				.param("purpose", "purpose test"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.fileName", is("testFile.txt")))
				.andExpect(jsonPath("$.bucket", is("roxbucket")))
				.andExpect(jsonPath("$.key").isNotEmpty())
				.andDo(print());
	}

	@Test
	public void givenValidFile_whenGetFileInfoEndpointIsHit_thenReturnFileInfoAnd200() throws Exception {

		mockMvc.perform(MockMvcRequestBuilders
				.get("/v1/applications/382b9037-5842-43e8-b99b-2f4611784cd6/files/27a88d52-ecff-4613-9b7f-88bc79adcd88")
				.contentType(MediaType.APPLICATION_JSON)
				.header("x-client-id", "11")
				.header("Authorization", token))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.fileName", is("testFile1.png")))
				.andExpect(jsonPath("$.purpose", is("purpose 1")))
				.andExpect(jsonPath("$.fileType", is("image/png")))
				.andExpect(jsonPath("$.fileSize", is(35080)))
				//                .andExpect(jsonPath("$.createdBy.name", is("RoxWrite User Client 1")))
				.andExpect(jsonPath("$.updatedBy.name", is("RoxWrite User Client 1")))
				.andDo(print());
	}

	@Test
	public void givenValidFile_whenDownloadFileEndpointIsHit_thenReturnFileAnd200() throws Exception {

		MockMultipartFile file = new MockMultipartFile(
				"file",
				"testFile.txt",
				MediaType.TEXT_PLAIN_VALUE,
				"Test Upload File".getBytes());

		MvcResult result = mockMvc
				.perform(MockMvcRequestBuilders.multipart("/v1/applications/839e72fc-6433-46fd-a259-5dbb50b913d6/files")
						.file(file)
						.contentType(MediaType.APPLICATION_JSON)
						.header("x-client-id", "11")
						.header("Authorization", token)
						.param("purpose", "purpose test"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.fileName", is("testFile.txt")))
				.andDo(print())
				.andReturn();

		String body = JsonPath.parse(result.getResponse().getContentAsString()).read("$.uuid");
		MvcResult downloadResult = mockMvc
				.perform(MockMvcRequestBuilders
						.get("/v1/applications/839e72fc-6433-46fd-a259-5dbb50b913d6/files/" + body + "/download")
						.contentType(MediaType.TEXT_PLAIN_VALUE)
						.header("x-client-id", "11")
						.header("Authorization", token))
				.andExpect(status().isOk())
				.andDo(print())
				.andReturn();

		Assert.assertEquals("Test Upload File", downloadResult.getResponse().getContentAsString());
	}

	@Test
	public void givenValidStoredFile_whenDeleteFileEndpointIsHit_thenDeleteFileAndReturn200() throws Exception {

		MockMultipartFile file = new MockMultipartFile(
				"file",
				"testFile.txt",
				MediaType.TEXT_PLAIN_VALUE,
				"Test Upload File".getBytes());

		MvcResult result = mockMvc
				.perform(MockMvcRequestBuilders.multipart("/v1/applications/839e72fc-6433-46fd-a259-5dbb50b913d6/files")
						.file(file)
						.contentType(MediaType.APPLICATION_JSON)
						.header("x-client-id", "11")
						.header("Authorization", token)
						.param("purpose", "purpose test"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.fileName", is("testFile.txt")))
				.andDo(print())
				.andReturn();

		String uuid = JsonPath.parse(result.getResponse().getContentAsString()).read("$.uuid");
		mockMvc.perform(
				MockMvcRequestBuilders.delete("/v1/applications/839e72fc-6433-46fd-a259-5dbb50b913d6/files/" + uuid)
						.contentType(MediaType.TEXT_PLAIN_VALUE)
						.header("x-client-id", "11")
						.header("Authorization", token))
				.andExpect(status().isOk())
				.andDo(print());

		mockMvc.perform(
				MockMvcRequestBuilders.get("/v1/applications/839e72fc-6433-46fd-a259-5dbb50b913d6/files/" + uuid)
						.contentType(MediaType.APPLICATION_JSON)
						.header("x-client-id", "11")
						.header("Authorization", token))
				.andExpect(status().isNotFound())
				.andDo(print());

	}

}