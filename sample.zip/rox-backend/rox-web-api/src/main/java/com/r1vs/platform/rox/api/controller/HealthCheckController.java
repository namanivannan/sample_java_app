package com.r1vs.platform.rox.api.controller;

import com.r1vs.platform.rox.api.model.MessageResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(produces = { MediaType.APPLICATION_JSON_VALUE })
@Tag(name = "Health Check Endpoint")
public class HealthCheckController {

	private static final Logger LOGGER = LoggerFactory.getLogger(HealthCheckController.class);

	private static final String OK = "OK";

	@GetMapping(value = "/healthcheck")
	@Operation(summary = "Get RoxWrite Health Check Endpoint.")
	public ResponseEntity<MessageResponse> getHealthCheck() {

		LOGGER.info("Get RoxWrite Health Check Endpoint");
		final MessageResponse messageResponse = new MessageResponse();
		messageResponse.setMessage(OK);
		return new ResponseEntity<>(messageResponse, HttpStatus.OK);
	}
}
