package com.r1vs.platform.rox.common.model.messages;

import java.util.List;

public class MessageAssociation {

	private List<MessageGroupAssociation> messages;

	public List<MessageGroupAssociation> getMessages() {

		return messages;
	}

	public void setMessages(List<MessageGroupAssociation> messages) {

		this.messages = messages;
	}
}
