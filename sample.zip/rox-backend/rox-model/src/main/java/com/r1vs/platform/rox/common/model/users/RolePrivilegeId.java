package com.r1vs.platform.rox.common.model.users;

import java.io.Serializable;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

public class RolePrivilegeId implements Serializable {

	private static final long serialVersionUID = 1L;

	private Integer roleId;

	private Integer privilegeId;

	public Integer getRoleId() {

		return roleId;
	}

	public void setRoleId(final Integer roleId) {

		this.roleId = roleId;
	}

	public Integer getPrivilegeId() {

		return privilegeId;
	}

	public void setPrivilegeId(final Integer privilegeId) {

		this.privilegeId = privilegeId;
	}

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof RolePrivilegeId)) {
			return false;
		}
		final RolePrivilegeId castOther = (RolePrivilegeId) other;
		return new EqualsBuilder().append(roleId, castOther.roleId).append(privilegeId, castOther.privilegeId)
				.isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(roleId).append(privilegeId).toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("roleId", roleId).append("privilegeId", privilegeId).toString();
	}

}
