package com.r1vs.platform.rox.common.exceptions;

public class InactiveOrDraftPbmException extends RuntimeException {

	public InactiveOrDraftPbmException(final String message) {

		super(message);
	}
}
