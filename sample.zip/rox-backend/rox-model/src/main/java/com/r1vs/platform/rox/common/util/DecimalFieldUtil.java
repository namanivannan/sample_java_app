package com.r1vs.platform.rox.common.util;

import java.math.BigDecimal;

public class DecimalFieldUtil {

	private static final BigDecimal ONE_THOUSAND = new BigDecimal("1000");

	private static final BigDecimal TEN_THOUSAND = new BigDecimal("10000");

	private DecimalFieldUtil() {

	};

	/**
	 * Converts to BigDecimal and divides to get a decimal with 3 decimal places
	 *
	 * @param value String representation
	 * @return BigDecimal object
	 */
	public static final BigDecimal convertWithThousandthsPlace(final String value) {

		if (StringUtil.isNotNullOrEmpty(value)) {
			final BigDecimal amount = new BigDecimal(value);

			return amount.divide(ONE_THOUSAND);
		}

		return null;

	}

	/**
	 * Converts to BigDecimal and divides to get a decimal with 4 decimal places
	 *
	 * @param value String representation
	 * @return BigDecimal object
	 */
	public static final BigDecimal convertWithTenThousandthsPlace(final String value) {

		if (StringUtil.isNotNullOrEmpty(value)) {
			final BigDecimal amount = new BigDecimal(value);

			return amount.divide(TEN_THOUSAND);
		}

		return null;

	}

}
