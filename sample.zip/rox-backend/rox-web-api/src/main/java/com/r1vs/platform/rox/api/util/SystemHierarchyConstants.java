package com.r1vs.platform.rox.api.util;

public class SystemHierarchyConstants {

	public static final String ACCOUNT_STATUS = "accountStatus";

	public static final String ACCOUNT_TYPE = "accountType";

	public static final String VENDOR_ID = "vendorId";

	public static final String ACCOUNT_NAME = "accountName";

	public static final String EXTERNAL_ACCOUNT_ID = "accountId";

	public static final String CARRIER_TYPE = "carrierType";

	public static final String CARRIER_STATUS = "carrierStatus";

	public static final String CARRIER_NAME = "carrierName";

	public static final String EXTERNAL_CARRIER_ID = "carrierId";

	public static final String SPONSOR_NAME = "sponsorName";

	public static final String SPONSOR_STATUS = "sponsorStatus";

	public static final String CARD_STATUS = "cardStatus";

	public static final String SPONSOR_TYPE = "sponsorType";

	public static final String EXTERNAL_SPONSOR_ID = "sponsorId";

	public static final String PBM_TYPE = "pbmType";

	public static final String PRORATION_TYPE = "proration";

	public static final String PLAN_TYPE = "planType";

	public static final String ACTION_FOR_PLAN_MAX = "actionForPlanMax";

	public static final String COMPOUND_COVERAGE = "compoundCoverage";

	public static final String DISPENSING_FEE_METHOD = "dispensingFeeMethod";

	public static final String COB_METHOD = "cobMethod";

	public static final String MEMBER_FINANCIAL_RESPONSIBILITY = "memberFinancialResponsibility";

	public static final String REJECT_FOR_PROVIDER_DENIAL = "rejectProvider";

	public static final String COB_NOT_COVERED = "cobNotCovered";

	public static final String COB_PAYMENT_NOT_COLLECTED = "cobPaymentReject";

	public static final String REQUIRE_OTHER_PAYER_AMOUNT = "requireOtherPayerAmountPaid";

	public static final String REQUIRE_OTHER_PAYER = "requireOtherPayer";

	public static final String COST_AVOIDANCE_METHOD = "costAvoidanceMethod";

	public static final String OTHER_COVERAGE_CODE = "otherCoverageCode";

	public static final String NETWORK_ASSIGNMENT = "networkAssignment";

	public static final String NETWORK_CLASSIFICATION = "networkClassification";

	public static final String CLAIM_TYPE = "claimType";

	public static final String OPERATOR = "operator";

	public static final String REPORTING_NETWORK = "reportNetwork";

	public static final String RESPONSE_NETWORK_ID = "responseNetworkId";

	public static final String RETURN_RESPONSE_GROUP = "responseGroupId";

	public static final String INDUSTRY_TYPE = "industryType";

	public static final String HELP_DESK_PHONE_TYPE = "helpDeskPhoneType";

	public static final String ACCOUNT_ASSIGNMENT = "accountId";

	public static final String SPONSOR_ASSIGNMENT = "sponsorId";

	public static final String CARRIER_ASSIGNMENT = "carrierId";

	public static final String PBM_ASSIGNMENT = "pbmId";

	public static final String THE_PBM_ID_CANNOT_BE_NULL = "The pbm id cannot be null";

	public static final String THE_PBM_ID_MUST_MATCH_THE_ONE_SELECTED = "The pbm id must match the one selected.";

	public static final String STATE_EXCLUSIONS = "stateExclusions";

	public static final String COST_SHARING_ORDER = "costSharingOrder";

	public static final String COST_SHARING_BASIS = "costSharingBasis";

	public static final String COVERAGE_LEVEL = "coverageLevel";

	public static final String PLAN_STATUS = "planStatus";

	public static final String EXTERNAL_PLAN_ID = "externalPlanId";

	public static final String PLAN_NAME = "planName";

	public static final String PRICING_METHODOLOGY = "pricingMethodology";

	public static final String RESTRICTION = "restriction";

	public static final String CONTACT = "contact";

	public static final String TAX_ASSESSMENT = "taxAssessment";

	public static final String CLAIM_RESPONSE_PLAN_ID = "claimResponsePlanId";

	public static final String COMPOUND_BRAND_CLASS = "compoundBrandClass";

	public static final String TAX_EXEMPTION = "taxExemption";

	public static final String SECURITY_USER_ACCESS_ID = "securityUserAccessId";

	public static final String PBM_NAME = "pbmName";

	public static final String EXTERNAL_PBM_ID = "externalPbmId";

	public static final String PBM_STATUS = "pbmStatus";

	public static final String GROUP_NAME = "groupName";

	public static final String EXTERNAL_GROUP_ID = "externalGroupId";

	public static final String GROUP_STATUS = "groupStatus";

	public static final String FILE_UPDATE_TYPE = "fileUpdateType";

	public static final String CONTACT_TYPE = "contactType";

	public static final String SPONSOR = "sponsor";

	public static final String ACCOUNT = "account";

	public static final String CARRIER = "carrier";

	public static final String PLAN = "plan";

	public static final String GROUP_PLAN = "groupPlan";

	public static final String GROUPS = "group";

	public static final String PBM = "pbm";

	public static final String DEFAULT_PLAN_ID = "defaultPlanId";

	public static final String DEFAULT_GROUP_ID = "defaultGroupId";

	public static final String PCN_USAGE = "pcnUsage";

	public static final String DRUG_LEVELS = "drugLevels";

	public static final String COB_COVERAGE_LEVEL = "cobCoverageLevel";

	public static final String COB_PAYMENT_ORDER = "cobPaymentOrder";

	public static final String NO_OTHER_COVERAGE_OCC1 = "noOtherCoverageOcc1";

	public static final String COB_REJECTED_OCC3 = "cobRejectedOcc3";

	public static final String ENROLLMENT_METHOD_TYPE = "enrollmentMethodType";

	public static final String MEMBER_ALIAS_METHOD_TYPE = "memberAliasType";

	public static final String DYNAMIC_ENROLLMENT_TYPE = "dynamicEnrollmentType";

	public static final String CARHOLDER_ID_ASSIGNMENT_TYPE = "cardholderIdAssignmentType";
}
