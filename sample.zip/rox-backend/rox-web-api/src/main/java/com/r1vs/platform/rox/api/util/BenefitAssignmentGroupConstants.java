package com.r1vs.platform.rox.api.util;

public class BenefitAssignmentGroupConstants {

	public static final String BENEFIT_ASSIGNMENT_RULE_STATUSES = "benefitAssignmentGroupRuleStatuses";

	public static final String BENEFIT_ASSIGNMENT_GROUP_STATUS = "benefitAssignmentGroupStatus";

	public static final String COVERED_DRUG_STATUS_CODE_METADATA_KEY = "benefitCoveredDrugStatusCodes";

	public static final String POS_REBATE_COVERAGE_METADATA_KEY = "posRebateCoverageCodes";

	// Prior Authorization
	public static final String PRIOR_AUTHORIZATION_METADATA_KEY = "priorAuthorizationCodes";

	public static final String PRIOR_AUTHORIZATION_TYPE = "priorAuthorizationType";

	public static final String FORMULARY_COVERAGE_METADATA_KEY = "formularyCoverageCodes";

	public static final String PREFERRED_DRUG_RULE_TIERS = "preferredDrugRuleTiers";

	public static final String BRAND_CLASS_METADATA_IDS = "brandClassMetadataIds";

	public static final String RULE_PRIORITY_ORDER = "rulePriorityOrder";

	public static final String RULE_HIERARCHY_LEVEL = "ruleHierarchyLevel";

	public static final String INLINE_CRITERIA_ATTRIBUTES = "inlineCriteriaAttributes";

	public static final String PRESCRIBER_COMPLEX_EXCEPTION_TYPE = "prescriberComplexExceptionType";

	public static final String PROVIDER_COMPLEX_EXCEPTION_TYPE = "providerComplexExceptionType";

	public static final String PRESCRIBER_DEFAULT_VALUES = "prescriberDefaultValues";

	public static final String PRESCRIBER_DEFAULT_KEYS = "prescriberDefaultKeys";

	public static final String PROVIDER_DEFAULT_VALUES = "providerDefaultValues";

	public static final String PROVIDER_DEFAULT_KEYS = "providerDefaultKeys";

	public static final String RULE_NAME = "ruleName";

	// create validator
	public static final String CREATE_BENEFIT_ASSIGNMENT_GROUP_REQUEST = "createBenefitAssignmentGroupRequest";

	public static final String STATUS_ID = "statusId";

	public static final String RULE_HIERARCHY_ID = "ruleHierarchyId";

	public static final String RULE_TYPE = "ruleType";

	public static final String PLAN_ID = "planId";

	// update validator
	public static final String UPDATE_BENEFIT_ASSIGNMENT_GROUP_REQUEST = "updateBenefitAssignmentGroupRequest";

	public static final String RULE_PRIORITY = "rulePriority";

	public static final String EFFECTIVE_START_DATE = "effectiveStartDate";

	public static final String EFFECTIVE_END_DATE = "effectiveEndDate";
}
