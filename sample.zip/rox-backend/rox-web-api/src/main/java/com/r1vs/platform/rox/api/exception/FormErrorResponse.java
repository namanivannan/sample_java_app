package com.r1vs.platform.rox.api.exception;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class FormErrorResponse {

	@JsonProperty("errors")
	private Object rejectedValue;

	public FormErrorResponse() {

		super();
	}

	public FormErrorResponse(final Object rejectedValue) {

		this.rejectedValue = rejectedValue;
	}

	public Object getRejectedValue() {

		return rejectedValue;
	}

	public void setRejectedValue(final Object rejectedValue) {

		this.rejectedValue = rejectedValue;
	}

}
