package com.r1vs.platform.rox.common.model.types;

import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

public enum StatusType {

	ACTIVE(0, "Active"),
	DRAFT(1, "Draft"),
	INACTIVE(2, "Inactive"),
	DELETED(3, "Deleted");

	private final Integer key;

	private final String value;

	public static final KeyValueEnumHelper<StatusType, Integer, String> HELPER = KeyValueEnumHelper
			.adapt(StatusType::key, StatusType::value, StatusType.values());

	StatusType(final Integer key, final String value) {

		this.value = value;
		this.key = key;
	}

	public Integer key() {

		return this.key;
	}

	public String value() {

		return this.value;
	}

	/**
	 * Get a map of status .
	 *
	 * @return statusTypeMap
	 */
	public static Map<Integer, String> getStatusTypeMap() {

		return Arrays.stream(StatusType.values()).collect(Collectors.toMap(StatusType::key, StatusType::value));

	}

	/**
	 * Get a map of status with String keys.
	 *
	 * @return statusTypeMap
	 */
	public static Map<String, String> getStatusTypeWitStringKeysMap() {

		return Arrays.stream(StatusType.values()).collect(
				Collectors.toMap((StatusType statusType) -> String.valueOf(statusType.key()), StatusType::value));

	}

	/**
	 * Iterate over the statusType enum and check if the status type exists
	 *
	 * @param statusTypeValue status type value
	 * @return formularyType
	 */
	public static StatusType getStatusType(final String statusTypeValue) {

		for (final StatusType statusType : StatusType.values()) {
			if (statusType.value().equalsIgnoreCase(statusTypeValue)) {
				return statusType;
			}
		}
		throw new IllegalArgumentException("Invalid Status Type.");
	}
}
