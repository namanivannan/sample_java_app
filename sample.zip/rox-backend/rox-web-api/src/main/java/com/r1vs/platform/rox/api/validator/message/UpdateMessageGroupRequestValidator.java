package com.r1vs.platform.rox.api.validator.message;

import com.r1vs.platform.rox.api.exception.Error;
import com.r1vs.platform.rox.api.model.message.UpdateMessageGroupRequest;
import com.r1vs.platform.rox.api.service.messagetemplate.MessageTemplateApiService;
import com.r1vs.platform.rox.api.validator.RoxWriteWebApiValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static com.r1vs.platform.rox.api.util.ValidationUtil.handleException;

@Component
public class UpdateMessageGroupRequestValidator extends MessageGroupRequestValidator
		implements RoxWriteWebApiValidator<UpdateMessageGroupRequest> {

	@Autowired
	private MessageTemplateApiService messageTemplateApiService;

	@Override
	public void validate(final UpdateMessageGroupRequest updateMessageGroupRequest) {

		final Error error = new Error();
		validateMessageGroupNameForUpdate(error, updateMessageGroupRequest, getClientIdForRequest());
		validatePrivacyLevel(error, updateMessageGroupRequest.getPrivacyLevel());
		validatePrivacySetting(error, updateMessageGroupRequest.getPrivacySetting());
		validateStatusCode(error, updateMessageGroupRequest.getStatusId());
		validateMessageGroupDescription(error, updateMessageGroupRequest.getMessageGroupDescription());
		validateMessageGroupAssociation(error, updateMessageGroupRequest.getMessages());

		handleException(error);
	}
}
