package com.r1vs.platform.rox.api.model.member;

import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.time.LocalDate;

public class MemberSearchRequestDTO implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 2043299870038792800L;

	private String firstName;

	private String lastName;

	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
	private LocalDate dateOfBirth;

	private String cardholderId;

	private Boolean status = true;

	private Integer groupId;

	private Integer accountId;

	private Integer carrierId;

	private Integer sponsorId;

	private String planExternalId;

	private String planName;

	private String benefitCoverageCode;

	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
	private LocalDate coverageStartDate;

	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
	private LocalDate coverageEndDate;

	private String cardholderFirstName;

	private String cardholderLastName;

	private String memberCity;

	private String memberState;

	private String memberZip;

	public String getFirstName() {

		return firstName;
	}

	public void setFirstName(final String firstName) {

		this.firstName = firstName;
	}

	public String getLastName() {

		return lastName;
	}

	public void setLastName(final String lastName) {

		this.lastName = lastName;
	}

	public LocalDate getDateOfBirth() {

		return dateOfBirth;
	}

	public void setDateOfBirth(final LocalDate dateOfBirth) {

		this.dateOfBirth = dateOfBirth;
	}

	public String getCardholderId() {

		return cardholderId;
	}

	public void setCardholderId(final String cardHolderId) {

		this.cardholderId = cardHolderId;
	}

	public Boolean getStatus() {

		return status;
	}

	public void setStatus(final Boolean status) {

		this.status = status;
	}

	public Integer getGroupId() {

		return groupId;
	}

	public void setGroupId(final Integer groupdId) {

		this.groupId = groupdId;
	}

	public Integer getAccountId() {

		return accountId;
	}

	public void setAccountId(final Integer accountId) {

		this.accountId = accountId;
	}

	public Integer getCarrierId() {

		return carrierId;
	}

	public void setCarrierId(final Integer carrierdId) {

		this.carrierId = carrierdId;
	}

	public Integer getSponsorId() {

		return sponsorId;
	}

	public void setSponsorId(final Integer sponsorId) {

		this.sponsorId = sponsorId;
	}

	public String getPlanExternalId() {

		return planExternalId;
	}

	public void setPlanExternalId(final String planExternalId) {

		this.planExternalId = planExternalId;
	}

	public String getPlanName() {

		return planName;
	}

	public void setPlanName(final String planName) {

		this.planName = planName;
	}

	public String getBenefitCoverageCode() {

		return benefitCoverageCode;
	}

	public void setBenefitCoverageCode(final String benefitCoverageCode) {

		this.benefitCoverageCode = benefitCoverageCode;
	}

	public LocalDate getCoverageStartDate() {

		return coverageStartDate;
	}

	public void setCoverageStartDate(final LocalDate coverageStartDate) {

		this.coverageStartDate = coverageStartDate;
	}

	public LocalDate getCoverageEndDate() {

		return coverageEndDate;
	}

	public void setCoverageEndDate(final LocalDate coverateEndDate) {

		this.coverageEndDate = coverateEndDate;
	}

	public String getCardholderFirstName() {

		return cardholderFirstName;
	}

	public void setCardholderFirstName(final String cardHolderFirstName) {

		this.cardholderFirstName = cardHolderFirstName;
	}

	public String getCardholderLastName() {

		return cardholderLastName;
	}

	public void setCardholderLastName(final String cardHolderLastName) {

		this.cardholderLastName = cardHolderLastName;
	}

	public String getMemberCity() {

		return memberCity;
	}

	public void setMemberCity(final String memberCity) {

		this.memberCity = memberCity;
	}

	public String getMemberState() {

		return memberState;
	}

	public void setMemberState(final String memberState) {

		this.memberState = memberState;
	}

	public String getMemberZip() {

		return memberZip;
	}

	public void setMemberZip(final String memberZip) {

		this.memberZip = memberZip;
	}

	@Override
	public String toString() {

		return "MemberSearchRequestDTO [firstName=" + firstName + ", lastName=" + lastName + ", dateOfBirth="
				+ dateOfBirth + ", cardholderId=" + cardholderId + ", status=" + status + ", groupId=" + groupId
				+ ", accountId=" + accountId + ", carrierId=" + carrierId + ", sponsorId=" + sponsorId
				+ ", planExternalId=" + planExternalId + ", planName=" + planName + ", benefitCoverageCode="
				+ benefitCoverageCode + ", coverageStartDate=" + coverageStartDate + ", coverageEndDate="
				+ coverageEndDate + ", cardholderFirstName=" + cardholderFirstName + ", cardholderLastName="
				+ cardholderLastName + ", memberCity=" + memberCity + ", memberState=" + memberState + ", memberZip="
				+ memberZip + "]";
	}

}
