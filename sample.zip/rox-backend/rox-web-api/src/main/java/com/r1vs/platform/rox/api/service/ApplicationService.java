package com.r1vs.platform.rox.api.service;

import com.r1vs.platform.rox.api.exception.RoxApiException;
import com.r1vs.platform.rox.api.model.application.ApplicationSearchRequestDTO;
import com.r1vs.platform.rox.api.model.application.initiate.*;
import com.r1vs.platform.rox.common.db.repository.business.*;
import com.r1vs.platform.rox.common.model.business.*;
import com.r1vs.platform.rox.common.model.business.storage.RoxFile;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static java.util.Objects.nonNull;

@Service
public class ApplicationService {

	public static final List<String> FINAL_STATUSES = List.of("Cancelled", "Approved", "Declined");

	private static final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

	private static final Logger LOGGER = LoggerFactory.getLogger(ApplicationService.class);

	public static final String DECLINED = "Declined";

	public static final String APPROVED = "Approved";

	public static final String NEW = "New";

	@Autowired
	private ApplicationRepository applicationRepository;

	@Autowired
	private BusinessRepository businessRepository;

	@Autowired
	private OwnerRepository ownerRepository;

	@Autowired
	private ValidationUtils validationUtils;

	@Autowired
	private ApplicationStatusRepository applicationStatusRepository;

	@Autowired
	private StateRepository stateRepository;

	@Autowired
	private OwnerService ownerService;

	@Autowired
	private MapperService mapperService;

	@Autowired
	private ModelMapper modelMapper;

	@Transactional
	public ApplicationDTO createApplication(String clientId, ApplicationDTO applicationDTO) {

		Client clientById = validationUtils.requireClient(clientId);

		LOGGER.error("Client found with client: {}", clientById);
		Application newApplication = generateNewApplication();
		newApplication.setClient(clientById);
		newApplication.setContractAmount(applicationDTO.getBusiness().getContractAmount());
		applicationRepository.save(newApplication);

		Business businessFromApplication = mapperService.getEntityFromDTO(applicationDTO.getBusiness(),
				BusinessCategory.BUSINESS);
		businessFromApplication.setApplication(newApplication);
		businessRepository.save(businessFromApplication);

		if (applicationDTO.getDebtor() != null) {
			Business debtorFromApplication = mapperService.getEntityFromDTO(applicationDTO.getDebtor(),
					BusinessCategory.DEBTOR);
			debtorFromApplication.setApplication(newApplication);
			businessRepository.save(debtorFromApplication);
		}

		for (OwnerDTO ownerDTO : applicationDTO.getOwners()) {
			Owner ownerFromApp = ownerService.getNewOwnerFromDTO(ownerDTO, Long.valueOf(clientId), newApplication);
			ownerRepository.save(ownerFromApp);
		}

		return mapperService.getDtoFromEntity(newApplication);
	}

	/**
	 * Generates a new Application with correspondent Ids and initial Status
	 *
	 * @return newly generated Application
	 */
	private Application generateNewApplication() {

		Application newApplication = new Application();
		newApplication.setUuid(UUID.randomUUID());

		newApplication.setStatus(applicationStatusRepository.getById(0));
		newApplication.setState(stateRepository.getById(0));

		return newApplication;
	}

	public ApplicationDTO changeStatus(ApplicationStatusChangeDTO applicationStatusChangeDTO, UUID id,
			String clientId) {

		ApplicationStatus newStatus =
				applicationStatusRepository.getStatusByName(applicationStatusChangeDTO.getStatus());
		if (null == newStatus) {
			throw new RoxApiException(String.format("Status %s not found", applicationStatusChangeDTO.getStatus()),
					HttpStatus.BAD_REQUEST);
		}
		Client client = validationUtils.requireClient(clientId);
		Application application = validationUtils.requireApplication(id, client);

		if (!isApplicationStatusAbleToUpdate(application, newStatus)) {
			throw new RoxApiException(
					String.format("Application in status %s is not able to set its status as %s",
							application.getStatus().getStatus(), newStatus.getStatus()),
					HttpStatus.BAD_REQUEST);
		}

		application.setStatus(newStatus);

		updateStateIfApplies(newStatus, application);

		return mapperService.getDtoFromEntity(applicationRepository.save(application));
	}

	/**
	 * Checks rules if the Application status is able to be updated, returns if it is updateable.
	 * 
	 * @param application Application to be updated
	 * @param newStatus New Status to apply
	 * @return true if the Status is able to be updated
	 */
	private boolean isApplicationStatusAbleToUpdate(Application application, ApplicationStatus newStatus) {

		String currentStatusName = application.getStatus().getStatus();

		// Declined applications shouldn't be status updated anymore
		if (DECLINED.equalsIgnoreCase(currentStatusName)) {
			return false;

			// Approved applications cannot go back to New
		} else if (APPROVED.equalsIgnoreCase(currentStatusName)) {
			if (NEW.equalsIgnoreCase(newStatus.getStatus())) {
				return false;
			}
		}
		return true;
	}

	private void updateStateIfApplies(ApplicationStatus newStatus, Application application) {

		if (FINAL_STATUSES.contains(newStatus.getStatus())) {
			application.setState(stateRepository.getStateByName("Completed"));
			application.setCompletedAt(OffsetDateTime.now());
		}
	}

	public Page<MinimalApplicationDTO> getApplications(String clientId, ApplicationSearchRequestDTO searchRequestDTO,
			Pageable pageable) {

		Client client = validationUtils.requireClient(clientId);
		Specification<Application> specification = getQueryForSearchingApplications(clientId, searchRequestDTO);
		Page<MinimalApplicationDTO> results = applicationRepository.findAll(specification, pageable)
				.map(application -> mapperService.getMinimalDtoFromEntity(application));

		return results;
	}

	public ApplicationDTO getApplication(UUID applicationId, String clientId) {

		Client client = validationUtils.requireClient(clientId);
		Application applicationEntity = validationUtils.requireApplication(applicationId, client);
		return mapperService.getDtoFromEntity(applicationEntity);
	}

	public Specification<Application> getQueryForSearchingApplications(String clientId,
			ApplicationSearchRequestDTO searchRequest) {

		return new Specification<Application>() {

			@Override
			public Predicate toPredicate(Root<Application> applicationRoot, CriteriaQuery<?> query,
					CriteriaBuilder criteriaBuilder) {

				String businessName = null;
				String creationDate = null;
				String status = null;
				if (nonNull(searchRequest)) {
					businessName = searchRequest.getBusinessName();
					creationDate = searchRequest.getCreationDate();
					status = searchRequest.getStatus();
				}

				List<Predicate> predicateList = new ArrayList<>();

				// clientId always required and provided
				predicateList
						.add(criteriaBuilder.equal(applicationRoot.get(Application_.CLIENT), Long.parseLong(clientId)));

				if (nonNull(businessName)) {
					Root<Business> businessRoot = query.from(Business.class);
					Predicate businessNameLike =
							criteriaBuilder.like(businessRoot.get(Business_.name), "%" + businessName + "%");
					Predicate businessNameIdEqualsAppId = criteriaBuilder.equal(
							businessRoot.get(Business_.APPLICATION), applicationRoot.get(Application_.ID));
					Predicate businessIsBusinessNotDebtor =
							criteriaBuilder.equal(businessRoot.get(Business_.categoryId), BusinessCategory.BUSINESS);
					predicateList.add(businessNameLike);
					predicateList.add(businessNameIdEqualsAppId);
					predicateList.add(businessIsBusinessNotDebtor);
				}

				if (nonNull(creationDate)) {

					LocalDate creationDateLowerBound = LocalDate.parse(creationDate, dateTimeFormatter);
					OffsetDateTime lowerBound =
							OffsetDateTime.of(creationDateLowerBound, LocalTime.MIN, ZoneOffset.UTC);
					// TODO remove next day and use LocalTimeMAx
					LocalDate creationDateUpperBound = creationDateLowerBound.plusDays(1);
					OffsetDateTime upperBound =
							OffsetDateTime.of(creationDateUpperBound, LocalTime.MIN, ZoneOffset.UTC);

					Predicate creationDateGreaterThan = criteriaBuilder
							.greaterThanOrEqualTo(applicationRoot.get(Application_.createdAt.getName()), lowerBound);
					Predicate creationDateLowerThan =
							criteriaBuilder.lessThan(applicationRoot.get(Application_.createdAt.getName()), upperBound);
					predicateList.add(creationDateGreaterThan);
					predicateList.add(creationDateLowerThan);
				}

				if (nonNull(status)) {
					Root<Status> statusRoot = query.from(Status.class);
					Predicate appStatusEqualsStatusId = criteriaBuilder.equal(
							applicationRoot.get(Application_.STATUS), statusRoot.get(Status_.ID));
					Predicate providedStatusNameEqualsStatus = criteriaBuilder.equal(
							statusRoot.get(Status_.STATUS), status);
					predicateList.add(appStatusEqualsStatusId);
					predicateList.add(providedStatusNameEqualsStatus);
				}

				return criteriaBuilder.and(predicateList.toArray(new Predicate[predicateList.size()]));
			}

		};
	}

	public List<RoxFileWithNotesDTO> getApplicationAttachments(UUID applicationId, String clientId) {

		Client client = validationUtils.requireClient(clientId);
		Application application = validationUtils.requireApplication(applicationId, client);
		List<RoxFileWithNotesDTO> responseRoxFileDTOs = new ArrayList<>();
		for (RoxFile roxFile : application.getFiles()) {
			responseRoxFileDTOs.add(modelMapper.map(roxFile, RoxFileWithNotesDTO.class));
		}
		return responseRoxFileDTOs;
	}
}
