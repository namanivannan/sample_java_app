package com.r1vs.platform.rox.common.model.business;

import com.r1vs.platform.rox.common.model.AuditedEntity;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;

@Entity
@Table(name = "email")
@EntityListeners(AuditingEntityListener.class)
public class Email extends AuditedEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@OneToOne
	@JoinColumn(name = "email_type_id", nullable = false)
	private EmailType emailType;

	@Column(name = "xref_id")
	private Long xrefId;

	@Column(name = "xref_type_id")
	private Long xrefTypeId;

	@Column(name = "description")
	private String description;

	@Column(name = "email_address")
	private String email;

	@Column(name = "is_primary")
	private Boolean isPrimary;

	public Long getId() {

		return this.id;
	}

	public void setId(Long id) {

		this.id = id;
	}

	public EmailType getEmailType() {

		return emailType;
	}

	public void setEmailType(EmailType emailType) {

		this.emailType = emailType;
	}

	public Long getXrefId() {

		return this.xrefId;
	}

	public void setXrefId(Long xrefId) {

		this.xrefId = xrefId;
	}

	public Long getXrefTypeId() {

		return this.xrefTypeId;
	}

	public void setXrefTypeId(Long xrefTypeId) {

		this.xrefTypeId = xrefTypeId;
	}

	public String getDescription() {

		return this.description;
	}

	public void setDescription(String description) {

		this.description = description;
	}

	public String getEmail() {

		return this.email;
	}

	public void setEmail(String email) {

		this.email = email;
	}

	public Boolean getIsPrimary() {

		return this.isPrimary;
	}

	public void setIsPrimary(Boolean isPrimary) {

		this.isPrimary = isPrimary;
	}
}
