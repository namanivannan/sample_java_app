package com.r1vs.platform.rox.api.util;

import com.google.common.collect.ImmutableMap;
import com.r1vs.platform.rox.common.model.types.memberenrollment.BenefitCoverageCode;
import com.r1vs.platform.rox.common.model.types.memberenrollment.RelationshipCode;

import java.util.Map;

public class BenefitCoverageUtil {

	private static Map<String, BenefitCoverageCode> subscriberOnlyCodes =
			new ImmutableMap.Builder<String, BenefitCoverageCode>()
					.put(RelationshipCode.CARDHOLDER.key(), BenefitCoverageCode.SUBSCRIBER)
					.build();

	private static Map<String, BenefitCoverageCode> subscriberAndSpouse =
			new ImmutableMap.Builder<String, BenefitCoverageCode>()
					.put(RelationshipCode.CARDHOLDER.key(), BenefitCoverageCode.SUBSCRIBER)
					.put(RelationshipCode.SPOUSE.key(), BenefitCoverageCode.SPOUSE_ONLY)
					.put(RelationshipCode.CARDHOLDER.key() + RelationshipCode.SPOUSE.key(),
							BenefitCoverageCode.SUBSCRIBER_AND_SPOUSE)
					.build();

	private static Map<String, BenefitCoverageCode> subscriberAndDependents =
			new ImmutableMap.Builder<String, BenefitCoverageCode>()
					.put(RelationshipCode.CARDHOLDER.key(), BenefitCoverageCode.SUBSCRIBER)
					.put(RelationshipCode.DEPENDENT.key(), BenefitCoverageCode.DEPENDENTS_ONLY)
					.put(RelationshipCode.OTHER.key(), BenefitCoverageCode.DEPENDENTS_ONLY)
					.put(RelationshipCode.CARDHOLDER.key() + RelationshipCode.DEPENDENT.key(),
							BenefitCoverageCode.SUBSCRIBER_AND_DEPENDENT)
					.put(RelationshipCode.CARDHOLDER.key() + RelationshipCode.OTHER.key(),
							BenefitCoverageCode.SUBSCRIBER_AND_DEPENDENT)
					.put(RelationshipCode.CARDHOLDER.key() + RelationshipCode.STUDENT.key(),
							BenefitCoverageCode.SUBSCRIBER_AND_DEPENDENT)
					.put(RelationshipCode.CARDHOLDER.key() + RelationshipCode.DISABLED_DEPENDENT.key(),
							BenefitCoverageCode.SUBSCRIBER_AND_DEPENDENT)
					.put(RelationshipCode.CARDHOLDER.key() + RelationshipCode.ADULT_DEPENDENT.key(),
							BenefitCoverageCode.SUBSCRIBER_AND_DEPENDENT)
					.put(RelationshipCode.CARDHOLDER.key() + RelationshipCode.SIGNIFICANT_OTHER.key(),
							BenefitCoverageCode.SUBSCRIBER_AND_DEPENDENT)
					.build();

	private static Map<String, BenefitCoverageCode> subscriberAndFamily =
			new ImmutableMap.Builder<String, BenefitCoverageCode>()
					.put(RelationshipCode.CARDHOLDER.key(), BenefitCoverageCode.SUBSCRIBER)
					.put(RelationshipCode.SPOUSE.key(), BenefitCoverageCode.SPOUSE_ONLY)
					.put(RelationshipCode.DEPENDENT.key(), BenefitCoverageCode.DEPENDENTS_ONLY)
					.put(RelationshipCode.CARDHOLDER.key() + RelationshipCode.DEPENDENT.key(),
							BenefitCoverageCode.SUBSCRIBER_AND_DEPENDENT)
					.put(RelationshipCode.CARDHOLDER.key() + RelationshipCode.SPOUSE.key(),
							BenefitCoverageCode.SUBSCRIBER_AND_SPOUSE)
					.put(RelationshipCode.SPOUSE.key() + RelationshipCode.DEPENDENT.key(),
							BenefitCoverageCode.SPOUSE_AND_DEPENDENT)
					.put(RelationshipCode.CARDHOLDER.key() + RelationshipCode.SPOUSE.key()
							+ RelationshipCode.DEPENDENT.key(), BenefitCoverageCode.FAMILY)
					.build();

	public static Map<String, Map<String, BenefitCoverageCode>> coverageCodes =
			new ImmutableMap.Builder<String, Map<String, BenefitCoverageCode>>()
					.put(BenefitCoverageCode.SUBSCRIBER.key(), subscriberOnlyCodes)
					.put(BenefitCoverageCode.SUBSCRIBER_AND_SPOUSE.key(), subscriberAndSpouse)
					.put(BenefitCoverageCode.SUBSCRIBER_AND_DEPENDENT.key(), subscriberAndDependents)
					.put(BenefitCoverageCode.FAMILY.key(), subscriberAndFamily)
					.build();

}
