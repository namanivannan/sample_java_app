package com.r1vs.platform.rox.common.security;

import java.nio.charset.StandardCharsets;

public class EncryptionConstants {

    public final static byte[] alreadyEncryptedPrefix = "{secret}:".getBytes(StandardCharsets.UTF_8);

}
