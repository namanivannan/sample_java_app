package com.r1vs.platform.rox.api.validator.role;

import com.r1vs.platform.rox.api.business.RoleService;
import com.r1vs.platform.rox.api.exception.Error;
import com.r1vs.platform.rox.api.model.role.RoleRequest;
import com.r1vs.platform.rox.api.model.role.UpdateRoleRequest;
import com.r1vs.platform.rox.api.util.RoleConstants;
import com.r1vs.platform.rox.common.db.service.role.AccessDomainService;
import com.r1vs.platform.rox.common.model.types.StatusType;
import com.r1vs.platform.rox.common.model.types.role.AccessType;
import com.r1vs.platform.rox.common.model.users.Role;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Locale;

import static com.r1vs.platform.rox.api.util.ValidationUtil.addError;
import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;
import static org.apache.commons.lang3.StringUtils.isBlank;

@Component
public class RoleRequestValidator {

	public static final String ALFA_NUMERIC_AND_SPACE = "^([a-zA-Z0-9]+\\s)*[a-zA-Z0-9]+$";

	@Autowired
	private RoleService roleService;

	@Autowired
	private AccessDomainService accessDomainService;

	@Autowired
	protected MessageSource messageSource;

	protected void validateStatusFlowForCreate(final Error error, final Integer statusId) {

		if (StatusType.DELETED.key().equals(statusId) || StatusType.INACTIVE.key().equals(statusId)) {
			addError(error, RoleConstants.STATUS,
					messageSource.getMessage(RoleConstants.INVALID_STATUS_FOR_CREATE, null, Locale.getDefault()),
					String.valueOf(statusId));
		}
	}

	protected void validateStatusFlowForUpdate(final Error error, final Integer roleId, final Integer statusId) {

		final Role role = roleService.getRoleByRoleId(roleId);
		if (nonNull(role)) {
			if (StatusType.DELETED.key().equals(role.getStatusId())
					|| StatusType.INACTIVE.key().equals(role.getStatusId())) {
				addError(error, RoleConstants.STATUS,
						messageSource.getMessage(RoleConstants.INVALID_STATUS_TRANSITION, null, Locale.getDefault()),
						String.valueOf(statusId));
			} else if (StatusType.ACTIVE.key() == role.getStatusId()) {
				if (StatusType.INACTIVE.key() != statusId) {
					addError(error, RoleConstants.STATUS,
							messageSource.getMessage(RoleConstants.INVALID_STATUS_TRANSITION, null,
									Locale.getDefault()),
							String.valueOf(statusId));
				}
			} else if (StatusType.DRAFT.key().equals(role.getStatusId())) {
				if (StatusType.INACTIVE.key().equals(statusId)) {
					addError(error, RoleConstants.STATUS,
							messageSource.getMessage(RoleConstants.INVALID_STATUS_TRANSITION, null,
									Locale.getDefault()),
							String.valueOf(statusId));
				}
			}
		} else {
			addError(error, RoleConstants.ROLE_ID,
					messageSource.getMessage(RoleConstants.NONEXISTENT_ROLE, null, Locale.getDefault()),
					String.valueOf(statusId));
		}
	}

	protected void validateStatusCode(final Error error, final Integer status) {

		if (!StatusType.getStatusTypeMap().containsKey(status)) {
			addError(error, RoleConstants.STATUS, messageSource.getMessage(RoleConstants.INVALID_STATUS,
					new Object[] { status }, Locale.getDefault()), String.valueOf(status));
		}
	}

	protected void validateRoleName(final Error error, final RoleRequest roleRequest) {

		if (isBlank(roleRequest.getRoleName())) {
			addError(error, RoleConstants.ROLE_NAME,
					messageSource.getMessage(RoleConstants.ROLE_NAME_IT_IS_REQUIRED,
							new Object[] { roleRequest.getRoleName() }, Locale.getDefault()),
					String.valueOf(roleRequest.getRoleName()));
		} else {
			if (!roleRequest.getRoleName().matches(ALFA_NUMERIC_AND_SPACE)) {
				addError(error, RoleConstants.ROLE_NAME,
						messageSource.getMessage(RoleConstants.INVALID_ROLE_NAME,
								new Object[] { roleRequest.getRoleName() }, Locale.getDefault()),
						roleRequest.getRoleName());
			}
		}
	}

	protected void validateRoleSystemName(final Error error, final RoleRequest roleRequest) {

		final List<Role> roleList = roleService.findBySystemName(roleRequest.getRoleSystemName());
		if (roleList.size() > 0) {
			addError(error, RoleConstants.SYSTEM_NAME,
					messageSource.getMessage(RoleConstants.SYSTEM_NAME_IS_ALREADY_IN_USE,
							new Object[] { roleRequest.getRoleSystemName() }, Locale.getDefault()),
					roleRequest.getRoleSystemName());
		}
	}

	protected void validateRoleSystemNameForUpdate(final Error error, final UpdateRoleRequest roleRequest,
			final Integer pbmId) {

		final Role role = roleService.getRoleByRoleId(roleRequest.getRoleId());

		if (isNull(role)) {
			addError(error, RoleConstants.ROLE_ID,
					messageSource.getMessage(RoleConstants.NONEXISTENT_ROLE,
							new Object[] { roleRequest.getRoleId() }, Locale.getDefault()),
					roleRequest.getRoleId().toString());
		} else {
			if (!role.getSystemName().equals(roleRequest.getRoleSystemName())) {
				validateRoleSystemName(error, roleRequest);
			}
		}
	}

	protected void validateAccessType(final Error error, final RoleRequest roleRequest) {

		final List<String> accessTypeList = AccessType.HELPER.getKeyList();
		/*
				roleRequest.getSubdomains().forEach(s -> {
					s.getAccessesRequested().forEach(a -> {
						if (!accessTypeList.contains(a.getAccess())) {
							addError(error, RoleConstants.ACCESS_NAME,
									messageSource.getMessage(RoleConstants.INVALID_ACCESS_NAME,
											new Object[] { a.getAccess() }, Locale.getDefault()),
									a.getAccess());
						}
					});
				});
		*/
	}

	public RoleService getRoleService() {

		return roleService;
	}

	public void setRoleService(final RoleService roleService) {

		this.roleService = roleService;
	}

	public AccessDomainService getAccessDomainService() {

		return accessDomainService;
	}

	public void setAccessDomainService(final AccessDomainService accessDomainService) {

		this.accessDomainService = accessDomainService;
	}

	public MessageSource getMessageSource() {

		return messageSource;
	}

	public void setMessageSource(final MessageSource messageSource) {

		this.messageSource = messageSource;
	}

}
