package com.r1vs.platform.rox.common.db.responses;

public interface DashboardAppsPerMonth {

	int getMonth();

	int getTotalApplications();
}
