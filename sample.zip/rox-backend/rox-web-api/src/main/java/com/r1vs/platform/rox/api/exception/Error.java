package com.r1vs.platform.rox.api.exception;

import java.util.ArrayList;
import java.util.List;

public class Error {

	public List<ErrorResponse> errorResponses = new ArrayList<>();

	public ErrorResponse addErrorResponse(final ErrorResponse errorResponse) {

		errorResponses.add(errorResponse);
		return errorResponse;
	}

	public List<ErrorResponse> getErrorResponses() {

		return errorResponses;
	}

}
