package com.r1vs.platform.rox.api.exception;

public class JsonFormatException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public JsonFormatException(final String message) {

		super(message);

	}
}
