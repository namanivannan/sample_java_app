package com.r1vs.platform.rox.api.model.role;

public class RoleResponse extends AccessListResponse {

	private Integer roleId;

	private String roleName;

	private String roleSystemName;

	private Integer statusId;

	private Integer pbmId;

	public Integer getRoleId() {

		return roleId;
	}

	public void setRoleId(final Integer roleId) {

		this.roleId = roleId;
	}

	public String getRoleName() {

		return roleName;
	}

	public void setRoleName(final String roleName) {

		this.roleName = roleName;
	}

	public String getRoleSystemName() {

		return roleSystemName;
	}

	public void setRoleSystemName(final String roleSystemName) {

		this.roleSystemName = roleSystemName;
	}

	public Integer getStatusId() {

		return statusId;
	}

	public void setStatusId(final Integer statusId) {

		this.statusId = statusId;
	}

	public Integer getPbmId() {

		return pbmId;
	}

	public void setPbmId(Integer pbmId) {

		this.pbmId = pbmId;
	}
}
