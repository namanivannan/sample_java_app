package com.r1vs.platform.rox.api.defaultvaluesetter.metadata;

import com.r1vs.platform.rox.api.defaultvaluesetter.RoxWriteWebApiDefaultValueSetter;
import com.r1vs.platform.rox.api.model.metadata.CreateMetadataRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class CreateMetadataDefaultValueSetter implements RoxWriteWebApiDefaultValueSetter<CreateMetadataRequest> {

	@Autowired
	private MetadataDefaultValueSetterSuplier defaultValueSetterSuplier;

	private MetadataDefaultValueSetter defaultValueSetter;

	@Override
	public void setDefaultValues(final CreateMetadataRequest createMetadataRequest) {

		defaultValueSetter = suplySetter(createMetadataRequest);
		defaultValueSetter.setDefaultValues(createMetadataRequest);
	}

	public MetadataDefaultValueSetter suplySetter(final CreateMetadataRequest createMetadataRequest) {

		return defaultValueSetterSuplier.supplyValidator(createMetadataRequest.getMetadataCategoryId());
	}

	public void setDefaultValueSetterSuplier(final MetadataDefaultValueSetterSuplier defaultValueSetterSuplier) {

		this.defaultValueSetterSuplier = defaultValueSetterSuplier;
	}

}
