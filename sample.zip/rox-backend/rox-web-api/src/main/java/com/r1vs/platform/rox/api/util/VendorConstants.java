package com.r1vs.platform.rox.api.util;

public class VendorConstants {

	public static final String INVALID_NULL = "INVALID_NULL";

	public static final String NULL = "null";

	public static final String CARD_PREFERENCES = "cardPreferences";

	public static final String SHIPPING_INFORMATION = "shippingInformation";

	public static final String NAME = "name";

	public static final String DESCRIPTION = "description";

	public static final String ID = "id";

	public static final String PBM_ID = "pbmId";

	public static final String NO_VENDOR_FOUND = "NO_VENDOR_FOUND";

	public static final String VERSION = "version";

	public static final String OPTIMISTIC_LOCKING_ERROR =
			"OPTIMISTIC_LOCKING_ERROR";

	public static final String STATUS = "status";

	public static final String DEFAULT_NUMBER_OF_CARDS = "defaultNumberOfCards";

	public static final String MAX_CARDS_PER_SUBSCRIBER = "maxCardsPerSubscriber";

	public static final String CARDS_FORMAT_OR_DESIGN = "cardsFormatOrDesign";

	public static final String CARD_CARRIER_STYLE = "cardCarrierStyle";

	public static final String CARD_PURPOSE_CODE = "cardPurposeCode";

	public static final String COVERAGE_DAYS = "coverageDays";

	public static final String NEW_MEMBER_COLLATERALS = "newMemberCollaterals";

	public static final String REPRINT_COLLATERALS = "reprintCollaterals";

	public static final String SHIPS_TO = "shipsTo";

	public static final String SHIPPING_CARRIER = "shippingCarrier";

	public static final String SHIPPING_OPTIONS = "shippingOptions";

	public static final String MEMBER_ADDRESS = "memberAddress";

	public static final String DROP_SHIP_ADDRESS = "dropShipAddress";

	public static final String INVALID_STATUS_TRANSITION = "Invalid Status Transition";

	public static final String INVALID_CARD_PURPOSE = "Invalid Card Purpose";

	public static final String INVALID_DROP_SHIP_ADDRESS = "Invalid Drop Ship Address";

	public static final String INVALID_MEMBER_ADDRESSES = "Invalid Member Addresses";

	public static final String INVALID_SHIPPING_CARRIER = "Invalid Shipping Carrier";

	public static final String INVALID_SHIPPING_OPTIONS = "Invalid Shipping Options";

	public static final String INVALID_SHIPS_TO = "Invalid ShipsTo";

	public static final String INVALID_STATE = "Invalid State";

	public static final String STATE = "state";

	public static final String STATUS_ID = "statusId";

	public static final String EQUALS = ":";

	public static final String PARTIAL_EQUALS = "::";
}
