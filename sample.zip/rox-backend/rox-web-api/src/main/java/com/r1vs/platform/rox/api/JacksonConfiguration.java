package com.r1vs.platform.rox.api;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.module.paramnames.ParameterNamesModule;
import com.r1vs.platform.rox.api.serialization.OffsetDateTimeDeserializer;
import com.r1vs.platform.rox.api.serialization.OffsetDateTimeSerializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.OffsetDateTime;

@Configuration
public class JacksonConfiguration {

	@Value("${spring.jackson.serialization.fail-on-empty-beans}")
	private boolean failOnEmptyBeans;

	@Value("${spring.jackson.deserialization.fail-on-unknown-properties}")
	private boolean failOnUnknownProperties;

	@Bean
	public ObjectMapper objectMapper() {

		final ObjectMapper mapper = new ObjectMapper()
				.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, getFailOnEmptyBeans())
				.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false)
				.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, getFailOnUnknownProperties());

		final SimpleModule customDateTimeModule = new SimpleModule();
		customDateTimeModule.addSerializer(new OffsetDateTimeSerializer());
		customDateTimeModule.addDeserializer(OffsetDateTime.class, new OffsetDateTimeDeserializer());
		mapper.registerModule(new JavaTimeModule()).registerModule(new Jdk8Module())
				.registerModule(new ParameterNamesModule()).registerModule(customDateTimeModule);

		return mapper;
	}

	public Boolean getFailOnEmptyBeans() {

		return failOnEmptyBeans;
	}

	public boolean getFailOnUnknownProperties() {

		return failOnUnknownProperties;
	}

}
