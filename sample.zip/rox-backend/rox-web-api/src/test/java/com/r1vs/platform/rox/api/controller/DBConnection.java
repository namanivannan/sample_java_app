package com.r1vs.platform.rox.api.controller;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@Component
public class DBConnection {

	private final static String API_ENDPOINT_LOGIN = "/login";

	private final static String TEST_USER = "{\"username\":\"roxadmin\",\"password\":\"4uBzZBB351V5u!\"}";

	public final static String TEST_USER_1 = "{\"username\":\"roxadmin2\",\"password\":\"4uBzZBB351V5u!\"}";

	public final static String TEST_USER_6 = "{\"username\":\"roxUser2\",\"password\":\"123456\"}";

	public final static String TEST_USER_2 = "{\"username\":\"roxadmin3\",\"password\":\"4uBzZBB351V5u!\"}";

	public final static String TEST_USER_3 = "{\"username\":\"roxadmin4\",\"password\":\"4uBzZBB351V5u!\"}";

	public final static String ADMIN = "{\"username\":\"roxsysadm\",\"password\":\"4uBzZBB351V5u!\"}";

	@Autowired
	private MockMvc mvc;

	/**
	 * login to db with user credentials and get token
	 *
	 * @return token
	 * @throws Exception
	 */
	public String loginToDb() throws Exception {

		return loginToDb(TEST_USER);
	}

	/**
	 * login to db with user credentials and get token
	 *
	 * @return token
	 * @throws Exception
	 */
	public String loginToDb(String test_user) throws Exception {

		return new JSONObject(getTokenWithUserCredentials(test_user)).getString(AUTHORIZATION);
	}

	/**
	 * perform a request to server to get a token
	 *
	 * @return token
	 * @throws Exception
	 */
	private String getTokenWithUserCredentials(final String json) throws Exception {

		return mvc
				.perform(post(API_ENDPOINT_LOGIN).contentType(MediaType.APPLICATION_JSON).content(json)
						.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk()).andReturn().getResponse().getContentAsString();

	}

}
