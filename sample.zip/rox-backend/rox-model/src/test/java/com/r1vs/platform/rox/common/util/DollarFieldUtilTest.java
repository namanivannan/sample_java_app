package com.r1vs.platform.rox.common.util;

import static org.junit.Assert.*;

import java.math.BigDecimal;

import com.r1vs.platform.rox.common.util.DollarFieldUtil;
import org.junit.Test;

public class DollarFieldUtilTest {

	@Test
	public void testConvertBigDecimalToNcpdpPositiveNumber1() {

		final String result = DollarFieldUtil.convertDecimalToNcpdpDollar(new BigDecimal("3.51"));

		assertEquals("35A", result);
	}

	@Test
	public void testConvertBigDecimalToNcpdpNegativeNumber1() {

		final String result = DollarFieldUtil.convertDecimalToNcpdpDollar(new BigDecimal("-3.51"));

		assertEquals("35J", result);
	}

	@Test
	public void testConvertBigDecimalToNcpdpPositiveNumber2() {

		final String result = DollarFieldUtil.convertDecimalToNcpdpDollar(new BigDecimal("100"));

		assertEquals("1000{", result);
	}

	@Test
	public void testConvertBigDecimalToNcpdpNegativeNumber2() {

		final String result = DollarFieldUtil.convertDecimalToNcpdpDollar(new BigDecimal("-100"));

		assertEquals("1000}", result);
	}

	@Test
	public void testConvertNcpdpToDecimalPositiveNumber1() {

		final BigDecimal result = DollarFieldUtil.convertNcpdpDollarToDecimal("351{");

		assertEquals(new BigDecimal("35.1"), result);
	}

	@Test
	public void testConvertNcpdpToDecimalPositiveNumber2() {

		final BigDecimal result = DollarFieldUtil.convertNcpdpDollarToDecimal("35A");

		assertEquals(new BigDecimal("3.51"), result);
	}

	@Test
	public void testConvertNcpdpToDecimalNegativeNumber1() {

		final BigDecimal result = DollarFieldUtil.convertNcpdpDollarToDecimal("351}");

		assertEquals(new BigDecimal("-35.1"), result);
	}

	@Test
	public void testConvertNcpdpToDecimalNegativeNumber2() {

		final BigDecimal result = DollarFieldUtil.convertNcpdpDollarToDecimal("35J");

		assertEquals(new BigDecimal("-3.51"), result);
	}

	@Test
	public void testNcpdpDollarReturnsNullWhenValueContainsPeriod() {

		final BigDecimal result = DollarFieldUtil.convertNcpdpDollarToDecimal("1.50");

		assertNull(result);
	}

	@Test
	public void testConvertBigDecimalWithManyDigitsToNcpdpPositiveNumber() {

		final String result = DollarFieldUtil.convertDecimalToNcpdpDollar(new BigDecimal("100.3456789"));

		assertEquals("1003E", result);
	}

	/**
	 * Verify truncation of digits is to two places.
	 */
	@Test
	public void testConvertBigDecimalWithManyDigitsToNcpdpNegativeNumber() {

		final String result = DollarFieldUtil.convertDecimalToNcpdpDollar(new BigDecimal("-100.3456789"));

		assertEquals("1003N", result);
	}

	/**
	 * Verify truncation of digits is to two places.
	 */
	@Test
	public void testConvertingNonOverpunchStringToOverpunchString1() {

		final String result = DollarFieldUtil.convertStringToNcpdpDollar("3.51");

		assertEquals("35A", result);
	}

	@Test
	public void testConvertingNonOverpunchStringToOverpunchString2() {

		final String result = DollarFieldUtil.convertStringToNcpdpDollar("-3.51");

		assertEquals("35J", result);
	}

	@Test
	public void testConvertingZeroToOverpunchString1() {

		final String result = DollarFieldUtil.convertStringToNcpdpDollar("0");

		assertEquals("00{", result);
	}

	@Test
	public void testConvertingZeroToOverpunchString2() {

		final String result = DollarFieldUtil.convertStringToNcpdpDollar("0.00");

		assertEquals("00{", result);
	}

	@Test
	public void testConvertingOverpunchStringToZero() {

		final BigDecimal result = DollarFieldUtil.convertNcpdpDollarToDecimal("00{");

		assertEquals(BigDecimal.ZERO, result);
	}

}
