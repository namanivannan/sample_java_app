package com.r1vs.platform.rox.api.util;

public class RuleConstants {

	public static final String RULE_PRIORITY = "rulePriority";

	// update rule validator
	public static final String UPDATE_RULE_REQUEST = "updateRuleRequest";

	public static final String STATUS_ID = "statusId";

	public static final String RULE_ID = "ruleId";

	public static final String INLINE_CRITERIA = "inlineCriteria";

	public static final String RULE_NAME = "ruleName";

	public static final String EFFECTIVE_START_DATE = "effectiveStartDate";

	public static final String EFFECTIVE_END_DATE = "effectiveEndDate";

	public static final String CRITERIA_ROW_ID = "criteriaRowId";

	public static final String PARENT_CRITERIA_ID = "parentCriteriaId";

	// create rule validator

	public static final String CREATE_RULE_REQUEST = "createRuleRequest";

	public static final String CRITERIA_ID = "criteriaId";

	public static final String CRITERIA_ATTRIBUTE_ID = "criteria.attributeId";

	public static final String CRITERIA_ATTRIBUTE_VALUE = "criteria.attributeValue";

	public static final String PARENT_CRITERIA = "parentCriteria";

	public static final String METADATA_IDS = "metadataIds";

	public static final String BCA_ID = "bcaId";

}
