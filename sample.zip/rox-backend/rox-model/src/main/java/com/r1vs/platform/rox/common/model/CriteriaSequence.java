package com.r1vs.platform.rox.common.model;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "criteria_sequence")
public class CriteriaSequence implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "criteria_sequence_id", nullable = false)
	private Long sequenceId;

	public Long getSequenceId() {

		return sequenceId;
	}

	public void setSequenceId(final Long sequenceId) {

		this.sequenceId = sequenceId;
	}

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof CriteriaSequence)) {
			return false;
		}
		final CriteriaSequence castOther = (CriteriaSequence) other;
		return new EqualsBuilder().append(sequenceId, castOther.sequenceId).isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(sequenceId).toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("sequenceId", sequenceId).toString();
	}
}
