package com.r1vs.platform.rox.common.model;

import java.io.Serializable;
import java.util.Objects;

import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * Used to host error code and message
 *
 */
public class ErrorItem implements Serializable {

	private static final long serialVersionUID = 3341842039069466895L;

	private String code;

	private String message;

	public ErrorItem() {

	}

	public ErrorItem(final String code) {

		this.code = code;
	}

	public ErrorItem(final String code, final String message) {

		this.code = code;
		this.message = message;
	}

	public String getCode() {

		return code;
	}

	public void setCode(final String code) {

		this.code = code;
	}

	public String getMessage() {

		return message;
	}

	public void setMessage(final String message) {

		this.message = message;
	}

	@Override
	public String toString() {

		final ToStringBuilder builder = new ToStringBuilder(this);
		builder.append("code", code).append("message", message);
		return builder.toString();
	}

	@Override
	public int hashCode() {

		return Objects.hash(code, message);
	}

	@Override
	public boolean equals(final Object obj) {

		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final ErrorItem other = (ErrorItem) obj;
		return Objects.equals(code, other.code) && Objects.equals(message, other.message);
	}

}
