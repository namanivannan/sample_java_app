package com.r1vs.platform.rox.api.validator.metadata;

import com.jsoniter.JsonIterator;
import com.jsoniter.any.Any;
import com.jsoniter.spi.JsonException;
import com.r1vs.platform.rox.api.exception.Error;
import com.r1vs.platform.rox.api.util.MetadataConstants;
import com.r1vs.platform.rox.api.util.ValidationUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class MetadataValidator {

	@Autowired
	private MetadataValidatorSupplier validator;

	private MetadataJsonValidator metadataJsonValidator;

	/**
	 * Validate metadata json and based on the metadata category id supply the proper validator for JSON validation
	 *
	 * @param metadataCategoryId metadataCategoryId
	 * @param json metadata json
	 * @param statusId statusId
	 */
	public void validateJson(final Integer metadataCategoryId, final String json, final Integer statusId) {

		Any any = null;

		try {
			any = JsonIterator.deserialize(json, Any.class);
		} catch (final JsonException exception) {
			final Error error = new Error();
			ValidationUtil.addErrorAndHandle(error, MetadataConstants.JSON, exception.getMessage(), json);
		}

		metadataJsonValidator = validator.supplyValidator(metadataCategoryId);

		metadataJsonValidator.validate(any, statusId);

	}

	public void setMetadataValidatorSupplier(final MetadataValidatorSupplier metadataValidatorSupplier) {

		validator = metadataValidatorSupplier;
	}

}
