package com.r1vs.platform.rox.api.processor;

import com.r1vs.platform.rox.api.model.admin.ClientSearchRequestDTO;
import com.r1vs.platform.rox.api.model.admin.ClientDTO;
import com.r1vs.platform.rox.api.service.rule.ClientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class ClientProcessor extends CommonProcessor<ClientDTO> {

	@Autowired
	private ClientService clientService;

	public ResponseEntity<List<ClientDTO>> getClients(ClientSearchRequestDTO searchRequest, Pageable pageParams) {

		Page<ClientDTO> clients = clientService.getClients(searchRequest, pageParams);
		return buildResponseAsListWithPagination(clients.getTotalElements(), clients.getNumber(),
				clients.getPageable().getPageSize(), clients.get().collect(Collectors.toList()));

	}
}
