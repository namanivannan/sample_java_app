package com.r1vs.platform.rox.common.model.types;

/**
 * Used to address RequestWrapper.pricingSubprocessResults depending on the pricing methodology used; Related to
 * PricingMethodologyType.
 *
 */
public enum PricingType {

	CLIENT("client"),
	PROVIDER("provider");

	private final String value;

	PricingType(final String value) {

		this.value = value;
	}

	public String value() {

		return this.value;
	}
}
