package com.r1vs.platform.rox.common.model.rule;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@Entity
@Table(name = "rule_hierarchy")
public class RuleHierarchy implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "level_id", nullable = false)
	private Integer levelId;

	@Column(name = "level_name", nullable = false)
	private String levelName;

	public Integer getLevelId() {

		return levelId;
	}

	public void setLevelId(final Integer levelId) {

		this.levelId = levelId;
	}

	public String getLevelName() {

		return levelName;
	}

	public void setLevelName(final String levelName) {

		this.levelName = levelName;
	}

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof RuleHierarchy)) {
			return false;
		}
		final RuleHierarchy castOther = (RuleHierarchy) other;
		return new EqualsBuilder().append(levelId, castOther.levelId).append(levelName, castOther.levelName).isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(levelId).append(levelName).toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("level_id", levelId).append("level_name", levelName).toString();
	}
}
