package com.r1vs.platform.rox.api.util;

public class RoleConstants {

	public static final String STATUS = "statusId";

	public static final String INVALID_STATUS = "INVALID_STATUS";

	public static final String INVALID_ROLE_STATUS = "INVALID_ROLE_STATUS";

	public static final String SYSTEM_NAME_IS_ALREADY_IN_USE = "SYSTEM_NAME_IS_ALREADY_IN_USE";

	public static final String SYSTEM_NAME = "roleSystemName";

	public static final String ROLE_NAME = "roleName";

	public static final String ACCESS_NAME = "accessName";

	public static final String INVALID_ACCESS_NAME = "INVALID_ACCESS_NAME";

	public static final String INVALID_ROLE_NAME = "INVALID_ROLE_NAME";

	public static final String NONEXISTENT_ROLE = "NONEXISTENT_ROLE";

	public static final String ROLE_ID = "roleId";

	public static final String INVALID_STATUS_TRANSITION = "INVALID_STATUS_TRANSITION";

	public static final String INVALID_STATUS_FOR_CREATE = "INVALID_STATUS_FOR_CREATE";

	public static final String DOMAIN_CODE = "domainCode";

	public static final String INVALID_DOMAIN_CODE = "INVALID_DOMAIN_CODE";

	public static final String ROLE_NAME_IT_IS_REQUIRED = "ROLE_NAME_IT_IS_REQUIRED";

	public static final String INVALID_ACCESS_ENTITY_FOR_DOMAIN_CODE = "INVALID_ACCESS_ENTITY_FOR_DOMAIN_CODE";
}
