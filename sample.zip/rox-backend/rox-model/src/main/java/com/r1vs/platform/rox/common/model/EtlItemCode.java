package com.r1vs.platform.rox.common.model;

public interface EtlItemCode {

}
