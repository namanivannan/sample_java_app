package com.r1vs.platform.rox.common.model.types;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import com.r1vs.platform.rox.common.db.repository.core.StateAbbreviationRepository;
import com.r1vs.platform.rox.common.model.StateAbbreviation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class StateAbbreviationType {

	@Autowired
	private StateAbbreviationRepository stateAbbreviationRepository;

	private static Map<Integer, String> stateAbbreviationMap = new HashMap<>();

	@PostConstruct
	public void init() {

		final List<StateAbbreviation> stateAbbreviations = stateAbbreviationRepository.findAll();

		stateAbbreviationMap = stateAbbreviations.stream()
				.collect(Collectors.toMap(StateAbbreviation::getId, StateAbbreviation::getStateAbbreviation));
	}

	public static Map<Integer, String> getStateAbbreviationMap() {

		return stateAbbreviationMap;
	}

	public Map<Integer, String> getStateMap() {

		return stateAbbreviationMap;
	}

	public StateAbbreviationRepository getStateAbbreviationRepository() {

		return stateAbbreviationRepository;
	}

	public void setStateAbbreviationRepository(final StateAbbreviationRepository stateAbbreviationRepository) {

		this.stateAbbreviationRepository = stateAbbreviationRepository;
	}

}
