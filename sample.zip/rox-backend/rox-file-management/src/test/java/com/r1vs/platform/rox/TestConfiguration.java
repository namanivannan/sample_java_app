package com.r1vs.platform.rox;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.data.domain.AuditorAware;

import java.util.Optional;

@SpringBootConfiguration
public class TestConfiguration {

	public TestConfiguration() {

	}

	private static final Logger LOGGER = LoggerFactory.getLogger(TestConfiguration.class);

	/**
	 * Provides a valid value for @CreatedBy and @UpdatedBy annotations
	 *
	 * @return Optional of 11L indicating the ID of the User we have in seed data for testing.
	 */
	@Bean
	public AuditorAware<Long> auditorProvider() {

		LOGGER.debug("AUDITOR AWARE CALLED");

		return () -> Optional.ofNullable(Long.valueOf(11L));
	}
}
