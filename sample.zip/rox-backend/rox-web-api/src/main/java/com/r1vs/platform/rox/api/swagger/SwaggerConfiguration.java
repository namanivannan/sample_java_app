package com.r1vs.platform.rox.api.swagger;

import com.google.common.collect.ImmutableList;
import io.swagger.v3.oas.models.ExternalDocumentation;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;

import java.util.HashSet;
import java.util.Set;

@Configuration
public class SwaggerConfiguration {

	private static final String AUTHORIZATION_KEY = "Authorization";

	private static final String BEARER_KEY = "Bearer";

	private static final String HEADER_KEY = "header";

	private static final Set<String> DEFAULT_PRODUCES_AND_CONSUMES = new HashSet<>(
			ImmutableList.of(MediaType.APPLICATION_JSON.toString()));

	@Bean
	public OpenAPI springShopOpenAPI() {

		return new OpenAPI()
				.info(new Info().title("RoxWrite API")
						.description("RoxWrite - Underwriting Automation Application")
						.version("v0.0.1")
						.license(new License().name("Private").url("https://roxwrite.com/")))
				.externalDocs(new ExternalDocumentation()
						.description("RoxWrite Site")
						.url("https://roxwrite.com/#contact"));
	}
	/*@Bean
	public Docket api() {
	
		return new Docket(DocumentationType.SWAGGER_2).select()
				.apis(Predicate.not(RequestHandlerSelectors.basePackage("org.springframework.boot")))
				.apis(Predicate.not(RequestHandlerSelectors.basePackage("org.springframework.data.rest"))).build()
				.produces(DEFAULT_PRODUCES_AND_CONSUMES).consumes(DEFAULT_PRODUCES_AND_CONSUMES)
				.securitySchemes(Collections.singletonList(apiKey())).globalOperationParameters(operationParameters());
	
	}
	
	private ApiKey apiKey() {
	
		return new ApiKey(AUTHORIZATION_KEY, BEARER_KEY, HEADER_KEY);
	}
	
	private List<Parameter> operationParameters() {
	
		final List<Parameter> headers = new ArrayList<>();
	
		headers.add(new ParameterBuilder().name("X-Client-Id").description("Client Id to use for all requests")
				.modelRef(new ModelRef("int")).parameterType("header").required(true).defaultValue("1").build());
	
		return headers;
	
	}*/
}
