package com.r1vs.platform.rox.common.model.users;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.r1vs.platform.rox.common.model.AuditedEntity;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@EntityListeners(AuditingEntityListener.class)
@IdClass(UserClientId.class)
@Table(name = "user_client")
public class UserClient extends AuditedEntity implements Serializable {

	private static final long serialVersionUID = 4127998524302659662L;

	@Id
	@Column(name = "user_id")
	private Long userId;

	@Id
	@Column(name = "client_id")
	private Integer clientId;

	public Long getUserId() {

		return userId;
	}

	public void setUserId(final Long userId) {

		this.userId = userId;
	}

	public Integer getClientId() {

		return clientId;
	}

	public void setClientId(final Integer clientId) {

		this.clientId = clientId;
	}

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof UserClient)) {
			return false;
		}
		final UserClient castOther = (UserClient) other;
		return new EqualsBuilder().append(userId, castOther.userId).append(clientId, castOther.clientId).isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(userId).append(clientId).toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("userId", userId).append("clientId", clientId).toString();
	}
}
