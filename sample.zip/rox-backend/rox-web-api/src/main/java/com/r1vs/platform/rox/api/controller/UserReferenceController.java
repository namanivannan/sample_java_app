package com.r1vs.platform.rox.api.controller;

import com.r1vs.platform.rox.api.processor.UserReferenceProcessor;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@CrossOrigin
@RestController
@RequestMapping(value = "/v1", produces = { MediaType.APPLICATION_JSON_VALUE })
@Tag(name = "Reference", description = "User Reference Service")
public class UserReferenceController {

	@Autowired
	private UserReferenceProcessor userReferenceProcessor;

	private static final Logger LOGGER = LoggerFactory.getLogger(UserReferenceController.class);

	@GetMapping(value = "/user-reference")
	@Operation(summary = "Get user references")
	public ResponseEntity<Map<String, Map<Integer, String>>> getUserReferences() {

		LOGGER.debug("Get user references");

		return new ResponseEntity<>(userReferenceProcessor.getUserReference(), HttpStatus.OK);

	}

}
