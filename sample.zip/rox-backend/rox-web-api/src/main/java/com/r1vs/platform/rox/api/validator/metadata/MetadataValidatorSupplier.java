package com.r1vs.platform.rox.api.validator.metadata;

import com.google.common.base.Supplier;
import com.r1vs.platform.rox.api.exception.Error;
import com.r1vs.platform.rox.api.exception.ErrorResponse;
import com.r1vs.platform.rox.api.util.MetadataConstants;
import com.r1vs.platform.rox.api.util.NumericValidatorUtil;
import com.r1vs.platform.rox.api.util.ValidationUtil;
import com.r1vs.platform.rox.api.validator.ValidationMessages;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

@Component
public class MetadataValidatorSupplier {

	@Autowired
	private MessageSource messageSource;

	@Autowired
	private NumericValidatorUtil numericValidatorUtil;

	private Map<Integer, Supplier<MetadataJsonValidator>> validatorSupplier;

	@PostConstruct
	public void init() {

		final Map<Integer, Supplier<MetadataJsonValidator>> validators = new HashMap<>();
		validatorSupplier = Collections.unmodifiableMap(validators);

	}

	/**
	 * Validate metadatacategoryId and return the validator
	 *
	 * @param metadataCategoryId metadataCategoryId
	 *
	 * @return validator
	 */
	public MetadataJsonValidator supplyValidator(final Integer metadataCategoryId) {

		final Supplier<MetadataJsonValidator> validator = validatorSupplier.get(metadataCategoryId);

		final Error error = new Error();

		if (validator == null) {
			error.addErrorResponse(new ErrorResponse(MetadataConstants.METADATA_CATEGORY_ID,
					ValidationMessages.INVALID_METADATA_CATEGORY_ID, metadataCategoryId));
		}

		ValidationUtil.handleException(error);

		return validator.get();
	}
}
