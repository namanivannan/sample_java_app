package com.r1vs.platform.rox.api.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ForgotPasswordResponse {

	@JsonProperty(value = "emailId")
	private String emailId;

	@JsonProperty(value = "responseMessage")
	private String responseMessage;

	public String getEmailId() {

		return emailId;
	}

	public void setEmailId(final String emailId) {

		this.emailId = emailId;
	}

	public String getResponseMessage() {

		return responseMessage;
	}

	public void setResponseMessage(final String responseMessage) {

		this.responseMessage = responseMessage;
	}

}
