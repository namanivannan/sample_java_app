package com.r1vs.platform.rox.api.util;

import com.r1vs.platform.rox.common.model.ContactDetails;
import com.r1vs.platform.rox.common.model.types.StateAbbreviationType;
import org.apache.commons.lang3.StringUtils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AddressSearchParserUtil {

	private static Pattern zipcode = Pattern.compile("(\\d{5}$)");

	// This creates a pattern that essentially ORs all the state codes together
	private static Pattern validStateCodes = Pattern
			.compile(StateAbbreviationType.getStateAbbreviationMap().values().stream().reduce(null, (result, value) -> {
				if (result == null) {
					return "(" + value + ")";
				}
				return result + "|(" + value + ")";
			}));

	private static Pattern cityEol = Pattern.compile("(, ([\\w ]*),?$)");

	/**
	 * This function takes a string that's assumed to be an address, and attempts to break it into its constituent parts
	 *
	 * Note: this *should not* be used to parse free text addresses to address components for the purpose of creating DB
	 * records! This is mainly used to attempt to break free text strings into searchable DB components and *will not*
	 * give guaranteed valid addresses! If you do want to parse free text to valid address components, take a look at a
	 * third party like MelissaData or any other CASS Certified third party solution. Accurately parsing and validating
	 * an address is hard.
	 *
	 * @param addressSearch the presumed address string
	 * @return ContactDetails with the address components
	 */
	public static ContactDetails parseSearchAddress(final String addressSearch) {

		String strippedString = addressSearch;

		final ContactDetails parsedAddress = new ContactDetails();

		if (strippedString == null) {
			return parsedAddress;
		}

		final Matcher zipMatch = zipcode.matcher(strippedString);
		if (zipMatch.find()) {
			final String zip = zipMatch.group();
			parsedAddress.setZipCode(zip);
			strippedString = StringUtils.strip(
					StringUtils.substringBefore(strippedString, zip) + StringUtils.substringAfter(strippedString, zip));
		}

		final Matcher stateMatch = validStateCodes.matcher(strippedString);
		if (stateMatch.find()) {
			final String state = stateMatch.group();
			parsedAddress.setState(state);
			strippedString = StringUtils.strip(StringUtils.substringBefore(strippedString, state)
					+ StringUtils.substringAfter(strippedString, state));
		}

		// city match needs to be done last, since the regex matches to the end of the
		// string
		final Matcher cityMatch = cityEol.matcher(strippedString);
		if (cityMatch.find()) {
			// Match 1 includes the comma and space, match 2 should be just the city
			final String citySubstring = cityMatch.group(1);
			final String city = cityMatch.group(2);
			parsedAddress.setCity(city);
			strippedString = StringUtils.substringBefore(strippedString, citySubstring);
		}

		parsedAddress.setMailingAddressLine1(strippedString);

		return parsedAddress;
	}
}
