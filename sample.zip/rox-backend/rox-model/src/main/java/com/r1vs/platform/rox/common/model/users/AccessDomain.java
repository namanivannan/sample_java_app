package com.r1vs.platform.rox.common.model.users;

import com.r1vs.platform.rox.common.model.AuditedEntity;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "access_domain")
public class AccessDomain extends AuditedEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "domain_entity_id", nullable = false)
	private Integer accessDomainId;

	@Column(name = "domain_code", nullable = false)
	private String domainCode;

	@Column(name = "domain_description", nullable = false)
	private String domainDescription;

	@Column(name = "parent_domain_code", nullable = false)
	private String parentDomainCode;

	@OneToMany(fetch = FetchType.LAZY)
	@JoinColumn(name = "domain_entity_id", referencedColumnName = "domain_entity_id", insertable = false,
			updatable = false)
	private List<AccessEntity> accessEntityList;

	public Integer getAccessDomainId() {

		return accessDomainId;
	}

	public void setAccessDomainId(Integer accessDomainId) {

		this.accessDomainId = accessDomainId;
	}

	public String getDomainCode() {

		return domainCode;
	}

	public void setDomainCode(String domainCode) {

		this.domainCode = domainCode;
	}

	public String getDomainDescription() {

		return domainDescription;
	}

	public void setDomainDescription(String domainDescription) {

		this.domainDescription = domainDescription;
	}

	public String getParentDomainCode() {

		return parentDomainCode;
	}

	public void setParentDomainCode(String parentDomainCode) {

		this.parentDomainCode = parentDomainCode;
	}

	public List<AccessEntity> getAccessEntityList() {

		return accessEntityList;
	}

	public void setAccessEntityList(List<AccessEntity> accessEntityList) {

		this.accessEntityList = accessEntityList;
	}
}
