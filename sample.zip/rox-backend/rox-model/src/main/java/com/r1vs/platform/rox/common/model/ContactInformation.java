package com.r1vs.platform.rox.common.model;

import java.util.List;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

public class ContactInformation {

	private List<ContactDetails> contactDetails;

	public List<ContactDetails> getContactDetails() {

		return contactDetails;
	}

	public void setContactDetails(final List<ContactDetails> contactDetails) {

		this.contactDetails = contactDetails;
	}

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof ContactInformation)) {
			return false;
		}
		final ContactInformation castOther = (ContactInformation) other;
		return new EqualsBuilder().append(contactDetails, castOther.contactDetails).isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(contactDetails).toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("contactDetails", contactDetails).toString();
	}

}
