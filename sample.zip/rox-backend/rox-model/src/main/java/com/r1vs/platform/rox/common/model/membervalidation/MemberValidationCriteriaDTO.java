package com.r1vs.platform.rox.common.model.membervalidation;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.r1vs.platform.rox.common.model.membervalidation.cache.MemberValidationCriteriaConditionCache;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.Objects;

/**
 * The DTO for member validation criteria.
 *
 */
public class MemberValidationCriteriaDTO implements Serializable {

	private static final long serialVersionUID = -3727336079313239624L;

	@JsonProperty(value = "id")
	private String id;

	/**
	 * One of the enum keys defined in StatusType.
	 */
	@JsonProperty(value = "status")
	private String status;

	@JsonProperty(value = "name")
	private String name;

	@JsonProperty(value = "description")
	private String description;

	/**
	 * One of the enum keys defined in MemberValidationCriteriaType
	 */
	@JsonProperty(value = "validationCriteriaType")
	private String validationCriteriaType;

	@JsonProperty(value = "criteriaConfig")
	private MemberValidationCriteriaConditionCache criteriaConfig;

	@JsonProperty(value = "createdAt")
	private OffsetDateTime createdAt;

	public String getId() {

		return id;
	}

	public void setId(final String id) {

		this.id = id;
	}

	public String getStatus() {

		return status;
	}

	public void setStatus(final String status) {

		this.status = status;
	}

	public String getName() {

		return name;
	}

	public void setName(final String name) {

		this.name = name;
	}

	public String getDescription() {

		return description;
	}

	public void setDescription(final String description) {

		this.description = description;
	}

	public String getValidationCriteriaType() {

		return validationCriteriaType;
	}

	public void setValidationCriteriaType(final String validationCriteriaType) {

		this.validationCriteriaType = validationCriteriaType;
	}

	public MemberValidationCriteriaConditionCache getCriteriaConfig() {

		return criteriaConfig;
	}

	public void setCriteriaConfig(final MemberValidationCriteriaConditionCache criteriaConfig) {

		this.criteriaConfig = criteriaConfig;
	}

	public OffsetDateTime getCreatedAt() {

		return createdAt;
	}

	public void setCreatedAt(final OffsetDateTime createdAt) {

		this.createdAt = createdAt;
	}

	@Override
	public int hashCode() {

		return Objects.hash(createdAt, criteriaConfig, description, id, name, status, validationCriteriaType);
	}

	@Override
	public boolean equals(final Object obj) {

		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final MemberValidationCriteriaDTO other = (MemberValidationCriteriaDTO) obj;
		return Objects.equals(createdAt, other.createdAt) && Objects.equals(criteriaConfig, other.criteriaConfig)
				&& Objects.equals(description, other.description) && Objects.equals(id, other.id)
				&& Objects.equals(name, other.name) && Objects.equals(status, other.status)
				&& Objects.equals(validationCriteriaType, other.validationCriteriaType);
	}

	@Override
	public String toString() {

		final ToStringBuilder builder = new ToStringBuilder(this);
		builder.append("id", id).append("status", status).append("name", name).append("description", description)
				.append("validationCriteriaType", validationCriteriaType).append("criteriaConfig", criteriaConfig)
				.append("createdAt", createdAt);
		return builder.toString();
	}

}
