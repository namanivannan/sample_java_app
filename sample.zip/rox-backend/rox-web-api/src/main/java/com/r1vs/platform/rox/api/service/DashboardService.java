package com.r1vs.platform.rox.api.service;

import com.r1vs.platform.rox.common.db.repository.business.*;
import com.r1vs.platform.rox.common.db.responses.DashboardAppsPerMonth;
import com.r1vs.platform.rox.api.util.DashboardConstants;
import com.r1vs.platform.rox.common.db.responses.DashboardTotalApplications;
import com.r1vs.platform.rox.common.model.business.Application;
import com.r1vs.platform.rox.common.model.business.Client;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.text.NumberFormat;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.Month;
import java.util.*;

@Service
public class DashboardService {

	@Autowired
	private ApplicationRepository applicationRepository;

	@Autowired
	private ValidationUtils validationUtils;

	private NumberFormat numberFormat = NumberFormat.getCurrencyInstance(Locale.US);

	public static final int MAX_MONTH = 12;

	//TODO ADD YEAR HEADER FOR FILTER
	public Map<String, Object> getPortFolioGrowth(String clientId) {

		Client client = validationUtils.requireClient(clientId);

		Map<Integer, Integer> newApplicationsPerMonth =
				getAppsPerMonth(applicationRepository.countNewApplicationsByMonth(client));
		Map<Integer, Integer> completedApplicationsPerMonth =
				getAppsPerMonth(applicationRepository.countCompletedApplicationsByMonth(client));

		List<Map> portFolioGrowthInfo =
				calculateApplicationsPerMonth(newApplicationsPerMonth, completedApplicationsPerMonth);

		Map<String, Object> portFolioGrowth = new HashMap<>();
		portFolioGrowth.put(DashboardConstants.PORTFOLIO_GROWTH, portFolioGrowthInfo);
		return portFolioGrowth;
	}

	public List<Map> calculateApplicationsPerMonth(Map<Integer, Integer> newApps, Map<Integer, Integer> completedApps) {

		List<Map> map = new ArrayList<>();
		for (int i = 1; i <= MAX_MONTH; i++) {
			Map<String, Map<String, Integer>> finalMap = new HashMap<>();
			finalMap.put(getShortForMonth(Month.of(i)), Map.ofEntries(
					Map.entry(DashboardConstants.NEW, newApps.getOrDefault(i, 0)),
					Map.entry(DashboardConstants.COMPLETED, completedApps.getOrDefault(i, 0))));
			map.add(finalMap);
		}
		return map;
	}

	public Map<Integer, Integer> getAppsPerMonth(List<DashboardAppsPerMonth> dashboardAppsPerMonths) {

		Map<Integer, Integer> map = new HashMap<>();
		for (DashboardAppsPerMonth dashboardAppsPerMonth : dashboardAppsPerMonths) {
			map.put(dashboardAppsPerMonth.getMonth(), dashboardAppsPerMonth.getTotalApplications());
		}
		return map;
	}

	public String getShortForMonth(Month month) {

		return month.toString().toLowerCase().substring(0, 3);
	}

	public Map<String, Object> getDashboardOverview(String clientId) {

		Client client = validationUtils.requireClient(clientId);
		List<DashboardTotalApplications> totalApplicationsByState =
				applicationRepository.countApplicationsByState(client);
		List<Map<String, Object>> overviewInfo = getOverviewInfo(totalApplicationsByState);

		overviewInfo.add(getAverageDuration(client));

		Map<String, Object> overview = new HashMap<>();
		overview.put(DashboardConstants.OVERVIEW, overviewInfo);
		return overview;
	}

	public List<Map<String, Object>> getOverviewInfo(List<DashboardTotalApplications> totalApplications) {

		List<Map<String, Object>> overviewInfo = new ArrayList<>();
		for (DashboardTotalApplications application : totalApplications) {

			Map<String, Object> totalAmount = new HashMap<>();
			totalAmount.put(DashboardConstants.NAME, application.getState() + " Applications");
			mapTotalAmount(totalAmount, DashboardConstants.VALUE, application.getTotalAmount());

			Map<String, Object> numberOfApplications = new HashMap<>();
			numberOfApplications.put(DashboardConstants.NAME, "No of " + application.getState() + " Applications");
			numberOfApplications.put(DashboardConstants.VALUE, application.getTotalApplications());

			overviewInfo.add(totalAmount);
			overviewInfo.add(numberOfApplications);
		}
		return overviewInfo;
	}

	public Map<String, Object> getAverageDuration(Client client) {

		Map<String, Object> duration = new HashMap<>();
		int page = 0;
		int durationCont = 0;
		int total = 0;
		Page<Application> applications;
		do {
			if (null!=client){
				applications = getPageApplicationByClient(client, page);
			}else{
				applications = getPageApplication(page);
			}
			total += applications.getNumberOfElements();
			for (Application application : applications) {
				if (null==application.getCompletedAt()){
					durationCont += Duration.between(application.getCreatedAt().toLocalDateTime(), LocalDateTime.now()).toDays();
				}else{
					durationCont += Duration.between(application.getCreatedAt().toLocalDateTime(), application.getCompletedAt()).toDays();
				}
			}
			page++;
		} while (applications.hasNext());
		if (durationCont!=0){
			durationCont/=total;
		}
		duration.put(DashboardConstants.DURATION, durationCont++);
		return duration;
	}

	//TODO Create query for duration average
	public Page<Application> getPageApplicationByClient(Client client, int page){
		return applicationRepository.getAllByClient(client, PageRequest.of(page, 100, Sort.by(Sort.Direction.ASC, "clientId")));
	}

	public Page<Application> getPageApplication(int page){
		return applicationRepository.findAll(PageRequest.of(page, 100, Sort.by(Sort.Direction.ASC, "createdAt")));
	}

	public Map<String, Object> getDashboardApplications(String clientId) {

		Client client = validationUtils.requireClient(clientId);

		List<DashboardTotalApplications> appsByStatus = applicationRepository.countApplicationsByStatus(client);
		Map<String, Object> applicationsInfo = getApplicationsInfo(appsByStatus);

		Map<String, Object> applications = new HashMap<>();
		applications.put(DashboardConstants.APPLICATIONS, applicationsInfo);
		return applications;
	}

	public Map<String, Object> getApplicationsInfo(List<DashboardTotalApplications> totalApplications) {

		Map<String, Object> applicationsInfo = new HashMap<>();

		List<Map<String, Integer>> openApplications = new ArrayList<>();
		List<Map<String, Integer>> applicationsValue = new ArrayList<>();

		for (DashboardTotalApplications totalApplicationsByStatus : totalApplications) {
			Map<String, Integer> numberOfApplications = new HashMap<>();
			Map<String, Integer> totalAmount = new HashMap<>();

			numberOfApplications.put(totalApplicationsByStatus.getStatus(),
					totalApplicationsByStatus.getTotalApplications());
			mapTotalAmount(totalAmount, totalApplicationsByStatus.getStatus(),
					totalApplicationsByStatus.getTotalAmount());

			openApplications.add(numberOfApplications);
			applicationsValue.add(totalAmount);
		}

		applicationsInfo.put(DashboardConstants.OPEN_APPLICATIONS, openApplications);
		applicationsInfo.put(DashboardConstants.APPLICATIONS_VALUE, applicationsValue);

		return applicationsInfo;
	}

	public void mapTotalAmount(Map map, String key, Integer amount) {

		if (null != amount) {
			map.put(key, amount);
		} else {
			map.put(key, 0);
		}
	}


	public Map<String, Object> getAdminPortFolioGrowth() {
		Map<Integer, Integer> newApplicationsPerMonth =
				getAppsPerMonth(applicationRepository.countNewApplicationsByMonth());
		Map<Integer, Integer> completedApplicationsPerMonth =
				getAppsPerMonth(applicationRepository.countCompletedApplicationsByMonth());

		List<Map> portFolioGrowthInfo =
				calculateApplicationsPerMonth(newApplicationsPerMonth, completedApplicationsPerMonth);

		Map<String, Object> portFolioGrowth = new HashMap<>();
		portFolioGrowth.put(DashboardConstants.PORTFOLIO_GROWTH, portFolioGrowthInfo);
		return portFolioGrowth;
	}



	public Map<String, Object> getAdminDashboardOverview() {
		List<DashboardTotalApplications> totalApplicationsByState =
				applicationRepository.countApplicationsByState();
		List<Map<String, Object>> overviewInfo = getOverviewInfo(totalApplicationsByState);

		overviewInfo.add(getAverageDuration(null));

		Map<String, Object> overview = new HashMap<>();
		overview.put(DashboardConstants.OVERVIEW, overviewInfo);
		return overview;
	}


	public Map<String, Object> getAdminDashboardApplications() {

		List<DashboardTotalApplications> appsByStatus = applicationRepository.countApplicationsByStatus();
		Map<String, Object> applicationsInfo = getApplicationsInfo(appsByStatus);

		Map<String, Object> applications = new HashMap<>();
		applications.put(DashboardConstants.APPLICATIONS, applicationsInfo);
		return applications;
	}



}
