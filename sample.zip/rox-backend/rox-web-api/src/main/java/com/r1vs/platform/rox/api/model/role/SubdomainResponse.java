package com.r1vs.platform.rox.api.model.role;

import java.util.List;

public class SubdomainResponse {

	private String domainName;

	private String domainCode;

	private List<AccessRequestedResponse> accessesRequested;

	public String getDomainName() {

		return domainName;
	}

	public void setDomainName(final String domainName) {

		this.domainName = domainName;
	}

	public String getDomainCode() {

		return domainCode;
	}

	public void setDomainCode(final String domainCode) {

		this.domainCode = domainCode;
	}

	public List<AccessRequestedResponse> getAccessesRequested() {

		return accessesRequested;
	}

	public void setAccessesRequested(final List<AccessRequestedResponse> accessesRequested) {

		this.accessesRequested = accessesRequested;
	}
}
