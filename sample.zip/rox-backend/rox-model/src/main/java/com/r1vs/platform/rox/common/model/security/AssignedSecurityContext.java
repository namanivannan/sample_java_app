package com.r1vs.platform.rox.common.model.security;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;

/**
 * This class records the privileges, roles and pbms assigned to a user.
 */
public class AssignedSecurityContext implements Serializable {

	private static final long serialVersionUID = 6666203120341323186L;

	private List<AssignedRole> roles;

	private List<AssignedPrivilege> privileges;

	private AssignedClient client;

	public List<AssignedRole> getRoles() {

		return roles;
	}

	public void setRoles(final List<AssignedRole> roles) {

		this.roles = roles;
	}

	public List<AssignedPrivilege> getPrivileges() {

		return privileges;
	}

	public void setPrivileges(final List<AssignedPrivilege> privileges) {

		this.privileges = privileges;
	}

	public AssignedClient getClient() {

		return client;
	}

	public void setClient(final AssignedClient client) {

		this.client = client;
	}

	@Override
	public int hashCode() {

		return Objects.hash(client, privileges, roles);
	}

	@Override
	public boolean equals(final Object obj) {

		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final AssignedSecurityContext other = (AssignedSecurityContext) obj;
		return Objects.equals(client, other.client) && Objects.equals(privileges, other.privileges)
				&& Objects.equals(roles, other.roles);
	}

	@Override
	public String toString() {

		return "AssignedSecurityContext [roles=" + roles + ", privileges=" + privileges + ", client=" + client + "]";
	}

}
