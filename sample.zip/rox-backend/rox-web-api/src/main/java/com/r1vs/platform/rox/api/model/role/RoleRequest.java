package com.r1vs.platform.rox.api.model.role;

public class RoleRequest {

	private String roleName;

	private String roleSystemName;

	private Integer statusId;

	public String getRoleName() {

		return roleName;
	}

	public void setRoleName(final String roleName) {

		this.roleName = roleName;
	}

	public String getRoleSystemName() {

		return roleSystemName;
	}

	public void setRoleSystemName(final String roleSystemName) {

		this.roleSystemName = roleSystemName;
	}

	public Integer getStatusId() {

		return statusId;
	}

	public void setStatusId(final Integer statusId) {

		this.statusId = statusId;
	}
}
