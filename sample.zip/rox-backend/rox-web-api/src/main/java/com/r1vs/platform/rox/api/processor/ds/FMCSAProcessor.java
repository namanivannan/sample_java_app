package com.r1vs.platform.rox.api.processor.ds;

import com.r1vs.platform.rox.api.exception.RoxApiException;
import com.r1vs.platform.rox.api.model.application.ds.InteractionResponseDTO;
import com.r1vs.platform.rox.api.model.application.ds.fcs.UCCSearchRequestDTO;
import com.r1vs.platform.rox.api.service.MapperService;
import com.r1vs.platform.rox.api.service.ValidationUtils;
import com.r1vs.platform.rox.api.service.ds.InteractionResponseService;
import com.r1vs.platform.rox.api.util.DSConstants;
import com.r1vs.platform.rox.common.db.repository.business.BusinessRepository;
import com.r1vs.platform.rox.common.db.repository.core.StateAbbreviationRepository;
import com.r1vs.platform.rox.common.db.repository.ds.InteractionResponseRepository;
import com.r1vs.platform.rox.common.model.StateAbbreviation;
import com.r1vs.platform.rox.common.model.business.*;
import com.r1vs.platform.rox.common.model.ds.InteractionResponse;
import com.r1vs.platform.rox.interaction.fcs.request.Reference;
import com.r1vs.platform.rox.interaction.fcs.request.SearchRequest;
import com.r1vs.platform.rox.interaction.fcs.response.StateInfoAndMetrics;
import com.r1vs.platform.rox.interaction.fcs.response.search.SearchInfoAndMetrics;
import com.r1vs.platform.rox.interaction.fcs.service.FCSService;
import com.r1vs.platform.rox.interaction.fmcsa.response.FMCSAQueryResultDataList;
import com.r1vs.platform.rox.interaction.fmcsa.response.FMCSAResponse;
import com.r1vs.platform.rox.interaction.fmcsa.service.FMCSAService;
import com.r1vs.platform.rox.interaction.fmcsa.utils.FMCSAConstants;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.function.Supplier;
import java.util.stream.Collectors;

@Service
public class FMCSAProcessor extends InteractionResponseService {

	private static final Logger LOGGER = LoggerFactory.getLogger(FMCSAProcessor.class);

	@Autowired
	private FMCSAService fmcsaService;

    public InteractionResponseDTO getFMCSAorPull(String clientId, UUID applicationId, String carrierType,
                                                 String codeValue) {

        Client client = validationUtils.requireClient(clientId);
        Application application = validationUtils.requireApplication(applicationId, client);
        InteractionResponse interactionResponseEntity = this.getInteractionResponse(clientId, applicationId,
                FMCSAConstants.PRODUCT_NAME, false);
        if (interactionResponseEntity == null) {
            FMCSAResponse fmcsaResponse = performFMCSASearchOperation(null, carrierType, codeValue);
            InteractionResponse interactionResponse = generateInteractionResponse(client,application, fmcsaResponse::getQueryResultData,
                    fmcsaResponse.getMetrics());
            interactionResponseRepository.save(interactionResponse);
            return mapperService.getDtoFromInteraction(interactionResponse);
        }
        return mapperService.getDtoFromInteraction(interactionResponseEntity);
    }

    public FMCSAQueryResultDataList performFMCSASearch(String fuzzyCarrierName,
                                                       String carrierType, String codeValue) {
        FMCSAResponse fmcsaResponse = performFMCSASearchOperation(fuzzyCarrierName, carrierType, codeValue);
        return fmcsaResponse.getQueryResultData();
    }
    public FMCSAResponse performFMCSASearchOperation(String fuzzyCarrierName,
                                                       String carrierType, String codeValue) {

        FMCSAResponse fmcsaResponse = fmcsaService.search(fuzzyCarrierName, carrierType, codeValue);
        LOGGER.info("fmcsaResponse {} ", fmcsaResponse);
        LOGGER.info("metrics {} ", fmcsaResponse.getMetrics());
        return fmcsaResponse;
    }


}
