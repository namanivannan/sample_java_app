package com.r1vs.platform.rox.api.interceptor;

import com.r1vs.platform.rox.api.business.UserService;
import com.r1vs.platform.rox.api.exception.AccessException;
import com.r1vs.platform.rox.api.exception.Error;
import com.r1vs.platform.rox.api.util.InterceptorConstants;
import com.r1vs.platform.rox.api.validator.ValidationMessages;
import com.r1vs.platform.rox.common.model.business.Client;
import com.r1vs.platform.rox.common.model.users.User;
import com.r1vs.platform.rox.common.util.StringUtil;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.annotation.Nullable;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.time.Clock;
import java.time.OffsetDateTime;
import java.util.Optional;

import static com.r1vs.platform.rox.api.util.InterceptorConstants.*;
import static com.r1vs.platform.rox.api.util.ValidationUtil.addError;
import static com.r1vs.platform.rox.api.util.ValidationUtil.handleException;

@Component
public class RoxWriteWebApiInterceptor implements HandlerInterceptor {

	private static final Logger LOGGER = LoggerFactory.getLogger(RoxWriteWebApiInterceptor.class);

	private final UserService userService;

	public RoxWriteWebApiInterceptor(final UserService userService) {

		this.userService = userService;
	}

	@Override
	public boolean preHandle(final HttpServletRequest request, final HttpServletResponse response, final Object handler)
			throws Exception {

		final long startTime = System.currentTimeMillis();
		LOGGER.info(LOG_REQUEST_URL_START_TIME, request.getRequestURL(), System.currentTimeMillis());
		final String userName = SecurityContextHolder.getContext().getAuthentication().getPrincipal().toString();
		if (StringUtil.isNullOrEmpty(userName)) {
			LOGGER.error("No user is logged in .");
			return false;
		}

		final Optional<User> userOptional = userService.findByUsername(userName);
		if (userOptional.isEmpty()) {
			LOGGER.error("No user found with username: {}", userName);
			return false;
		}

		final OffsetDateTime now = OffsetDateTime.now(Clock.systemUTC());

		final User user = userOptional.get();
		if (user.isActive() != null
				&& (!user.isActive())) {
			LOGGER.error("User has been disabled: {}", userName);
			throw new AccessException("User has been disabled: " + userName, HttpStatus.FORBIDDEN);
		}

		if (StringUtils.isNumeric(request.getHeader(CLIENT_ID))) {
            validateUserClientAccess(user, Long.valueOf(request.getHeader(CLIENT_ID)));
		}

		request.setAttribute(USER_ID, user.getUserId());
		request.setAttribute(START_TIME, startTime);
		return true;

	}

	/**
	 * Checks if user has clientId assigned
	 *
	 * @param user user
	 * @param clientId clientId
	 */
	private void validateUserClientAccess(final User user, final Long clientId) {
        // TODO add logic to check the role rox admin can view client users/create them
        final boolean validClient = user.isSuperuser() || user.getClient().getId().equals(clientId);
        if (!validClient) {
            LOGGER.error("User does not have access to clientId: {}", clientId);
            final Error error = new Error();
            addError(error, CLIENT_ID, ValidationMessages.INVALID_USER_CLIENT_ID, String.valueOf(clientId));
            handleException(error);
        }
	}

	@Override
	public void afterCompletion(final HttpServletRequest request, final HttpServletResponse response,
			final Object handler, @Nullable final Exception ex) throws Exception {

		final long startTime = (Long) request.getAttribute(START_TIME);
		LOGGER.info(LOG_REQUEST_URL_END_TIME, request.getRequestURL(), System.currentTimeMillis());
		LOGGER.info(LOG_REQUEST_URL_LOG_TIME_TAKEN, request.getRequestURL(),
				(System.currentTimeMillis() - startTime));
	}

}
