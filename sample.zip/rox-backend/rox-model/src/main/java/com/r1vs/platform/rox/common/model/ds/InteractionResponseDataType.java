package com.r1vs.platform.rox.common.model.ds;

public enum InteractionResponseDataType {
	JSON,
	XML
}
