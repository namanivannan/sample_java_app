package com.r1vs.platform.rox.common.model.business;

import com.r1vs.platform.rox.common.model.AuditedEntity;
import com.r1vs.platform.rox.common.model.business.storage.RoxFile;
import com.r1vs.platform.rox.common.model.notes.Notes;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

@Entity
@Table(name = "application")
@EntityListeners(AuditingEntityListener.class)
public class Application extends AuditedEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@Column(name = "uuid")
	private UUID uuid;

	@Column(name = "contract_amount")
	private Long contractAmount;

	@OneToOne
	@JoinColumn(name = "client_id", nullable = false)
	private Client client;

	@OneToOne
	@JoinColumn(name = "status_id", nullable = false)
	private ApplicationStatus status;

	@OneToOne
	@JoinColumn(name = "state_id", nullable = false)
	private State state;

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "application")
	private List<Notes> notes;

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "application")
	private List<RoxFile> files;

	@Column(name = "completed_at")
	private OffsetDateTime completedAt;

	public Long getId() {

		return this.id;
	}

	public void setId(Long id) {

		this.id = id;
	}

	public UUID getUuid() {

		return uuid;
	}

	public void setUuid(UUID uuid) {

		this.uuid = uuid;
	}

	public Client getClient() {

		return client;
	}

	public Long getContractAmount() {

		return contractAmount;
	}

	public void setContractAmount(Long contractAmount) {

		this.contractAmount = contractAmount;
	}

	public void setClient(Client client) {

		this.client = client;
	}

	public ApplicationStatus getStatus() {

		return status;
	}

	public void setStatus(ApplicationStatus status) {

		this.status = status;
	}

	public State getState() {

		return state;
	}

	public void setState(State state) {

		this.state = state;
	}

	public List<Notes> getNotes() {

		return notes;
	}

	public void setNotes(List<Notes> notes) {

		this.notes = notes;
	}

	public List<RoxFile> getFiles() {

		return files;
	}

	public void setFiles(List<RoxFile> roxFiles) {

		this.files = roxFiles;
	}

	public OffsetDateTime getCompletedAt() {

		return completedAt;
	}

	public void setCompletedAt(OffsetDateTime completedAt) {

		this.completedAt = completedAt;
	}
}
