package com.r1vs.platform.rox.common.model.users;

import java.io.Serializable;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

public class UserClientId implements Serializable {

	private static final long serialVersionUID = 1L;

	private Integer userId;

	private Integer clientId;

	public Integer getUserId() {

		return userId;
	}

	public void setUserId(final Integer userId) {

		this.userId = userId;
	}

	public Integer getPbmId() {

		return clientId;
	}

	public void setClientId(final Integer clientId) {

		this.clientId = clientId;
	}

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof UserClientId)) {
			return false;
		}
		final UserClientId castOther = (UserClientId) other;
		return new EqualsBuilder().append(userId, castOther.userId).append(clientId, castOther.clientId).isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(userId).append(clientId).toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("userId", userId).append("clientId", clientId).toString();
	}

}
