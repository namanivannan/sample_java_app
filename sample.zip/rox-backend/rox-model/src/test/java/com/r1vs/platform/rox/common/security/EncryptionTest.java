package com.r1vs.platform.rox.common.security;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.r1vs.platform.rox.common.db.repository.business.IdentificationTypeRepository;
import com.r1vs.platform.rox.common.db.repository.ds.IdentificationRepository;
import com.r1vs.platform.rox.common.model.business.Identification;
import org.apache.commons.io.IOUtils;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionTemplate;

import java.io.IOException;
import java.math.BigInteger;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(SpringRunner.class)
@SpringBootTest// required as this is in test folder.
@ActiveProfiles("test")
public class EncryptionTest {

    @Autowired
    private IdentificationRepository identificationRepository;

    @Autowired
    private IdentificationTypeRepository identificationTypeRepository;

    @Autowired
    private SessionFactory sessionFactory;

    @Autowired
    private PlatformTransactionManager transactionManager;

    private TransactionTemplate transactionTemplate;

    @Before
    public void setUp() {
        transactionTemplate = new TransactionTemplate(transactionManager);
    }

    @Test
    public void givenEntityWithEncryptedAnnotation_whenStoringToDb_thenPlainDataIsNotEncrypted() throws IOException {


        // needs to have a transaction to read the data outside with hibernate
        Long entityId = transactionTemplate.execute(status -> {
            Identification entity = new Identification();
            entity.setIdentificationType(identificationTypeRepository.findByType("EIN").get());
            entity.setIsPrimary(true);
            entity.setIdentification("1234567890"); // Ten digit to feature proof EIN and SSN that length is nine.
            identificationRepository.save(entity);
            return entity.getId();
        });


        Long savedEntityId = entityId;

        // Prep work
        Session session = sessionFactory.openSession();

        // Query
        Transaction tx = session.beginTransaction();
        SQLQuery query = session.createSQLQuery("select id,identification.identification from identification where id = :idParam");
        query.setParameter("idParam", savedEntityId);
        List<Object[]> rows = query.list();

        assertThat(rows).hasSize(1);

        Object[] uniqueResult = rows.get(0);

        assertThat(uniqueResult[0]).isEqualTo(BigInteger.valueOf(savedEntityId));
        assertThat((String) uniqueResult[1]).as("Encrypted column does not contain plaintext info").doesNotContain("1234567890"); // identification
        assertThat((String) uniqueResult[1]).as("Encrypted column has encrypted value").isEqualTo("e3NlY3JldH06AAAAB3sidiI6MX2q6Qbk52fbJgeauERPbRAg"); // identification


        // needs a transaction to get identification data
      transactionTemplate.execute(status -> {

        Identification recoveredIdentification = identificationRepository.getById(savedEntityId);
        assertThat(recoveredIdentification.getIdentification()).as("Entity read from repository contains plaintext")
                .isEqualTo("1234567890");


        return null;
      });



        session.close();
    }

    // TODO add test to verify Decryption params serializes correctly using "v" only as field name and not full to avoid
    // big encrypted values

    // TODO verify size of encrypted chunk with and without the control flags

    public String getTextFileAsString(String filePath) throws IOException {

        return IOUtils.toString(
                this.getClass().getResourceAsStream(filePath),
                "UTF-8");
    }

}
