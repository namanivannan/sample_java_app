package com.r1vs.platform.rox.api.util;

public class CriteriaConstants {

	public static final String CRITERIA_NAME = "name";

	public static final String CRITERIA_STATUS = "criteriaStatus";

	public static final String CRITERIA_DOMAINS = "criteriaDomains";

	public static final String CRITERIA_CATEGORY_ID = "criteriaCategoryId";

	public static final String CRITERIA_FORMAT_ID = "criteriaFormatId";

	public static final String STATUS = "status";

	public static final String DOMAIN = "domain";

	public static final String FORMAT = "format";

	public static final String CATEGORY = "category";

	public static final String INCLUDE_EXCLUDE = "includeExclude";

	public static final String OPERATOR = "operator";

	public static final String PAREN = "paren";

	public static final String AND_OR = "andOr";

	public static final String CLAIM = "Claim";

	public static final String DRUG = "Drug";

	public static final String PROVIDER = "Provider";

	public static final String CONDITIONS = "conditions";

	public static final String CRITERIA = "Criteria";

	public static final String EMBEDDED_CRITERIA_ID = "embeddedCriteriaId";

	public static final String MEMBER = "Member";

	public static final String CLAIMHISTORY = "Claim History";

}
