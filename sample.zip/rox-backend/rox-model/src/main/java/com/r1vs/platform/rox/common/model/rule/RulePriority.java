package com.r1vs.platform.rox.common.model.rule;

import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

public class RulePriority implements Sortable {

	@NotNull
	private Long ruleId;

	private Integer priority;

	public RulePriority() {

		super();
	}

	public RulePriority(@NotNull final Long ruleId, final Integer priority) {

		super();
		this.ruleId = ruleId;
		this.priority = priority;
	}

	public Long getRuleId() {

		return ruleId;
	}

	public void setRuleId(final Long ruleId) {

		this.ruleId = ruleId;
	}

	@Override
	public Integer getPriority() {

		return priority;
	}

	public void setPriority(final Integer priority) {

		this.priority = priority;
	}

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof RulePriority)) {
			return false;
		}
		final RulePriority castOther = (RulePriority) other;
		return new EqualsBuilder().append(ruleId, castOther.ruleId).append(priority, castOther.priority).isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(ruleId).append(priority).toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("ruleId", ruleId).append("priority", priority).toString();
	}

}
