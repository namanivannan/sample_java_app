package com.r1vs.platform.rox.api.util;

import java.math.BigDecimal;

/**
 * This interface defines commonly-used numeric limits.
 */
public interface NumericLimitConstants {

	static final BigDecimal DECIMAL_9_AND_2_NINES = new BigDecimal("999999999.99");

	static final BigDecimal DECIMAL_2_AND_2_NINES = new BigDecimal("99.99");

	static final BigDecimal DECIMAL_0 = BigDecimal.ZERO;

	static final BigDecimal DECIMAL_3_NINES = new BigDecimal("999");

	static final BigDecimal DECIMAL_3_AND_2_NINES = new BigDecimal("999.99");

}
