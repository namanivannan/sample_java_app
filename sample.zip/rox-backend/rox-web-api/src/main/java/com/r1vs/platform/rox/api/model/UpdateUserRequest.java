package com.r1vs.platform.rox.api.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.r1vs.platform.rox.api.validator.user.ValidPassword;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.validation.constraints.NotNull;
import java.time.OffsetDateTime;
import java.util.List;

public class UpdateUserRequest extends UserRequest {

	private static final long serialVersionUID = 1L;

	@NotNull
	private Long userId;

	private List<Integer> roleIds;

	@ValidPassword
	private String password;

	private Boolean isActive;

	public Long getUserId() {

		return userId;
	}

	public void setUserId(final Long userId) {

		this.userId = userId;
	}

	public List<Integer> getRoleIds() {

		return roleIds;
	}

	public void setRoleIds(final List<Integer> roleIds) {

		this.roleIds = roleIds;
	}

	public String getPassword() {

		return password;
	}

	public void setPassword(final String password) {

		this.password = password;
	}

	public Boolean isActive() {

		return isActive;
	}

	public void setisActive(final Boolean isActive) {

		this.isActive = isActive;
	}

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof UpdateUserRequest)) {
			return false;
		}
		final UpdateUserRequest castOther = (UpdateUserRequest) other;
		return new EqualsBuilder().append(userId, castOther.userId).append(roleIds, castOther.roleIds)
				.append(password, castOther.password).append(isActive, castOther.isActive).isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(userId).append(roleIds).append(password).append(isActive)
				.toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("userId", userId).append("roleIds", roleIds)
				.append("password", password).append("isActive", isActive).toString();
	}

}
