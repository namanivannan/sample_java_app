package com.r1vs.platform.rox.api.util;

public class MessageTemplateConstants {

	public static final String MESSAGE_NAME = "messageName";

	public static final String MESSAGE_NAME_ALREADY_EXISTS = "MESSAGE_NAME_ALREADY_EXISTS";

	public static final String MESSAGE_TYPE = "messageType";

	public final static String INVALID_MESSAGE_TYPE = "INVALID_MESSAGE_TYPE";

	public static final String PRIVACY_LEVEL = "privacyLevel";

	public final static String INVALID_PRIVACY_LEVEL = "INVALID_PRIVACY_LEVEL";

	public static final String PRIVACY_SETTING = "privacySetting";

	public final static String INVALID_PRIVACY_SETTING = "INVALID_PRIVACY_SETTING";

	public static final String MESSAGE_TEMPLATE_ID = "messageTemplateId";

	public final static String INVALID_MESSAGE_TEMPLATE_ID = "INVALID_MESSAGE_TEMPLATE_ID";

}
