package com.r1vs.platform.rox.api.service;

import com.r1vs.platform.rox.common.db.repository.business.ApplicationRepository;
import com.r1vs.platform.rox.common.db.repository.business.storage.RoxFileRepository;
import com.r1vs.platform.rox.common.db.repository.core.UserRepository;
import com.r1vs.platform.rox.common.model.AuditedEntity;
import com.r1vs.platform.rox.common.model.business.Application;
import com.r1vs.platform.rox.common.model.business.storage.RoxFile;
import com.r1vs.platform.rox.common.model.users.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AuditUtilsService {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private ApplicationRepository applicationRepository;

	@Autowired
	private RoxFileRepository roxFileRepository;

	/**
	 * Recover audit Users from ids set on the same Entity. This function should be used when we need to populate the
	 * User objects in audited entities before mapping to DTOs
	 * 
	 * @param entity Entity to be updated.
	 * @return same Entity, for convenience if needed.
	 */
	public AuditedEntity recoverAuditObjects(AuditedEntity entity) {

		Optional<User> createdByResult = userRepository.findById(entity.getCreatedById());
		createdByResult.ifPresent(entity::setCreatedBy);
		Optional<User> updatedByResult = userRepository.findById(entity.getUpdatedById());
		updatedByResult.ifPresent(entity::setUpdatedBy);
		return entity;
	}

	/**
	 * Updates "updatedById" and "updatedAt" fields for a given Application based on the copyFrom entity.
	 * 
	 * @param applicationEntity entity to be updated
	 * @param copyFrom entity used as reference to copy the fields from
	 */
	public void touchApplicationUpdateFields(Application applicationEntity, AuditedEntity copyFrom) {

		applicationEntity.setUpdatedById(copyFrom.getUpdatedById());
		applicationEntity.setUpdatedAt(copyFrom.getUpdatedAt());
		applicationRepository.save(applicationEntity);
	}

	/**
	 * Updates "updatedById" and "updatedAt" fields for a given File based on the copyFrom entity.
	 * 
	 * @param roxFileEntity entity to be updated
	 * @param copyFrom entity used as reference to copy the fields from
	 */
	public void touchRoxFileUpdateFields(RoxFile roxFileEntity, AuditedEntity copyFrom) {

		roxFileEntity.setUpdatedById(copyFrom.getUpdatedById());
		roxFileEntity.setUpdatedAt(copyFrom.getUpdatedAt());
		touchApplicationUpdateFields(roxFileEntity.getApplication(), copyFrom);
		roxFileRepository.save(roxFileEntity);
	}

}
