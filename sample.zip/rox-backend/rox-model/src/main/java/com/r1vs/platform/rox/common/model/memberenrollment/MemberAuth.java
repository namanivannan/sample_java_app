package com.r1vs.platform.rox.common.model.memberenrollment;

import com.r1vs.platform.rox.common.model.BitemporalEntity;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.OffsetDateTime;

@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "member_prior_auth")
public class MemberAuth extends BitemporalEntity implements Serializable {

	private static final long serialVersionUID = 12982304980L;

	@Id
	@Column(name = "member_prior_auth_id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long memberPriorAuthId;

	@Column(name = "auth_name", nullable = false)
	@NotNull
	private String authName;

	@Column(name = "pbm_id")
	private Integer pbmId;

	@Column(name = "drug_level")
	private String drugLevel;

	@Column(name = "drug_level_value")
	private String drugLevelValue;

	@Column(name = "inline_criteria")
	private Boolean inlineCriteria;

	@Column(name = "member_id", nullable = false)
	@NotNull
	private Integer memberId;

	@Column(name = "auth_type_code", nullable = false)
	@NotNull
	private String authTypeCode;

	@Column(name = "auth_level_code")
	@NotNull
	@Size(min = 1, max = 15)
	private String authLevelCode;

	@Column(name = "outcome_code")
	@NotNull
	@Size(min = 1, max = 15)
	private String outcomeCode;

	@Column(name = "outcome_reason_code")
	@Size(min = 1, max = 15)
	private String outcomeReasonCode;

	@Column(name = "auth_reason_code")
	@NotNull
	@Size(min = 1, max = 15)
	private String authReasonCode;

	@Column(name = "auth_by_info")
	@Size(min = 1, max = 150)
	private String authByInfo;

	@Column(name = "prescriber_info")
	@Size(min = 1, max = 150)
	private String prescriberInfo;

	@Column(name = "pa_tracking_number")
	@NotNull
	private String paTrackingNumber;

	@Column(name = "auto_assign_pa_tracking_number")
	@NotNull
	private Boolean autoAssignPaTrackingNumber;

	@Column(name = "external_tracking_number")
	@Size(min = 1, max = 150)
	private String externalTrackingNumber;

	@Column(name = "auth_number_of_fills")
	@Size(min = 1, max = 150)
	private String authNumberOfFills;

	@Column(name = "auth_start_date")
	@NotNull
	private LocalDate authStartDate;

	@Column(name = "auth_end_date")
	@NotNull
	private LocalDate authEndDate;

	@Column(name = "auth_priority_code")
	@Size(min = 1, max = 15)
	@NotNull
	private String authPriorityCode;

	@Column(name = "auth_request_start_date_time")
	private OffsetDateTime authRequestStartDateTime;

	@Column(name = "auth_request_end_date_time")
	private OffsetDateTime authRequestEndDateTime;

	@Column(name = "criteria_id")
	private Long criteriaId;

	@Column(name = "status_id")
	@NotNull
	private byte statusId;

	@Column(name = "comments")
	private String comments;

	@Column(name = "pa_tracking_number_on_claim_required")
	private Boolean paTrackingNumberOnClaimRequired;

	@Column(name = "provider_action")
	private String providerAction;

	@Column(name = "providers")
	private String providers;

	@Column(name = "prescriber_action")
	private String prescriberAction;

	@Column(name = "prescribers")
	private String prescribers;

	@Column(name = "change_formulary_status")
	private String changeFormularyStatus;

	@Column(name = "change_preferred_drug_status")
	private String changePreferredDrugStatus;

	@Column(name = "edits")
	private String edits;

	@Column(name = "criteria_row_id")
	private Integer criteriaRowId;

	@Column(name = "criteria")
	private String criteria;

	public String getDrugLevel() {

		return drugLevel;
	}

	public void setDrugLevel(String drugLevel) {

		this.drugLevel = drugLevel;
	}

	public String getDrugLevelValue() {

		return drugLevelValue;
	}

	public void setDrugLevelValue(String drugLevelValue) {

		this.drugLevelValue = drugLevelValue;
	}

	public Boolean getPaTrackingNumberOnClaimRequired() {

		return paTrackingNumberOnClaimRequired;
	}

	public void setPaTrackingNumberOnClaimRequired(Boolean paTrackingNumberOnClaimRequired) {

		this.paTrackingNumberOnClaimRequired = paTrackingNumberOnClaimRequired;
	}

	public Integer getPbmId() {

		return pbmId;
	}

	public void setPbmId(Integer pbmId) {

		this.pbmId = pbmId;
	}

	public Boolean getInlineCriteria() {

		return inlineCriteria;
	}

	public void setInlineCriteria(Boolean inlineCriteria) {

		this.inlineCriteria = inlineCriteria;
	}

	public Boolean getAutoAssignPaTrackingNumber() {

		return autoAssignPaTrackingNumber;
	}

	public String getProviderAction() {

		return providerAction;
	}

	public void setProviderAction(String providerAction) {

		this.providerAction = providerAction;
	}

	public String getProviders() {

		return providers;
	}

	public void setProviders(String providers) {

		this.providers = providers;
	}

	public String getPrescriberAction() {

		return prescriberAction;
	}

	public void setPrescriberAction(String prescriberAction) {

		this.prescriberAction = prescriberAction;
	}

	public String getPrescribers() {

		return prescribers;
	}

	public void setPrescribers(String prescribers) {

		this.prescribers = prescribers;
	}

	public String getChangeFormularyStatus() {

		return changeFormularyStatus;
	}

	public void setChangeFormularyStatus(String changeFormularyStatus) {

		this.changeFormularyStatus = changeFormularyStatus;
	}

	public String getChangePreferredDrugStatus() {

		return changePreferredDrugStatus;
	}

	public void setChangePreferredDrugStatus(String changePreferredDrugStatus) {

		this.changePreferredDrugStatus = changePreferredDrugStatus;
	}

	public String getEdits() {

		return edits;
	}

	public void setEdits(String edits) {

		this.edits = edits;
	}

	public Long getMemberPriorAuthId() {

		return memberPriorAuthId;
	}

	public void setMemberPriorAuthId(final Long memberPriorAuthId) {

		this.memberPriorAuthId = memberPriorAuthId;
	}

	public Integer getCriteriaRowId() {

		return criteriaRowId;
	}

	public void setCriteriaRowId(Integer criteriaRowId) {

		this.criteriaRowId = criteriaRowId;
	}

	public String getCriteria() {

		return criteria;
	}

	public void setCriteria(String criteria) {

		this.criteria = criteria;
	}

	public String getAuthName() {

		return authName;
	}

	public void setAuthName(final String authName) {

		this.authName = authName;
	}

	public Integer getMemberId() {

		return memberId;
	}

	public void setMemberId(final Integer memberId) {

		this.memberId = memberId;
	}

	public String getAuthTypeCode() {

		return authTypeCode;
	}

	public void setAuthTypeCode(final String authTypeCode) {

		this.authTypeCode = authTypeCode;
	}

	public Long getCriteriaId() {

		return criteriaId;
	}

	public void setCriteriaId(final Long criteriaId) {

		this.criteriaId = criteriaId;
	}

	public String getAuthLevelCode() {

		return authLevelCode;
	}

	public void setAuthLevelCode(final String authLevelCode) {

		this.authLevelCode = authLevelCode;
	}

	public String getOutcomeCode() {

		return outcomeCode;
	}

	public void setOutcomeCode(final String outcomeCode) {

		this.outcomeCode = outcomeCode;
	}

	public String getOutcomeReasonCode() {

		return outcomeReasonCode;
	}

	public void setOutcomeReasonCode(final String outcomeReasonCode) {

		this.outcomeReasonCode = outcomeReasonCode;
	}

	public String getAuthReasonCode() {

		return authReasonCode;
	}

	public void setAuthReasonCode(final String authReasonCode) {

		this.authReasonCode = authReasonCode;
	}

	public String getAuthByInfo() {

		return authByInfo;
	}

	public void setAuthByInfo(final String authByInfo) {

		this.authByInfo = authByInfo;
	}

	public String getPrescriberInfo() {

		return prescriberInfo;
	}

	public void setPrescriberInfo(final String prescriberInfo) {

		this.prescriberInfo = prescriberInfo;
	}

	public String getPaTrackingNumber() {

		return paTrackingNumber;
	}

	public void setPaTrackingNumber(final String paTrackingNumber) {

		this.paTrackingNumber = paTrackingNumber;
	}

	public Boolean getPaTrackingNumberRequired() {

		return autoAssignPaTrackingNumber;
	}

	public void setAutoAssignPaTrackingNumber(final Boolean autoAssignPaTrackingNumber) {

		this.autoAssignPaTrackingNumber = autoAssignPaTrackingNumber;
	}

	public String getExternalTrackingNumber() {

		return externalTrackingNumber;
	}

	public void setExternalTrackingNumber(final String externalTrackingNumber) {

		this.externalTrackingNumber = externalTrackingNumber;
	}

	public String getAuthNumberOfFills() {

		return authNumberOfFills;
	}

	public void setAuthNumberOfFills(final String authNumberOfFills) {

		this.authNumberOfFills = authNumberOfFills;
	}

	public LocalDate getAuthStartDate() {

		return authStartDate;
	}

	public void setAuthStartDate(final LocalDate authStartDate) {

		this.authStartDate = authStartDate;
	}

	public LocalDate getAuthEndDate() {

		return authEndDate;
	}

	public void setAuthEndDate(final LocalDate authEndDate) {

		this.authEndDate = authEndDate;
	}

	public String getAuthPriorityCode() {

		return authPriorityCode;
	}

	public void setAuthPriorityCode(final String authPriorityCode) {

		this.authPriorityCode = authPriorityCode;
	}

	public OffsetDateTime getAuthRequestStartDateTime() {

		return authRequestStartDateTime;
	}

	public void setAuthRequestStartDateTime(final OffsetDateTime authRequestStartDateTime) {

		this.authRequestStartDateTime = authRequestStartDateTime;
	}

	public OffsetDateTime getAuthRequestEndDateTime() {

		return authRequestEndDateTime;
	}

	public void setAuthRequestEndDateTime(final OffsetDateTime authRequestEndDateTime) {

		this.authRequestEndDateTime = authRequestEndDateTime;
	}

	public byte getStatusId() {

		return statusId;
	}

	public void setStatusId(final byte statusId) {

		this.statusId = statusId;
	}

	public String getComments() {

		return comments;
	}

	public void setComments(final String comments) {

		this.comments = comments;
	}

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof MemberAuth)) {
			return false;
		}
		final MemberAuth castOther = (MemberAuth) other;
		return new EqualsBuilder().append(memberPriorAuthId, castOther.memberPriorAuthId).isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(memberPriorAuthId).toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("memberPriorAuthId", memberPriorAuthId).toString();
	}

}
