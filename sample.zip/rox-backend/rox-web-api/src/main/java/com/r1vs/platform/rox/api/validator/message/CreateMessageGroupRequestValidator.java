package com.r1vs.platform.rox.api.validator.message;

import com.r1vs.platform.rox.api.exception.Error;
import com.r1vs.platform.rox.api.model.message.CreateMessageGroupRequest;
import com.r1vs.platform.rox.api.validator.RoxWriteWebApiValidator;
import org.springframework.stereotype.Component;

import static com.r1vs.platform.rox.api.util.ValidationUtil.handleException;

@Component
public class CreateMessageGroupRequestValidator extends MessageGroupRequestValidator
		implements RoxWriteWebApiValidator<CreateMessageGroupRequest> {

	@Override
	public void validate(final CreateMessageGroupRequest createMessageGroupRequest) {

		final Error error = new Error();

		validateMessageGroupName(error, createMessageGroupRequest.getMessageGroupName(), getClientIdForRequest());
		validatePrivacyLevel(error, createMessageGroupRequest.getPrivacyLevel());
		validatePrivacySetting(error, createMessageGroupRequest.getPrivacySetting());
		validateStatusCode(error, createMessageGroupRequest.getStatusId());
		validateStatusIdForCreateMessageGroup(error, createMessageGroupRequest);
		validateMessageGroupDescription(error, createMessageGroupRequest.getMessageGroupDescription());

		validateMessageGroupAssociation(error, createMessageGroupRequest.getMessages());

		handleException(error);
	}

}
