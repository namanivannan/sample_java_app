package com.r1vs.platform.rox.api.util;

/**
 * This class contains common constants that will be used in the benefit coverage alternative module.
 *
 */
public class BenefitCoverageAlternativeConstants {

	public static final String ERROR_WHILE_PROCESSING_FILE_HEADER = "ERROR_WHILE_PROCESSING_FILE_HEADER";

	public static final String ERROR_WHILE_PROCESSING_FILE_CONTENT = "ERROR_WHILE_PROCESSING_FILE_CONTENT";

	public static final String ERROR_WHILE_OPENING_FILE = "ERROR_WHILE_OPENING_FILE";

	public static final String ERROR_WHILE_SAVING_FILE_TO_BUCKET = "ERROR_WHILE_SAVING_FILE_TO_BUCKET";

	public static final String ERROR_WHILE_UPLOADING_FILE = "ERROR_WHILE_UPLOADING_FILE";

	public static final String ERROR_WHILE_DOWNLOADING_FILE = "ERROR_WHILE_DOWNLOADING_FILE";

	public static final String INVALID_BENEFIT_COVERAGE_NAME = "INVALID_BENEFIT_COVERAGE_NAME";

	public static final String BENEFIT_COVERAGE_NAME_ALREADY_EXISTS = "BENEFIT_COVERAGE_NAME_ALREADY_EXISTS";

	public static final String INVALID_BENEFIT_COVERAGE_MESSAGE = "INVALID_BENEFIT_COVERAGE_MESSAGE";

	public static final String ERROR_WHILE_COPYING_FILE = "ERROR_WHILE_COPYING_FILE";

	public static final String RESTRICTION_OF_CONCURRENT_BCA = "RESTRICTION_OF_CONCURRENT_BCA";

	public static final String UNKNOWN_ERROR = "UNKNOWN_ERROR";

	public static final String PBM_ID = "pbmId";

	public static final String STATUS_ID = "statusId";

	public static final String NAME = "benefitCoverageName";

	public static final String BCA_ID = "bcaId";

	public static final String EFFECTIVE_START_DATE = "effectiveStartDate";

	public static final String EFFECTIVE_END_DATE = "effectiveEndDate";

	public static final String BCA_VID = "bcaVid";

	public static final String ATTRIBUTE_CONSTANT = "attribute";

	public static final String VALUE_CONSTANT = "value";

	public static final String BENEFIT_COVERAGE_NAME = "benefitCoverageName";

	public static final String BENEFIT_COVERAGE_MESSAGE = "message";

	public static final String EQUALS = ":";

	public static final String LIKE = "::";

	public static final String GREATER_THAN = ">";

	public static final String LESS_THAN = "<";

	public static final String INVALID_STATUS = "INVALID_STATUS";

	public static final String INVALID_ID = "INVALID_ID";

	public static final String BCA_PROCESSING = "PROCESSING";

	public static final String BCA_COMPLETED = "COMPLETED";

	public static final String BCA_ERROR = "ERROR";

	public static final String ATTRIBUTE = "ATTRIBUTE";

	public static final String VALUE = "VALUE";

	public static final String BENEFIT_COVERAGE_PROVIDER = "BENEFIT_COVERAGE_PROVIDER";

	public static final String FORMULARY_PROVIDER = "FORMULARY_PROVIDER";

	public static final String PREFERRED_DRUG_PROVIDER = "PREFERRED_DRUG_PROVIDER";

	public static final String PRIOR_AUTHORIZATION_PROVIDER = "PRIOR_AUTHORIZATION_PROVIDER";

	public static final String THERAPEUTIC_ALTERNATIVE_PROVIDER = "THERAPEUTIC_ALTERNATIVE_PROVIDER";

	public static final String BENEFIT_COVERAGE_MEMBER = "BENEFIT_COVERAGE_MEMBER";

	public static final String FORMULARY_MEMBER = "FORMULARY_MEMBER";

	public static final String PREFERRED_DRUG_MEMBER = "PREFERRED_DRUG_MEMBER";

	public static final String PRIOR_AUTHORIZATION_MEMBER = "PRIOR_AUTHORIZATION_MEMBER";

	public static final String THERAPEUTIC_ALTERNATIVE_MEMBER = "THERAPEUTIC_ALTERNATIVE_MEMBER";

	public static final String BENEFIT_COVERAGE_NDC_ALTERNATIVE = "BENEFIT_COVERAGE_NDC_ALTERNATIVE";

	public static final String FORMULARY_NDC_ALTERNATIVE = "FORMULARY_NDC_ALTERNATIVE";

	public static final String PREFERRED_DRUG_NDC_ALTERNATIVE = "PREFERRED_DRUG_NDC_ALTERNATIVE";

	public static final String PRIOR_AUTHORIZATION_NDC_ALTERNATIVE = "PRIOR_AUTHORIZATION_NDC_ALTERNATIVE";

	public static final String THERAPEUTIC_ALTERNATIVE_NDC_ALTERNATIVE = "THERAPEUTIC_ALTERNATIVE_NDC_ALTERNATIVE";

}
