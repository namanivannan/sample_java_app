package com.r1vs.platform.rox.api.util;

public class MessageGroupConstants {

	public static final String MESSAGE_GROUP_NAME = "messageGroupName";

	public final static String INVALID_MESSAGE_GROUP = "INVALID_MESSAGE_GROUP";

	public final static String MESSAGE_GROUP_NAME_ALREADY_EXISTS = "MESSAGE_GROUP_NAME_ALREADY_EXISTS";

	public final static String INVALID_STATUS = "INVALID_STATUS";

	public static final String STATUS = "statusId";

	public final static String INVALID_MESSAGE_GROUP_STATUS = "INVALID_MESSAGE_GROUP_STATUS";

	public static final String PRIVACY_LEVEL = "privacyLevel";

	public final static String INVALID_PRIVACY_LEVEL = "INVALID_PRIVACY_LEVEL";

	public static final String PRIVACY_SETTING = "privacySetting";

	public final static String INVALID_PRIVACY_SETTING = "INVALID_PRIVACY_SETTING";

	public final static String INVALID_LENGTH_IN_MESSAGE_GROUP_NAME = "INVALID_LENGTH_IN_MESSAGE_GROUP_NAME";

	public final static String INVALID_LENGTH_IN_MESSAGE_GROUP_DESCRIPTION =
			"INVALID_LENGTH_IN_MESSAGE_GROUP_DESCRIPTION";

	public final static String INVALID_NUMBER_OF_MESSAGE_ASSOCIATIONS = "INVALID_NUMBER_OF_MESSAGE_ASSOCIATIONS";

	public final static String MESSAGES_IN_MESSAGE_GROUPS = "MESSAGES_IN_MESSAGE_GROUPS";

	public final static String MESSAGES_IN_MESSAGE_ARE_INVALID = "MESSAGES_IN_MESSAGE_ARE_INVALID";

	public final static String CRITERIA_MESSAGES_IN_MESSAGE_GROUP_ARE_INVALID =
			"CRITERIA_MESSAGES_IN_MESSAGE_GROUP_ARE_INVALID";

	public final static String MESSAGES_IN_MESSAGE_GROUP_DONOT_EXISTS = "MESSAGES_IN_MESSAGE_GROUP_DONOT_EXISTS";

	public final static String ERROR_MESSAGE_GROUP = "Error";

	public final static String ERROR_PROCESSING_A_MESSAGE_GROUP = "ERROR_PROCESSING_A_MESSAGE_GROUP";

	public static final String ID = "id";

	public final static String INVALID_ID = "NO_MESSAGE_GROUP_EXISTS_WITH_GIVEN_ID";

	public final static String INVALID_NUMBER_OF_MESSAGES = "INVALID_NUMBER_OF_MESSAGES";

}
