package com.r1vs.platform.rox.api.util;

public class MemberCardRequestConstants {

	public static final String ID = "id";

	public static final String REQUEST_TYPE = "requestType";

	public static final String MEMBER_ID = "memberId";

	public static final String NUMBER_OF_CARDS = "numberOfCards";

	public static final String WAIVE_FEE_REASON = "waiveFeeReasonType";

	public static final String INVALID_REQUEST_TYPE = "INVALID_REQUEST_TYPE";

	public static final String INVALID_STATUS_CARD = "INVALID_STATUS_CARD";

	public static final String INVALID_WAIVE_FEE_REASON = "INVALID_WAIVE_FEE_REASON";

	public static final String INVALID_NUMBER_OF_CARDS = "INVALID_NUMBER_OF_CARDS";

	public static final String STATUS = "status";

	public static final String INVALID_NULL = "INVALID_NULL_CARD";

	public static final String NULL = "Null";

	public static final String QUEUED = "QUED";

	public static final String CANCELLED = "CANC";

	public static final String PROCESSED = "PROC";

	public static final String MEMBER_CARD_REQUEST_NOT_FOUND =
			"MEMBER_CARD_REQUEST_NOT_FOUND";

	public static final String INVALID_STATUS_TRANSITION =
			"INVALID_STATUS_TRANSITION";

	public static final String NOT_CARD_REGISTERED =
			"NOT_CARD_REGISTERED";

	public static final String NOT_MEMBER_REGISTERED =
			"NOT_MEMBER_REGISTERED";

	public static final String QUEUED_CARD_REQUEST_ERROR_MESSAGE =
			"QUEUED_CARD_REQUEST_ERROR_MESSAGE";

	public static final String MEMBER_MISS_CARDHOLDER_ID =
			"MEMBER_MISS_CARDHOLDER_ID";

	public static final String ERROR = "error";

	public static final String SUCCESS = "success";

	public static final String MEMBER_PROFILE_NOT_FOUND = "MEMBER_PROFILE_NOT_FOUND";

	public static final String USER_PROFILE_NOT_FOUND = "USER_PROFILE_NOT_FOUND";

	public static final String EXCEPTION_MESSAGE_MEMBER_PROFILE_NOT_FOUND =
			"EXCEPTION_MESSAGE_MEMBER_PROFILE_NOT_FOUND";

	public static final String EXCEPTION_MESSAGE_MEMBER_ALIAS_NOT_FOUND =
			"EXCEPTION_MESSAGE_MEMBER_ALIAS_NOT_FOUND";

	public static final String PBM_ID = "pbmId";

	public static final String CREATE_DATE = "createDate";

	public static final String UPDATE_DATE = "updateDate";

	public static final String CARD_HOLDER_ID = "cardHolderId";

	public static final String EQUALS = ":";

	public static final String LIKE = "%%";

	public static final String VERSION = "version";

	public static final String OPTIMISTIC_LOCKING_ERROR =
			"OPTIMISTIC_LOCKING_ERROR";

	public static final String GROUP_ID =
			"groupId";

	public static final String ACCOUNT_ID =
			"accountId";

	public static final String CARRIER_ID =
			"carrierId";

	public static final String SPONSOR_ID =
			"sponsorId";

	public static final String CARD_REQUEST_REJECTED =
			"CARD_REQUEST_REJECTED";

	public static final String EXCEPTION_ON_VENDOR_MESSAGE =
			"EXCEPTION_ON_VENDOR_MESSAGE";

	public static final String CARD_REQUEST_REJECTED_FOR_N_OF_CARDS =
			"CARD_REQUEST_REJECTED_FOR_N_OF_CARDS";

	public static final String VENDOR_ID =
			"vendorId";

	public static final String NO_VENDOR_ASSOCIATED_ON_SYSTEM_HIERARCHY =
			"NO_VENDOR_ASSOCIATED_ON_SYSTEM_HIERARCHY";
}
