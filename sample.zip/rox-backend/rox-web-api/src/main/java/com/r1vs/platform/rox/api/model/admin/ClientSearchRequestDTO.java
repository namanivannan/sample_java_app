package com.r1vs.platform.rox.api.model.admin;

import java.io.Serializable;

public class ClientSearchRequestDTO implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 2043299870038792800L;

	private String creationDate;

	private String status;

	private String clientName;

	private String ownerFirstName;

	private String ownerLastName;

	private String clientCity;

	private String clientState;

	private String clientZip;

	public String getCreationDate() {

		return creationDate;
	}

	public void setCreationDate(String creationDate) {

		this.creationDate = creationDate;
	}

	public String getStatus() {

		return status;
	}

	public void setStatus(final String status) {

		this.status = status;
	}

	public String getOwnerFirstName() {

		return ownerFirstName;
	}

	public void setOwnerFirstName(String ownerFirstName) {

		this.ownerFirstName = ownerFirstName;
	}

	public String getOwnerLastName() {

		return ownerLastName;
	}

	public void setOwnerLastName(String ownerLastName) {

		this.ownerLastName = ownerLastName;
	}

	public String getClientName() {

		return clientName;
	}

	public void setClientName(String clientName) {

		this.clientName = clientName;
	}

	public String getClientCity() {

		return clientCity;
	}

	public void setClientCity(String clientCity) {

		this.clientCity = clientCity;
	}

	public String getClientState() {

		return clientState;
	}

	public void setClientState(String clientState) {

		this.clientState = clientState;
	}

	public String getClientZip() {

		return clientZip;
	}

	public void setClientZip(String clientZip) {

		this.clientZip = clientZip;
	}

	@Override
	public String toString() {

		return "ClientSearchRequestDTO{" +
				"creationDate='" + creationDate + '\'' +
				", status='" + status + '\'' +
				", clientName='" + clientName + '\'' +
				", ownerFirstName='" + ownerFirstName + '\'' +
				", ownerLastName='" + ownerLastName + '\'' +
				", clientCity='" + clientCity + '\'' +
				", clientState='" + clientState + '\'' +
				", clientZip='" + clientZip + '\'' +
				'}';
	}
}
