package com.r1vs.platform.rox.common.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "code_type")
public class CodeType extends AuditedEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "code_type_id", nullable = false)
	private Integer codeTypeId;

	@Column(name = "code_type_system_name")
	private String codeTypeSystemName;

	@Column(name = "code_type_description")
	private String codeTypeDescription;

	@OneToMany(mappedBy = "type")
	private Set<Code> codes;

	public Integer getCodeTypeId() {

		return codeTypeId;
	}

	public void setCodeTypeId(final Integer codeTypeId) {

		this.codeTypeId = codeTypeId;
	}

	public String getCodeTypeSystemName() {

		return codeTypeSystemName;
	}

	public void setCodeTypeSystemName(final String codeTypeSystemName) {

		this.codeTypeSystemName = codeTypeSystemName;
	}

	public String getCodeTypeDescription() {

		return codeTypeDescription;
	}

	public void setCodeTypeDescription(final String codeTypeDescription) {

		this.codeTypeDescription = codeTypeDescription;
	}

	public Set<Code> getCodes() {

		return codes;
	}

	public void setCodes(final Set<Code> codes) {

		this.codes = codes;
	}

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof CodeType)) {
			return false;
		}
		final CodeType castOther = (CodeType) other;
		return new EqualsBuilder().append(codeTypeId, castOther.codeTypeId)
				.append(codeTypeSystemName, castOther.codeTypeSystemName)
				.append(codeTypeDescription, castOther.codeTypeDescription).isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(codeTypeId).append(codeTypeSystemName).append(codeTypeDescription)
				.toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("codeTypeId", codeTypeId)
				.append("codeTypeSystemName", codeTypeSystemName).append("codeTypeDescription", codeTypeDescription)
				.toString();
	}

}
