package com.r1vs.platform.rox.common.util;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

public final class NcpdpParserUtil {

	public static final String FIELD_KEY = "field";

	public static final String GROUP_KEY = "group";

	public static final String SEGMENT_KEY = "segment";

	public static final String STX_KEY = "stx";

	public static final String ETX_KEY = "etx";

	public static final String FIELD_DELIMITER = "<1C>";

	public static final String GROUP_DELIMITER = "<1D>";

	public static final String SEGMENT_DELIMITER = "<1E>";

	public static final String STX_DELIMITER = "<STX>";

	public static final String ETX_DELIMITER = "<ETX>";

	public static final String FIELD_DELIMITER_UNICODE = "\u001C";

	public static final String GROUP_DELIMITER_UNICODE = "\u001D";

	public static final String SEGMENT_DELIMITER_UNICODE = "\u001E";

	public static final String STX_DELIMITER_UNICODE = "\u0002";

	public static final String ETX_DELIMITER_UNICODE = "\u0003";

	public static final String D0_VERSION = "D0";

	public static final String EMPTY_STRING = "";

	public static final Integer REQUEST_HEADER_LENGTH = 56;

	// map.get("group") = "\u001D";
	protected static final Map<String, String> CONTROL_CHARACTERS_UNICODE =
			Collections.unmodifiableMap(new HashMap<>());

	// map.get("group") = "<1D>";
	public static final Map<String, String> CONTROL_CHARACTERS_NON_UNICODE =
			Collections.unmodifiableMap(new HashMap<>());

	public static final Map<String, String> RESPONSE_SEGMENT_TO_OBJECT_MAP = new HashMap<>();

	public static final Map<String, String> TRANSACTION_SEGMENTS_MAP = new HashMap<>();

	private static final String[] TRANSACTION_SEGMENT_ARRAY = { "StatusSegment", "ClaimSegment", "PricingSegment",
			"DURPPS", "PriorAuthorizationSegment", "CoordinationBenefitsOtherPayers" };

	protected static final List<String> TRANSACTION_SEGMENTS =
			Collections.unmodifiableList(Arrays.asList(TRANSACTION_SEGMENT_ARRAY));

	static {

		CONTROL_CHARACTERS_UNICODE.put(FIELD_KEY, FIELD_DELIMITER_UNICODE);
		CONTROL_CHARACTERS_UNICODE.put(GROUP_KEY, GROUP_DELIMITER_UNICODE);
		CONTROL_CHARACTERS_UNICODE.put(SEGMENT_KEY, SEGMENT_DELIMITER_UNICODE);
		CONTROL_CHARACTERS_UNICODE.put(STX_KEY, STX_DELIMITER_UNICODE);
		CONTROL_CHARACTERS_UNICODE.put(ETX_KEY, ETX_DELIMITER_UNICODE);

		CONTROL_CHARACTERS_NON_UNICODE.put(FIELD_KEY, FIELD_DELIMITER);
		CONTROL_CHARACTERS_NON_UNICODE.put(GROUP_KEY, GROUP_DELIMITER);
		CONTROL_CHARACTERS_NON_UNICODE.put(SEGMENT_KEY, SEGMENT_DELIMITER);
		CONTROL_CHARACTERS_NON_UNICODE.put(STX_KEY, STX_DELIMITER);
		CONTROL_CHARACTERS_NON_UNICODE.put(ETX_KEY, ETX_DELIMITER);

	}

	private NcpdpParserUtil() {

	}

	public static Boolean isTransactionLoopField(final String fieldName) {

		return TRANSACTION_SEGMENTS.contains(fieldName);
	}

	/**
	 * Converts unicode control characters in string to an escaped version of the same. Basically: unicode to
	 * non-unicode.
	 *
	 * Example use case: response from switch will have characters that might be unreadable in some contexts, so if they
	 * are converted they will present uniformly in all contexts.
	 *
	 * @param sourceString source string which contains non-printable unicode characters
	 *
	 * @return string with printable ncpdp-style control characters (still might need to be java escaped/unescaped
	 *         depending on needs)
	 */
	public static String convertControlCharactersToNcpdpPrintable(final String sourceString) {

		if (sourceString == null) {
			return StringUtils.EMPTY;
		}

		return sourceString
				.replaceAll(CONTROL_CHARACTERS_UNICODE.get(SEGMENT_KEY),
						CONTROL_CHARACTERS_NON_UNICODE.get(SEGMENT_KEY))
				.replaceAll(CONTROL_CHARACTERS_UNICODE.get(GROUP_KEY), CONTROL_CHARACTERS_NON_UNICODE.get(GROUP_KEY))
				.replaceAll(CONTROL_CHARACTERS_UNICODE.get(FIELD_KEY), CONTROL_CHARACTERS_NON_UNICODE.get(FIELD_KEY))
				.replaceAll(CONTROL_CHARACTERS_UNICODE.get(STX_KEY), CONTROL_CHARACTERS_NON_UNICODE.get(STX_KEY))
				.replaceAll(CONTROL_CHARACTERS_UNICODE.get(ETX_KEY), CONTROL_CHARACTERS_NON_UNICODE.get(ETX_KEY))

		;
	}

	/**
	 * Converts non-unicode characters in string to unicode equivalents. Basically non-unicode to unicode.
	 *
	 * Example use case: claim tool and ncpdp documentation all represent control characters using angle brackets
	 * instead of their unicode equivalent to ensure that non-printing characters are seen. These must be converted back
	 * before they can be used in the switch.
	 *
	 * @param sourceString source string which contains &lt;1D&gt;, for example
	 * @return string with unicode characters in-line (still might need to be java escaped/unescaped depending on needs)
	 */
	public static String convertNcpdpPrintableCharactersToUnicode(final String sourceString) {

		return sourceString
				.replaceAll(CONTROL_CHARACTERS_NON_UNICODE.get(SEGMENT_KEY),
						CONTROL_CHARACTERS_UNICODE.get(SEGMENT_KEY))
				.replaceAll(CONTROL_CHARACTERS_NON_UNICODE.get(GROUP_KEY), CONTROL_CHARACTERS_UNICODE.get(GROUP_KEY))
				.replaceAll(CONTROL_CHARACTERS_NON_UNICODE.get(FIELD_KEY), CONTROL_CHARACTERS_UNICODE.get(FIELD_KEY))
				.replaceAll(CONTROL_CHARACTERS_NON_UNICODE.get(STX_KEY), CONTROL_CHARACTERS_UNICODE.get(STX_KEY))
				.replaceAll(CONTROL_CHARACTERS_NON_UNICODE.get(ETX_KEY), CONTROL_CHARACTERS_UNICODE.get(ETX_KEY));
	}
}
