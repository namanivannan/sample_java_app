package com.r1vs.platform.rox.api.service;

import com.r1vs.platform.rox.api.exception.RoxApiException;
import com.r1vs.platform.rox.api.model.application.initiate.OwnerDTO;
import com.r1vs.platform.rox.common.db.repository.business.*;
import com.r1vs.platform.rox.common.model.business.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class OwnerService {

	private static final Logger LOGGER = LoggerFactory.getLogger(OwnerService.class);


	@Autowired
	private ValidationUtils validationUtils;

	@Autowired
	private OwnerRepository ownerRepository;

	@Autowired
	private MapperService mapperService;

	@Autowired
	private AuditUtilsService auditUtilsService;

	private static Integer MAX_AMOUNT_OF_OWNERS;

	@Value("${roxwrite.max-amount-of-owners-per-application}")
	public void setMaxAmountOfOwners(Integer maxAmountOfOwners) {
		OwnerService.MAX_AMOUNT_OF_OWNERS = maxAmountOfOwners;
	}

	public OwnerDTO createOwner(String clientId, UUID applicationId, OwnerDTO ownerDTO) {

		Client client = validationUtils.requireClient(clientId);
		Application application = validationUtils.requireApplication(applicationId, client);
		if (ownerRepository.findOwnerByApplicationAndApplicationClient(application, client).size()==MAX_AMOUNT_OF_OWNERS){
			throw new RoxApiException("Application reached max amount of owners already", HttpStatus.BAD_REQUEST);
		}
		Owner ownerEntity = getNewOwnerFromDTO(ownerDTO, client.getId(), application);
		ownerRepository.save(ownerEntity);
		auditUtilsService.recoverAuditObjects(ownerEntity);
		auditUtilsService.touchApplicationUpdateFields(application, ownerEntity);
		return mapperService.getDtoFromEntity(ownerEntity);

	}

	/**
	 * Initializes a new Owner Entity populating UUID and Application related
	 * 
	 * @param ownerDTO Original data from clients to be used
	 * @param clientId Client Id to inject ownership
	 * @param application Application to be related with
	 * @return Owner Entity with fields initialized ready to save.
	 */
	public Owner getNewOwnerFromDTO(OwnerDTO ownerDTO, Long clientId, Application application) {

		Owner ownerEntity = mapperService.getEntityFromDTO(ownerDTO, clientId);
		ownerEntity.setUuid(UUID.randomUUID());
		LOGGER.trace("Setting {} as ownerEntity.UUID", ownerEntity.getUuid());
		ownerEntity.setApplication(application);
		return ownerEntity;
	}

	public void deleteOwner(String clientId, UUID applicationId, UUID ownerId) {

		Owner owner = validationUtils.requireOwner(clientId, applicationId, ownerId);
		ownerRepository.delete(owner);
	}

	public OwnerDTO getOwner(String clientId, UUID applicationId, UUID ownerId) {

		return mapperService.getDtoFromEntity(validationUtils.requireOwner(clientId, applicationId, ownerId));
	}

	public Page<OwnerDTO> getOwnersForApplication(String clientId, UUID applicationId, Pageable pageParams) {

		Client client = validationUtils.requireClient(clientId);
		Page<Owner> results = ownerRepository.findOwnerByApplicationAndApplicationClient(
				validationUtils.requireApplication(applicationId, client), client, pageParams);
		return results.map(entity -> mapperService.getDtoFromEntity(entity));
	}

	public OwnerDTO patchOwner(String clientId, UUID applicationId, UUID ownerId, OwnerDTO ownerDTO) {

		Owner existingOwnerEntity = validationUtils.requireOwner(clientId, applicationId, ownerId);
		Owner newOwnerData = mapperService.getEntityFromDTO(ownerDTO, Long.valueOf(clientId));
		// TODO apply allowed list of fields to patch, maybe a new DTO to simplify
		Owner ownerEntityToSave = mapperService.patchExistingData(existingOwnerEntity, newOwnerData);
		ownerRepository.save(ownerEntityToSave);
		auditUtilsService.recoverAuditObjects(ownerEntityToSave);
		auditUtilsService.touchApplicationUpdateFields(ownerEntityToSave.getApplication(), ownerEntityToSave);
		return mapperService.getDtoFromEntity(ownerEntityToSave);
	}
}
