package com.r1vs.platform.rox.api.model.security;

import com.fasterxml.jackson.annotation.JsonProperty;

public class RefreshTokenRequest {

	@JsonProperty(value = "Refresh_token")
	private String token;

	public String getToken() {

		return token;
	}

	public void setToken(final String token) {

		this.token = token;
	}

}
