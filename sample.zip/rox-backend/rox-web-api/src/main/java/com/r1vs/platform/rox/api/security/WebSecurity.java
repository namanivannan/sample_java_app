package com.r1vs.platform.rox.api.security;

import com.r1vs.platform.rox.api.filter.JWTAuthenticationFilter;
import com.r1vs.platform.rox.api.filter.JWTAuthorizationFilter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.Arrays;
import java.util.List;

@EnableWebSecurity(debug = false)
@Configuration
public class WebSecurity extends WebSecurityConfigurerAdapter {

	@Value("${roxwrite.web_api.auth_token_expiration}")
	private long authTokenExpiration;

	@Value("${roxwrite.web_api.refresh_token_expiration}")
	private long refreshTokenExpiration;

	@Value("#{'${roxwrite.web_api.allowed_origins}'.split(',')}")
	private List<String> allowedOrigins;

	private final UserDetailsService userDetailsService;

	private final BCryptPasswordEncoder bCryptPasswordEncoder;

	public WebSecurity(final UserDetailsService userDetailsService, final BCryptPasswordEncoder bCryptPasswordEncoder) {

		this.userDetailsService = userDetailsService;
		this.bCryptPasswordEncoder = bCryptPasswordEncoder;
	}

	@Override
	protected void configure(final HttpSecurity http) throws Exception {

		http.headers().and().authorizeRequests().antMatchers(SecurityConstants.AUTH_WHITELIST).permitAll()
				.antMatchers( "/v*/clients*","/v*/dashboard/rox/*").hasAuthority(SecurityConstants.MANAGE_CLIENT)
				.antMatchers("/v*/users*","/v*/users/{userId}/change-password")
                .hasAnyAuthority(SecurityConstants.MANAGE_CLIENT_USER,SecurityConstants.MANAGE_USER)
                .antMatchers( "/v*/roles*").hasAuthority(SecurityConstants.MANAGE_ROLE)
                .antMatchers( "/v*/privileges*").hasAuthority(SecurityConstants.MANAGE_PRIVILEGES)
                .antMatchers(SecurityConstants.MATCHES_ALL).authenticated()
				.and()
				.addFilter(new JWTAuthenticationFilter(authenticationManager(), authTokenExpiration,
						refreshTokenExpiration))
				.addFilter(new JWTAuthorizationFilter(authenticationManager(), userDetailsService)).anonymous().and()
				.authorizeRequests().anyRequest().authenticated().and().cors().and().csrf().disable()
				.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);

	}

	@Bean
	public CorsConfigurationSource corsConfigurationSource() {

		final CorsConfiguration configuration = new CorsConfiguration();
		configuration.setAllowedOrigins(allowedOrigins);
		configuration.setAllowedMethods(Arrays.asList("GET", "POST", "PATCH", "PUT", "DELETE", "OPTIONS"));
		configuration.setAllowedHeaders(Arrays.asList("*"));
		configuration.setAllowCredentials(true);

		final UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();

		source.registerCorsConfiguration("/v1/**", configuration);
		source.registerCorsConfiguration("/users/**", configuration);
		source.registerCorsConfiguration("/login/**", configuration);
		source.registerCorsConfiguration("/logout/**", configuration);

		return source;
	}

	@Override
	public void configure(final AuthenticationManagerBuilder auth) throws Exception {

		auth.userDetailsService(userDetailsService).passwordEncoder(bCryptPasswordEncoder);
	}

}
