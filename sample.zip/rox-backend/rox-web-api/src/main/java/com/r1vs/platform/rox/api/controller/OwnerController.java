package com.r1vs.platform.rox.api.controller;

import com.r1vs.platform.rox.api.model.application.initiate.NotesDTO;
import com.r1vs.platform.rox.api.model.application.initiate.OwnerDTO;
import com.r1vs.platform.rox.api.service.ApplicationService;
import com.r1vs.platform.rox.api.service.OwnerService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

import static com.r1vs.platform.rox.api.constants.ControllerConstants.*;
import static com.r1vs.platform.rox.api.util.ControllerUtils.getPageableFromHeaderParams;
import static com.r1vs.platform.rox.api.util.InterceptorConstants.CLIENT_ID;

@CrossOrigin
@RestController
@RequestMapping(value = "/v1/applications/{applicationId}/owners", produces = { MediaType.APPLICATION_JSON_VALUE })
@Tag(name = "Owner", description = "Owner Controller provides operations to create, update and delete Owners related " +
		"to an Application")
public class OwnerController {

	@Autowired
	private ApplicationService applicationService;

	@Autowired
	private OwnerService ownerService;

	private static final Logger LOGGER = LoggerFactory.getLogger(OwnerController.class);

	@PostMapping
	@Operation(summary = "Create new Owner for Application")
	public ResponseEntity<OwnerDTO> createOwner(@RequestHeader(CLIENT_ID) String clientId,
			@PathVariable UUID applicationId,
			@RequestBody OwnerDTO ownerDTO) {

		LOGGER.debug("Create new Owner endpoint hit");
		return new ResponseEntity<>(ownerService.createOwner(clientId, applicationId, ownerDTO),
				HttpStatus.CREATED);

	}

	@DeleteMapping(value = "/{ownerId}")
	@Operation(summary = "Delete Owner for Application")
	public ResponseEntity<Void> deleteOwner(@RequestHeader(CLIENT_ID) String clientId,
			@PathVariable UUID applicationId,
			@PathVariable UUID ownerId) {

		LOGGER.debug("Delete Owner endpoint hit");
		ownerService.deleteOwner(clientId, applicationId, ownerId);
		return ResponseEntity.ok().build();

	}

	@PatchMapping(value = "/{ownerId}")
	@Operation(summary = "Modify Owner for Application")
	public ResponseEntity<OwnerDTO> updateOwner(@RequestHeader(CLIENT_ID) String clientId,
			@PathVariable UUID applicationId,
			@PathVariable UUID ownerId,
			@RequestBody OwnerDTO ownerDTO) {

		LOGGER.debug("Patch Owner endpoint hit");
		return new ResponseEntity<>(ownerService.patchOwner(clientId, applicationId, ownerId, ownerDTO), HttpStatus.OK);

	}

	@GetMapping(value = "/{ownerId}")
	@Operation(summary = "Get Owner")
	public ResponseEntity<OwnerDTO> getOwner(@RequestHeader(CLIENT_ID) String clientId,
			@PathVariable UUID applicationId,
			@PathVariable UUID ownerId) {

		LOGGER.debug("Get Owner endpoint hit");
		return new ResponseEntity<>(ownerService.getOwner(clientId, applicationId, ownerId), HttpStatus.OK);
	}

	@GetMapping
	@Operation(summary = "Get Owners for Application")
	public ResponseEntity<Page<OwnerDTO>> getOwners(
			@RequestHeader(value = X_PAGINATION_LIMIT, defaultValue = "20") Integer pageLimit,
			@RequestHeader(value = X_PAGINATION_NUM, defaultValue = "0") Integer pageNumber,
			@RequestHeader(value = X_PAGINATION_SORT, defaultValue = "createdAt,desc") String sortingParam,
			@RequestHeader(CLIENT_ID) String clientId,
			@PathVariable UUID applicationId) {

		Pageable pageParams = getPageableFromHeaderParams(pageLimit, pageNumber, sortingParam);
		return new ResponseEntity<>(ownerService.getOwnersForApplication(clientId, applicationId, pageParams),
				HttpStatus.OK);
	}

}
