package com.r1vs.platform.rox.common.model.notes;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.*;

import com.r1vs.platform.rox.common.model.AuditedEntity;
import com.r1vs.platform.rox.common.model.business.Application;
import com.r1vs.platform.rox.common.model.business.Client;
import com.r1vs.platform.rox.common.model.business.storage.RoxFile;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

/**
 * This is the model class for notes.
 */
@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "notes")
public class Notes extends AuditedEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long noteId;

	@Column(name = "uuid")
	private UUID uuid;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "application_id")
	private Application application;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "rox_file_id")
	private RoxFile roxFile;

	@Column(name = "notes")
	private String notes;

	public Long getNoteId() {

		return noteId;
	}

	public void setNoteId(Long noteId) {

		this.noteId = noteId;
	}

	public UUID getUuid() {

		return uuid;
	}

	public void setUuid(UUID uuid) {

		this.uuid = uuid;
	}

	public Application getApplication() {

		return application;
	}

	public void setApplication(Application application) {

		this.application = application;
	}

	public String getNotes() {

		return notes;
	}

	public void setNotes(String notes) {

		this.notes = notes;
	}

	public RoxFile getRoxFile() {

		return roxFile;
	}

	public void setRoxFile(RoxFile roxFile) {

		this.roxFile = roxFile;
	}
}
