package com.r1vs.platform.rox.common.model.dp;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;
import javax.persistence.Version;

import com.r1vs.platform.rox.common.model.AuditedEntity;

@Entity
@Table(name = "dp_data_input")
@Inheritance(strategy = InheritanceType.JOINED)
public class DataInput extends AuditedEntity implements Serializable {

	private static final long serialVersionUID = 2628233015010123904L;

	@Id
	@Column(name = "id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Version
	private Integer version;

	@Column(name = "pbm_id")
	private Integer pbmId;

	@Column(name = "input_uuid")
	private String inputUUID;

	@Column(name = "registration_code")
	private String registrationCode;

	@Column(name = "state", nullable = false)
	private String state;

	@Column(name = "input_class", nullable = false)
	private String inputClass;

	@Column(name = "configuration")
	private String configuration;

	public Integer getId() {

		return id;
	}

	public void setId(final Integer id) {

		this.id = id;
	}

	public Integer getVersion() {

		return version;
	}

	public void setVersion(final Integer version) {

		this.version = version;
	}

	public String getInputUUID() {

		return inputUUID;
	}

	public void setInputUUID(final String inputUUID) {

		this.inputUUID = inputUUID;
	}

	public String getRegistrationCode() {

		return registrationCode;
	}

	public void setRegistrationCode(final String registrationCode) {

		this.registrationCode = registrationCode;
	}

	public String getState() {

		return state;
	}

	public void setState(final String state) {

		this.state = state;
	}

	public String getInputClass() {

		return inputClass;
	}

	public void setInputClass(final String inputClass) {

		this.inputClass = inputClass;
	}

	public String getConfiguration() {

		return configuration;
	}

	public void setConfiguration(final String configuration) {

		this.configuration = configuration;
	}

	public Integer getPbmId() {

		return pbmId;
	}

	public void setPbmId(final Integer pbmId) {

		this.pbmId = pbmId;
	}

}
