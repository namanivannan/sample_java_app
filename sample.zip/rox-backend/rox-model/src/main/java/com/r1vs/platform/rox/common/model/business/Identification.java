package com.r1vs.platform.rox.common.model.business;

import com.r1vs.platform.rox.common.model.AuditedEntity;
import com.r1vs.platform.rox.common.security.annotations.Encrypted;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;

@Entity
@Table(name = "identification")
@EntityListeners(AuditingEntityListener.class)
public class Identification extends AuditedEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@OneToOne
	@JoinColumn(name = "identification_type_id", nullable = false)
	private IdentificationType identificationType;

	@Column(name = "xref_id")
	private Long xrefId;

	@Column(name = "xref_type_id")
	private Long xrefTypeId;

	@Column(name = "description")
	private String description;

	@Column(name = "identification")
	@Encrypted
    private String identification;

	@Column(name = "is_primary")
	private Boolean isPrimary;

	public Long getId() {

		return this.id;
	}

	public void setId(Long id) {

		this.id = id;
	}

	public IdentificationType getIdentificationType() {

		return identificationType;
	}

	public void setIdentificationType(IdentificationType identificationType) {

		this.identificationType = identificationType;
	}

	public Long getXrefId() {

		return this.xrefId;
	}

	public void setXrefId(Long xrefId) {

		this.xrefId = xrefId;
	}

	public Long getXrefTypeId() {

		return this.xrefTypeId;
	}

	public void setXrefTypeId(Long xrefTypeId) {

		this.xrefTypeId = xrefTypeId;
	}

	public String getDescription() {

		return this.description;
	}

	public void setDescription(String description) {

		this.description = description;
	}

	public String getIdentification() {

		return this.identification;
	}

	public void setIdentification(String identification) {

		this.identification = identification;
	}

	public Boolean getIsPrimary() {

		return this.isPrimary;
	}

	public void setIsPrimary(Boolean isPrimary) {

		this.isPrimary = isPrimary;
	}
}
