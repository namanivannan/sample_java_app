package com.r1vs.platform.rox.api.util;

public class BasisOfCostCodeTestUtil {

	public static final String API_ENDPOINT = "/v1/basis-of-cost-codes";

	public static final String CREATE_ENDPOINT = "/v1/basis-of-cost-code";

	public static final String HISTORY_ENDPOINT = "/v1/basis-of-cost-code/MAC/history";

	public static final Integer BASIS_OF_COST_CODE_ID = 1;

	public static final String DATE_OF_SERVICE = "20170101";

	public static final String BASIS_OF_COST_CODE = "MAC";

	public static final Integer PBM_ID = 1;

	public static final String BASIS_OF_COST_CODE_DESCRIPTION = "MAC 1";

	public static final String CREATE_JSON =
			"{\"code\":\"test\",\"description\":\"test\",\"reimbursementAssignment\":\"1\",\"statusId\":1,\"effectiveStartDate\":\"2017-01-01\",\"effectiveEndDate\":\"9999-12-31\"}";

	public static final String CREATE_JSON_WITH_WRONG_STATUS_ID =
			"{\"code\":\"test\",\"description\":\"test\",\"reimbursementAssignment\":\"1\",\"statusId\":10,\"effectiveStartDate\":\"2017-01-01\",\"effectiveEndDate\":\"9999-12-31\"}";

	public static final String UPDATE_JSON =
			"{\"id\":1,\"code\":\"update\",\"description\":\"MAC\",\"reimbursementAssignment\":\"1\",\"statusId\":1,\"effectiveStartDate\":\"2017-01-01\",\"effectiveEndDate\":\"9999-12-31\"}";

	public static final String UPDATE_JSON_WITH_WRONG_STATUS_ID =
			"{\"id\":1,\"code\":\"update\",\"description\":\"MAC\",\"reimbursementAssignment\":\"1\",\"statusId\":10,\"effectiveStartDate\":\"2017-01-01\",\"effectiveEndDate\":\"9999-12-31\"}";
}
