package com.r1vs.platform.rox.common.model.users;

import com.r1vs.platform.rox.common.model.AuditedEntity;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "group_role")
public class GroupRole extends AuditedEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "group_role_id", nullable = false)
	private Integer groupRoleId;

	@Column(name = "access_group_id")
	private Integer accessGroupId;

	@Column(name = "role_id")
	private Integer roleId;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "access_group_id", nullable = false, insertable = false, updatable = false)
	private AccessGroup accessGroup;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "role_id", nullable = false, insertable = false, updatable = false)
	private Role role;

	public Integer getGroupRoleId() {

		return groupRoleId;
	}

	public void setGroupRoleId(Integer groupRoleId) {

		this.groupRoleId = groupRoleId;
	}

	public Integer getAccessGroupId() {

		return accessGroupId;
	}

	public void setAccessGroupId(Integer accessGroupId) {

		this.accessGroupId = accessGroupId;
	}

	public Integer getRoleId() {

		return roleId;
	}

	public void setRoleId(Integer roleId) {

		this.roleId = roleId;
	}

	public AccessGroup getAccessGroup() {

		return accessGroup;
	}

	public void setAccessGroup(AccessGroup accessGroup) {

		this.accessGroup = accessGroup;
	}

	public Role getRole() {

		return role;
	}

	public void setRole(Role role) {

		this.role = role;
	}
}
