package com.r1vs.platform.rox.api;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ResourceBundleMessageSource;

/**
 * This brings the messages resources for the application.
 */
@Configuration
public class MessagesConfiguration {

	@Bean
	public ResourceBundleMessageSource messageSource() {

		final var source = new ResourceBundleMessageSource();
		source.setBasenames("com/r1vs/platform/rox/api/validator/messages",
				"com/r1vs/platform/rox/api/validator/role_messages",
				"com/r1vs/platform/rox/api/validator/user_messages",
				"com/r1vs/platform/rox/api/validator/message_manager_messages",
				"com/r1vs/platform/rox/api/validator/member_auth_messages",
				"com/r1vs/platform/rox/api/validator/note_messages",
				"com/r1vs/platform/rox/api/validator/job_management_messages");
		source.setUseCodeAsDefaultMessage(true);
		return source;
	}
}
