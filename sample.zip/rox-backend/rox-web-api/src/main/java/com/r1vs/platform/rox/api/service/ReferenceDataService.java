package com.r1vs.platform.rox.api.service;

import com.r1vs.platform.rox.common.db.repository.business.ApplicationStatusRepository;
import com.r1vs.platform.rox.common.db.repository.business.BusinessTypeRepository;
import com.r1vs.platform.rox.common.db.repository.business.IndustryTypeRepository;
import com.r1vs.platform.rox.common.db.repository.core.StateAbbreviationRepository;
import com.r1vs.platform.rox.common.db.repository.role.PrivilegeRepository;
import com.r1vs.platform.rox.common.model.StateAbbreviation;
import com.r1vs.platform.rox.common.model.business.ApplicationStatus;
import com.r1vs.platform.rox.common.model.business.BusinessType;
import com.r1vs.platform.rox.common.model.business.IndustryType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReferenceDataService {

	@Autowired
	private ApplicationStatusRepository applicationStatusRepository;

	@Autowired
	private BusinessTypeRepository businessTypeRepository;

	@Autowired
	private IndustryTypeRepository industryTypeRepository;

	@Autowired
	private PrivilegeRepository privilegeRepository;

	@Autowired
	private StateAbbreviationRepository stateAbbreviationRepository;

	public List<BusinessType> getAllBusinessTypes() {

		return businessTypeRepository.findAll();
	}

	public List<ApplicationStatus> getAllApplicationStatus() {

		return applicationStatusRepository.findAll();
	}

	public List<IndustryType> getAllIndustryType() {

		return industryTypeRepository.findAll();
	}

	public List<StateAbbreviation> getAllStateAbbreviation() {

		return stateAbbreviationRepository.findAll();
	}
}
