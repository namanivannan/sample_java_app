package com.r1vs.platform.rox.api.model;

import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.Objects;

public class UserRequest implements Serializable {

	private static final long serialVersionUID = 1L;

	@NotNull
	private String firstName;

	@NotNull
	@Email
	private String email;

	@NotNull
	private String lastName;

	//@Size(min = 6, message = "Username length must be at least 6 characters")
	@NotNull
	private String username;

	@NotNull
	@NotBlank
	@Size(min = 8, message = "Password length must be at least 8 characters")
	private String password;

	private int phoneTypeId;

	private String phone;

	public String getEmail() {

		return email;
	}

	public void setEmail(final String email) {

		this.email = email;
	}

	public String getFirstName() {

		return firstName;
	}

	public void setFirstName(final String firstName) {

		this.firstName = firstName;
	}

	public String getLastName() {

		return lastName;
	}

	public void setLastName(final String lastName) {

		this.lastName = lastName;
	}

	public String getPassword() {

		return password;
	}

	public void setPassword(String password) {

		this.password = password;
	}


	public String getUsername() {

		return username;
	}

	public void setUsername(String username) {

		this.username = username;
	}


	public int getPhoneTypeId() {

		return phoneTypeId;
	}

	public void setPhoneTypeId(int phoneTypeId) {

		this.phoneTypeId = phoneTypeId;
	}

	public String getPhone() {

		return phone;
	}

	public void setPhone(String phone) {

		this.phone = phone;
	}

	@Override
	public boolean equals(Object o) {

		if (this == o)
			return true;
		if (o == null || getClass() != o.getClass())
			return false;
		UserRequest that = (UserRequest) o;
		return phoneTypeId == that.phoneTypeId && firstName.equals(that.firstName)
				&& email.equals(that.email) && lastName.equals(that.lastName) && username.equals(that.username)
				&& password.equals(that.password) && Objects.equals(phone, that.phone);
	}

	@Override
	public int hashCode() {

		return Objects.hash(firstName, email, lastName, username, password, phoneTypeId, phone);
	}

	@Override
	public String toString() {

		return "UserRequest{" +
				"firstName='" + firstName + '\'' +
				", email='" + email + '\'' +
				", lastName='" + lastName + '\'' +
				", username='" + username + '\'' +
				", password='" + password + '\'' +
				", phoneTypeId=" + phoneTypeId +
				", phone='" + phone + '\'' +
				'}';
	}
}
