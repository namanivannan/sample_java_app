package com.r1vs.platform.rox.common.model.business;

public enum BusinessCategory {
	BUSINESS,
	DEBTOR;
}
