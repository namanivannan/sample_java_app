package com.r1vs.platform.rox.api.validator.message;

import com.r1vs.platform.rox.api.exception.Error;
import com.r1vs.platform.rox.api.model.message.UpdateMessageTemplateRequest;
import com.r1vs.platform.rox.api.service.messagetemplate.MessageTemplateApiService;
import com.r1vs.platform.rox.common.model.messages.MessageTemplate;
import com.r1vs.platform.rox.common.model.types.StatusType;
import com.r1vs.platform.rox.common.model.types.message.MessageType;
import com.r1vs.platform.rox.common.model.types.message.PrivacyLevelType;
import com.r1vs.platform.rox.common.model.types.message.PrivacySettingType;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import java.util.Locale;
import java.util.Objects;

import static com.r1vs.platform.rox.api.util.MessageTemplateConstants.*;
import static com.r1vs.platform.rox.api.util.MetadataConstants.STATUS;
import static com.r1vs.platform.rox.api.util.ValidationUtil.addError;
import static com.r1vs.platform.rox.api.validator.ValidationMessages.*;

@Component
public class MessageTemplateRequestValidator {

	@Autowired
	private MessageTemplateApiService messageTemplateApiService;

	@Autowired
	protected MessageSource messageSource;

	/**
	 * Validate messageTemplate privacyLevel
	 *
	 * @param error error
	 * @param privacyLevel privacyLevel
	 */
	protected void validatePrivacyLevel(final Error error, final String privacyLevel) {

		if (privacyLevel != null && !PrivacyLevelType.HELPER.containsKey(privacyLevel)) {
			addError(error, PRIVACY_LEVEL, messageSource.getMessage(INVALID_PRIVACY_LEVEL, null, Locale.getDefault()),
					String.valueOf(privacyLevel));
		}
	}

	/**
	 * Validate messageTemplate privacySetting
	 *
	 * @param error error
	 * @param privacySetting privacySetting
	 */
	protected void validatePrivacySetting(final Error error, final String privacySetting) {

		if (privacySetting != null && !PrivacySettingType.HELPER.containsKey(privacySetting)) {
			addError(error, PRIVACY_SETTING,
					messageSource.getMessage(INVALID_PRIVACY_SETTING, null, Locale.getDefault()),
					String.valueOf(privacySetting));
		}
	}

	/**
	 * Validate uniqueness for Message Template Name
	 *
	 * @param error error
	 * @param messageName messageName
	 */
	protected void validateMessageName(final Error error, final String messageName, final Integer pbmId) {

		if (messageName == null || messageName.isEmpty() || messageName.length() > 50) {
			addError(error, MESSAGE_NAME,
					messageSource.getMessage(MESSAGE_NAME_LENGTH_RESTRICTION, null, Locale.getDefault()), messageName);
		}

		if (!CollectionUtils.isEmpty(messageTemplateApiService.findByMessageName(messageName, pbmId))) {
			addError(error, MESSAGE_NAME,
					messageSource.getMessage(MESSAGE_NAME_ALREADY_EXISTS, null, Locale.getDefault()), messageName);
		}

	}

	protected void validateMessageNameForUpdate(final Error error,
			final UpdateMessageTemplateRequest updateMessageTemplateRequest, final Integer pbmId) {

		if (updateMessageTemplateRequest.getMessageName() == null
				|| updateMessageTemplateRequest.getMessageName().isEmpty()
				|| updateMessageTemplateRequest.getMessageName().length() > 50) {
			addError(error, MESSAGE_NAME,
					messageSource.getMessage(MESSAGE_NAME_LENGTH_RESTRICTION, null, Locale.getDefault()),
					updateMessageTemplateRequest.getMessageName());
		}

		final String messageName =
				messageTemplateApiService.getMessageTemplateById(updateMessageTemplateRequest.getMessageTemplateId())
						.map(MessageTemplate::getMessageName).orElse(StringUtils.EMPTY);

		if (!Objects.equals(messageName, updateMessageTemplateRequest.getMessageName()) &&
				CollectionUtils.isNotEmpty(messageTemplateApiService
						.findByMessageName(updateMessageTemplateRequest.getMessageName(), pbmId))) {
			addError(error, MESSAGE_NAME,
					messageSource.getMessage(MESSAGE_NAME_ALREADY_EXISTS, null, Locale.getDefault()),
					updateMessageTemplateRequest.getMessageName());
		}

	}

	/**
	 * Validate messageTemplate status
	 *
	 * @param error error
	 * @param status status
	 */
	protected void validateStatus(final Error error, final Integer status) {

		validateStatusCode(error, status);

		if (status != null && StatusType.DELETED.key().equals(status) || StatusType.INACTIVE.key().equals(status)) {
			addError(error, STATUS,
					messageSource.getMessage(INVALID_MESSAGE_TEMPLATE_STATUS, null, Locale.getDefault()),
					String.valueOf(status));
		}
	}

	protected void validateStatusCode(final Error error, final Integer status) {

		if (!StatusType.getStatusTypeMap().containsKey(status)) {
			addError(error, STATUS, INVALID_STATUS, String.valueOf(status));
		}
	}

	/**
	 * Validate messageTemplate messageType
	 *
	 * @param error error
	 * @param messageType messageType
	 */
	protected void validateMessageType(final Error error, final String messageType) {

		if (!MessageType.HELPER.containsKey(messageType)) {
			addError(error, MESSAGE_TYPE, messageSource.getMessage(INVALID_MESSAGE_TYPE, null, Locale.getDefault()),
					String.valueOf(messageType));
		}
	}

	public MessageTemplateApiService getMessageTemplateApiService() {

		return messageTemplateApiService;
	}

	public void setMessageTemplateApiService(final MessageTemplateApiService messageTemplateApiService) {

		this.messageTemplateApiService = messageTemplateApiService;
	}

	public MessageSource getMessageSource() {

		return messageSource;
	}

	public void setMessageSource(final MessageSource messageSource) {

		this.messageSource = messageSource;
	}
}
