package com.r1vs.platform.rox.api.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.BAD_REQUEST)
public class InvalidFormDataException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	private final FormErrorResponse errorResponse;

	public InvalidFormDataException(final FormErrorResponse errorResponse) {

		super();
		this.errorResponse = errorResponse;
	}

	public FormErrorResponse getErrorResponses() {

		return errorResponse;
	}

}
