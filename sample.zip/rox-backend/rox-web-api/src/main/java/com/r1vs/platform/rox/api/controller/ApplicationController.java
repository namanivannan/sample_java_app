package com.r1vs.platform.rox.api.controller;

import com.r1vs.platform.rox.api.model.application.ApplicationSearchRequestDTO;
import com.r1vs.platform.rox.api.model.application.initiate.*;
import com.r1vs.platform.rox.api.processor.ApplicationProcessor;
import com.r1vs.platform.rox.api.service.ApplicationService;
import com.r1vs.platform.rox.api.service.BusinessService;
import com.r1vs.platform.rox.api.service.StatusService;
import com.r1vs.platform.rox.common.model.business.Application;
import com.r1vs.platform.rox.common.model.business.ApplicationStatus;
import com.r1vs.platform.rox.common.model.business.Business;
import com.r1vs.platform.rox.common.model.business.Client;
import com.r1vs.platform.rox.common.model.business.storage.RoxFile;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static com.r1vs.platform.rox.api.constants.ControllerConstants.*;
import static com.r1vs.platform.rox.api.util.ControllerUtils.getPageableFromHeaderParams;
import static com.r1vs.platform.rox.api.util.InterceptorConstants.CLIENT_ID;

@CrossOrigin
@RestController
@RequestMapping(value = "/v1", produces = { MediaType.APPLICATION_JSON_VALUE })
@Tag(name = "Application", description = "Application Service")
public class ApplicationController {

	@Autowired
	private BusinessService businessService;

	@Autowired
	private ApplicationService applicationService;

	@Autowired
	private ApplicationProcessor applicationProcessor;

	private static final Logger LOGGER = LoggerFactory.getLogger(ApplicationController.class);

	@PostMapping(value = "/applications")
	@Operation(summary = "Create new Application")
	public ResponseEntity<ApplicationDTO> createApplication(@RequestHeader(CLIENT_ID) String clientId,
			@RequestBody ApplicationDTO applicationDTO) {

		LOGGER.debug("Create new application endpoint hit");

		return new ResponseEntity<>(applicationService.createApplication(clientId, applicationDTO),
				HttpStatus.OK);

	}

	@PatchMapping("/applications/{applicationId}/status")
	public ResponseEntity<ApplicationDTO> updateApplicationStatus(@PathVariable UUID applicationId,
			@RequestHeader(CLIENT_ID) String clientId,
			@Valid @RequestBody ApplicationStatusChangeDTO applicationStatusChangeDTO) {

		ApplicationDTO applicationDTO =
				applicationService.changeStatus(applicationStatusChangeDTO, applicationId, clientId);
		return new ResponseEntity<>(applicationDTO, HttpStatus.OK);
	}

	@GetMapping("/applications")
	public ResponseEntity<List<MinimalApplicationDTO>> getApplications(
			@RequestHeader(CLIENT_ID) String clientId,
			@RequestHeader(value = X_PAGINATION_LIMIT, defaultValue = "20") Integer pageLimit,
			@RequestHeader(value = X_PAGINATION_NUM, defaultValue = "0") Integer pageNumber,
			@RequestHeader(value = X_PAGINATION_SORT, defaultValue = "createdAt,desc") String sortingParam,
			@ModelAttribute ApplicationSearchRequestDTO searchRequest) {

		Pageable pageParams = getPageableFromHeaderParams(pageLimit, pageNumber, sortingParam);

		return applicationProcessor.getApplications(clientId, searchRequest, pageParams);
	}

	@GetMapping("/applications/{applicationId}")
	public ResponseEntity<ApplicationDTO> getApplication(@PathVariable UUID applicationId,
			@RequestHeader(CLIENT_ID) String clientId) {

		ApplicationDTO applications = applicationService.getApplication(applicationId, clientId);
		return new ResponseEntity<>(applications, HttpStatus.OK);
	}

	@GetMapping("/applications/{applicationId}/files")
	@Operation(summary = "Get a list of attachments of an Application")
	public ResponseEntity<List<RoxFileWithNotesDTO>> getApplicationFiles(@RequestHeader(CLIENT_ID) String clientId,
			@PathVariable UUID applicationId) throws IOException {

		return new ResponseEntity<>(applicationService.getApplicationAttachments(applicationId, clientId),
				HttpStatus.OK);
	}
}
