package com.r1vs.platform.rox.api.processor;

import com.r1vs.platform.rox.api.model.application.ApplicationSearchRequestDTO;
import com.r1vs.platform.rox.api.model.application.initiate.MinimalApplicationDTO;
import com.r1vs.platform.rox.api.service.ApplicationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class ApplicationProcessor extends CommonProcessor<MinimalApplicationDTO> {

	@Autowired
	private ApplicationService applicationService;

	public ResponseEntity<List<MinimalApplicationDTO>> getApplications(String clientId,
			ApplicationSearchRequestDTO searchRequest, Pageable pageParams) {

		Page<MinimalApplicationDTO> applications =
				applicationService.getApplications(clientId, searchRequest, pageParams);
		return buildResponseAsListWithPagination(applications.getTotalElements(), applications.getNumber(),
				applications.getPageable().getPageSize(), applications.get().collect(Collectors.toList()));

	}
}
