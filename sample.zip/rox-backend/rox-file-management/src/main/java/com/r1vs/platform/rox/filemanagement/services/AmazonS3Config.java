package com.r1vs.platform.rox.filemanagement.services;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.client.builder.AwsClientBuilder.EndpointConfiguration;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.data.ConditionalOnRepositoryType;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * This class sets the configuration and credentials for S3Storage
 */
@Configuration
public class AmazonS3Config {

	@Value("${AWS_REGION}")
	private String region;

	@Value("${roxwrite.application-files.s3.url:#{null}}")
	private String s3EndpointUrl;

	@Value("${roxwrite.application-files.s3.bucket-name}")
	private String bucketName;

	@Value("${roxwrite.application-files.s3.access-key:#{null}}")
	private String accessKey;

	@Value("${roxwrite.application-files.s3.secret-key:#{null}")
	private String secretKey;

	@Bean(name = "localStackS3Client")
	@ConditionalOnProperty(prefix = "roxwrite.application-files.s3", name = "url")
	public AmazonS3 localStackS3Client() {

		return AmazonS3ClientBuilder.standard()
				.withCredentials(getCredentialsProvider())
				.withEndpointConfiguration(getEndpointConfiguration(s3EndpointUrl))
				.build();
	}

	@Bean(name = "amazonS3")
	@ConditionalOnProperty(prefix = "roxwrite.application-files.s3", name = "url", matchIfMissing = true)
	public AmazonS3 amazonS3() {

		return AmazonS3ClientBuilder.defaultClient();
	}

	private EndpointConfiguration getEndpointConfiguration(String url) {

		return new EndpointConfiguration(url, region);
	}

	private AWSStaticCredentialsProvider getCredentialsProvider() {

		return new AWSStaticCredentialsProvider(getBasicAWSCredentials());
	}

	private BasicAWSCredentials getBasicAWSCredentials() {

		return new BasicAWSCredentials(accessKey, secretKey);
	}

	public String getRegion() {

		return region;
	}

	public void setRegion(String region) {

		this.region = region;
	}

	public String getS3EndpointUrl() {

		return s3EndpointUrl;
	}

	public void setS3EndpointUrl(String s3EndpointUrl) {

		this.s3EndpointUrl = s3EndpointUrl;
	}

	public String getBucketName() {

		return bucketName;
	}

	public void setBucketName(String bucketName) {

		this.bucketName = bucketName;
	}

	public String getAccessKey() {

		return accessKey;
	}

	public void setAccessKey(String accessKey) {

		this.accessKey = accessKey;
	}

	public String getSecretKey() {

		return secretKey;
	}

	public void setSecretKey(String secretKey) {

		this.secretKey = secretKey;
	}
}
