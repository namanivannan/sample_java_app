package com.r1vs.platform.rox.common.security.service;

/**
 * This should do only byte[] to byte[] operations
 */
public interface LowLevelEncryptionService {

    byte[] encrypt(byte[] value) ;

    byte[] decrypt(byte[] value);
}
