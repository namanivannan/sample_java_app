package com.r1vs.platform.rox.common.model.rule;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.r1vs.platform.rox.common.model.AuditedEntity;
import com.r1vs.platform.rox.common.model.business.Status;
import com.r1vs.platform.rox.common.model.business.Client;
import org.apache.commons.lang3.builder.CompareToBuilder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "metadata")
public class Metadata extends AuditedEntity implements Serializable, Comparable<Metadata> {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "metadata_id", nullable = false)
	private Long metadataId;

	@Column(name = "client_id")
	private Integer clientId;

	@Column(name = "metadata_name")
	@NotNull
	private String metadataName;

	@Column(name = "metadata_category_id", nullable = false)
	private Integer metadataCategoryId;

	@Column(name = "json", nullable = false)
	private String json;

	@Column(name = "status_id")
	@NotNull
	private Integer statusId;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "status_id", nullable = false, insertable = false, updatable = false)
	private Status status;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "client_id", nullable = false, insertable = false, updatable = false)
	private Client client;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "metadata_category_id", nullable = false, insertable = false, updatable = false)
	private MetadataCategory metadataCategory;

	// Donot delete this when refactoring.
	@Override
	public int compareTo(final Metadata other) {

		return new CompareToBuilder().append(metadataId, other.metadataId).toComparison();
	}

	public Long getMetadataId() {

		return metadataId;
	}

	public void setMetadataId(final Long metadataId) {

		this.metadataId = metadataId;
	}

	public Integer getClientId() {

		return clientId;
	}

	public void setClientId(final Integer clientId) {

		this.clientId = clientId;
	}

	public String getMetadataName() {

		return metadataName;
	}

	public void setMetadataName(final String metadataName) {

		this.metadataName = metadataName;
	}

	public Integer getMetadataCategoryId() {

		return metadataCategoryId;
	}

	public void setMetadataCategoryId(final Integer metadataCategoryId) {

		this.metadataCategoryId = metadataCategoryId;
	}

	public String getJson() {

		return json;
	}

	public void setJson(final String json) {

		this.json = json;
	}

	public Integer getStatusId() {

		return statusId;
	}

	public void setStatusId(final Integer statusId) {

		this.statusId = statusId;
	}

	public Status getStatus() {

		return status;
	}

	public void setStatus(final Status status) {

		this.status = status;
	}

	public Client getClient() {

		return client;
	}

	public void setClient(final Client client) {

		this.client = client;
	}

	public MetadataCategory getMetadataCategory() {

		return metadataCategory;
	}

	public void setMetadataCategory(final MetadataCategory metadataCategory) {

		this.metadataCategory = metadataCategory;
	}

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof Metadata)) {
			return false;
		}
		final Metadata castOther = (Metadata) other;
		return new EqualsBuilder().append(metadataId, castOther.metadataId).append(clientId, castOther.clientId)
				.append(metadataName, castOther.metadataName).append(metadataCategoryId, castOther.metadataCategoryId)
				.append(json, castOther.json).append(statusId, castOther.statusId).isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(metadataId).append(clientId).append(metadataName).append(metadataCategoryId)
				.append(json).append(statusId).toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("metadataId", metadataId).append("clientId", clientId)
				.append("metadataName", metadataName).append("metadataCategoryId", metadataCategoryId)
				.append("json", json).append("statusId", statusId).toString();
	}

}
