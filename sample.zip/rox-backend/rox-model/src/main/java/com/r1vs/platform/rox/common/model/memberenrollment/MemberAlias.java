package com.r1vs.platform.rox.common.model.memberenrollment;

import com.r1vs.platform.rox.common.model.BitemporalEntity;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.OffsetDateTime;

@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "member_alias")
public class MemberAlias extends BitemporalEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "member_alias_id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer memberAliasId;

	@Column(name = "member_id", nullable = false)
	@NotNull
	private Integer memberId;

	@Column(name = "pbm_id")
	private Integer pbmId;

	@Column(name = "alias_id")
	@Size(max = 18)
	@NotNull
	private String aliasId;

	@Column(name = "alias_id_qualifier")
	@Size(min = 1, max = 2)
	@NotNull
	private String aliasIdQualifier;

	@Column(name = "alias_id_state")
	@Size(min = 1, max = 2)
	private String aliasIdState;

	@Column(name = "status_id", nullable = false)
	@NotNull
	private Integer statusId;

	@Column(name = "input_id")
	private String inputId;

	/**
	 * Relationships
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "member_id", nullable = false, insertable = false, updatable = false)
	private Member member;

	public MemberAlias() {

	}

	private MemberAlias(final Builder builder) {

		memberId = builder.memberId;
		pbmId = builder.pbmId;
		aliasId = builder.aliasId;
		aliasIdQualifier = builder.aliasIdQualifier;
		aliasIdState = builder.aliasIdState;
		effectiveStartDate = builder.effectiveStartDate;
		effectiveEndDate = builder.effectiveEndDate;
		deactivatedAt = builder.deactivatedAt;
		activatedAt = builder.activatedAt;
		statusId = builder.statusId;
	}

	public static class Builder {

		private final Integer memberId;

		private final Integer pbmId;

		private final String aliasId;

		private final String aliasIdQualifier;

		private String aliasIdState = null;

		private final Integer statusId;

		private final LocalDate effectiveStartDate;

		private final LocalDate effectiveEndDate;

		private final OffsetDateTime deactivatedAt;

		private final OffsetDateTime activatedAt;

		public Builder(final Integer memberId, final Integer pbmId, final String aliasId, final String aliasIdQualifier,
				final Integer statusId,
				final LocalDate effectiveStartDate, final LocalDate effectiveEndDate,
				final OffsetDateTime deactivatedAt,
				final OffsetDateTime activatedAt) {

			this.memberId = memberId;
			this.pbmId = pbmId;
			this.aliasId = aliasId;
			this.aliasIdQualifier = aliasIdQualifier;
			this.statusId = statusId;
			this.effectiveStartDate = effectiveStartDate;
			this.effectiveEndDate = effectiveEndDate;
			this.deactivatedAt = deactivatedAt;
			this.activatedAt = activatedAt;
		}

		public Builder aliasIdState(final String val) {

			aliasIdState = val;
			return this;
		}

		public MemberAlias build() {

			return new MemberAlias(this);
		}

	}

	public Integer getMemberAliasId() {

		return memberAliasId;
	}

	public void setMemberAliasId(final Integer memberAliasId) {

		this.memberAliasId = memberAliasId;
	}

	public Integer getMemberId() {

		return memberId;
	}

	public void setMemberId(final Integer memberId) {

		this.memberId = memberId;
	}

	public Integer getPbmId() {

		return pbmId;
	}

	public void setPbmId(final Integer pbmId) {

		this.pbmId = pbmId;
	}

	public String getAliasId() {

		return aliasId;
	}

	public void setAliasId(final String aliasId) {

		this.aliasId = aliasId;
	}

	public String getAliasIdQualifier() {

		return aliasIdQualifier;
	}

	public void setAliasIdQualifier(final String aliasIdQualifier) {

		this.aliasIdQualifier = aliasIdQualifier;
	}

	public String getAliasIdState() {

		return aliasIdState;
	}

	public void setAliasIdState(final String aliasIdState) {

		this.aliasIdState = aliasIdState;
	}

	public Integer getStatusId() {

		return statusId;
	}

	public void setStatusId(final Integer statusId) {

		this.statusId = statusId;
	}

	public Member getMember() {

		return member;
	}

	public void setMember(final Member member) {

		this.member = member;
	}

	public String getInputId() {

		return inputId;
	}

	public void setInputId(final String inputId) {

		this.inputId = inputId;
	}

	/**
	 *
	 * Checks the data so that no duplicate row is inserted in database. Only fields that will not be unique are added
	 * to this equals check!
	 */
	@Override
	public boolean itemEqualsRow(final Object other) {

		if (!(other instanceof MemberAlias)) {
			return false;
		}
		final MemberAlias castOther = (MemberAlias) other;
		return new EqualsBuilder().append(memberId, castOther.memberId).append(pbmId, castOther.pbmId)
				.append(aliasId, castOther.aliasId)
				.append(aliasIdQualifier, castOther.aliasIdQualifier).append(aliasIdState, castOther.aliasIdState)
				.append(getEffectiveStartDate(), castOther.getEffectiveStartDate())
				.append(getEffectiveEndDate(), castOther.getEffectiveEndDate()).isEquals();
	}

	/**
	 *
	 * Note: Regenerating equals, hashCode, and toString may re-introduce purposely removed related entities which cause
	 * lazy load exceptions after session has been closed. Please exclude relationships from these methods.
	 */
	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof MemberAlias)) {
			return false;
		}
		final MemberAlias castOther = (MemberAlias) other;
		return new EqualsBuilder().append(memberAliasId, castOther.memberAliasId).append(memberId, castOther.memberId)
				.append(pbmId, castOther.pbmId)
				.append(aliasId, castOther.aliasId).append(aliasIdQualifier, castOther.aliasIdQualifier)
				.append(aliasIdState, castOther.aliasIdState).isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(memberAliasId).append(memberId).append(pbmId).append(aliasId)
				.append(aliasIdQualifier)
				.append(aliasIdState).toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("memberAliasId", memberAliasId).append("memberId", memberId)
				.append("pbmId", pbmId)
				.append("aliasId", aliasId).append("aliasIdQualifier", aliasIdQualifier)
				.append("aliasIdState", aliasIdState).toString();
	}

}
