package com.r1vs.platform.rox.api.controller;

import com.r1vs.platform.rox.api.exception.ValidationException;
import com.r1vs.platform.rox.api.model.ApiVersionReferenceResponse;
import com.r1vs.platform.rox.api.response.ResponseMessages;
import com.r1vs.platform.rox.api.util.ApiVersionUtil;
import com.r1vs.platform.rox.common.util.StringUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.HashMap;
import java.util.Properties;

@RestController
@RequestMapping(value = "/v1", produces = { MediaType.APPLICATION_JSON_VALUE })
@Tag(name = "API Version", description = "RoxWrite web API version reference Service")
public class APIVersionReferenceController {

	private static final Logger LOGGER = LoggerFactory.getLogger(APIVersionReferenceController.class);

	@GetMapping(value = "/webapi/version")
	@Operation(summary = "Get RoxWrite web API version.")
	public ResponseEntity<ApiVersionReferenceResponse> getApiVersion() {

		LOGGER.info("Get RoxWrite web api version");

		final String version = ApiVersionUtil.getModuleVersionNumber();

		if (StringUtil.isNullOrEmpty(version)) {
			throw new ValidationException(ResponseMessages.ERROR_PROCESSING_API_VERSION);
		}

		final ApiVersionReferenceResponse apiVersionReferenceResponse = new ApiVersionReferenceResponse();
		apiVersionReferenceResponse.setVersion(version);

		return new ResponseEntity<>(apiVersionReferenceResponse, HttpStatus.OK);

	}

	@RequestMapping("/build-info")
	public HashMap<String, String> getVersion() throws IOException {

		final Properties properties = new Properties();
		properties.load(getClass().getClassLoader().getResourceAsStream("git.properties"));

		final HashMap<String, String> response = new HashMap<>();
		response.put("branch", String.valueOf(properties.get("git.branch")));
		response.put("dirty", String.valueOf(properties.get("git.dirty")));
		response.put("commit.id", String.valueOf(properties.get("git.commit.id"))); // OR
																					// properties.get("git.commit.id")
																					// depending on your configuration
		response.put("commit.abbrev", String.valueOf(properties.get("git.commit.id.abbrev")));
		response.put("commit.time", String.valueOf(properties.get("git.commit.time")));
		response.put("build.time", String.valueOf(properties.get("git.build.time")));
		response.put("build.version", String.valueOf(properties.get("git.build.version")));
		response.put("build.number", String.valueOf(properties.get("git.build.number")));

		final String version = ApiVersionUtil.getModuleVersionNumber();
		response.put("roxwrite-web-api.pom.version", version);

		return response;
	}

}
