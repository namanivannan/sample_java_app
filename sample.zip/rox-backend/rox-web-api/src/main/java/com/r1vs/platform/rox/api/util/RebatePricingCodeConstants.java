package com.r1vs.platform.rox.api.util;

public class RebatePricingCodeConstants {

	public static final String REBATE_PRICING_CODE = "rebatePricingCode";

	public static final String REBATE_PRICING_CODE_STATUS = "rebatePricingCodeStatus";

}
