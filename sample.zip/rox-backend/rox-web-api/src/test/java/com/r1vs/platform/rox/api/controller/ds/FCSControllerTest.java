package com.r1vs.platform.rox.api.controller.ds;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.JsonPath;
import com.r1vs.platform.rox.api.controller.DBConnection;
import com.r1vs.platform.rox.api.utils.BaseTest;
import com.r1vs.platform.rox.common.db.repository.ds.InteractionResponseRepository;
import com.r1vs.platform.rox.common.model.ds.InteractionResponse;
import com.r1vs.platform.rox.common.util.StringUtil;
import com.r1vs.platform.rox.interaction.fcs.connector.FCSConnector;
import com.r1vs.platform.rox.interaction.fcs.request.SearchRequest;
import com.r1vs.platform.rox.interaction.fcs.response.search.SearchInfo;
import com.r1vs.platform.rox.interaction.fcs.response.search.SearchInfoAndMetrics;
import org.apache.commons.io.IOUtils;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.util.UUID;

import static com.r1vs.platform.rox.api.controller.DBConnection.TEST_USER_1;
import static org.mockito.ArgumentMatchers.any;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.*;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@RunWith(SpringRunner.class)
@AutoConfigureMockMvc
@Sql("/com/r1vs/platform/rox/api/controller/fixture2.sql")
@ActiveProfiles("test")
public class FCSControllerTest extends BaseTest {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private FCSConnector fcsConnector;

	@Captor
	private ArgumentCaptor<SearchRequest> searchRequestCaptor;

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private DBConnection dbConnection;

	@Autowired
	private InteractionResponseRepository interactionResponseRepository;

	private String token;

	private String token_user_1;

	private String token_user_2;

	@Before
	public void setUp() throws Exception {

		if (StringUtil.isNullOrEmpty(token)) {
			token = dbConnection.loginToDb();
			token_user_1 = dbConnection.loginToDb(TEST_USER_1);
			token_user_2 = token;
		}
	}

	@Test
	public void givenWorkingFcsConnector_whenUserSearchesInUcc_thenInteractionResponsesAreDeliveredCorrectly()
			throws Exception {

		/*
		Testing business case
		include inactive fillings true propagated
		Date propagated
		 */
		SearchInfoAndMetrics mockedResponse = new SearchInfoAndMetrics();
		mockedResponse.setSearchInfo(objectMapper
				.readValue(getTextFileAsString("/payloads/fcs/sample_response_fcs.json"), SearchInfo.class));
		mockedResponse.getMetrics().setStartTime(System.currentTimeMillis());
		mockedResponse.getMetrics().setEndTime(System.currentTimeMillis());
		mockedResponse.getMetrics().setDuration(22L);

		when(fcsConnector.searchDebtorName(any(SearchRequest.class))).thenReturn(mockedResponse);

		mockMvc.perform(MockMvcRequestBuilders.post("/v1/applications/839e72fc-6433-46fd-a259-5dbb50b913d6/ucc/search")
				.content("{\n" +
						"  \"businessId\": \"839e72fc-6433-46fd-a259-5dbb50b913d6\",\n" +
						"  \"includeInactiveFilings\": true,\n" +
						"  \"date\": \"2020-12-30\"\n" +
						"}")
				.contentType(MediaType.APPLICATION_JSON)
				.header("x-client-id", "11")
				.header("Authorization", token))
				.andExpect(status().isOk())
				.andDo(print());

		Mockito.verify(fcsConnector).searchDebtorName(searchRequestCaptor.capture());

		SearchRequest generatedRequest = searchRequestCaptor.getValue();
		Assertions.assertThat(generatedRequest.getIncludeInactiveFilings()).isTrue();
		Assertions.assertThat(generatedRequest.getUpdatedSearchFrom()).isEqualTo("2020-12-30T00:00:00"); // TODO assert format with tz?
		Assertions.assertThat(generatedRequest.getSearchFirstName()).isEqualTo("");
		Assertions.assertThat(generatedRequest.getSearchLastName()).isEqualTo("");
		Assertions.assertThat(generatedRequest.getSearchOrganizationName()).isEqualTo("Brown Transportation");
		Assertions.assertThat(generatedRequest.getStateCode()).isEqualTo("NJ");

	}

	@Test
	public void givenWorkingFcsConnectorWorking_whenUserSearchesInUcc_thenInteractionResponsesAreDeliveredCorrectly()
			throws Exception {

		/*
		Testing owners case
		include inactive fillings false propagated
		payload without date
		 */
		SearchInfoAndMetrics mockedResponse = new SearchInfoAndMetrics();
		mockedResponse.setSearchInfo(objectMapper
				.readValue(getTextFileAsString("/payloads/fcs/sample_response_fcs.json"), SearchInfo.class));
		mockedResponse.getMetrics().setStartTime(System.currentTimeMillis());
		mockedResponse.getMetrics().setEndTime(System.currentTimeMillis());
		mockedResponse.getMetrics().setDuration(22L);

		when(fcsConnector.searchDebtorName(any(SearchRequest.class))).thenReturn(mockedResponse);

		mockMvc.perform(MockMvcRequestBuilders.post("/v1/applications/382b9037-5842-43e8-b99b-2f4611784cd6/ucc/search")
				.content("{\n" +
						"  \"ownerId\": \"17bd8e27-8228-40ac-afbb-ea6894e55d17\",\n" +
						"  \"includeInactiveFilings\": false\n" +
						"}")
				.contentType(MediaType.APPLICATION_JSON)
				.header("x-client-id", "11")
				.header("Authorization", token))
				.andExpect(status().isOk())
				.andDo(print());

		Mockito.verify(fcsConnector).searchDebtorName(searchRequestCaptor.capture());

		SearchRequest generatedRequest = searchRequestCaptor.getValue();
		System.out.println(generatedRequest);
		Assertions.assertThat(generatedRequest.getIncludeInactiveFilings()).isFalse();
		Assertions.assertThat(generatedRequest.getUpdatedSearchFrom()).isNull();
		Assertions.assertThat(generatedRequest.getSearchFirstName()).isEqualTo("Mickey Blue1");
		Assertions.assertThat(generatedRequest.getSearchLastName()).isEqualTo("Mouse");
		Assertions.assertThat(generatedRequest.getSearchOrganizationName()).isEqualTo("");
		Assertions.assertThat(generatedRequest.getStateCode()).isEqualTo("NJ");

	}

	@Test
	@Transactional
	public void givenValidInteractionResponseAndApplication_whenFCSDocumentEndpointIsHit_thenCreateSecondInteractionResponse() throws Exception {
		MvcResult result = mockMvc.perform(MockMvcRequestBuilders.post("/v1/fcs/839e72fc-6433-46fd-a259-5dbb50b913d6/ad5638ad-ea75-40d3-aba0-72003e7655d8/document")
						.contentType(MediaType.APPLICATION_JSON)
						.content(getTextFileAsString("/payloads/fcs/ucc_document_response.json"))
						.header("x-client-id", "11")
						.header("Authorization", token))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.provider", is("FMCSA")))
				.andExpect(jsonPath("$.name", is("FMCSA_SEARCH")))
				.andDo(print())
				.andReturn();

		InteractionResponse interactionResponse = interactionResponseRepository.getByUuid(
				UUID.fromString(JsonPath.parse(result.getResponse().getContentAsString()).read("$.uuid")));

		assertThat(interactionResponse).isNotNull();
		assertThat(interactionResponse.getInteractionResponseParent().getUuid()).isEqualTo(UUID.fromString("ad5638ad-ea75-40d3-aba0-72003e7655d8"));
	}

}