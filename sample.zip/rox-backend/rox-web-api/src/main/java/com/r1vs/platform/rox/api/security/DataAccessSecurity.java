package com.r1vs.platform.rox.api.security;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.Collection;
import java.util.Set;

/**
 * Dedicated class to handle the privileges for the current user
 */
public class DataAccessSecurity {

	/**
	 * Check if user has PHI data view access.
	 *
	 * @return
	 */
	public static boolean hasAnyOfApplicationDataAccessPrivileges() {

		return hasAnyOfThePrivileges(SecurityConstants.APPLICATION_VIEW_AUTHORITIES);
	}

	public static boolean canManageApplicationData() {

		return hasPrivilege(SecurityConstants.APPLICATION_ALL_AUTHORITY);
	}

	public static boolean canGetApplicationData() {

		return canManageApplicationData() || hasPrivilege(SecurityConstants.APPLICATION_GET_AUTHORITY);
	}

	public static boolean canListApplicationData() {

		return canManageApplicationData() || hasPrivilege(SecurityConstants.APPLICATION_LIST_AUTHORITY);
	}

	/**
	 * Check if the current user has the given privilege
	 *
	 * @param privilege String
	 * @return true if user has privilege, false otherwise
	 */
	private static boolean hasPrivilege(final GrantedAuthority privilege) {

		final Collection<? extends GrantedAuthority> userPrivileges =
				SecurityContextHolder.getContext().getAuthentication().getAuthorities();
		return userPrivileges.contains(privilege);
	}

	/**
	 * Check if the current user has any of the given privileges
	 *
	 * @param privileges Set
	 * @return true if user has any of the privileges, false otherwise
	 */
	public static boolean hasAnyOfThePrivileges(final Set<? extends GrantedAuthority> privileges) {

		// return false if user don't provide anything to check
		if (privileges == null || privileges.isEmpty()) {
			return false;
		}
		final Collection<? extends GrantedAuthority> userPrivileges =
				SecurityContextHolder.getContext().getAuthentication().getAuthorities();
		return privileges.stream().anyMatch(grantedAuthority -> userPrivileges.contains(grantedAuthority));
	}

	/**
	 * Check if the current user has all the given privileges
	 *
	 * @param privileges List
	 * @return true if user has all the privileges, false otherwise
	 */
	public static boolean hasAllOfThePrivileges(final Set<? extends GrantedAuthority> privileges) {

		// return false if user don't provide anything to check
		if (privileges == null || privileges.isEmpty()) {
			return false;
		}
		return SecurityContextHolder.getContext().getAuthentication().getAuthorities().containsAll(privileges);

	}
}
