package com.r1vs.platform.rox.api.model.role;

public class UpdateRoleRequest extends RoleRequest {

	private Integer roleId;

	public Integer getRoleId() {

		return roleId;
	}

	public void setRoleId(final Integer roleId) {

		this.roleId = roleId;
	}
}
