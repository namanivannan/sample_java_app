package com.r1vs.platform.rox.common.model.types;

import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

public enum CompoundCoverageType {

	BYPASS(0, "Bypass", "Bypass - Covered Drugs"),
	DENY(1, "Deny", "Deny - All Drugs"),
	PAY(2, "Pay",
			"Pay - Single Drug"),
	REJECT(3, "Reject", "Reject - Exclude Compounds");

	private final Integer key;

	private final String value;

	private final String description;

	CompoundCoverageType(final Integer key, final String value, final String description) {

		this.value = value;
		this.key = key;
		this.description = description;
	}

	public Integer key() {

		return this.key;
	}

	public String value() {

		return this.value;
	}

	public String description() {

		return this.description;
	}

	/**
	 * Get a map of compound coverage .
	 *
	 * @return compoundCoverageTypeMap
	 */
	public static Map<Integer, String> getCompoundCoverageTypeMap() {

		return Arrays.stream(CompoundCoverageType.values())
				.collect(Collectors.toMap(CompoundCoverageType::key, CompoundCoverageType::value));

	}

	/**
	 * Get a map of compound coverage descriptions.
	 *
	 * @return compoundCoverageTypeDescriptionMap
	 */
	public static Map<Integer, String> getCompoundCoverageTypeDescriptionMap() {

		return Arrays.stream(CompoundCoverageType.values())
				.collect(Collectors.toMap(CompoundCoverageType::key, CompoundCoverageType::description));

	}

	/**
	 * Iterate over the CompoundCoverageType enum and check if the compound coverage exists.
	 *
	 * @param compoundCoverageKey compoundCoverageKey
	 * @return CompoundCoverageType
	 */
	public static CompoundCoverageType getCompoundCoverageType(final Integer compoundCoverageKey) {

		for (final CompoundCoverageType compoundCoverageType : CompoundCoverageType.values()) {
			if (compoundCoverageType.key().equals(compoundCoverageKey)) {
				return compoundCoverageType;
			}
		}
		throw new IllegalArgumentException("Invalid compoundCoverage String.");
	}

}
