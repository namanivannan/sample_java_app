package com.r1vs.platform.rox.common.model.metadatacategories;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

public class MessageMetadata {

	private String message;

	private String messageGroupId;

	private String id;

	public String getMessageGroupId() {

		return messageGroupId;
	}

	public void setMessageGroupId(String messageGroupId) {

		this.messageGroupId = messageGroupId;
	}

	public String getMessage() {

		return message;
	}

	public void setMessage(final String message) {

		this.message = message;
	}

	public String getId() {

		return id;
	}

	public void setId(String id) {

		this.id = id;
	}

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof MessageMetadata)) {
			return false;
		}
		final MessageMetadata castOther = (MessageMetadata) other;
		return new EqualsBuilder().append(message, castOther.message).isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(message).toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("message", message).toString();
	}

}
