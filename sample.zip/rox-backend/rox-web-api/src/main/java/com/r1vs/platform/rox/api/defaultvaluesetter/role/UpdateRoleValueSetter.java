package com.r1vs.platform.rox.api.defaultvaluesetter.role;

import com.r1vs.platform.rox.api.defaultvaluesetter.RoxWriteWebApiDefaultValueSetter;
import com.r1vs.platform.rox.api.model.role.UpdateRoleRequest;
import org.springframework.stereotype.Component;

@Component
public class UpdateRoleValueSetter extends BaseRoleDefaultValueSetter
		implements RoxWriteWebApiDefaultValueSetter<UpdateRoleRequest> {

	@Override
	public void setDefaultValues(final UpdateRoleRequest updateRoleRequest) {

		setDefaultRoleSystemName(updateRoleRequest);
	}
}
