package com.r1vs.platform.rox.api.filter;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.r1vs.platform.rox.api.model.MessageResponse;
import com.r1vs.platform.rox.api.response.ResponseMessages;
import com.r1vs.platform.rox.api.util.TokenUtility;
import com.r1vs.platform.rox.common.model.users.User;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

public class JWTAuthenticationFilter extends UsernamePasswordAuthenticationFilter {

	@Value("${roxwrite.web_api.auth_token_expiration}")
	private final long authTokenExpiration;

	@Value("${roxwrite.web_api.refresh_token_expiration}")
	private final long refreshTokenExpiration;

	private final AuthenticationManager authenticationManager;

	public JWTAuthenticationFilter(final AuthenticationManager authenticationManager, final long authTokenExpiration,
			final long refreshTokenExpiration) {

		this.authenticationManager = authenticationManager;
		this.authTokenExpiration = authTokenExpiration;
		this.refreshTokenExpiration = refreshTokenExpiration;
	}

	@Override
	public Authentication attemptAuthentication(final HttpServletRequest request, final HttpServletResponse response)
			throws AuthenticationException {

		User creds = null;

		try {
			creds = new ObjectMapper().readValue(request.getInputStream(),
					User.class);

			return authenticationManager
					.authenticate(new UsernamePasswordAuthenticationToken(creds.getUsername(), creds.getPassword()));
		} catch (final IOException e) {
			return authenticationManager
					.authenticate(new UsernamePasswordAuthenticationToken("none", "none", new ArrayList<>()));
		}
	}

	@Override
	protected void successfulAuthentication(final HttpServletRequest req, final HttpServletResponse res,
			final FilterChain chain, final Authentication auth) throws IOException, ServletException {

		final String userName = ((UserDetails) auth.getPrincipal()).getUsername();

		final HashMap<String, String> tokens = TokenUtility.generateAppTokens(userName, authTokenExpiration,
				refreshTokenExpiration);

		final String responseString = TokenUtility.createResponse(tokens);

		res.setContentType(MediaType.APPLICATION_JSON_VALUE);
		res.getOutputStream().println(responseString);
		res.setStatus(HttpServletResponse.SC_OK);
	}

	@Override
	protected void unsuccessfulAuthentication(final HttpServletRequest request, final HttpServletResponse response,
			final AuthenticationException failed) throws IOException, ServletException {

		SecurityContextHolder.clearContext();

		final HashMap<String, String> responseValues = new HashMap<>();
		responseValues.put("Error", ResponseMessages.INVALID_USER_CREDENTIALS);

		final MessageResponse messageResponse = new MessageResponse();
		messageResponse.setMessage(TokenUtility.createResponse(responseValues));
		response.setContentType(MediaType.APPLICATION_JSON_VALUE);
		response.setStatus(HttpStatus.UNAUTHORIZED.value());
		response.getOutputStream().println(messageResponse.getMessage());

	}

}
