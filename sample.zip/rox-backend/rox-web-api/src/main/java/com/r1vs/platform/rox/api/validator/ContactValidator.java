package com.r1vs.platform.rox.api.validator;

import com.jsoniter.JsonIterator;
import com.jsoniter.spi.JsonException;
import com.r1vs.platform.rox.api.exception.Error;
import com.r1vs.platform.rox.common.model.ContactDetails;
import com.r1vs.platform.rox.common.model.types.ContactType;
import com.r1vs.platform.rox.common.model.types.StateAbbreviationType;
import com.r1vs.platform.rox.common.util.StringUtil;
import org.springframework.stereotype.Component;

import static com.r1vs.platform.rox.api.util.ContactConstant.*;
import static com.r1vs.platform.rox.api.util.ValidationUtil.addError;

@Component
public class ContactValidator {

	public void validateContact(final String contactJson, final Error error) {

		if (StringUtil.isNullOrEmpty(contactJson)) {
			return;
		}

		ContactDetails[] contactDetails = null;
		try {
			contactDetails = JsonIterator.deserialize(contactJson, ContactDetails[].class);
		} catch (final JsonException jsonException) {
			addError(error, CONTACT_JSON, ValidationMessages.INVALID_CONTACT_STRUCTURE, contactJson);
		}

		if (contactDetails != null && contactDetails.length != 0) {

			for (final ContactDetails contactDetailsIT : contactDetails) {
				validateState(error, contactDetailsIT.getState());
				validateContactType(error, contactDetailsIT.getContactType());
			}
		}
	}

	private void validateContactType(final Error error, final String contactType) {

		if (StringUtil.isNotNullOrEmpty(contactType) && !ContactType.getContactTypeMap().containsKey(contactType)) {
			addError(error, CONTACT_TYPE, ValidationMessages.INVALID_CONTACT_TYPE, contactType);
		}

	}

	private void validateState(final Error error, final String state) {

		if (StringUtil.isNotNullOrEmpty(state)
				&& !StateAbbreviationType.getStateAbbreviationMap().containsValue(state.toUpperCase())) {
			addError(error, STATE, ValidationMessages.INVALID_STATE, state);
		}

	}
}
