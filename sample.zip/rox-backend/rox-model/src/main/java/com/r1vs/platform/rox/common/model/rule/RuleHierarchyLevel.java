package com.r1vs.platform.rox.common.model.rule;

import com.r1vs.platform.rox.common.model.types.KeyValueEnumHelper;

import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

public enum RuleHierarchyLevel {

	MEMBER_COMPLEX(1, "Member Complex"),
	MEMBER_EXCEPTION(2, "Member Exception"),
	PRESCRIBER_COMPLEX(3,
			"Prescriber Complex"),
	PROVIDER_COMPLEX(4, "Provider Complex"),
	PLAN_COMPLEX(5,
			"Plan Complex"),
	PRESCRIBER_NETWORK_EXCEPTION(6,
			"Prescriber Network Exception"),
	PROVIDER_NETWORK_EXCEPTION(7,
			"Provider Network Exception"),
	PLAN_EXCEPTION(8,
			"Plan Exception"),
	PRESCRIBER_NETWORK_DEFAULT(9,
			"Prescriber Network Default"),
	PROVIDER_NETWORK_DEFAULT(10,
			"Provider Network Default"),
	PLAN_DEFAULT(11,
			"Plan Default"),
	PBM(12, "Pbm");

	public static final KeyValueEnumHelper<RuleHierarchyLevel, Integer, String> HELPER = KeyValueEnumHelper
			.adapt(RuleHierarchyLevel::key, RuleHierarchyLevel::value, RuleHierarchyLevel.values());

	private final Integer key;

	private final String value;

	RuleHierarchyLevel(final Integer key, final String value) {

		this.key = key;
		this.value = value;
	}

	public Integer key() {

		return key;
	}

	public String value() {

		return value;
	}

	/**
	 * Get a map of rule hierarchies .
	 *
	 * @return ruleHierarchyLevelMap
	 */
	public static Map<Integer, String> getRuleHierarchyLevelMap() {

		return Arrays.stream(RuleHierarchyLevel.values())
				.collect(Collectors.toMap(RuleHierarchyLevel::key, RuleHierarchyLevel::value));

	}

	/**
	 * Iterate over the rule hierarchy enum and check if the rule hierarchy level exists
	 *
	 * @param ruleHierarchyLevelValue ruleHierarchyLevelValue
	 * @return ruleHierarchyLevel
	 */
	public static RuleHierarchyLevel getRuleHierarchyLevel(final String ruleHierarchyLevelValue) {

		for (final RuleHierarchyLevel ruleHierarchyLevel : RuleHierarchyLevel.values()) {
			if (ruleHierarchyLevel.value().equalsIgnoreCase(ruleHierarchyLevelValue)) {
				return ruleHierarchyLevel;
			}
		}
		throw new IllegalArgumentException("Invalid rule Hierarchy Level.");
	}

}
