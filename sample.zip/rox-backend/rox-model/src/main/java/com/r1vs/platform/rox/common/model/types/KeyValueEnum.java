package com.r1vs.platform.rox.common.model.types;

public interface KeyValueEnum {

	String key();

	String value();
}
