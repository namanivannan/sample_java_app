package com.r1vs.platform.rox.api.controller.role;

import com.r1vs.platform.rox.api.defaultvaluesetter.RoxWriteWebApiDefaultValueSetter;
import com.r1vs.platform.rox.api.model.admin.ClientSearchRequestDTO;
import com.r1vs.platform.rox.api.model.admin.RoleSearchRequestDTO;
import com.r1vs.platform.rox.api.model.application.initiate.CreateRoleDTO;
import com.r1vs.platform.rox.api.model.application.initiate.RoleDTO;
import com.r1vs.platform.rox.api.model.role.*;
import com.r1vs.platform.rox.api.processor.role.RoleProcessor;
import com.r1vs.platform.rox.api.validator.RoxWriteWebApiValidator;
import com.r1vs.platform.rox.common.model.types.StatusType;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static com.r1vs.platform.rox.api.constants.ControllerConstants.X_PAGINATION_SORT;
import static com.r1vs.platform.rox.api.response.ResponseMessages.X_PAGINATION_LIMIT;
import static com.r1vs.platform.rox.api.response.ResponseMessages.X_PAGINATION_NUM;
import static com.r1vs.platform.rox.api.util.ControllerUtils.getPageableFromHeaderParams;
import static com.r1vs.platform.rox.api.util.InterceptorConstants.CLIENT_ID;

@RestController
@RequestMapping(value = "/v1", produces = { MediaType.APPLICATION_JSON_VALUE })
@Tag(name = "role", description = "Role Service")
@Validated
public class RoleController {

	private static final Logger LOGGER = LoggerFactory.getLogger(RoleController.class);

	@Autowired
	private RoleProcessor roleProcessor;

	@Autowired
	private RoxWriteWebApiValidator<CreateRoleRequest> createRoleValidator;

	@Autowired
	private RoxWriteWebApiValidator<UpdateRoleRequest> updateRoleValidator;

	@Autowired
	private RoxWriteWebApiValidator<ChangeRoleStatusRequest> changeRoleStatusValidator;

	@Autowired
	private RoxWriteWebApiDefaultValueSetter<CreateRoleRequest> createRoleRequestDefaultSetter;

	@Autowired
	private RoxWriteWebApiDefaultValueSetter<UpdateRoleRequest> updateRoleRequestDefaultSetter;

	@PostMapping("/roles")
	@Operation(summary = "Create role")
	public ResponseEntity<RoleDTO> createRole(@RequestHeader(CLIENT_ID) String clientId,
			@RequestBody @Validated final CreateRoleDTO roleDTO) {

		LOGGER.info("Role to be created: " + roleDTO);
		return new ResponseEntity<>(roleProcessor.processCreateRole(clientId, roleDTO), HttpStatus.CREATED);
	}

	@GetMapping("/roles/{roleId}")
	@Operation(summary = "SearchInfo role")
	public ResponseEntity<RoleResponse> findByRoleId(
			@PathVariable final Integer roleId) throws Exception {

		LOGGER.info("Role search");
		return roleProcessor.findByRoleId(roleId);
	}

	@GetMapping("/roles")
	@Operation(summary = "SearchInfo role")
	public ResponseEntity<List<RoleDTO>> searchRole(@RequestHeader(CLIENT_ID) String clientId,
													@RequestHeader(value = X_PAGINATION_LIMIT, defaultValue = "20") final Integer paginationLimit,
													@RequestHeader(value = X_PAGINATION_NUM, defaultValue = "0") final Integer paginationNum,
													@RequestHeader(value = X_PAGINATION_SORT, defaultValue = "createdAt,desc") String sortingParam,
                                                    @ModelAttribute RoleSearchRequestDTO searchRequest) {
		LOGGER.info("Role search");
		Pageable pageParams = getPageableFromHeaderParams(paginationLimit, paginationNum, sortingParam);
		return new ResponseEntity<>(roleProcessor.getAllRoles(clientId, searchRequest, pageParams), HttpStatus.OK );
	}

	@GetMapping("/roles/accessList")
	@Operation(summary = "Get access list")
	public ResponseEntity<AccessListResponse> getAccessList() throws Exception {

		LOGGER.info("Get access list");
		return roleProcessor.getAccessList();
	}

	@PatchMapping("/roles/{roleId}")
	@Operation(summary = "Update role")
	public ResponseEntity<RoleDTO> updateRole(@RequestHeader(CLIENT_ID) String clientId,
												   @Validated @RequestBody final RoleDTO roleDTO,
												   @PathVariable final Integer roleId) {

		LOGGER.info("Role to be update: " + roleId);
		return new ResponseEntity<>(roleProcessor.processUpdateRole(clientId, roleDTO, roleId), HttpStatus.OK);
	}

	@PutMapping(value = "/roles/delete/{roleId}")
	@Operation(summary = "Delete role")
	public ResponseEntity<RoleResponse> deleteRole(
			@PathVariable final Integer roleId,
			@RequestBody final ChangeRoleStatusRequest request) throws Exception {

		LOGGER.info("Change status on role with id: " + roleId);

		request.setRoleId(roleId);
		request.setStatusId(StatusType.DELETED.key());
		changeRoleStatusValidator.validate(request);

		return roleProcessor.processDelete(request);
	}

//	@PutMapping(value = "/roles/active/{roleId}")
//	@Operation(summary = "Active role")
//	public ResponseEntity<RoleDTO> activeRole(
//			@PathVariable final Integer roleId,
//			@RequestBody final RoleDTO updateRoleRequest) throws Exception {
//
//		updateRoleRequest.setRoleId(roleId);
//
//		updateRoleRequest.setStatusId(StatusType.ACTIVE.key());
//
//		updateRoleRequestDefaultSetter.setDefaultValues(updateRoleRequest);
//
//		LOGGER.info("Role to be update and activate: " + updateRoleRequest);
//
//		updateRoleValidator.validate(updateRoleRequest);
//
//		return roleProcessor.processUpdateRole(updateRoleRequest);
//	}

	@PutMapping(value = "/roles/inactive/{roleId}")
	@Operation(summary = "Inactive role")
	public ResponseEntity<RoleResponse> inactiveRole(
			@PathVariable final Integer roleId,
			@RequestBody final ChangeRoleStatusRequest request) throws Exception {

		LOGGER.info("Change status on role with id: " + roleId);

		request.setRoleId(roleId);
		request.setStatusId(StatusType.INACTIVE.key());
		changeRoleStatusValidator.validate(request);

		return roleProcessor.processChangeStatus(request);
	}
}
