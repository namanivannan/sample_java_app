package com.r1vs.platform.rox.common.util;

import java.text.ParseException;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FieldSetDateMapperFormatter {

	public static final Logger LOGGER = LoggerFactory.getLogger(FieldSetDateMapperFormatter.class);

	private String dateFormat;

	public FieldSetDateMapperFormatter() {

	}

	public FieldSetDateMapperFormatter(final String dateFormat) {

		this.dateFormat = dateFormat;
	}

	public void setDateFormat(final String dateFormat) {

		this.dateFormat = dateFormat;
	}

	public LocalDate getFormattedDate(final String inputString) throws ParseException {

		if (StringUtil.isNotNullOrEmpty(inputString)) {

			try {

				return LocalDate.parse(inputString, getDateTimeFormatter());

			} catch (final DateTimeParseException exception) {
				LOGGER.error("Error parsing date: " + inputString + " with format: " + dateFormat);

				throw new ParseException(exception.getMessage(), exception.getErrorIndex());
			}
		}

		return null;
	}

	public OffsetDateTime getFormattedDateTime(final String inputString) throws ParseException {

		if (StringUtil.isNotNullOrEmpty(inputString)) {
			try {
				return OffsetDateTime
						.of(LocalDate.parse(inputString, getDateTimeFormatter()).atStartOfDay(), ZoneOffset.UTC);

			} catch (final DateTimeParseException exception) {
				LOGGER.error("Error parsing date: " + inputString + " with format: " + dateFormat);

				throw new ParseException(exception.getMessage(), exception.getErrorIndex());
			}
		}

		return null;
	}

	private DateTimeFormatter getDateTimeFormatter() {

		return DateTimeFormatter.ofPattern(dateFormat);
	}
}
