package com.r1vs.platform.rox.common.model.dp;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Version;

import com.r1vs.platform.rox.common.model.AuditedEntity;

@Entity
@Table(name = "dp_data_input_registration")
public class DataInputRegistration extends AuditedEntity implements Serializable {

	private static final long serialVersionUID = 2628233015010123904L;

	@Id
	@Column(name = "id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Version
	private Integer version;

	@Column(name = "pbm_id")
	private Integer pbmId;

	@Column(name = "pbm_specific")
	private Boolean pbmSpecific;

	@Column(name = "registration_code")
	private String registrationCode;

	@Column(name = "description")
	private String description;

	@Column(name = "primary_category")
	private String primaryCategory;

	@Column(name = "secondary_category")
	private String secondaryCategory;

	@Column(name = "tertiary_category")
	private String tertiaryCategory;

	@Column(name = "quaternary_category")
	private String quaternaryCategory;

	@Column(name = "status")
	private String status;

	@OneToOne(mappedBy = "dataInputRegistration", fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	private DataProcessingConfig dataProcessingConfig;

	public Integer getId() {

		return id;
	}

	public void setId(final Integer id) {

		this.id = id;
	}

	public Integer getVersion() {

		return version;
	}

	public void setVersion(final Integer version) {

		this.version = version;
	}

	public Integer getPbmId() {

		return pbmId;
	}

	public void setPbmId(final Integer pbmId) {

		this.pbmId = pbmId;
	}

	public Boolean getPbmSpecific() {

		return pbmSpecific;
	}

	public void setPbmSpecific(final Boolean pbmSpecific) {

		this.pbmSpecific = pbmSpecific;
	}

	public String getRegistrationCode() {

		return registrationCode;
	}

	public void setRegistrationCode(final String registrationCode) {

		this.registrationCode = registrationCode;
	}

	public String getDescription() {

		return description;
	}

	public void setDescription(final String description) {

		this.description = description;
	}

	public String getStatus() {

		return status;
	}

	public void setStatus(final String status) {

		this.status = status;
	}

	public DataProcessingConfig getDataProcessingConfig() {

		return dataProcessingConfig;
	}

	public void setDataProcessingConfig(final DataProcessingConfig dataProcessingConfig) {

		this.dataProcessingConfig = dataProcessingConfig;
	}

	public String getPrimaryCategory() {

		return primaryCategory;
	}

	public void setPrimaryCategory(final String primaryCategory) {

		this.primaryCategory = primaryCategory;
	}

	public String getSecondaryCategory() {

		return secondaryCategory;
	}

	public void setSecondaryCategory(final String secondaryCategory) {

		this.secondaryCategory = secondaryCategory;
	}

	public String getTertiaryCategory() {

		return tertiaryCategory;
	}

	public void setTertiaryCategory(final String tertiaryCategory) {

		this.tertiaryCategory = tertiaryCategory;
	}

	public String getQuaternaryCategory() {

		return quaternaryCategory;
	}

	public void setQuaternaryCategory(final String quaternaryCategory) {

		this.quaternaryCategory = quaternaryCategory;
	}

}
