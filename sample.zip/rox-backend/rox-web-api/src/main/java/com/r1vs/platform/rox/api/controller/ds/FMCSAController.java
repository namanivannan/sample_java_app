package com.r1vs.platform.rox.api.controller.ds;

import com.r1vs.platform.rox.api.exception.ValidationException;
import com.r1vs.platform.rox.api.model.application.ds.InteractionResponseDTO;
import com.r1vs.platform.rox.api.processor.ds.FMCSAProcessor;
import com.r1vs.platform.rox.api.service.ds.InteractionResponseService;
import com.r1vs.platform.rox.interaction.fmcsa.response.FMCSAQueryResultDataList;
import com.r1vs.platform.rox.interaction.fmcsa.service.FMCSAService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.Size;
import java.util.UUID;

import static com.r1vs.platform.rox.api.util.InterceptorConstants.CLIENT_ID;

@RestController
@RequestMapping(value = "/v1", produces = { MediaType.APPLICATION_JSON_VALUE })
@Tag(name = "FMCSA SearchInfo Data")
public class FMCSAController {

	private static final Logger LOGGER = LoggerFactory.getLogger(FMCSAController.class);

	@Autowired
	private FMCSAProcessor fmcsaProcessor;

	@GetMapping(value = "/fmcsa/search")
	@Operation(summary = "Get FMCSA SearchInfo Data.")
	public ResponseEntity<FMCSAQueryResultDataList> search(
			@RequestParam(required = false, name = "carrierName:fuzzy") String fuzzyCarrierName,
			@RequestParam(required = false, name = "codeType") String carrierType,
			@Size(min = 1, max = 9, message = "size must be between {min} and {max}") @RequestParam(required = false,
					name = "codeValue") String codeValue) {

		validateInput(fuzzyCarrierName, carrierType, codeValue);
		LOGGER.debug("Get FMCSA SearchInfo Data with fuzzyCarrierName {} ", fuzzyCarrierName);
		return new ResponseEntity<>(
                fmcsaProcessor.performFMCSASearch(fuzzyCarrierName, carrierType, codeValue),
				HttpStatus.OK);
	}

	@GetMapping(value = "/applications/{applicationId}/fmcsa")
	@Operation(summary = "Get FMCSA SearchInfo Info for an application.")
	public ResponseEntity<InteractionResponseDTO> search(@PathVariable UUID applicationId,
			@RequestHeader(CLIENT_ID) String clientId,
			@RequestParam(required = false, name = "codeType") String carrierType,
			@Size(min = 1, max = 9, message = "size must be between {min} and {max}") @RequestParam(required = false,
					name = "codeValue") String codeValue) {

		validateInput(null, carrierType, codeValue);
		LOGGER.debug("Get FMCSA SearchInfo Data with carrierType {} codeValue {} ", carrierType, codeValue);
		return new ResponseEntity<>(
                fmcsaProcessor.getFMCSAorPull(clientId, applicationId, carrierType, codeValue),
				HttpStatus.OK);
	}

	private void validateInput(String fuzzyCarrierName,
			String carrierType, String codeValue) throws ValidationException {

		if (StringUtils.isEmpty(fuzzyCarrierName) && StringUtils.isEmpty(carrierType)
				&& StringUtils.isEmpty(codeValue)) {
			throw new ValidationException("You must provide at least name or dotNumber or mcNumber");
		}
	}

}
