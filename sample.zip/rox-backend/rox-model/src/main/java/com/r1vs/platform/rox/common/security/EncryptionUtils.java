package com.r1vs.platform.rox.common.security;


import com.r1vs.platform.rox.common.model.business.Identification;
import com.r1vs.platform.rox.common.model.ds.InteractionResponse;
import com.r1vs.platform.rox.common.security.annotations.Encrypted;
import org.springframework.core.annotation.AnnotationUtils;

import java.lang.reflect.Field;

public abstract class EncryptionUtils {
    public static boolean isFieldEncrypted(Field field) {
        return AnnotationUtils.findAnnotation(field, Encrypted.class) != null;
    }

    public static int getPropertyIndex(String name, String[] properties) {
        for (int i = 0; i < properties.length; i++) {
            if (name.equals(properties[i])) {
                return i;
            }
        }
        throw new IllegalArgumentException("No property was found for name " + name);
    }

    /**
     * Checks if Object o can be decrypted, this is to avoid unneeded checks on data that don't require to be secured
     * @param o the instance to check if it should be checked for secured fields
     * @return true if it requires security checks.
     */
    public static boolean isInEncryptionWhitelist(Object o) {
        if (o instanceof Identification) {
            return true;
        }
        if (o instanceof InteractionResponse) {
            return true;
        }
        return false;
    }

}