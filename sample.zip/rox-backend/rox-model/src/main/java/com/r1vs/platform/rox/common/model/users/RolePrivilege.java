package com.r1vs.platform.rox.common.model.users;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.r1vs.platform.rox.common.model.AuditedEntity;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@IdClass(RolePrivilegeId.class)
@Table(name = "role_privilege")
@EntityListeners(AuditingEntityListener.class)
public class RolePrivilege extends AuditedEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "role_id")
	@NotNull
	private Integer roleId;

	@Id
	@Column(name = "privilege_id")
	@NotNull
	private Integer privilegeId;

	public Integer getRoleId() {

		return roleId;
	}

	public void setRoleId(final Integer roleId) {

		this.roleId = roleId;
	}

	public Integer getPrivilegeId() {

		return privilegeId;
	}

	public void setPrivilegeId(final Integer privilegeId) {

		this.privilegeId = privilegeId;
	}

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof RolePrivilege)) {
			return false;
		}
		final RolePrivilege castOther = (RolePrivilege) other;
		return new EqualsBuilder().append(roleId, castOther.roleId).append(privilegeId, castOther.privilegeId)
				.isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(roleId).append(privilegeId).toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("roleId", roleId).append("privilegeId", privilegeId).toString();
	}

}
