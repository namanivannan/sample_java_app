package com.r1vs.platform.rox.common.model.rule;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;

import com.r1vs.platform.rox.common.model.BitemporalEntity;
import com.r1vs.platform.rox.common.model.business.Status;
import com.r1vs.platform.rox.common.model.business.Client;
import com.r1vs.platform.rox.common.util.MetadataUtil;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "rule")
public class Rule extends BitemporalEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", nullable = false)
	private Integer id;

	@Column(name = "rule_id", nullable = false)
	private Long ruleId;

	@Column(name = "client_id")
	private Integer clientId;

	@Column(name = "rule_name")
	@NotNull
	private String ruleName;

	@Column(name = "parent_criteria_id", nullable = false)
	private Long parentCriteriaId;

	@Column(name = "criteria_id", nullable = false)
	private Long criteriaId;

	@Column(name = "metadata_ids")
	private String metadataIds;

	@Column(name = "bca_id")
	private Long bcaId;

	@Column(name = "status_id")
	@NotNull
	private Integer statusId;

	@Transient
	private Integer ruleHierarchyId;

	@Transient
	private Integer ruleTypeId;

	@Transient
	private Criteria parentCriteria;

	@Transient
	private Criteria criteria;

	@Transient
	private List<Metadata> metadataList;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "status_id", nullable = false, insertable = false, updatable = false)
	private Status status;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "client_id", nullable = false, insertable = false, updatable = false)
	private Client client;

	public Integer getId() {

		return id;
	}

	public void setId(final Integer id) {

		this.id = id;
	}

	public Long getRuleId() {

		return ruleId;
	}

	public void setRuleId(final Long ruleId) {

		this.ruleId = ruleId;
	}

	public Integer getClientId() {

		return clientId;
	}

	public void setClientId(final Integer clientId) {

		this.clientId = clientId;
	}

	public String getRuleName() {

		return ruleName;
	}

	public void setRuleName(final String ruleName) {

		this.ruleName = ruleName;
	}

	public Long getParentCriteriaId() {

		return parentCriteriaId;
	}

	public void setParentCriteriaId(final Long parentCriteriaId) {

		this.parentCriteriaId = parentCriteriaId;
	}

	public Long getCriteriaId() {

		return criteriaId;
	}

	public void setCriteriaId(final Long criteriaId) {

		this.criteriaId = criteriaId;
	}

	public List<Long> getMetadataIds() {

		return MetadataUtil.getMetadataIdsFromJsonObjectString(metadataIds);
	}

	public void setMetadataIds(final List<Long> metadataIds) {

		if (CollectionUtils.isNotEmpty(metadataIds)) {
			this.metadataIds = metadataIds.toString();
		}
	}

	public Long getBcaId() {

		return bcaId;
	}

	public void setBcaId(Long bcaId) {

		this.bcaId = bcaId;
	}

	public Integer getStatusId() {

		return statusId;
	}

	public void setStatusId(final Integer statusId) {

		this.statusId = statusId;
	}

	public Integer getRuleHierarchyId() {

		return ruleHierarchyId;
	}

	public void setRuleHierarchyId(final Integer ruleHierarchyId) {

		this.ruleHierarchyId = ruleHierarchyId;
	}

	public Integer getRuleTypeId() {

		return ruleTypeId;
	}

	public void setRuleTypeId(final Integer ruleTypeId) {

		this.ruleTypeId = ruleTypeId;
	}

	public Criteria getParentCriteria() {

		return parentCriteria;
	}

	public void setParentCriteria(final Criteria parentCriteria) {

		this.parentCriteria = parentCriteria;
	}

	public Criteria getCriteria() {

		return criteria;
	}

	public void setCriteria(final Criteria criteria) {

		this.criteria = criteria;
	}

	public List<Metadata> getMetadataList() {

		return metadataList;
	}

	public void setMetadataList(final List<Metadata> metadataList) {

		this.metadataList = metadataList;
	}

	public Status getStatus() {

		return status;
	}

	public void setStatus(final Status status) {

		this.status = status;
	}

	public Client getClient() {

		return client;
	}

	public void setClient(final Client client) {

		this.client = client;
	}

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof Rule)) {
			return false;
		}
		final Rule castOther = (Rule) other;
		return new EqualsBuilder().append(id, castOther.id).append(ruleId, castOther.ruleId)
				.append(clientId, castOther.clientId).append(ruleName, castOther.ruleName)
				.append(parentCriteriaId, castOther.parentCriteriaId).append(criteriaId, castOther.criteriaId)
				.append(metadataIds, castOther.metadataIds).append(bcaId, castOther.bcaId)
				.append(statusId, castOther.statusId).append(ruleHierarchyId, castOther.ruleHierarchyId)
				.append(ruleTypeId, castOther.ruleTypeId).append(parentCriteria, castOther.parentCriteria)
				.append(criteria, castOther.criteria).append(metadataList, castOther.metadataList)
				.isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(id).append(ruleId).append(clientId).append(ruleName)
				.append(parentCriteriaId)
				.append(criteriaId).append(metadataIds).append(bcaId).append(statusId).append(ruleHierarchyId)
				.append(ruleTypeId)
				.append(parentCriteria).append(criteria).append(metadataList).toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("id", id).append("ruleId", ruleId).append("clientId", clientId)
				.append("ruleName", ruleName).append("parentCriteriaId", parentCriteriaId)
				.append("criteriaId", criteriaId).append("metadataIds", metadataIds).append("bcaId", bcaId)
				.append("statusId", statusId)
				.append("ruleHierarchyId", ruleHierarchyId).append("ruleTypeId", ruleTypeId)
				.append("parentCriteria", parentCriteria).append("criteria", criteria)
				.append("metadataList", metadataList).toString();
	}
}
