package com.r1vs.platform.rox.api.security;

import com.r1vs.platform.rox.api.interceptor.RoxWriteWebApiInterceptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebMvcConfig implements WebMvcConfigurer {

	private static final String MATCHES_ALL = "/**";

	private static final String[] ALLOWED_METHODS = { "POST", "GET", "PUT", "OPTIONS", "DELETE", "HEAD" };

	@Autowired
	private RoxWriteWebApiInterceptor roxWriteWebApiInterceptor;

	@Override
	public void addCorsMappings(final CorsRegistry registry) {

		registry.addMapping(MATCHES_ALL).allowedMethods(ALLOWED_METHODS);
	}

	@Override
	public void addInterceptors(final InterceptorRegistry registry) {

		registry.addInterceptor(roxWriteWebApiInterceptor).excludePathPatterns(SecurityConstants.AUTH_WHITELIST);
	}

}
