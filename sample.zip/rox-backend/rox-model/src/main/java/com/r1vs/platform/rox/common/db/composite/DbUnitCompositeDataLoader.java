package com.r1vs.platform.rox.common.db.composite;

import static java.util.Arrays.*;

import java.net.MalformedURLException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.dbunit.database.DatabaseConfig;
import org.dbunit.database.DatabaseConnection;
import org.dbunit.database.IDatabaseConnection;
import org.dbunit.dataset.CompositeDataSet;
import org.dbunit.dataset.DataSetException;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.xml.FlatXmlDataSetBuilder;
import org.dbunit.ext.mysql.MySqlDataTypeFactory;
import org.dbunit.operation.DatabaseOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class DbUnitCompositeDataLoader {

	private static final List<String> DATASET_FILENAMES = asList("claim-history-data.xml", "groups-data.xml",
			"medispan-drug-data.xml", "member-data.xml", "member-validation-data.xml", "metadata-data.xml",
			"plan-data.xml", "provider-data.xml",
			"rebate-pricing-data.xml", "basis-of-cost-data.xml", "criteria-data.xml", "rule-data.xml",
			"rule-member-data.xml", "system-hierarchy-code-data.xml", "system-hierarchy-config-data.xml",
			"system-hierarchy-data.xml", "override-history-data.xml", "group-member-age-rule-data.xml",
			"benefit-assignment-group-data.xml", "accumulator-data.xml");

	private static final List<String> NO_RULES_DATASET_FILENAME = asList("no-rules-exist-data.xml");

	private static final Logger LOGGER = LoggerFactory.getLogger(DbUnitCompositeDataLoader.class);

	private boolean isDataSetLoaded;

	@Autowired
	private DataSource dataSource;

	public void setDataSource(final DataSource dataSource) {

		this.dataSource = dataSource;
	}

	public void seedDbUnitData() {

		if (!isDataSetLoaded) {

			isDataSetLoaded = true;

			try {
				loadSeedDatasets(DATASET_FILENAMES);
			} catch (final Exception e) {
				LOGGER.error("Error in seedDbUnitData()", e);
			}
		}
	}

	public void emptyRules() {

		try {
			loadSeedDatasets(NO_RULES_DATASET_FILENAME);
		} catch (final Exception e) {
			LOGGER.error("Error in emptyRules()", e);
		}

		isDataSetLoaded = false;
	}

	private void loadSeedDatasets(final List<String> filenames)
			throws MalformedURLException, DataSetException, SQLException {

		final List<IDataSet> dataSetList = new ArrayList<>();
		for (final String filename : filenames) {
			final IDataSet dataSet = new FlatXmlDataSetBuilder().setColumnSensing(true)
					.build(this.getClass().getResourceAsStream(filename));
			dataSetList.add(dataSet);
		}

		final IDataSet[] dataSets = dataSetList.toArray(new IDataSet[dataSetList.size()]);

		insertCompositeSeedData(dataSets);
	}

	private void insertCompositeSeedData(final IDataSet[] dataSets) throws SQLException {

		try {

			final Connection connection = dataSource.getConnection();

			final IDatabaseConnection iDatabaseConnection = new DatabaseConnection(connection);

			final DatabaseConfig config = iDatabaseConnection.getConfig();
			config.setProperty(DatabaseConfig.FEATURE_ALLOW_EMPTY_FIELDS, true);
			config.setProperty(DatabaseConfig.PROPERTY_DATATYPE_FACTORY, new MySqlDataTypeFactory());

			DatabaseOperation.CLEAN_INSERT.execute(iDatabaseConnection, new CompositeDataSet(dataSets));

			iDatabaseConnection.close();
			connection.close();

		} catch (final Exception e) {
			LOGGER.error("Error in insertCompositeSeedData()", e);
		}
	}
}
