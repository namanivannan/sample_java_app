# RoxWrite Common README


## Getting started
This project is contains shared entities, dao objects, utility classes, and database migrations.

* Database setup:
    * create local database: roxwrite_local
	* create user: roxwrite, password: roxwrite
	* see roxwrite-parent-pom README for database connection configuration
* Prepare build:
    * project dependencies:
		* roxwrite-parent-pom
    * run: ```mvn clean install``` from project root
* Database migrations:
	* run (all outstanding) migrations:
		* ```mvn liquibase:update```
			* liquibase will use provided config/liquibase.properties file by default; this will work for local development purposes
			* to supply an alternative: ```mvn liquibase:update -Dliquibase.propertyFile=/Users/roxwrite/liquibase-dev.properties``` (must use absolute path)
			* alternatively, one can use the liquibase.jar file directly; details <a href="https://www.liquibase.org/documentation/command_line.html">here</a>.
	* rollback migrations (roll back n migrations, where n=1):
		* ```mvn liquibase:rollback -Dliquibase.rollbackCount=1```
	* to create a new migration (creates migration file for 'users' table with boilerplate code):
		* ```./migration:make create_users_table```
	* to run migration that seeds test data, use contexts=dev
		* ```mvn liquibase:update -Dliquibase.contexts=dev```
		* if no context is specified, mvn will run all migrations by default, however, this is now being overridden such that running: ```mvn liquibase:update``` effectively runs -> ```mvn liquibase:update -Dliquibase.contexts=qa``` 
		* if an unknown context is specified, ie: ```-Dliquibase.contexts=prod```, mvn will run all migrations, excluding ones where the specified context does not match (ie. all migrations marked with context="dev")
		* if a liquibase command is aborted, the db locks will not be released, you can force a lock release by running ```mvn liquibase:releaseLocks```
