package com.r1vs.platform.rox.common.model.metadatacategories;

import java.util.Arrays;
import java.util.List;

public final class MetadataCategoryConstants {

	public static final Integer AGE_LIMIT_EDIT_CATEGORY_ID = 1;

	public static final Integer CLAIM_DOLLAR_MIN_MAX_EDIT_CATEGORY_ID = 2;

	public static final Integer DAW_EDIT_CATEGORY_ID = 3;

	public static final Integer DAYS_SUPPLY_LIMIT_EDIT_CATEGORY_ID = 4;

	public static final Integer SMALLEST_PACKAGE_SIZE_EDIT_CATEGORY_ID = 5;

	public static final Integer QUANTITY_LIMIT_EDIT_CATEGORY_ID = 6;

	public static final Integer QUANTITY_PER_DAY_EDIT_CATEGORY_ID = 7;

	public static final Integer OVERRIDES_EDIT_CATEGORY_ID = 8;

	public static final Integer REFILL_LIMIT_EDIT_CATEGORY_ID = 9;

	public static final Integer FILING_LIMIT_EDIT_CATEGORY_ID = 10;

	public static final Integer DEDUCTIBLE_EDIT_CATEGORY_ID = 12;

	public static final Integer DISPENSE_FEE_EDIT_CATEGORY_ID = 13;

	public static final Integer INCENTIVE_FEE_EDIT_CATEGORY_ID = 14;

	public static final Integer INGREDIENT_COST_EDIT_CATEGORY_ID = 15;

	public static final Integer POS_REBATE_EDIT_CATEGORY_ID = 16;

	public static final Integer MEMBER_OUT_OF_POCKET_MAX_EDIT_CATEGORY_ID = 19;

	public static final Integer PLAN_AMOUNT_STOP_LOSS_EDIT_CATEGORY_ID = 20;

	public static final Integer FORMULARY_OPEN_FLAG_TYPE_ID = 23;

	public static final Integer FORMULARY_CLOSED_FLAG_TYPE_ID = 24;

	public static final Integer BENEFIT_COVERAGE_FLAG_TYPE_ID = 25;

	public static final Integer PREFERRED_DRUG_FLAG_TYPE_ID = 26;

	public static final Integer PRIOR_AUTHORIZATION_FLAG_TYPE_ID = 27;

	public static final Integer PROGRAM_ADMIN_FEE_EDIT_CATEGORY_ID = 28;

	public static final Integer POS_REBATE_COVERAGE_FLAG_TYPE_ID = 29;

	public static final List<Integer> FORMULARY_COVERAGE_FLAG_TYPE_ID = Arrays.asList(23, 24);

	public static final Integer OTHER_SERVICES_FEE_EDIT_CATEGORY_ID = 30;

	public static final Integer COPAY_COINSURANCE_EDIT_CATEGORY_ID = 31;

	public static final Integer BRAND_CLASS_EDIT_CATEGORY_ID = 32;

	public static final Integer REFILL_TOO_SOON_EDIT_CATEGORY_ID = 33;

	public static final Integer DAYS_SUPPLY_MAX_ACCUMULATION_EDIT_CATEGORY_ID = 34;

	public static final Integer UNITS_MAX_ACCUMULATION_EDIT_CATEGORY_ID = 35;

	public static final Integer FILLS_MAX_ACCUMULATION_EDIT_CATEGORY_ID = 36;

	public static final Integer QUANTITY_MAX_ACCUMULATION_EDIT_CATEGORY_ID = 37;

	public static final Integer PLAN_PAY_MAX_ACCUMULATION_EDIT_CATEGORY_ID = 38;

	public static final List<Integer> BENIFIT_MAX_EDIT_CATEGORY_IDS =
			Arrays.asList(DAYS_SUPPLY_MAX_ACCUMULATION_EDIT_CATEGORY_ID, UNITS_MAX_ACCUMULATION_EDIT_CATEGORY_ID,
					FILLS_MAX_ACCUMULATION_EDIT_CATEGORY_ID, QUANTITY_MAX_ACCUMULATION_EDIT_CATEGORY_ID,
					PLAN_PAY_MAX_ACCUMULATION_EDIT_CATEGORY_ID);

	public static final List<Integer> ACCUMULATION_EDIT_CATEGORY_IDS =
			Arrays.asList(DAYS_SUPPLY_MAX_ACCUMULATION_EDIT_CATEGORY_ID, UNITS_MAX_ACCUMULATION_EDIT_CATEGORY_ID,
					FILLS_MAX_ACCUMULATION_EDIT_CATEGORY_ID, QUANTITY_MAX_ACCUMULATION_EDIT_CATEGORY_ID,
					PLAN_PAY_MAX_ACCUMULATION_EDIT_CATEGORY_ID, DEDUCTIBLE_EDIT_CATEGORY_ID,
					MEMBER_OUT_OF_POCKET_MAX_EDIT_CATEGORY_ID,
					PLAN_AMOUNT_STOP_LOSS_EDIT_CATEGORY_ID);

	public static final Integer SAFETY_EDITS_EDIT_CATEGORY_ID = 39;

	public static final Integer STEP_THERAPY_EDIT_CATEGORY_ID = 40;

	private MetadataCategoryConstants() {

	}
}
