package com.r1vs.platform.rox.api.model.role;

public class AccessRequestedResponse {

	private String access;

	public String getAccess() {

		return access;
	}

	public void setAccess(final String access) {

		this.access = access;
	}

}
