package com.r1vs.platform.rox.api.validator.user;

import com.google.common.base.Joiner;
import org.passay.*;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class PasswordConstraintValidator implements ConstraintValidator<ValidPassword, String> {

	@Override
	public void initialize(final ValidPassword arg0) {

	}

	@Override
	public boolean isValid(final String password, final ConstraintValidatorContext context) {

		if (password == null) {
			return true;
		}

		final LengthRule lengthRule = new LengthRule();
		lengthRule.setMinimumLength(8);

		final CharacterCharacteristicsRule characterRule = new CharacterCharacteristicsRule();

		// Define M (4 in this case)
		characterRule.setNumberOfCharacteristics(4);
		// Senthil : Changed to 4 to accept minimum one upper and one lower case character

		// Define elements of N (upper, lower, digit, symbol)
		characterRule.getRules().add(new CharacterRule(EnglishCharacterData.UpperCase, 1));
		characterRule.getRules().add(new CharacterRule(EnglishCharacterData.LowerCase, 1));
		characterRule.getRules().add(new CharacterRule(EnglishCharacterData.Digit, 1));
		characterRule.getRules().add(new CharacterRule(EnglishCharacterData.Special, 1));

		final WhitespaceRule whitespaceRule = new WhitespaceRule();

		final PasswordValidator validator = new PasswordValidator(lengthRule, characterRule, whitespaceRule);

		final RuleResult result = validator.validate(new PasswordData(password));
		if (result.isValid()) {
			return true;
		}

		context.disableDefaultConstraintViolation();
		context.buildConstraintViolationWithTemplate(Joiner.on(", ").join(validator.getMessages(result)).trim())
				.addConstraintViolation();

		return false;
	}
}
