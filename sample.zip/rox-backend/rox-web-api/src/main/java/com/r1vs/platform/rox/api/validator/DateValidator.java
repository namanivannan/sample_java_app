package com.r1vs.platform.rox.api.validator;

import com.r1vs.platform.rox.api.exception.Error;
import com.r1vs.platform.rox.api.response.ResponseMessages;
import com.r1vs.platform.rox.common.util.StringUtil;
import org.springframework.stereotype.Component;

import static com.r1vs.platform.rox.api.util.ValidationUtil.addErrorAndHandle;

@Component
public class DateValidator implements RoxWriteWebApiValidator<String> {

	public final static String DATE_OF_SERVICE = "dateOfService";

	@Override
	public void validate(final String dateOfService) {

		final Error error = new Error();

		if (StringUtil.isNullOrEmpty(dateOfService)) {
			addErrorAndHandle(error, DATE_OF_SERVICE, ResponseMessages.DATE_OF_SERVICE_CANNOT_BE_NULL, dateOfService);
		}
	}
}
