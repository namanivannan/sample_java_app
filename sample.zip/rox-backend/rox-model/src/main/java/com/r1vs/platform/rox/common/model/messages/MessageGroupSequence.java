package com.r1vs.platform.rox.common.model.messages;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "message_group_sequence")
public class MessageGroupSequence implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "message_group_sequence_id", nullable = false)
	private Integer messageGroupSequenceId;

	public Integer getMessageGroupSequenceId() {

		return messageGroupSequenceId;
	}

	public void setMessageGroupSequenceId(final Integer messageGroupSequenceId) {

		this.messageGroupSequenceId = messageGroupSequenceId;
	}

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof MessageGroupSequence)) {
			return false;
		}
		final MessageGroupSequence castOther = (MessageGroupSequence) other;
		return new EqualsBuilder().append(messageGroupSequenceId, castOther.messageGroupSequenceId).isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(messageGroupSequenceId).toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("messageGroupSequenceId", messageGroupSequenceId).toString();
	}
}
