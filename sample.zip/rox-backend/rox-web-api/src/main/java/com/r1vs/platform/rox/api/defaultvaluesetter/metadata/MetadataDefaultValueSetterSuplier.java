package com.r1vs.platform.rox.api.defaultvaluesetter.metadata;

import com.google.common.base.Supplier;
import com.r1vs.platform.rox.api.exception.Error;
import com.r1vs.platform.rox.api.exception.ErrorResponse;
import com.r1vs.platform.rox.api.util.MetadataConstants;
import com.r1vs.platform.rox.api.util.ValidationUtil;
import com.r1vs.platform.rox.api.validator.ValidationMessages;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

@Component
public class MetadataDefaultValueSetterSuplier {

	private Map<Integer, Supplier<MetadataDefaultValueSetter>> setterSupplier;

	@PostConstruct
	public void init() {

		final Map<Integer, Supplier<MetadataDefaultValueSetter>> setters = new HashMap<>();

		setterSupplier = Collections.unmodifiableMap(setters);

	}

	/**
	 * Validate metadatacategoryId and return the validator
	 *
	 * @param metadataCategoryId metadataCategoryId
	 *
	 * @return validator
	 */
	public MetadataDefaultValueSetter supplyValidator(final Integer metadataCategoryId) {

		final Supplier<MetadataDefaultValueSetter> setter = setterSupplier.get(metadataCategoryId);

		final Error error = new Error();

		if (setter == null) {
			error.addErrorResponse(new ErrorResponse(MetadataConstants.METADATA_CATEGORY_ID,
					ValidationMessages.INVALID_METADATA_CATEGORY_ID, metadataCategoryId));
		}

		ValidationUtil.handleException(error);

		return setter.get();
	}

}
