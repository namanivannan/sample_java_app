package com.r1vs.platform.rox.api.util;

import com.r1vs.platform.rox.common.model.types.StatusType;

public class GroupPlanConstants {

	public static final Integer ACTIVE_STATUS = StatusType.ACTIVE.key();

	public static final String STATUS = "groupStatus";

	public static final String GROUP_PLAN_ID = "groupPlanId";

	public static final String GROUP_ID = "groupId";

	public static final String PLAN_ID = "planId";

	public static final String ACTION_FOR_PLAN_MAX = "actionForPlanMax";

	public static final String COB_METHOD = "cobMethod";

	public static final String OPPAP_SETTINGS = "opapSettings";

	public static final String OPPRA_SETTINGS = "oppraSettings";

	public static final String COB_NOT_COVERED = "cobNotCovered";

	public static final String COB_PAYMENT_REJECT = "cobPaymentReject";

	public static final String COB_PAYMENT_ORDER = "cobPaymentOrder";

	public static final String COMPOUND_COVERAGE = "compoundCoverage";

	public static final String COST_AVOIDANCE_METHOD = "costAvoidanceMethod";

	public static final String DISPENSING_FEE_METHOD = "dispensingFeeMethod";

	public static final String MEMBER_FINANCIAL_RESPONSIBILITY = "memberFinancialResponsibility";

	public static final String COB_REJECTED = "cobRejected";

	public static final String INVALID_VALUE = "This field should not have value";

	public static final String INVALID_TRUE = "This field should not be true";

	public static final String COB_COVERAGE_LEVEL = "cobCoverageLevel";

	public static final String COB_COST_AVOIDANCE = "costAvoidance";

	public static final String INVALID_COVERAGE_LEVEL = "cobCoverageLevel";

	public static final String OTHER_COVERAGE_CODE = "otherCoverageCode";

	public static final String PRORATION = "proration";

	public static final String REJECT_PROVIDER = "rejectProvider";

	public static final String REQUIRE_OTHER_PAYER_AMOUNT_PAID = "requireOtherPayerAmountPaid";

	public static final String REQUIRE_OTHER_PAYER = "requireOtherPayer";

}
