package com.r1vs.platform.rox.common.model.memberenrollment;

import com.r1vs.platform.rox.common.model.AuditedEntity;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Set;

@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "member")
public class Member extends AuditedEntity implements Serializable {

	private static final long serialVersionUID = 2098234097234L;

	@Id
	@Column(name = "member_id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer memberId;

	@Column(name = "pbm_id")
	private Integer pbmId;

	@Transient
	private MemberProfile memberProfile;

	@OneToMany(mappedBy = "member", fetch = FetchType.LAZY)
	private Set<MemberProfile> memberProfiles;

	@OneToMany(mappedBy = "member", fetch = FetchType.LAZY)
	private Set<MemberAlias> memberAlias;

	@Column(name = "input_id")
	private String inputId;

	public Integer getMemberId() {

		return memberId;
	}

	public void setMemberId(final Integer memberId) {

		this.memberId = memberId;
	}

	public MemberProfile getMemberProfile() {

		return memberProfile;
	}

	public void setMemberProfile(final MemberProfile memberProfile) {

		this.memberProfile = memberProfile;
	}

	public Set<MemberProfile> getMemberProfiles() {

		return memberProfiles;
	}

	public void setMemberProfiles(final Set<MemberProfile> memberProfiles) {

		this.memberProfiles = memberProfiles;
	}

	public Set<MemberAlias> getMemberAlias() {

		return memberAlias;
	}

	public void setMemberAlias(final Set<MemberAlias> memberAlias) {

		this.memberAlias = memberAlias;
	}

	public Integer getPbmId() {

		return pbmId;
	}

	public void setPbmId(final Integer pbmId) {

		this.pbmId = pbmId;
	}

	public String getInputId() {

		return inputId;
	}

	public void setInputId(final String inputId) {

		this.inputId = inputId;
	}

	/**
	 * Note: Regenerating equals, hashCode, and toString may re-introduce purposely removed related entities which cause
	 * lazy load exceptions after session has been closed. Please exclude relationships from these methods.
	 */

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof Member)) {
			return false;
		}
		final Member castOther = (Member) other;
		return new EqualsBuilder().append(memberId, castOther.memberId).isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(memberId).toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("memberId", memberId).toString();
	}

}
