package com.r1vs.platform.rox.api.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.r1vs.platform.rox.api.model.CreateUserRequest;
import com.r1vs.platform.rox.api.model.application.initiate.ChangePasswordDTO;
import com.r1vs.platform.rox.api.model.application.initiate.CheckEmailDTO;
import com.r1vs.platform.rox.api.model.application.initiate.UpdateUserDTO;
import com.r1vs.platform.rox.api.repository.UserRoleRepository;
import com.r1vs.platform.rox.common.db.repository.core.UserRepository;
import com.r1vs.platform.rox.common.model.users.User;
import com.r1vs.platform.rox.common.model.users.UserRole;
import com.r1vs.platform.rox.common.util.StringUtil;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;

import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.CoreMatchers.is;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@Sql("fixture2.sql")
public class UserControllerTest {

	private static String token, admToken, tokenTestUser, tokenTestUser6;

	@Autowired
	ObjectMapper objectMapper;

	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private DBConnection dbConnection;

	@Autowired
	private UserRoleRepository userRoleRepository;

	@Autowired
	private UserRepository userRepository;

	@Before
	public void setUp() throws Exception {

		if (StringUtil.isNullOrEmpty(token)) {
			token = dbConnection.loginToDb();
			admToken = dbConnection.loginToDb(DBConnection.ADMIN);
			tokenTestUser = dbConnection.loginToDb(DBConnection.TEST_USER_3);
			tokenTestUser6 = dbConnection.loginToDb(DBConnection.TEST_USER_6);
		}
	}

	@Test
	public void givenCreateUserRequest_whenCreateUser_ThenStatus200() throws Exception {

		CreateUserRequest userRequest = new CreateUserRequest();
		userRequest.setPhone("123");
		userRequest.setUsername("pipe8");
		userRequest.setFirstName("FirstName");
		userRequest.setLastName("LastName");
		userRequest.setPhoneTypeId(1);
		userRequest.setEmail("pipe8@gmail.com");
		userRequest.setPassword("12345678");
		userRequest.setUserRoles(new ArrayList<>());
		userRequest.getUserRoles().add("CLIENT_ADMIN");
		MvcResult mvcResult = mockMvc.perform(post("/v1/users")
				.header(AUTHORIZATION, token)
				.header("x-client-id", "11")
				.contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(userRequest)))
				.andExpect(status().isCreated())
				.andExpect(jsonPath("$.message", is("User pipe8 created successfully.")))
				.andReturn();

		Long userId = userRepository.findByUsername("pipe8").get().getUserId();

		assertThat(userRoleRepository.findByUserId(userId).get(0).getRole().getSystemName())
				.isEqualTo("CLIENT_ADMIN");
	}

	@Test
	public void givenCreateUserRequest_whenUsernameAlreadyRegistered_ThenStatus400() throws Exception {

		CreateUserRequest userRequest = new CreateUserRequest();
		userRequest.setPhone("123");
		userRequest.setUsername("roxsysadm");
		userRequest.setFirstName("FirstName");
		userRequest.setLastName("LastName");
		userRequest.setPhoneTypeId(1);
		userRequest.setEmail("pipe8@gmail.com");
		userRequest.setPassword("12345678");
		mockMvc.perform(post("/v1/users")
				.header(AUTHORIZATION, token)
				.header("x-client-id", "11")
				.contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(userRequest)))
				.andExpect(status().isBadRequest());
	}

	@Test
	public void givenValidClientId_whenListUsersEndpointIsHit_thenStatus200() throws Exception {

		mockMvc.perform(get("/v1/users")
						.header(AUTHORIZATION, token)
						.header("x-client-id", "11")
						.header("X-PAGINATION-LIMIT", 2)
						.header("X-Pagination-Sort", "createdAt,asc")
						.header("X-PAGINATION-NUM", 0))
				.andExpect(status().isPartialContent())
				.andExpect(jsonPath("$[0].username", is("roxadmin3")))
				.andExpect(jsonPath("$[0].userId", is(13)))
				.andExpect(jsonPath("$[1].username", is("roxadmin")))
				.andExpect(jsonPath("$[1].userId", is(11)))
				.andExpect(jsonPath("$.[1].roles[0]", is("Test Role")))
				.andDo(print());
	}

	@Test
	public void givenValidClientId_whenListAllUsersEndpointIsHit_thenStatus200() throws Exception {

		mockMvc.perform(get("/v1/users")
						.header(AUTHORIZATION, token)
						.header("x-client-id", "11")
						.header("X-PAGINATION-LIMIT", 3)
						.header("X-Pagination-Sort", "createdAt,asc")
						.header("X-PAGINATION-NUM", 0))
				.andExpect(status().isPartialContent())
				.andExpect(jsonPath("$[0].username", is("roxadmin3")))
				.andExpect(jsonPath("$[0].userId", is(13)))
				.andExpect(jsonPath("$[1].username", is("roxadmin")))
				.andExpect(jsonPath("$[1].userId", is(11)))
				.andExpect(jsonPath("$.[1].roles[0]", is("Test Role")))
				.andExpect(jsonPath("$[2].username", is("roxadmin4")))
				.andExpect(jsonPath("$[2].userId", is(14)))
				.andDo(print());
	}

	@Test
	public void givenNotValidClientId_whenListUsersEndpointIsHit_thenStatus400() throws Exception {

		mockMvc.perform(get("/v1/users")
				.header(AUTHORIZATION, token)
				.header("x-client-id", "1")
				.header("X-PAGINATION-LIMIT", 1)
				.header("X-PAGINATION-NUM", 0))
				.andExpect(status().isBadRequest());
	}

	@Test
	public void givenActiveUser_whenInactivateUserEndpointIsHit_thenInactivateUserAndReturn200() throws Exception {

		mockMvc.perform(post("/v1/users/12/disable")
				.header(AUTHORIZATION, token))
				.andExpect(status().isOk());
	}

	@Test
	public void givenInactiveUser_whenInactivateUserEndpointIsHit_thenReturn400() throws Exception {

		mockMvc.perform(post("/v1/users/3/disable")
				.header(AUTHORIZATION, token))
				.andExpect(status().isBadRequest());
	}

	@Test
	public void givenInactiveUser_whenActivateUserEndpointIsHit_thenActivateUserAndReturn200() throws Exception {

		mockMvc.perform(post("/v1/users/13/enable")
				.header(AUTHORIZATION, token))
				.andExpect(status().isOk());
	}

	@Test
	public void givenActiveUser_whenActivateUserEndpointIsHit_thenReturn400() throws Exception {

		mockMvc.perform(post("/v1/users/2/enable")
						.header(AUTHORIZATION, token))
				.andExpect(status().isBadRequest());
	}

	@Test
	public void givenValidUser_whenUpdateUserEndpointIsHit_thenUpdateUserAndReturn200() throws Exception {

		UpdateUserDTO updateUserDTO = new UpdateUserDTO();
		updateUserDTO.setUsername("roxadminUpdated");
		updateUserDTO.setEmail("updatedEmail@gmail.com");
		updateUserDTO.setFirstName("UpdatedName");
		updateUserDTO.setLastName("updatedLastName");
		updateUserDTO.setPhone("321321321");

		mockMvc.perform(patch("/v1/users/11")
						.header(AUTHORIZATION, token)
						.header("x-client-id", "11")
						.contentType(MediaType.APPLICATION_JSON)
						.content(objectMapper.writeValueAsString(updateUserDTO)))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.message", is("User roxadminUpdated updated successfully.")))
				.andDo(print());



		User user = userRepository.findByUsername("roxadminUpdated").get();

		assertThat(user.getEmail()).isEqualTo("updatedEmail@gmail.com");
		assertThat(user.getPhone()).isEqualTo("321321321");
		assertThat(user.getFirstName()).isEqualTo("UpdatedName");
		assertThat(user.getLastName()).isEqualTo("updatedLastName");
	}

	@Test
	public void givenValidUserAndRoles_whenUpdateUserEndpointIsHit_thenUpdateUserAndReturn200() throws Exception {

		UpdateUserDTO updateUserDTO = new UpdateUserDTO();
		updateUserDTO.setUsername("roxadminUpdated");
		updateUserDTO.setEmail("updatedEmail@gmail.com");
		updateUserDTO.setFirstName("UpdatedName");
		updateUserDTO.setLastName("updatedLastName");
		updateUserDTO.setPhone("321321321");

		updateUserDTO.setRoles(new ArrayList<>());
		updateUserDTO.getRoles().add("TEST_ROLE1");
		updateUserDTO.getRoles().add("TEST_ROLE2");

		mockMvc.perform(patch("/v1/users/11")
						.header(AUTHORIZATION, token)
						.header("x-client-id", "11")
						.contentType(MediaType.APPLICATION_JSON)
						.content(objectMapper.writeValueAsString(updateUserDTO)))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.message", is("User roxadminUpdated updated successfully.")))
				.andDo(print());



		User user = userRepository.findByUsername("roxadminUpdated").get();

		List<UserRole> userRoles = userRoleRepository.findByUserId(user.getUserId());

		assertThat(user.getEmail()).isEqualTo("updatedEmail@gmail.com");
		assertThat(user.getPhone()).isEqualTo("321321321");
		assertThat(user.getFirstName()).isEqualTo("UpdatedName");
		assertThat(user.getLastName()).isEqualTo("updatedLastName");
		assertThat(userRoles.get(0).getRole().getSystemName()).isEqualTo("TEST_ROLE1");
		assertThat(userRoles.get(1).getRole().getSystemName()).isEqualTo("TEST_ROLE2");
		assertThat(userRoles.size()).describedAs("Old roles have been removed").isEqualTo(2);
	}

	@Test
	public void givenValidUserAndROXADMINROLE_whenUpdateUserEndpointIsHit_thenThrow403() throws Exception {

		UpdateUserDTO updateUserDTO = new UpdateUserDTO();
		updateUserDTO.setUsername("roxadminUpdated");
		updateUserDTO.setEmail("updatedEmail@gmail.com");
		updateUserDTO.setFirstName("UpdatedName");
		updateUserDTO.setLastName("updatedLastName");
		updateUserDTO.setPhone("321321321");

		updateUserDTO.setRoles(new ArrayList<>());
		updateUserDTO.getRoles().add("TEST_ROLE1");
		updateUserDTO.getRoles().add("ROX_ADMIN");

		mockMvc.perform(patch("/v1/users/11")
						.header(AUTHORIZATION, token)
						.header("x-client-id", "11")
						.contentType(MediaType.APPLICATION_JSON)
						.content(objectMapper.writeValueAsString(updateUserDTO)))
				.andExpect(status().isForbidden())
				.andExpect(jsonPath("$[0].message", is("ROX_ADMIN CANNOT BE ASSIGNED")))
				.andDo(print());
	}

	@Test
	public void givenValidCustomerUserAndOldPassword_whenChangePasswordEndpointIsHit_thenChangesPasswordSuccessfully() throws Exception{

		ChangePasswordDTO changePasswordDTO = new ChangePasswordDTO();
		changePasswordDTO.oldPassword = "123456";
		changePasswordDTO.newPassword= "654321";

		mockMvc.perform(post("/v1/user/change-password")
						.contentType(MediaType.APPLICATION_JSON)
						.header("x-client-id", "11")
						.header(AUTHORIZATION, tokenTestUser6)
						.content(objectMapper.writeValueAsString(changePasswordDTO)))
				.andExpect(status().isOk())
				.andDo(print());

		Map<String, String> login = new HashMap<>();
		login.put("username", "roxUser2");
		login.put("password", "654321");
		mockMvc.perform(post("/login")
						.contentType(MediaType.APPLICATION_JSON)
						.content(objectMapper.writeValueAsString(login)))
				.andExpect(status().isOk())
				.andDo(print());
	}

	@Test
	public void givenValidCustomerUserAndWrongOldPassword_whenChangePasswordEndpointIsHit_thenThrows401() throws Exception{

		ChangePasswordDTO changePasswordDTO = new ChangePasswordDTO();
		changePasswordDTO.oldPassword = "1234567";
		changePasswordDTO.newPassword= "654321";

		mockMvc.perform(post("/v1/user/change-password")
						.contentType(MediaType.APPLICATION_JSON)
						.header("x-client-id", "11")
						.header(AUTHORIZATION, tokenTestUser6)
						.content(objectMapper.writeValueAsString(changePasswordDTO)))
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("$[0].message", is("Wrong old password")))
				.andDo(print());
	}

	@Test
	public void givenCustomerLogin_whenAdminChangePasswordEndpointIsHit_thenThrows403() throws Exception{

		ChangePasswordDTO changePasswordDTO = new ChangePasswordDTO();
		changePasswordDTO.newPassword= "654321";

		mockMvc.perform(post("/v1/users/15/change-password")
						.contentType(MediaType.APPLICATION_JSON)
						.header(AUTHORIZATION, tokenTestUser6)
						.content(objectMapper.writeValueAsString(changePasswordDTO)))
				.andExpect(status().isForbidden())
				.andDo(print());
	}


	@Test
	public void givenAdminLoginAndOld_whenAdminChangePasswordEndpointIsHit_thenChangesPasswordSuccessfully() throws Exception{

		ChangePasswordDTO changePasswordDTO = new ChangePasswordDTO();
		changePasswordDTO.newPassword= "654321";

		mockMvc.perform(post("/v1/users/15/change-password")
						.contentType(MediaType.APPLICATION_JSON)
						.header(AUTHORIZATION, admToken)
						.content(objectMapper.writeValueAsString(changePasswordDTO)))
				.andExpect(status().isOk())
				.andDo(print());

		Map<String, String> login = new HashMap<>();
		login.put("username", "roxUser");
		login.put("password", "654321");
		mockMvc.perform(post("/login")
						.contentType(MediaType.APPLICATION_JSON)
						.content(objectMapper.writeValueAsString(login)))
				.andExpect(status().isOk())
				.andDo(print());
	}

	@Test
	public void givenCreateUserRequestWithAlreadyStoredEmail_whenCreateUser_ThenReturn400() throws Exception {

		CreateUserRequest userRequest = new CreateUserRequest();
		userRequest.setPhone("123");
		userRequest.setUsername("pipe9");
		userRequest.setFirstName("FirstName");
		userRequest.setLastName("LastName");
		userRequest.setPhoneTypeId(1);
		userRequest.setEmail("roxwrite-admin@roxwrite.com");
		userRequest.setPassword("12345678");
		userRequest.setUserRoles(new ArrayList<>());
		userRequest.getUserRoles().add("CLIENT_ADMIN");

		mockMvc.perform(post("/v1/users")
						.header(AUTHORIZATION, token)
						.header("x-client-id", "11")
						.contentType(MediaType.APPLICATION_JSON)
						.content(objectMapper.writeValueAsString(userRequest)))
				.andExpect(status().isBadRequest())
				.andDo(print());
	}

	@Test
	public void givenValidEmail_whenCheckEmailEndpointIsHit_ThenReturnOK() throws Exception {

		CheckEmailDTO checkEmailDTO = new CheckEmailDTO();
		checkEmailDTO.setEmail("roxwrite-admin@roxwrite.com");

		mockMvc.perform(get("/v1/users/checkEmail")
						.header(AUTHORIZATION, token)
						.header("x-client-id", "11")
						.contentType(MediaType.APPLICATION_JSON)
						.content(objectMapper.writeValueAsString(checkEmailDTO)))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.exists", is(true)))
				.andDo(print());
	}

	@Test
	public void givenNotValidEmail_whenCheckEmailEndpointIsHit_ThenReturn400() throws Exception {

		CheckEmailDTO checkEmailDTO = new CheckEmailDTO();
		checkEmailDTO.setEmail("notValidEmailToCheck");

		mockMvc.perform(get("/v1/users/checkEmail")
						.header(AUTHORIZATION, token)
						.header("x-client-id", "11")
						.contentType(MediaType.APPLICATION_JSON)
						.content(objectMapper.writeValueAsString(checkEmailDTO)))
				.andExpect(status().isBadRequest())
				.andDo(print());
	}

	@Test
	public void givenNotStoredEmail_whenCheckEmailEndpointIsHit_ThenReturn400() throws Exception {

		CheckEmailDTO checkEmailDTO = new CheckEmailDTO();
		checkEmailDTO.setEmail("roxwr@roxwrite.com");

		mockMvc.perform(get("/v1/users/checkEmail")
						.header(AUTHORIZATION, token)
						.header("x-client-id", "11")
						.contentType(MediaType.APPLICATION_JSON)
						.content(objectMapper.writeValueAsString(checkEmailDTO)))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.exists", is(false)))
				.andDo(print());
	}
}
