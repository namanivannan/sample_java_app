package com.r1vs.platform.rox.common.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "code")
public class Code extends AuditedEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "code_id", nullable = false)
	private Integer codeId;

	@Column(name = "code_type_id")
	private Integer codeTypeId;

	@Column(name = "code_value")
	private String codeValue;

	@Column(name = "code_description")
	private String codeDescription;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "code_type_id", nullable = false, insertable = false, updatable = false)
	private CodeType type;

	public Integer getCodeId() {

		return codeId;
	}

	public void setCodeId(final Integer codeId) {

		this.codeId = codeId;
	}

	public Integer getCodeTypeId() {

		return codeTypeId;
	}

	public void setCodeTypeId(final Integer codeTypeId) {

		this.codeTypeId = codeTypeId;
	}

	public String getCodeValue() {

		return codeValue;
	}

	public void setCodeValue(final String codeValue) {

		this.codeValue = codeValue;
	}

	public String getCodeDescription() {

		return codeDescription;
	}

	public void setCodeDescription(final String codeDescription) {

		this.codeDescription = codeDescription;
	}

	public CodeType getType() {

		return type;
	}

	public void setType(final CodeType type) {

		this.type = type;
	}

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof Code)) {
			return false;
		}
		final Code castOther = (Code) other;
		return new EqualsBuilder().append(codeId, castOther.codeId).append(codeTypeId, castOther.codeTypeId)
				.append(codeValue, castOther.codeValue).append(codeDescription, castOther.codeDescription).isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(codeId).append(codeTypeId).append(codeValue).append(codeDescription)
				.toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("codeId", codeId).append("codeTypeId", codeTypeId)
				.append("codeValue", codeValue).append("codeDescription", codeDescription).toString();
	}

}
