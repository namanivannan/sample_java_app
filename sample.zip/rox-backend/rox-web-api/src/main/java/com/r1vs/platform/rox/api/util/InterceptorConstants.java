package com.r1vs.platform.rox.api.util;

public class InterceptorConstants {

	public static final String CLIENT_ID = "x-client-Id";

	public static final String USER_ID = "userId";

	public static final String LOG_REQUEST_URL = "Request URL::";

	public static final String START_TIME = "startTime";

	public static final String LOG_REQUEST_URL_START_TIME = LOG_REQUEST_URL + " {} :: Start Time={}";

	public static final String LOG_REQUEST_URL_END_TIME = LOG_REQUEST_URL + " {} :: End Time={}";

	public static final String LOG_REQUEST_URL_LOG_TIME_TAKEN = LOG_REQUEST_URL + " {} :: End Time={}";

}
