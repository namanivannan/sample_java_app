package com.r1vs.platform.rox.api.repository;

import com.r1vs.platform.rox.common.model.users.Role;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface RoleRepository extends JpaRepository<Role, Integer> {

	/**
	 * Gets all the roles for for the list of role id passed.
	 *
	 * @param roleIds roleIds for which roles are needed.
	 * @return list of Roles
	 */
	List<Role> findByRoleIdIn(final List<Integer> roleIds);

	default List<Role> findByRoleNames(final List<String> roleNames) {

		return findBySystemNameIn(roleNames);
	}

	List<Role> findBySystemNameIn(final List<String> roleNames);

	Role findByRoleId(final Integer roleId);

	Role findRoleBySystemName(String systemName);

	List<Role> findBySystemName(String roleSystemName);

	Page<Role> findAll(Specification<Role> specification, Pageable pageable);

	Optional<Role> findOneBySystemName(String roleSystemName);

	List<Role> findAllByStatusId(Integer key);

}
