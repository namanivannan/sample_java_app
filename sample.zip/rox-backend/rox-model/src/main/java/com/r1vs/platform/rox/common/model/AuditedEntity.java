package com.r1vs.platform.rox.common.model;

import java.io.Serializable;
import java.time.Clock;
import java.time.OffsetDateTime;

import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MappedSuperclass;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.hibernate.annotations.CreationTimestamp;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.LastModifiedBy;

import com.r1vs.platform.rox.common.model.users.User;

@MappedSuperclass
public class AuditedEntity implements Serializable {

	private static final long serialVersionUID = 12423522352225L;

	@NotNull
	@CreationTimestamp
	@Column(name = "created_at", updatable = false)
	private OffsetDateTime createdAt;

	@NotNull
	@Column(name = "updated_at", updatable = true)
	private OffsetDateTime updatedAt;

	@NotNull
	@CreatedBy
	@Column(name = "created_by")
	private Long createdById;

	@NotNull
	@LastModifiedBy
	@Column(name = "updated_by")
	private Long updatedById;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "created_by", referencedColumnName = "user_id", insertable = false, updatable = false)
	private User createdBy;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "updated_by", referencedColumnName = "user_id", insertable = false, updatable = false)
	private User updatedBy;

	@PrePersist
	public void prePersistCreatedAt() {

		this.createdAt = OffsetDateTime.now(Clock.systemUTC());
		this.updatedAt = OffsetDateTime.now(Clock.systemUTC());
	}

	@PreUpdate
	public void prePersistUpdatedAt() {

		this.updatedAt = OffsetDateTime.now(Clock.systemUTC());
	}

	public OffsetDateTime getCreatedAt() {

		return createdAt;
	}

	public void setCreatedAt(final OffsetDateTime createdAt) {

		this.createdAt = createdAt;
	}

	public OffsetDateTime getUpdatedAt() {

		return updatedAt;
	}

	public void setUpdatedAt(final OffsetDateTime updatedAt) {

		this.updatedAt = updatedAt;
	}

	public Long getCreatedById() {

		return createdById;
	}

	public void setCreatedById(final Long createdById) {

		this.createdById = createdById;
	}

	public Long getUpdatedById() {

		return updatedById;
	}

	public void setUpdatedById(final Long updatedById) {

		this.updatedById = updatedById;
	}

	public User getCreatedBy() {

		return createdBy;
	}

	public void setCreatedBy(final User createdByUser) {

		this.createdBy = createdByUser;
	}

	public User getUpdatedBy() {

		return updatedBy;
	}

	public void setUpdatedBy(final User updatedByUser) {

		this.updatedBy = updatedByUser;
	}

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof AuditedEntity)) {
			return false;
		}
		final AuditedEntity castOther = (AuditedEntity) other;
		return new EqualsBuilder().append(createdAt, castOther.createdAt).append(updatedAt, castOther.updatedAt)
				.append(createdById, castOther.createdById).append(updatedById, castOther.updatedById).isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(createdAt).append(updatedAt).append(createdById).append(updatedById)
				.toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("createdAt", createdAt).append("updatedAt", updatedAt)
				.append("createdById", createdById).append("updatedById", updatedById).toString();
	}
}
