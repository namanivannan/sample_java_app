#!/usr/bin/env bash

set -o errexit
set -o pipefail

awsenv && eval $(cat /ssm/.env) || echo "failed to get ssm parameter overrides"
echo "SSM PARAM VERSION:${BASE2_VERSION}"

if [[ "${LIQUIBASE_MIGRATIONS}x" == "x" ]]; then
  export LIQUIBASE_MIGRATIONS="${ENVIRONMENT_NAME}"
fi

echo "Generating liquibase.properties"
cat << EOF > /workspace/src/main/resources/config/liquibase.properties
# General Config
classpath=/opt/jdbc/postgresql.jar
logLevel=debug

#Migrations
changeLogFile=liquibase/liquibase-config.xml
databaseChangeLogLockTableName=migrations_lock
databaseChangeLogTableName=migrations

contexts=${LIQUIBASE_MIGRATIONS}

# Database Config
driver=org.postgresql.Driver
url=jdbc:postgresql://rds:3306/roxwrite
username=${ROXWRITE_DB_USER}
password=${ROXWRITE_DB_PASSWORD}
EOF

exec "$@"
