package com.r1vs.platform.rox.common.model.users;

import java.io.Serializable;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

public class UserRoleId implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long userId;

	private Integer roleId;

	public Long getUserId() {

		return userId;
	}

	public void setUserId(final Long userId) {

		this.userId = userId;
	}

	public Integer getRoleId() {

		return roleId;
	}

	public void setRoleId(final Integer roleId) {

		this.roleId = roleId;
	}

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof UserRoleId)) {
			return false;
		}
		final UserRoleId castOther = (UserRoleId) other;
		return new EqualsBuilder().append(userId, castOther.userId).append(roleId, castOther.roleId).isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(userId).append(roleId).toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("userId", userId).append("roleId", roleId).toString();
	}

}
