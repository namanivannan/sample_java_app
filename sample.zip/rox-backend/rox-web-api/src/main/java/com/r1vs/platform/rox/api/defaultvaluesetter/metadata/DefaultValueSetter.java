package com.r1vs.platform.rox.api.defaultvaluesetter.metadata;

import com.jsoniter.JsonIterator;
import com.jsoniter.any.Any;
import com.jsoniter.output.JsonStream;
import com.jsoniter.spi.JsonException;
import com.r1vs.platform.rox.api.exception.Error;
import com.r1vs.platform.rox.api.model.metadata.CreateMetadataRequest;
import com.r1vs.platform.rox.api.model.metadata.UpdateMetadataRequest;
import com.r1vs.platform.rox.api.util.ValidationUtil;
import org.springframework.core.GenericTypeResolver;

import static com.r1vs.platform.rox.api.util.MetadataConstants.JSON;

public abstract class DefaultValueSetter<T> implements MetadataDefaultValueSetter {

	public Class<T> genericType;

	@SuppressWarnings("unchecked")
	public DefaultValueSetter() {

		this.genericType = (Class<T>) GenericTypeResolver.resolveTypeArgument(getClass(), DefaultValueSetter.class);
	}

	public T deserialize(final String json) {

		Any any = null;

		try {
			any = JsonIterator.deserialize(json, Any.class);
		} catch (final JsonException exception) {
			final Error error = new Error();
			ValidationUtil.addErrorAndHandle(error, JSON, exception.getMessage(), json);
		}

		return JsonIterator.deserialize(any.toString(), genericType);
	}

	public String serialize(final T t) {

		return JsonStream.serialize(t);
	}

	@Override
	public abstract void setDefaultValues(CreateMetadataRequest createMetadataRequest);

	@Override
	public abstract void setDefaultValues(UpdateMetadataRequest updateMetadataRequest);
}
