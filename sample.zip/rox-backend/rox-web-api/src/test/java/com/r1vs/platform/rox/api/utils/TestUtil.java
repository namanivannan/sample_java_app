package com.r1vs.platform.rox.api.utils;

import org.apache.commons.io.IOUtils;

import java.io.IOException;

public class TestUtil {

	public static String getTextFileAsString(String filePath) throws IOException {

		return IOUtils.toString(
				TestUtil.class.getClass().getResourceAsStream(filePath),
				"UTF-8");
	}
}
