package com.r1vs.platform.rox.common.model.business;

import com.r1vs.platform.rox.common.model.AuditedEntity;
import com.r1vs.platform.rox.common.model.users.User;

import javax.persistence.*;

@Entity
public class StatusLog extends AuditedEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	Long id;

	String description;

	@OneToOne
	@JoinColumn(name = "application_status_id")
	ApplicationStatus status;

	@OneToOne
	@JoinColumn(name = "application_id")
	Application application;

	@OneToOne
	@JoinColumn(name = "user_id")
	User user;

	public Long getId() {

		return id;
	}

	public void setId(Long id) {

		this.id = id;
	}

	public String getDescription() {

		return description;
	}

	public void setDescription(String description) {

		this.description = description;
	}

	public Application getApplication() {

		return application;
	}

	public void setApplication(Application application) {

		this.application = application;
	}

	public User getUser() {

		return user;
	}

	public void setUser(User user) {

		this.user = user;
	}
}
