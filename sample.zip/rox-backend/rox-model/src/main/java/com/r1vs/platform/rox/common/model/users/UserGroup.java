package com.r1vs.platform.rox.common.model.users;

import com.r1vs.platform.rox.common.model.AuditedEntity;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "user_group")
public class UserGroup extends AuditedEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "user_group_id", nullable = false)
	private Long userGroupId;

	@Column(name = "user_id")
	private Long userId;

	@Column(name = "access_group_id")
	private Long accessGroupId;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "user_id", nullable = false, insertable = false, updatable = false)
	private User user;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "access_group_id", nullable = false, insertable = false, updatable = false)
	private AccessGroup accessGroup;

	public Long getUserGroupId() {

		return userGroupId;
	}

	public void setUserGroupId(Long userGroupId) {

		this.userGroupId = userGroupId;
	}

	public Long getUserId() {

		return userId;
	}

	public void setUserId(Long userId) {

		this.userId = userId;
	}

	public Long getAccessGroupId() {

		return accessGroupId;
	}

	public void setAccessGroupId(Long accessGroupId) {

		this.accessGroupId = accessGroupId;
	}

	public User getUser() {

		return user;
	}

	public void setUser(User user) {

		this.user = user;
	}

	public AccessGroup getAccessGroup() {

		return accessGroup;
	}

	public void setAccessGroup(AccessGroup accessGroup) {

		this.accessGroup = accessGroup;
	}
}
