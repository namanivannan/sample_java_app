package com.r1vs.platform.rox.common.model.users;

import java.io.Serializable;
import java.time.Clock;
import java.time.OffsetDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.r1vs.platform.rox.common.model.AuditedEntity;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "registration_token")
public class RegistrationToken extends AuditedEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	// 60 min * 24 hrs = 1 day in minutes
	public static final int EXPIRATION = 60 * 24;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "registration_token_id", nullable = false)
	private long registrationTokenId;

	@Column(name = "user_id", nullable = false)
	private Long userId;

	@Column(name = "token")
	private String token;

	@Column(name = "expiry_date")
	private OffsetDateTime expiryDate;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "user_id", nullable = false, insertable = false, updatable = false)
	private User user;

	public RegistrationToken() {

		super();
	}

	public RegistrationToken(final User user, final String token) {

		super();
		this.userId = user.getUserId();
		this.token = token;
		this.expiryDate = calculateExpiryDate(EXPIRATION);
	}

	public static final OffsetDateTime calculateExpiryDate(final int expiryTimeInMinutes) {

		final OffsetDateTime now = OffsetDateTime.now(Clock.systemUTC());
		return now.plusMinutes(expiryTimeInMinutes);
	}

	public long getRegistrationTokenId() {

		return registrationTokenId;
	}

	public void setRegistrationTokenId(final long registrationTokenId) {

		this.registrationTokenId = registrationTokenId;
	}

	public Long getUserId() {

		return userId;
	}

	public void setUserId(final Long userId) {

		this.userId = userId;
	}

	public String getToken() {

		return token;
	}

	public void setToken(final String token) {

		this.token = token;
	}

	public OffsetDateTime getExpiryDate() {

		return expiryDate;
	}

	public void setExpiryDate(final OffsetDateTime expiryDate) {

		this.expiryDate = expiryDate;
	}

	public User getUser() {

		return user;
	}

	public void setUser(final User user) {

		this.user = user;
	}

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof RegistrationToken)) {
			return false;
		}
		final RegistrationToken castOther = (RegistrationToken) other;
		return new EqualsBuilder().append(registrationTokenId, castOther.registrationTokenId)
				.append(userId, castOther.userId).append(token, castOther.token)
				.append(expiryDate, castOther.expiryDate).isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(registrationTokenId).append(userId).append(token).append(expiryDate)
				.toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("registrationTokenId", registrationTokenId).append("userId", userId)
				.append("token", token).append("expiryDate", expiryDate).toString();
	}

}
