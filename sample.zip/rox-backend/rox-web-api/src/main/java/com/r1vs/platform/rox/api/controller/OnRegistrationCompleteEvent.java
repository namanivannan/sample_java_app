package com.r1vs.platform.rox.api.controller;

import com.r1vs.platform.rox.common.model.users.User;
import org.springframework.context.ApplicationEvent;

public class OnRegistrationCompleteEvent extends ApplicationEvent {

	private static final long serialVersionUID = 1L;

	private User user;

	private String token;

	public OnRegistrationCompleteEvent(final User createdUser, final String token) {

		super(createdUser);

		this.user = createdUser;
		this.token = token;
	}

	public User getUser() {

		return user;
	}

	public void setUser(final User user) {

		this.user = user;
	}

	public String getToken() {

		return token;
	}

	public void setToken(final String token) {

		this.token = token;
	}

}
