package com.r1vs.platform.rox.api.validator.role;

import com.r1vs.platform.rox.api.exception.Error;
import com.r1vs.platform.rox.api.model.role.ChangeRoleStatusRequest;
import com.r1vs.platform.rox.api.validator.RoxWriteWebApiValidator;
import org.springframework.stereotype.Component;

import static com.r1vs.platform.rox.api.util.ValidationUtil.handleException;

@Component
public class ChangeRoleStatusValidator extends RoleRequestValidator
		implements RoxWriteWebApiValidator<ChangeRoleStatusRequest> {

	@Override
	public void validate(final ChangeRoleStatusRequest changeRoleStatusRequest) {

		final Error error = new Error();

		validateStatusCode(error, changeRoleStatusRequest.getStatusId());

		validateStatusFlowForUpdate(error, changeRoleStatusRequest.getRoleId(), changeRoleStatusRequest.getStatusId());

		handleException(error);
	}

}
