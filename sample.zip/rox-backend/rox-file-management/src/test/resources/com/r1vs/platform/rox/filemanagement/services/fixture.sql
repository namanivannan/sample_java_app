SET REFERENTIAL_INTEGRITY FALSE;

truncate table address;
truncate table application_status;
truncate table application;
truncate table business_address;
truncate table business_email;
truncate table business_identification;
truncate table business_phone;
truncate table business_type;
truncate table business;
truncate table clients;
truncate table email;
truncate table identification;
truncate table owner_address;
truncate table owner_email;
truncate table owner_identification;
truncate table owner_phone;
truncate table owner;
truncate table phone;
truncate table rox_file;
truncate table users;


INSERT INTO address (id, address_type_id, description, xref_id, xref_type_id, is_primary, address1, address2, city, state, zip4, zip5, country_code, county, created_at, updated_at, created_by, updated_by) VALUES (1, 2, null, null, null, true, '273 E 26TH ST', '660-D', 'PATERSON', 'New Jersey', null, '07514', null, null, '2022-02-21 15:38:57.524114', '2022-02-21 15:38:57.522935', 11, 11);
INSERT INTO address (id, address_type_id, description, xref_id, xref_type_id, is_primary, address1, address2, city, state, zip4, zip5, country_code, county, created_at, updated_at, created_by, updated_by) VALUES (2, 2, null, null, null, true, '273 E 26TH ST', '660-D', 'PATERSON', 'New Jersey', null, '07514', null, null, '2022-02-21 15:38:57.625735', '2022-02-21 15:38:57.625302', 11, 11);
INSERT INTO address (id, address_type_id, description, xref_id, xref_type_id, is_primary, address1, address2, city, state, zip4, zip5, country_code, county, created_at, updated_at, created_by, updated_by) VALUES (3, 2, null, null, null, true, '273 E 26TH ST', '660-D', 'PATERSON', 'New Jersey', null, '07514', null, null, '2022-02-21 15:40:46.229706', '2022-02-21 15:40:46.229415', 11, 11);
INSERT INTO address (id, address_type_id, description, xref_id, xref_type_id, is_primary, address1, address2, city, state, zip4, zip5, country_code, county, created_at, updated_at, created_by, updated_by) VALUES (4, 2, null, null, null, true, '273 E 26TH ST', '660-D', 'PATERSON', 'New Jersey', null, '07514', null, null, '2022-02-21 15:40:46.276354', '2022-02-21 15:40:46.275965', 11, 11);
INSERT INTO address (id, address_type_id, description, xref_id, xref_type_id, is_primary, address1, address2, city, state, zip4, zip5, country_code, county, created_at, updated_at, created_by, updated_by) VALUES (5, 2, null, null, null, true, '273 E 26TH ST', '660-D', 'PATERSON', 'New Jersey', null, '07514', null, null, '2022-02-21 15:40:51.926186', '2022-02-21 15:40:51.925894', 11, 11);
INSERT INTO address (id, address_type_id, description, xref_id, xref_type_id, is_primary, address1, address2, city, state, zip4, zip5, country_code, county, created_at, updated_at, created_by, updated_by) VALUES (6, 2, null, null, null, true, '273 E 26TH ST', '660-D', 'PATERSON', 'New Jersey', null, '07514', null, null, '2022-02-21 15:40:51.966727', '2022-02-21 15:40:51.966472', 11, 11);
INSERT INTO address (id, address_type_id, description, xref_id, xref_type_id, is_primary, address1, address2, city, state, zip4, zip5, country_code, county, created_at, updated_at, created_by, updated_by) VALUES (7, 2, null, null, null, true, '273 E 26TH ST', '660-D', 'PATERSON', 'New Jersey', null, '07514', null, null, '2022-02-21 15:40:58.131332', '2022-02-21 15:40:58.131031', 11, 11);
INSERT INTO address (id, address_type_id, description, xref_id, xref_type_id, is_primary, address1, address2, city, state, zip4, zip5, country_code, county, created_at, updated_at, created_by, updated_by) VALUES (8, 2, null, null, null, true, '273 E 26TH ST', '660-D', 'PATERSON', 'New Jersey', null, '07514', null, null, '2022-02-21 15:40:58.182891', '2022-02-21 15:40:58.182629', 11, 11);
INSERT INTO address (id, address_type_id, description, xref_id, xref_type_id, is_primary, address1, address2, city, state, zip4, zip5, country_code, county, created_at, updated_at, created_by, updated_by) VALUES (9, 2, null, null, null, true, '273 E 26TH ST', '660-D', 'PATERSON', 'New Jersey', null, '07514', null, null, '2022-02-21 15:41:08.063089', '2022-02-21 15:41:08.062723', 11, 11);
INSERT INTO address (id, address_type_id, description, xref_id, xref_type_id, is_primary, address1, address2, city, state, zip4, zip5, country_code, county, created_at, updated_at, created_by, updated_by) VALUES (10, 2, null, null, null, true, '273 E 26TH ST', '660-D', 'PATERSON', 'New Jersey', null, '07514', null, null, '2022-02-21 15:41:08.109229', '2022-02-21 15:41:08.108717', 11, 11);
INSERT INTO address (id, address_type_id, description, xref_id, xref_type_id, is_primary, address1, address2, city, state, zip4, zip5, country_code, county, created_at, updated_at, created_by, updated_by) VALUES (11, 2, null, null, null, true, '273 E 26TH ST', '660-D', 'PATERSON', 'New Jersey', null, '07514', null, null, '2022-02-21 15:41:15.549508', '2022-02-21 15:41:15.549306', 11, 11);
INSERT INTO address (id, address_type_id, description, xref_id, xref_type_id, is_primary, address1, address2, city, state, zip4, zip5, country_code, county, created_at, updated_at, created_by, updated_by) VALUES (12, 2, null, null, null, true, '273 E 26TH ST', '660-D', 'PATERSON', 'New Jersey', null, '07514', null, null, '2022-02-21 15:41:15.576814', '2022-02-21 15:41:15.576614', 11, 11);
INSERT INTO application_status (id, status) VALUES (0, 'New');
INSERT INTO application_status (id, status) VALUES (1, 'Under Review');
INSERT INTO application_status (id, status) VALUES (2, 'Pending');
INSERT INTO application_status (id, status) VALUES (3, 'Approved');
INSERT INTO application_status (id, status) VALUES (4, 'Declined');
INSERT INTO application_status (id, status) VALUES (5, 'Cancelled');
INSERT INTO application (id, uuid, contract_amount, completed_at, client_id, status_id, state_id, created_at, updated_at, created_by, updated_by) VALUES
(11, '382b9037-5842-43e8-b99b-2f4611784cd6', 10000, null,                          11, 0, 0, '2022-02-20 15:38:57.366701', '2022-02-21 15:38:57.366398', 11, 11), /** Blue Transportation */
(13, '839e72fc-6433-46fd-a259-5dbb50b913d6', 20000, null,                          11, 0, 0, '2022-02-20 15:40:46.196742', '2022-02-21 15:40:46.196201', 11, 11), /** Brown Transportation */
(14, '4d61f5c0-bca0-4388-bb02-8693d298ffd5', 30000, '2022-03-10 15:40:51.886182',  11, 5, 1, '2022-02-21 15:40:51.886182', '2022-02-21 15:40:51.885838', 11, 11), /** Green Transportation */
(15, '47b798cf-8aa7-422c-8467-ce08b9edcfe9', 40000, null,                          12, 1, 0, '2022-02-21 15:40:58.098305', '2022-02-21 15:40:58.098061', 12, 12), /** Pink Transportation */
(16, '84ec6f35-f861-406c-a4ec-b9d33ccb88dc', 50000, null,                          12, 1, 0, '2022-02-22 15:41:08.029428', '2022-02-21 15:41:08.029106', 12, 12), /** Purple Transportation */
(17, '588d3527-0938-4ad9-839b-7a7ca4ed851d', 60000, null,                          12, 1, 0, '2022-02-22 15:41:15.529201', '2022-02-21 15:41:15.529002', 12, 12); /** Red Transportation */

INSERT INTO business_address (address_id, business_id) VALUES (1, 1);
INSERT INTO business_address (address_id, business_id) VALUES (3, 2);
INSERT INTO business_address (address_id, business_id) VALUES (5, 3);
INSERT INTO business_address (address_id, business_id) VALUES (7, 4);
INSERT INTO business_address (address_id, business_id) VALUES (9, 5);
INSERT INTO business_address (address_id, business_id) VALUES (11, 6);
INSERT INTO business_email (email_id, business_id) VALUES (1, 1);
INSERT INTO business_email (email_id, business_id) VALUES (3, 2);
INSERT INTO business_email (email_id, business_id) VALUES (5, 3);
INSERT INTO business_email (email_id, business_id) VALUES (7, 4);
INSERT INTO business_email (email_id, business_id) VALUES (9, 5);
INSERT INTO business_email (email_id, business_id) VALUES (11, 6);
INSERT INTO business_identification (identification_id, business_id) VALUES (1, 1);
INSERT INTO business_identification (identification_id, business_id) VALUES (3, 2);
INSERT INTO business_identification (identification_id, business_id) VALUES (5, 3);
INSERT INTO business_identification (identification_id, business_id) VALUES (7, 4);
INSERT INTO business_identification (identification_id, business_id) VALUES (9, 5);
INSERT INTO business_identification (identification_id, business_id) VALUES (11, 6);
INSERT INTO business_phone (phone_id, business_id) VALUES (1, 1);
INSERT INTO business_phone (phone_id, business_id) VALUES (3, 2);
INSERT INTO business_phone (phone_id, business_id) VALUES (5, 3);
INSERT INTO business_phone (phone_id, business_id) VALUES (7, 4);
INSERT INTO business_phone (phone_id, business_id) VALUES (9, 5);
INSERT INTO business_phone (phone_id, business_id) VALUES (11, 6);
INSERT INTO business_type (id, type) VALUES (0, 'Corporations');
INSERT INTO business_type (id, type) VALUES (1, 'S Corporations');
INSERT INTO business_type (id, type) VALUES (2, 'Sole Proprietorships');
INSERT INTO business_type (id, type) VALUES (3, 'Partnerships');
INSERT INTO business_type (id, type) VALUES (4, 'Limited Liability Company (LLC)');
INSERT INTO business_type (id, type) VALUES (5, 'Limited Liability Corporation');

INSERT INTO business (id, application_id, name, business_type_id, industry_type_id, dot_number, mc_number, website, dba_name, category_id, is_primary, created_at, created_by, updated_at, updated_by) VALUES
   (1, 11, 'Blue Transportation', 5, 0, '123', '321', 'rule1vs.com', 'dbaName', 0, true, '2022-02-21 15:38:57.507170', 11, '2022-02-21 15:38:57.498459', 11),
   (2, 13, 'Brown Transportation', 5, 0, '234', '432', 'rule1vs.com', 'dbaName', 0, true, '2022-02-21 15:40:46.226399', 11, '2022-02-21 15:40:46.225998', 11),
   (3, 14, 'Green Transportation', 5, 0, '345', '543', 'rule1vs.com', 'dbaName', 0, true, '2022-02-21 15:40:51.922954', 11, '2022-02-21 15:40:51.922534', 11),
   (4, 15, 'Pink Transportation', 5, 0, '456', '654', 'rule1vs.com', 'dbaName', 0, true, '2022-02-21 15:40:58.125023', 11, '2022-02-21 15:40:58.124505', 11),
   (5, 16, 'Purple Transportation', 5, 0, '567', '765', 'rule1vs.com', 'dbaName', 0, true, '2022-02-21 15:41:08.058926', 11, '2022-02-21 15:41:08.058473', 11),
   (7, 16, 'Purple Debtor', 5, 0, '678','876', 'rule1vs.com', 'dbaName', 1, true, '2022-02-21 15:41:08.058926', 11, '2022-02-21 15:41:08.058473', 11),
   (6, 17, 'Red Transportation', 5, 0, '789', '987', 'rule1vs.com', 'dbaName', 0, true, '2022-02-21 15:41:15.545208', 11, '2022-02-21 15:41:15.544813', 11),
   (8, 11, 'Debtor', 5, 0, '3177401', '654321', 'debtor.com', null, 1, true, '2022-03-09 13:38:13.469975', 11, '2022-03-09 13:38:13.369455', 11);

INSERT INTO clients (id, uuid, code, name, business_type_id, address1, address2, city, state, zip4, zip5, county, ein, phone_type_id, phone, website, active, created_at, created_by, updated_at, updated_by) VALUES
(11, 'a920004b-e1aa-4a6d-85f1-10863e61363d', 'testCode', 'RoxWriteAdmin Client', 4, 'testAddr1', 'testAddr2', 'testCity', 'GA', '1', '1', 'testCounty', 'testEIN', 3, '5555555555', 'www.roxwrite.com', 1, '2022-02-09 00:00:00.000000', 11, '2022-02-09 00:00:00.000000', 11),
(12, 'a920004b-e1aa-4a6d-85f1-10863e61363E', 'testCode2', 'RoxWriteAdmin Cl2', 4, 'testAddr1', 'testAddr2', 'testCity', 'GA', '1', '1', 'testCounty', 'testEIN', 3, '5555555555', 'www.roxwrite.com', 1, '2022-02-09 00:00:00.000000', 11, '2022-02-09 00:00:00.000000', 11),
(13, 'a920004b-e1aa-4a6d-85f1-10863e61363c', 'testCode3', 'RoxWriteAdmin Cl3', 4, 'testAddr1', 'testAddr2', 'testCity', 'GA', '1', '1', 'testCounty', 'testEIN', 3, '5555555555', 'www.roxwrite.com', 0, '2022-02-09 00:00:00.000000', 11, '2022-02-09 00:00:00.000000', 11);
INSERT INTO email (id, email_type_id, xref_id, xref_type_id, description, email_address, is_primary, created_at, updated_at, created_by, updated_by) VALUES (1, 2, null, null, null, null, true, '2022-02-21 15:38:57.534586', '2022-02-21 15:38:57.533117', 11, 11);
INSERT INTO email (id, email_type_id, xref_id, xref_type_id, description, email_address, is_primary, created_at, updated_at, created_by, updated_by) VALUES (2, 2, null, null, null, null, true, '2022-02-21 15:38:57.633301', '2022-02-21 15:38:57.631759', 11, 11);
INSERT INTO email (id, email_type_id, xref_id, xref_type_id, description, email_address, is_primary, created_at, updated_at, created_by, updated_by) VALUES (3, 2, null, null, null, null, true, '2022-02-21 15:40:46.235930', '2022-02-21 15:40:46.235381', 11, 11);
INSERT INTO email (id, email_type_id, xref_id, xref_type_id, description, email_address, is_primary, created_at, updated_at, created_by, updated_by) VALUES (4, 2, null, null, null, null, true, '2022-02-21 15:40:46.279602', '2022-02-21 15:40:46.279301', 11, 11);
INSERT INTO email (id, email_type_id, xref_id, xref_type_id, description, email_address, is_primary, created_at, updated_at, created_by, updated_by) VALUES (5, 2, null, null, null, null, true, '2022-02-21 15:40:51.931037', '2022-02-21 15:40:51.930355', 11, 11);
INSERT INTO email (id, email_type_id, xref_id, xref_type_id, description, email_address, is_primary, created_at, updated_at, created_by, updated_by) VALUES (6, 2, null, null, null, null, true, '2022-02-21 15:40:51.973467', '2022-02-21 15:40:51.973204', 11, 11);
INSERT INTO email (id, email_type_id, xref_id, xref_type_id, description, email_address, is_primary, created_at, updated_at, created_by, updated_by) VALUES (7, 2, null, null, null, null, true, '2022-02-21 15:40:58.136495', '2022-02-21 15:40:58.136048', 11, 11);
INSERT INTO email (id, email_type_id, xref_id, xref_type_id, description, email_address, is_primary, created_at, updated_at, created_by, updated_by) VALUES (8, 2, null, null, null, null, true, '2022-02-21 15:40:58.189834', '2022-02-21 15:40:58.189289', 11, 11);
INSERT INTO email (id, email_type_id, xref_id, xref_type_id, description, email_address, is_primary, created_at, updated_at, created_by, updated_by) VALUES (9, 2, null, null, null, null, true, '2022-02-21 15:41:08.068548', '2022-02-21 15:41:08.068179', 11, 11);
INSERT INTO email (id, email_type_id, xref_id, xref_type_id, description, email_address, is_primary, created_at, updated_at, created_by, updated_by) VALUES (10, 2, null, null, null, null, true, '2022-02-21 15:41:08.114761', '2022-02-21 15:41:08.114493', 11, 11);
INSERT INTO email (id, email_type_id, xref_id, xref_type_id, description, email_address, is_primary, created_at, updated_at, created_by, updated_by) VALUES (11, 2, null, null, null, null, true, '2022-02-21 15:41:15.552834', '2022-02-21 15:41:15.552633', 11, 11);
INSERT INTO email (id, email_type_id, xref_id, xref_type_id, description, email_address, is_primary, created_at, updated_at, created_by, updated_by) VALUES (12, 2, null, null, null, null, true, '2022-02-21 15:41:15.580790', '2022-02-21 15:41:15.580591', 11, 11);
INSERT INTO rox_file (id, uuid, purpose, bucket, key, file_name, file_type, file_size, application_id, created_at, updated_at, created_by, updated_by) VALUES
(11, '27a88d52-ecff-4613-9b7f-88bc79adcd88', 'purpose 1', 'roxbucket', '11/382b9037-5842-43e8-b99b-2f4611784cd6/2022-03-07T12:20:11.204874100-testFile1.png', 'testFile1.png', 'image/png', 35080, 11, '2022-03-02 17:42:30.023783', '2022-03-02 17:42:29.982659', 11, 11),
(12, '9e8e37f5-cb76-4198-bfe8-e021960fcc52', 'purpose 2', 'roxbucket', '11/382b9037-5842-43e8-b99b-2f4611784cd6/2022-03-07T12:20:11.204874100-testFile2.png', 'testFile2.png', 'image/png', 35080, 11, '2022-03-02 17:42:30.023783', '2022-03-02 17:42:29.982659', 11, 11);
INSERT INTO identification (id, identification_type_id, xref_id, xref_type_id, description, identification, is_primary, created_at, updated_at, created_by, updated_by) VALUES (1, 1, null, null, null, '11111111111111', true, '2022-02-21 15:38:57.544017', '2022-02-21 15:38:57.543324', 11, 11);
INSERT INTO identification (id, identification_type_id, xref_id, xref_type_id, description, identification, is_primary, created_at, updated_at, created_by, updated_by) VALUES (2, 2, null, null, null, '23827827827', true, '2022-02-21 15:38:57.643859', '2022-02-21 15:38:57.643284', 11, 11);
INSERT INTO identification (id, identification_type_id, xref_id, xref_type_id, description, identification, is_primary, created_at, updated_at, created_by, updated_by) VALUES (3, 1, null, null, null, '11111111111111', true, '2022-02-21 15:40:46.239663', '2022-02-21 15:40:46.239417', 11, 11);
INSERT INTO identification (id, identification_type_id, xref_id, xref_type_id, description, identification, is_primary, created_at, updated_at, created_by, updated_by) VALUES (4, 2, null, null, null, '23827827827', true, '2022-02-21 15:40:46.284555', '2022-02-21 15:40:46.284031', 11, 11);
INSERT INTO identification (id, identification_type_id, xref_id, xref_type_id, description, identification, is_primary, created_at, updated_at, created_by, updated_by) VALUES (5, 1, null, null, null, '11111111111111', true, '2022-02-21 15:40:51.936115', '2022-02-21 15:40:51.935835', 11, 11);
INSERT INTO identification (id, identification_type_id, xref_id, xref_type_id, description, identification, is_primary, created_at, updated_at, created_by, updated_by) VALUES (6, 2, null, null, null, '23827827827', true, '2022-02-21 15:40:51.977924', '2022-02-21 15:40:51.977647', 11, 11);
INSERT INTO identification (id, identification_type_id, xref_id, xref_type_id, description, identification, is_primary, created_at, updated_at, created_by, updated_by) VALUES (7, 1, null, null, null, '152627839892', true, '2022-02-21 15:40:58.142290', '2022-02-21 15:40:58.141686', 11, 11);
INSERT INTO identification (id, identification_type_id, xref_id, xref_type_id, description, identification, is_primary, created_at, updated_at, created_by, updated_by) VALUES (8, 2, null, null, null, '23827827827', true, '2022-02-21 15:40:58.197208', '2022-02-21 15:40:58.196749', 11, 11);
INSERT INTO identification (id, identification_type_id, xref_id, xref_type_id, description, identification, is_primary, created_at, updated_at, created_by, updated_by) VALUES (9, 1, null, null, null, '11111111111111', true, '2022-02-21 15:41:08.075355', '2022-02-21 15:41:08.074998', 11, 11);
INSERT INTO identification (id, identification_type_id, xref_id, xref_type_id, description, identification, is_primary, created_at, updated_at, created_by, updated_by) VALUES (10, 2, null, null, null, '23827827827', true, '2022-02-21 15:41:08.120289', '2022-02-21 15:41:08.119762', 11, 11);
INSERT INTO identification (id, identification_type_id, xref_id, xref_type_id, description, identification, is_primary, created_at, updated_at, created_by, updated_by) VALUES (11, 1, null, null, null, '11111111111111', true, '2022-02-21 15:41:15.556199', '2022-02-21 15:41:15.555998', 11, 11);
INSERT INTO identification (id, identification_type_id, xref_id, xref_type_id, description, identification, is_primary, created_at, updated_at, created_by, updated_by) VALUES (12, 2, null, null, null, '23827827827', true, '2022-02-21 15:41:15.583776', '2022-02-21 15:41:15.583556', 11, 11);
INSERT INTO owner_address (address_id, owner_id) VALUES (2, 1);
INSERT INTO owner_address (address_id, owner_id) VALUES (4, 2);
INSERT INTO owner_address (address_id, owner_id) VALUES (6, 3);
INSERT INTO owner_address (address_id, owner_id) VALUES (8, 4);
INSERT INTO owner_address (address_id, owner_id) VALUES (10, 5);
INSERT INTO owner_address (address_id, owner_id) VALUES (12, 6);
INSERT INTO owner_email (email_id, owner_id) VALUES (2, 1);
INSERT INTO owner_email (email_id, owner_id) VALUES (4, 2);
INSERT INTO owner_email (email_id, owner_id) VALUES (6, 3);
INSERT INTO owner_email (email_id, owner_id) VALUES (8, 4);
INSERT INTO owner_email (email_id, owner_id) VALUES (10, 5);
INSERT INTO owner_email (email_id, owner_id) VALUES (12, 6);
INSERT INTO owner_identification (identification_id, owner_id) VALUES (2, 1);
INSERT INTO owner_identification (identification_id, owner_id) VALUES (4, 2);
INSERT INTO owner_identification (identification_id, owner_id) VALUES (6, 3);
INSERT INTO owner_identification (identification_id, owner_id) VALUES (8, 4);
INSERT INTO owner_identification (identification_id, owner_id) VALUES (10, 5);
INSERT INTO owner_identification (identification_id, owner_id) VALUES (12, 6);
INSERT INTO owner_phone (phone_id, owner_id) VALUES (2, 1);
INSERT INTO owner_phone (phone_id, owner_id) VALUES (4, 2);
INSERT INTO owner_phone (phone_id, owner_id) VALUES (6, 3);
INSERT INTO owner_phone (phone_id, owner_id) VALUES (8, 4);
INSERT INTO owner_phone (phone_id, owner_id) VALUES (10, 5);
INSERT INTO owner_phone (phone_id, owner_id) VALUES (12, 6);
INSERT INTO owner (id, uuid, application_id, first_name, last_name, date_of_birth,identifier, created_at, created_by, updated_at, updated_by) VALUES
(1, '17bd8e27-8228-40ac-afbb-ea6894e55d17', 11, 'Mickey Blue', 'Mouse'  , '2022-02-21', null, '2022-02-21 15:38:57.618130', 11, '2022-02-21 15:38:57.616900', 11),
(2, 'aa19e4bf-2f93-4668-ae90-01209eec8cca', 13, 'Mickey Brown', 'Mouse' , '2022-02-21', null, '2022-02-21 15:40:46.272269', 11, '2022-02-21 15:40:46.271511', 11),
(3, 'fe985a25-2788-4bcf-9bc4-c632f536d9de', 14, 'Mickey Green', 'Mouse' , '2022-02-21', null, '2022-02-21 15:40:51.961878', 11, '2022-02-21 15:40:51.961485', 11),
(4, 'c78c34c1-bf28-4b9f-8bc0-18ae08a710c9', 15, 'Mickey', 'Minnie'      , '2022-02-21', null, '2022-02-21 15:40:58.179633', 11, '2022-02-21 15:40:58.178848', 11),
(5, 'bc5fbaf0-0be3-437d-9fec-ae9344fefc52', 16, 'Mickey Purple', 'Mouse', '2022-02-21', null, '2022-02-21 15:41:08.105518', 11, '2022-02-21 15:41:08.104938', 11),
(6, 'd99d34cc-b6e2-4a8f-9bb3-258c755d501e', 17, 'Mickey Red', 'Mouse'   , '2022-02-21', null, '2022-02-21 15:41:15.573147', 11, '2022-02-21 15:41:15.572824', 11);
INSERT INTO phone (id, phone_type_id, description, xref_id, xref_type_id, is_primary, number, extension, created_at, updated_at, created_by, updated_by) VALUES (1, 3, null, null, null, true, '4049097501', null, '2022-02-21 15:38:57.553566', '2022-02-21 15:38:57.552187', 11, 11);
INSERT INTO phone (id, phone_type_id, description, xref_id, xref_type_id, is_primary, number, extension, created_at, updated_at, created_by, updated_by) VALUES (2, 3, null, null, null, true, '4049097501', null, '2022-02-21 15:38:57.650065', '2022-02-21 15:38:57.648959', 11, 11);
INSERT INTO phone (id, phone_type_id, description, xref_id, xref_type_id, is_primary, number, extension, created_at, updated_at, created_by, updated_by) VALUES (3, 3, null, null, null, true, '4049097501', null, '2022-02-21 15:40:46.243358', '2022-02-21 15:40:46.243128', 11, 11);
INSERT INTO phone (id, phone_type_id, description, xref_id, xref_type_id, is_primary, number, extension, created_at, updated_at, created_by, updated_by) VALUES (4, 3, null, null, null, true, '4049097501', null, '2022-02-21 15:40:46.288814', '2022-02-21 15:40:46.288581', 11, 11);
INSERT INTO phone (id, phone_type_id, description, xref_id, xref_type_id, is_primary, number, extension, created_at, updated_at, created_by, updated_by) VALUES (5, 3, null, null, null, true, '4049097501', null, '2022-02-21 15:40:51.940003', '2022-02-21 15:40:51.939764', 11, 11);
INSERT INTO phone (id, phone_type_id, description, xref_id, xref_type_id, is_primary, number, extension, created_at, updated_at, created_by, updated_by) VALUES (6, 3, null, null, null, true, '4049097501', null, '2022-02-21 15:40:51.983848', '2022-02-21 15:40:51.983574', 11, 11);
INSERT INTO phone (id, phone_type_id, description, xref_id, xref_type_id, is_primary, number, extension, created_at, updated_at, created_by, updated_by) VALUES (7, 3, null, null, null, true, '4049097501', null, '2022-02-21 15:40:58.148246', '2022-02-21 15:40:58.147941', 11, 11);
INSERT INTO phone (id, phone_type_id, description, xref_id, xref_type_id, is_primary, number, extension, created_at, updated_at, created_by, updated_by) VALUES (8, 3, null, null, null, true, '4049097501', null, '2022-02-21 15:40:58.203513', '2022-02-21 15:40:58.202922', 11, 11);
INSERT INTO phone (id, phone_type_id, description, xref_id, xref_type_id, is_primary, number, extension, created_at, updated_at, created_by, updated_by) VALUES (9, 3, null, null, null, true, '4049097501', null, '2022-02-21 15:41:08.081037', '2022-02-21 15:41:08.080724', 11, 11);
INSERT INTO phone (id, phone_type_id, description, xref_id, xref_type_id, is_primary, number, extension, created_at, updated_at, created_by, updated_by) VALUES (10, 3, null, null, null, true, '4049097501', null, '2022-02-21 15:41:08.126371', '2022-02-21 15:41:08.126074', 11, 11);
INSERT INTO phone (id, phone_type_id, description, xref_id, xref_type_id, is_primary, number, extension, created_at, updated_at, created_by, updated_by) VALUES (11, 3, null, null, null, true, '4049097501', null, '2022-02-21 15:41:15.560038', '2022-02-21 15:41:15.559806', 11, 11);
INSERT INTO phone (id, phone_type_id, description, xref_id, xref_type_id, is_primary, number, extension, created_at, updated_at, created_by, updated_by) VALUES (12, 3, null, null, null, true, '4049097501', null, '2022-02-21 15:41:15.587317', '2022-02-21 15:41:15.587074', 11, 11);

INSERT INTO users (user_id, client_id, username, first_name, last_name, password, email, phone_type_id, phone, registered, registered_date, active, is_superuser, version, created_by, created_at, updated_by, updated_at) VALUES
(1, null, 'roxsysadm', 'RoxWrite', 'System', '$2a$12$Ox.VXcSBRAAbDE0WO8QnxuQafpIywsTsCxSBZkTLACu26d19p9RYW', 'roxwrite@roxwrite.com', null, null, true, '2022-02-21 12:25:01.369899', true, true, 1, 1, '2022-02-21 12:25:01.369899', 1, '2022-02-21 12:25:01.369899'),
(11, 11, 'roxadmin', 'RoxWrite',   'User', '$2a$12$Ox.VXcSBRAAbDE0WO8QnxuQafpIywsTsCxSBZkTLACu26d19p9RYW', 'roxwrite-admin@roxwrite.com', 15, '555-555-5555', true, '2022-02-21 12:25:02.274556', true, false, 1, 1, '2022-02-21 12:25:02.274556', 1, '2022-02-21 12:25:02.274556'),
(12, 12, 'roxadmin2', 'RoxWrite2', 'User', '$2a$12$Ox.VXcSBRAAbDE0WO8QnxuQafpIywsTsCxSBZkTLACu26d19p9RYW', 'roxwrite-admin2@roxwrite.com', 15, '555-555-5555', true, '2022-02-21 12:25:02.274556', true, false, 1, 1, '2022-02-21 12:25:02.274556', 1, '2022-02-21 12:25:02.274556'),
(13, 13, 'roxadmin3', 'RoxWrite3', 'User', '$2a$12$Ox.VXcSBRAAbDE0WO8QnxuQafpIywsTsCxSBZkTLACu26d19p9RYW', 'roxwrite-admin3@roxwrite.com', 15, '555-555-5555', true, '2022-02-21 12:25:02.274556', false, false, 1, 1, '2022-02-21 12:25:02.274556', 1, '2022-02-21 12:25:02.274556');



SET REFERENTIAL_INTEGRITY TRUE;
