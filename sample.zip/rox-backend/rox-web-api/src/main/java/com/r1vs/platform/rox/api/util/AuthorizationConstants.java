package com.r1vs.platform.rox.api.util;

public class AuthorizationConstants {

	public static final String AUTHORIZATION_ACTION = "authTypeCode";

	public static final String INVALID_AUTHORIZATION_ACTION = "INVALID_AUTHORIZATION_ACTION";

	public static final String AUTHORIZATION_LEVEL = "authLevelCode";

	public static final String INVALID_AUTHORIZATION_LEVEL = "INVALID_AUTHORIZATION_LEVEL";

	public static final String OUTCOME = "outcomeCode";

	public static final String INVALID_OUTCOME = "INVALID_OUTCOME";

	public static final String INVALID_OUTCOME_FOR_UPDATE = "INVALID_OUTCOME_FOR_UPDATE";

	public static final String REASON_FOR_OUTCOME = "outcomeReasonCode";

	public static final String INVALID_REASON_FOR_OUTCOME = "INVALID_REASON_FOR_OUTCOME";

	public static final String AUTHORIZATION_REASON = "authReasonCode";

	public static final String INVALID_AUTHORIZATION_REASON = "INVALID_AUTHORIZATION_REASON";

	public static final String AUTHORIZATION_PRIORITY = "authPriorityCode";

	public static final String INVALID_AUTHORIZATION_PRIORITY = "INVALID_AUTHORIZATION_PRIORITY";

	public static final String PROVIDER_ACTION = "providerAction";

	public static final String INVALID_PROVIDER_ACTION = "INVALID_PROVIDER_ACTION";

	public static final String PRESCRIBER_ACTION = "prescriberAction";

	public static final String INVALID_PRESCRIBER_ACTION = "INVALID_PRESCRIBER_ACTION";

	public static final String CHANGE_FORMULARY_STATUS = "changeFormularyStatus";

	public static final String INVALID_CHANGE_FORMULARY_STATUS = "INVALID_CHANGE_FORMULARY_STATUS";

	public static final String CHANGE_PREFERRED_DRUG_STATUS = "changePreferredDrugStatus";

	public static final String INVALID_CHANGE_PREFERRED_DRUG_STATUS = "INVALID_CHANGE_PREFERRED_DRUG_STATUS";

	public static final String INVALID_NULL = "INVALID_NULL";

	public static final String PA_TRACKING_NUMBER_ALREADY_EXISTS = "PA_TRACKING_NUMBER_ALREADY_EXISTS";

	public static final String INVALID_EDIT = "INVALID_EDIT";

	public static final String INVALID_PROVIDER_ID = "INVALID_PROVIDER_ID";

	public static final String BASIC_INFO = "basicInfo";

	public static final String AUTH_END_DATE = "authEndDate";

	public static final String INVALID_AUTH_END_DATE = "INVALID_AUTH_END_DATE";

	public static final String AUTH_BY_INFO = "authByInfo";

	public static final String AUTH_START_DATE = "authStartDate";

	public static final String INVALID_AUTH_START_DATE = "INVALID_AUTH_START_DATE";

	public static final String PRESCRIBER_INFO = "prescriberInfo";

	public static final String EXTERNAL_TRACKING_NUMBER = "externalTrackingNumber";

	public static final String AUTO_ASSIGN_PA_TRACKING_NUMBER = "autoAssignPaTrackingNumber";

	public static final String PA_TRACKING_NUMBER = "paTrackingNumber";

	public static final String PA_TRACKING_NUMBER_ON_CLAIM_REQUIRED = "paTrackingNumberOnClaimRequired";

	public static final String AUTH_NUMBER_OF_FILLS = "authNumberOfFills";

	public static final String AUTH_REQUEST_START_DATE_TIME = "authRequestStartDateTime";

	public static final String AUTH_REQUEST_END_DATE_TIME = "authRequestEndDateTime";

	public static final String PROVIDER_ID = "providerId";

	public static final String AUTH_COMMENT = "authComment";

	public static final String INVALID_AUTH_COMMENT_LENGTH = "INVALID_AUTH_COMMENT_LENGTH";

	public static final String PROVIDERS = "providers";

	public static final String PRESCRIBERS = "prescribers";

	public static final String PRESCRIBER_ID = "prescriberId";

	public static final String PRESCRIBER_VERSION = "prescriberVersion";

	public static final String ADJUST_OR_UPDATE_OR_OVERRIDE = "adjustOrUpdateOrOverride";

	public static final String EDITS = "edits";

	public static final String EDIT_CATEGORY = "editCategory";

	public static final String BYPASS_CATEGORY = "bypassCategory";

	public static final String EDIT = "editId";

	public static final String ERROR_EDITS = "Error";

	public static final String ERROR_CRITERIA = "Error";

	public static final String ERROR_PROVIDERS = "Error";

	public static final String ERROR_PROCESSING_AN_EDIT = "ERROR_PROCESSING_AN_EDIT";

	public static final String ERROR_PROCESSING_CRITERIA = "ERROR_PROCESSING_CRITERIA";

	public static final String ERROR_PROCESSING_A_PROVIDER = "ERROR_PROCESSING_A_PROVIDER";

	public static final String EDIT_ID = "editId";

	public static final String EDIT_VERSION = "editVersion";

	public static final String MEMBER_ID = "memberId";

	public static final String INVALID_MEMBER_ID = "INVALID_MEMBER_ID";

	public static final String INVALID_MEMBER_ID_FOR_UPDATE = "INVALID_MEMBER_ID_FOR_UPDATE";

	public static final String MEMBER_PRIOR_AUTH_ID = "memberPriorAuthId";

	public static final String INVALID_MEMBER_PRIOR_AUTH_ID_FOR_UPDATE = "INVALID_MEMBER_PRIOR_AUTH_ID_FOR_UPDATE";

	public static final String INVALID_MEMBER_ID_AND_AUTH_ID_FOR_UPDATE = "INVALID_MEMBER_ID_AND_AUTH_ID_FOR_UPDATE";

	public static final String INVALID_AUTH_END_DATE_EXPIRED = "INVALID_AUTH_END_DATE_EXPIRED";

	public static final String CRITERIA_ID = "criteriaId";

	public static final String INVALID_CRITERIA_ID = "INVALID_CRITERIA_ID";

	public static final String CRITERIA_AND_DRUG_DATA = "criteriaData and drugData";

	public static final String MISSING_CRITERIA_AND_DRUG_DATA = "missing criteriaData and missing drugData";

	public static final String INVALID_CRITERIA_AND_DRUG_DATA = "INVALID_CRITERIA_AND_DRUG_DATA";

	public static final String INVALID_MISSING_CRITERIA_AND_DRUG_DATA = "INVALID_MISSING_CRITERIA_AND_DRUG_DATA";

	public static final String INVALID_DATE_RANGE = "INVALID_DATE_RANGE";

	public static final String INVALID_END_DATE_EXTENSION_DATE = "INVALID_END_DATE_EXTENSION_DATE";

	public static final String NO_AUTHORIZATION_FOUND = "NO_AUTHORIZATION_FOUND";

	public static final String ACTIVE = "0";

	public static final String DRAFT = "1";

	public static final String INACTIVE = "2";

	public static final String DELETED = "3";

	public static final String NOT_VALID_STATUS_TRANSITION = "NOT_VALID_STATUS_TRANSITION";

	public static final String INVALID_STATUS = "INVALID_STATUS_VALUE";

	public static final String INVALID_OUTCOME_FOR_DEACTIVATE = "INVALID_OUTCOME_FOR_DEACTIVATE";

	public static final String INVALID_STATUS_FOR_DEACTIVATE = "INVALID_STATUS_FOR_DEACTIVATE";

}
