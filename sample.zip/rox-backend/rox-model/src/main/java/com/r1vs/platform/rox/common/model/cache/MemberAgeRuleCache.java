package com.r1vs.platform.rox.common.model.cache;

import java.io.Serializable;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

public class MemberAgeRuleCache implements Serializable {

	private static final long serialVersionUID = 8579971067776938103L;

	private Integer relationshipType;

	private Integer relationshipClarification;

	private Integer maxAge;

	private Integer coverageLimitation;

	public Integer getRelationshipType() {

		return relationshipType;
	}

	public void setRelationshipType(final Integer relationshipType) {

		this.relationshipType = relationshipType;
	}

	public Integer getRelationshipClarification() {

		return relationshipClarification;
	}

	public void setRelationshipClarification(final Integer relationshipClarification) {

		this.relationshipClarification = relationshipClarification;
	}

	public Integer getMaxAge() {

		return maxAge;
	}

	public void setMaxAge(final Integer maxAge) {

		this.maxAge = maxAge;
	}

	public Integer getCoverageLimitation() {

		return coverageLimitation;
	}

	public void setCoverageLimitation(final Integer coverageLimitation) {

		this.coverageLimitation = coverageLimitation;
	}

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof MemberAgeRuleCache)) {
			return false;
		}
		final MemberAgeRuleCache castOther = (MemberAgeRuleCache) other;
		return new EqualsBuilder().append(relationshipType, castOther.relationshipType)
				.append(relationshipClarification, castOther.relationshipClarification).append(maxAge, castOther.maxAge)
				.append(coverageLimitation, castOther.coverageLimitation).isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(relationshipType).append(relationshipClarification).append(maxAge)
				.append(coverageLimitation).toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("relationshipType", relationshipType)
				.append("relationshipClarification", relationshipClarification).append("maxAge", maxAge)
				.append("coverageLimitation", coverageLimitation).toString();
	}

}
