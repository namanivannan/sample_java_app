package com.r1vs.platform.rox.api.service;

import com.r1vs.platform.rox.api.model.application.initiate.AccessGroupDTO;
import com.r1vs.platform.rox.api.repository.RoleRepository;
import com.r1vs.platform.rox.common.db.repository.business.AccessGroupRepository;
import com.r1vs.platform.rox.common.db.repository.business.StatusRepository;
import com.r1vs.platform.rox.common.model.users.AccessGroup;
import com.r1vs.platform.rox.common.model.users.GroupRole;
import com.r1vs.platform.rox.common.model.users.Role;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
public class AccessGroupService {

	private static Integer STATUS_ACTIVE = 0;

	@Autowired
	private ValidationUtils validationUtils;

	@Autowired
	private RoleRepository roleRepository;

	@Autowired
	private AccessGroupRepository accessGroupRepository;

	@Autowired
	private StatusRepository statusRepository;

	public AccessGroupDTO createAccessGroup(String clientId, AccessGroupDTO accessGroupDTO) {

		validationUtils.requireClient(clientId);
		AccessGroup accessGroup = new AccessGroup();
		accessGroup.setGroupRoles(new ArrayList<>());

		accessGroup.setStatusId(STATUS_ACTIVE);
		accessGroup.setGroupName(accessGroupDTO.getName());

		for (Role role : roleRepository.findBySystemNameIn(accessGroupDTO.getRoles())) {
			GroupRole groupRole = new GroupRole();
			groupRole.setRole(role);
			accessGroup.getGroupRoles().add(groupRole);
		}

		accessGroupRepository.save(accessGroup);

		return accessGroupDTO;
	}
}
