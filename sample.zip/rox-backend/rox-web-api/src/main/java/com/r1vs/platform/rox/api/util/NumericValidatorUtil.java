package com.r1vs.platform.rox.api.util;

import com.r1vs.platform.rox.api.exception.ErrorResponse;
import com.r1vs.platform.rox.api.validator.ValidationMessages;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Locale;

@Component
public class NumericValidatorUtil {

	@Autowired
	private MessageSource messageSource;

	/**
	 * Validate if incoming decimal value has correct number of decimals.
	 * 
	 * Note it will pass if the incoming field value is null.
	 * 
	 * For example, if maxAllowedDecimals is 2, then 0.954 is invalid while 0.95 is valid.
	 * 
	 * @param field
	 * @param fieldValue
	 * @param maxAllowedDecimals
	 * @return
	 */
	public ErrorResponse validateDecimalPoints(final String field, final BigDecimal fieldValue,
			final int allowedDecimalPoints) {

		if (fieldValue != null) {
			final String valueText = fieldValue.toPlainString();
			final int index = valueText.indexOf('.');
			if (index != -1 && valueText.length() - index - 1 > allowedDecimalPoints) {
				final ErrorResponse errorResponse = new ErrorResponse();
				errorResponse.setField(field);
				errorResponse.setMessage(messageSource.getMessage(ValidationMessages.TOO_MANY_DECIMAL_POINTS,
						new Object[] { field, allowedDecimalPoints }, Locale.getDefault()));
				return errorResponse;
			}
		}
		return null;
	}

	/**
	 * Min and Max decimals must not be null to do the range validation.
	 * 
	 * The fieldValue could be null and if so it will be reported as error.
	 * 
	 * If everything is passed, this method will return null.
	 * 
	 * @param field
	 * @param fieldValue
	 * @param minValue
	 * @param minInclusive
	 * @param maxValue
	 * @param maxInclusive
	 * @return
	 */
	public ErrorResponse validateDecimalRange(final String field, final BigDecimal fieldValue,
			final BigDecimal minValue,
			final boolean minInclusive, final BigDecimal maxValue, final boolean maxInclusive) {

		if (minValue == null)
			throw new RuntimeException("Null minValue passed in");
		if (maxValue == null)
			throw new RuntimeException("Null maxValue passed in");
		if (fieldValue == null
				|| (minInclusive ? fieldValue.compareTo(minValue) < 0 : fieldValue.compareTo(minValue) <= 0)
				|| (maxInclusive ? fieldValue.compareTo(maxValue) > 0 : fieldValue.compareTo(maxValue) >= 0)) {
			final ErrorResponse errorResponse = new ErrorResponse();
			errorResponse.setField(field);
			//currently ValidationUtil.addError() always set a String as the rejected value
			errorResponse.setRejectedValue(fieldValue == null ? "null" : fieldValue.toPlainString());
			if (minInclusive) {
				errorResponse.setMessage(messageSource.getMessage(
						maxInclusive ? ValidationMessages.INVALID_MIN_INCLUSIVE_AND_MAX_INCLUSIVE_RANGE
								: ValidationMessages.INVALID_MIN_INCLUSIVE_AND_MAX_EXCLUSIVE_RANGE,
						new Object[] { field, minValue.toPlainString(), maxValue.toPlainString() },
						Locale.getDefault()));
			} else {
				errorResponse.setMessage(messageSource.getMessage(
						maxInclusive ? ValidationMessages.INVALID_MIN_EXCLUSIVE_AND_MAX_INCLUSIVE_RANGE
								: ValidationMessages.INVALID_MIN_EXCLUSIVE_AND_MAX_EXCLUSIVE_RANGE,
						new Object[] { field, minValue.toPlainString(), maxValue.toPlainString() },
						Locale.getDefault()));
			}
			return errorResponse;
		}
		return null;
	}

	/**
	 * Validate if a given integer is in the range between minValue and maxValue.
	 * 
	 * If everything is passed, this method will return null.
	 * 
	 * @param field
	 * @param fieldValue
	 * @param minValue
	 * @param minInclusive
	 * @param maxValue
	 * @param maxInclusive
	 * @return
	 */
	public ErrorResponse validateIntegerRange(final String field, final Integer fieldValue, final int minValue,
			final boolean minInclusive,
			final int maxValue, final boolean maxInclusive) {

		return validateRange(field, fieldValue, Integer.valueOf(minValue), minInclusive, Integer.valueOf(maxValue),
				maxInclusive);
	}

	/**
	 * Min and Max must not be null to do the range validation.
	 * 
	 * The fieldValue could be null and if so it will be reported as error.
	 * 
	 * If everything is passed, this method will return null.
	 * 
	 * @param field
	 * @param fieldValue
	 * @param minValue
	 * @param minInclusive
	 * @param maxValue
	 * @param maxInclusive
	 * @return
	 */
	public <T extends Comparable<T>> ErrorResponse validateRange(final String field, final T fieldValue,
			final T minValue,
			final boolean minInclusive, final T maxValue, final boolean maxInclusive) {

		if (minValue == null)
			throw new RuntimeException("Null minValue passed in");
		if (maxValue == null)
			throw new RuntimeException("Null maxValue passed in");
		if (fieldValue == null
				|| (minInclusive ? fieldValue.compareTo(minValue) < 0 : fieldValue.compareTo(minValue) <= 0)
				|| (maxInclusive ? fieldValue.compareTo(maxValue) > 0 : fieldValue.compareTo(maxValue) >= 0)) {
			final ErrorResponse errorResponse = new ErrorResponse();
			errorResponse.setField(field);
			//currently ValidationUtil.addError() always set a String as the rejected value
			errorResponse.setRejectedValue(String.valueOf(fieldValue));
			if (minInclusive) {
				errorResponse.setMessage(messageSource.getMessage(
						maxInclusive ? ValidationMessages.INVALID_MIN_INCLUSIVE_AND_MAX_INCLUSIVE_RANGE
								: ValidationMessages.INVALID_MIN_INCLUSIVE_AND_MAX_EXCLUSIVE_RANGE,
						new Object[] { field, String.valueOf(minValue), String.valueOf(maxValue) },
						Locale.getDefault()));
			} else {
				errorResponse.setMessage(messageSource.getMessage(
						maxInclusive ? ValidationMessages.INVALID_MIN_EXCLUSIVE_AND_MAX_INCLUSIVE_RANGE
								: ValidationMessages.INVALID_MIN_EXCLUSIVE_AND_MAX_EXCLUSIVE_RANGE,
						new Object[] { field, String.valueOf(minValue), String.valueOf(maxValue) },
						Locale.getDefault()));
			}
			return errorResponse;
		}
		return null;
	}

	/**
	 * Check if value of startField < or <= value of endField
	 * 
	 * @param <T>
	 * @param startField
	 * @param startFieldValue
	 * @param endField
	 * @param endFieldValue
	 * @param inclusive
	 * @return
	 */
	public <T extends Comparable<T>> ErrorResponse validateLessThan(final String startField, final T startFieldValue,
			final String endField, final T endFieldValue, final boolean inclusive) {

		if (startFieldValue == null)
			throw new RuntimeException("Null startFieldValue passed in");
		if (endFieldValue == null)
			throw new RuntimeException("Null endFieldValue passed in");
		if (StringUtils.isBlank(startField))
			throw new RuntimeException("Blank startField passed in");
		if (StringUtils.isBlank(endField))
			throw new RuntimeException("Blank endField passed in");
		if (inclusive ? startFieldValue.compareTo(endFieldValue) > 0 : startFieldValue.compareTo(endFieldValue) >= 0) {
			final ErrorResponse errorResponse = new ErrorResponse();
			errorResponse.setField(startField);
			//currently ValidationUtil.addError() always set a String as the rejected value
			errorResponse.setRejectedValue(String.valueOf(startFieldValue));
			errorResponse.setMessage(messageSource.getMessage(
					inclusive ? ValidationMessages.INVALID_NOT_LARGER_THAN : ValidationMessages.INVALID_LESS_THAN,
					new Object[] { startField, endField }, Locale.getDefault()));
			return errorResponse;
		}
		return null;
	}

	/**
	 * Check if value of startField > or >= value of endField
	 * 
	 * @param <T>
	 * @param startField
	 * @param startFieldValue
	 * @param endField
	 * @param endFieldValue
	 * @param inclusive
	 * @return
	 */
	public <T extends Comparable<T>> ErrorResponse validateLargerThan(final String startField, final T startFieldValue,
			final String endField, final T endFieldValue, final boolean inclusive) {

		if (startFieldValue == null)
			throw new RuntimeException("Null startFieldValue passed in");
		if (endFieldValue == null)
			throw new RuntimeException("Null endFieldValue passed in");
		if (StringUtils.isBlank(startField))
			throw new RuntimeException("Blank startField passed in");
		if (StringUtils.isBlank(endField))
			throw new RuntimeException("Blank endField passed in");
		if (inclusive ? startFieldValue.compareTo(endFieldValue) < 0 : startFieldValue.compareTo(endFieldValue) <= 0) {
			final ErrorResponse errorResponse = new ErrorResponse();
			errorResponse.setField(startField);
			//currently ValidationUtil.addError() always set a String as the rejected value
			errorResponse.setRejectedValue(String.valueOf(startFieldValue));
			errorResponse.setMessage(messageSource.getMessage(
					inclusive ? ValidationMessages.INVALID_NOT_LESS_THAN : ValidationMessages.INVALID_LARGER_THAN,
					new Object[] { startField, endField }, Locale.getDefault()));
			return errorResponse;
		}
		return null;
	}
}
