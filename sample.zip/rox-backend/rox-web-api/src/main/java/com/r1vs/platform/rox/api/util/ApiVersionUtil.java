package com.r1vs.platform.rox.api.util;

import com.r1vs.platform.rox.RoxWriteWebApiApplication;
import org.apache.maven.model.Model;
import org.apache.maven.model.io.xpp3.MavenXpp3Reader;
import org.codehaus.plexus.util.xml.pull.XmlPullParserException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;

public class ApiVersionUtil {

	private static final Logger LOGGER = LoggerFactory.getLogger(ApiVersionUtil.class);

	private final static String POM_FILE = "pom.xml";

	public static final String META_INF_POM_PATH = "/META-INF/maven/com.r1vs.platform.rox/rox-web-api/pom.xml";

	/**
	 * This method will help you get the module version number from its pom.
	 *
	 * @return moduleVersionNumber
	 */
	public static String getModuleVersionNumber() {

		final Model model = getModel();

		if (model != null) {
			final String version = model.getVersion();
			return version != null ? version : getParentModuleVersionNumber();
		}
		return null;

	}

	/**
	 * This method will help you get the parent pom version number.
	 *
	 * @return parentModuleVersionNumber
	 */
	public static String getParentModuleVersionNumber() {

		final Model model = getModel();

		if (model != null && model.getParent() != null) {
			return model.getParent().getVersion();
		}

		return null;
	}

	/**
	 * Get the model. Read the pom.xml using MavenXpp3Reader and get the model.
	 *
	 * @return model
	 */
	private static Model getModel() {

		final MavenXpp3Reader reader = new MavenXpp3Reader();

		Model model = null;
		try {
			if (new File(POM_FILE).exists()) {
				model = reader.read(new FileReader(POM_FILE));
			} else {
				model = reader.read(
						new InputStreamReader(RoxWriteWebApiApplication.class.getResourceAsStream(META_INF_POM_PATH)));
			}
		} catch (final FileNotFoundException e) {
			LOGGER.error("File Not found: ", e.getMessage());
		} catch (final IOException e) {
			LOGGER.error("Error reading file: ", e.getMessage());
		} catch (final XmlPullParserException e) {
			LOGGER.error("Error parsing xml file: ", e.getMessage());
		}
		return model;
	}

}
