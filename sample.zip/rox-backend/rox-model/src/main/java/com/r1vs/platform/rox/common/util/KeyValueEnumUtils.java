package com.r1vs.platform.rox.common.util;

import com.r1vs.platform.rox.common.model.types.KeyValueEnum;

public class KeyValueEnumUtils {

	/**
	 *
	 * @param <E> E
	 * @param enumClass the enum class implementing KeyValueEnum
	 * @param key key
	 * @return the value in the Enum's (key,value) pair
	 */
	public static <E extends Enum<E> & KeyValueEnum> String getValueByKey(final Class<E> enumClass, final String key) {

		if (key == null) {
			return null;
		}
		for (final E constant : enumClass.getEnumConstants()) {
			if (key.contains(constant.key())) {
				return constant.value();
			}
		}
		return null;
	}

}
