package com.r1vs.platform.rox.api.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.r1vs.platform.rox.api.exception.ValidationException;
import com.r1vs.platform.rox.api.model.CreateUserRequest;
import com.r1vs.platform.rox.api.model.UserRequest;
import com.r1vs.platform.rox.api.model.admin.ClientDTO;
import com.r1vs.platform.rox.api.model.application.ds.InteractionHolderForTableDTO;
import com.r1vs.platform.rox.api.model.application.ds.InteractionResponseDTO;
import com.r1vs.platform.rox.api.model.application.ds.FCSDocumentInteractionResponseDTO;
import com.r1vs.platform.rox.api.model.application.initiate.*;
import com.r1vs.platform.rox.api.model.application.initiate.UserDTO;
import com.r1vs.platform.rox.api.repository.UserRoleRepository;
import com.r1vs.platform.rox.api.service.ds.EntityType;
import com.r1vs.platform.rox.common.db.repository.business.*;
import com.r1vs.platform.rox.common.db.repository.note.NotesRepository;
import com.r1vs.platform.rox.common.db.repository.role.PrivilegeRepository;
import com.r1vs.platform.rox.common.db.repository.role.RolePrivilegeRepository;
import com.r1vs.platform.rox.common.model.business.*;
import com.r1vs.platform.rox.common.model.business.storage.RoxFile;
import com.r1vs.platform.rox.common.model.ds.InteractionResponse;
import com.r1vs.platform.rox.common.model.notes.Notes;
import com.r1vs.platform.rox.common.model.users.*;
import com.r1vs.platform.rox.common.model.users.Role;
import com.r1vs.platform.rox.common.model.users.User;
import com.r1vs.platform.rox.common.model.users.UserRole;
import org.apache.commons.lang3.StringUtils;
import org.modelmapper.ModelMapper;
import org.modelmapper.PropertyMap;
import org.modelmapper.TypeToken;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.OffsetDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class MapperService implements InitializingBean {

	@Autowired
	private BusinessRepository businessRepository;

	@Autowired
	private UserRoleRepository userRoleRepository;

	@Autowired
	private RolePrivilegeRepository rolePrivilegeRepository;

	@Autowired
	private PrivilegeRepository privilegeRepository;

	@Autowired
	private OwnerRepository ownerRepository;

	@Autowired
	private NotesRepository notesRepository;

	@Autowired
	private IndustryTypeRepository industryTypeRepository;

	@Autowired
	private BusinessTypeRepository businessTypeRepository;

	@Autowired
	private AddressTypeRepository addressTypeRepository;

	@Autowired
	private PhoneTypeRepository phoneTypeRepository;

	@Autowired
	private EmailTypeRepository emailTypeRepository;

	@Autowired
	private IdentificationTypeRepository identificationTypeRepository;

	@Autowired
	private AuditUtilsService auditUtilsService;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	@Qualifier("nonNullModelMapper")
	private ModelMapper nonNullModelMapper;

	@Autowired
	private ObjectMapper objectMapper;

	private static final Logger LOGGER = LoggerFactory.getLogger(MapperService.class);

	@Value("${roxwrite.mapper.identification-viewable-chars}")
	private int IDENTIFICATION_SHOWN_CHARACTERS;


	@Override
	public void afterPropertiesSet() throws Exception {

		configureMappingRules(modelMapper);
		configureMappingRules(nonNullModelMapper);

	}

	private void configureMappingRules(ModelMapper inputMapper) {

		inputMapper.addMappings(new PropertyMap<BusinessDTO, Business>() {

			@Override
			protected void configure() {

				skip(destination.getEmails());
				skip(destination.getPhones());
				skip(destination.getAddresses());
				skip(destination.getIdentifications());
			}
		});

		inputMapper.addMappings(new PropertyMap<OwnerDTO, Owner>() {

			@Override
			protected void configure() {

				skip(destination.getEmails());
				skip(destination.getPhones());
				skip(destination.getAddresses());
				skip(destination.getIdentifications());
			}
		});

		inputMapper.addMappings(new PropertyMap<User, UserDTO>() {

			@Override
			protected void configure() {

				using(ctx -> generateFullname(
						((User) ctx.getSource()).getFirstName(),
						((User) ctx.getSource()).getLastName())).map(source, destination.getName());
			}
		});

		inputMapper.addMappings(new PropertyMap<Business, BusinessDTO>() {

			@Override
			protected void configure() {

				map(source.getCreatedBy(), destination.getCreatedBy());
				map(source.getUpdatedBy(), destination.getUpdatedBy());
			}
		});

		inputMapper.addMappings(new PropertyMap<Owner, OwnerDTO>() {

			@Override
			protected void configure() {

				map(source.getCreatedBy(), destination.getCreatedBy());
				map(source.getUpdatedBy(), destination.getUpdatedBy());

			}
		});

		inputMapper.addMappings(new PropertyMap<Client, ClientDTO>() {

			@Override
			protected void configure() {

				map(source.getCreatedBy(), destination.getCreatedBy());
				map(source.getUpdatedBy(), destination.getUpdatedBy());

			}
		});


		inputMapper.addMappings(new PropertyMap<Notes, NotesDTO>() {

			@Override
			protected void configure() {

				map(source.getCreatedBy(), destination.getCreatedBy());
				map(source.getUpdatedBy(), destination.getUpdatedBy());

			}
		});

		inputMapper.addMappings(new PropertyMap<RoxFile, RoxFileWithNotesDTO>() {

			@Override
			protected void configure() {

				map(source.getCreatedBy(), destination.getCreatedBy());
				map(source.getUpdatedBy(), destination.getUpdatedBy());

			}
		});

		inputMapper.addMappings(new PropertyMap<RoxFile, RoxFileDTO>() {

			@Override
			protected void configure() {

				map(source.getCreatedBy(), destination.getCreatedBy());
				map(source.getUpdatedBy(), destination.getUpdatedBy());

			}
		});

		inputMapper.addMappings(new PropertyMap<Application, ApplicationDTO>() {

			@Override
			protected void configure() {

				using(ctx -> calculateDayDifferenceDifferenceWithToday(
						((Application) ctx.getSource()).getCreatedAt())).map(source, destination.getDuration());
				map(source.getCreatedBy(), destination.getCreatedBy());
				map(source.getUpdatedBy(), destination.getUpdatedBy());
			}
		});

		inputMapper.addMappings(new PropertyMap<Identification, IdentificationDTO>() {

			@Override
			protected void configure() {
				using(ctx -> mapIdentificationField(((Identification) ctx.getSource()).getIdentification())
				).map(source, destination.getIdentification());
			}
		});

		inputMapper.addMappings(new PropertyMap<Application, MinimalApplicationDTO>() {

			@Override
			protected void configure() {

				using(ctx -> calculateDayDifferenceDifferenceWithToday(
						((Application) ctx.getSource()).getCreatedAt())).map(source, destination.getDuration());
				map(source.getCreatedBy(), destination.getCreatedBy());
				map(source.getUpdatedBy(), destination.getUpdatedBy());
			}
		});

		inputMapper.addMappings(new PropertyMap<InteractionResponse, InteractionResponseDTO>() {

			@Override
			protected void configure() {

				map(source.getCreatedBy(), destination.getCreatedBy());
				using(ctx -> convertToString(((InteractionResponse) ctx.getSource()).getResponse())).map(source,
						destination.getResponse());
				using(ctx -> mapEntityName(((InteractionResponse) ctx.getSource()))).map(source, destination.getName());
				using(ctx -> mapEntityType(((InteractionResponse) ctx.getSource()))).map(source,
						destination.getEntityType());
				using(ctx -> mapEntityUUID(((InteractionResponse) ctx.getSource()))).map(source,
						destination.getEntityUUID());
				map(source.getName(), destination.getProductName());
			}
		});

	}

	private String generateFullname(String firstname, String lastname) {

		return firstname + " " + lastname;
	}

	private Long calculateDayDifferenceDifferenceWithToday(OffsetDateTime timeReference) {

		return Duration.between(timeReference, OffsetDateTime.now()).toDays() + 1;
	}

	private JsonNode convertToString(byte[] response) {

		JsonNode jsonNode = null;
		try {
			jsonNode = response != null ? objectMapper.readTree(new String(response)) : null;
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		return jsonNode;
	}

	private String mapEntityName(InteractionResponse sourceDSResponse) {

		String name = null;
		LOGGER.error("Mapping entity with owner {} and business {} ", sourceDSResponse.getOwner(),
				sourceDSResponse.getBusiness());
		if (sourceDSResponse.getOwner() != null) {
			name = sourceDSResponse.getOwner().getFirstName() + " " + sourceDSResponse.getOwner().getLastName();
		} else if (sourceDSResponse.getBusiness() != null) {
			name = sourceDSResponse.getBusiness().getName();
		}
		return name;
	}

	private EntityType mapEntityType(InteractionResponse sourceDSResponse) {

		if (sourceDSResponse.getOwner() != null) {
			return EntityType.OWNER;
		} else if (sourceDSResponse.getBusiness() != null) {
			return EntityType.BUSINESS;
		}
		return EntityType.UNKNOWN;
	}

	private UUID mapEntityUUID(InteractionResponse sourceDSResponse) {

		if (sourceDSResponse.getOwner() != null) {
			return sourceDSResponse.getOwner().getUuid();
		}
		return sourceDSResponse.getApplication().getUuid();
	}
	private String mapIdentificationField(String plainIdentificationValue) {
		int originalLength = plainIdentificationValue.length();
		int maskLength = originalLength - IDENTIFICATION_SHOWN_CHARACTERS;
		String mask = StringUtils.repeat('*', maskLength);
		return StringUtils.overlay(plainIdentificationValue, mask, 0, maskLength);
	}

	/**
	 * Converts from BusinessDTO to BusinessEntity, set in a function in case we need to switch to manual mapping
	 *
	 * @param businessDTO DTO to convert
	 * @return JPA Entity
	 */
	public Business getEntityFromDTO(BusinessDTO businessDTO, BusinessCategory category) {
		// TODO remove clientId to let Spring do the @CreatedBy work. Added just to continue with story

		Business mappedEntity = modelMapper.map(businessDTO, Business.class);

		String industryFromDto = businessDTO.getIndustryType();
		IndustryType industryTypeFromRepository = industryTypeRepository.findByType(industryFromDto)
				.orElseThrow(() -> new ValidationException("industryType not found"));
		mappedEntity.setIndustryType(industryTypeFromRepository);

		String businessTypeFromDto = businessDTO.getBusinessType();
		BusinessType businessTypeFromRepository = getBusinessType(businessTypeFromDto);
		mappedEntity.setBusinessType(businessTypeFromRepository);

		List<Address> addressList = mapAddressDtoToEntity(businessDTO.getAddresses());

		List<Phone> phoneList = mapPhoneDtoToEntity(businessDTO.getPhones());

		List<Identification> identificationList =
				mapIndentificationDtoToEntity(businessDTO.getIdentifications());

		List<Email> emailList = mapEmailDtoToEntity(businessDTO.getEmails());

		mappedEntity.setAddresses(addressList);
		mappedEntity.setPhones(phoneList);
		mappedEntity.setIdentifications(identificationList);
		mappedEntity.setEmails(emailList);

		mappedEntity.setCategoryId(category);

		return mappedEntity;
	}

	public Owner getEntityFromDTO(OwnerDTO ownerDTO, Long clientId) {

		Owner mappedEntity = modelMapper.map(ownerDTO, Owner.class);

		List<Address> addressList = mapAddressDtoToEntity(ownerDTO.getAddresses());

		List<Phone> phoneList = mapPhoneDtoToEntity(ownerDTO.getPhones());

		List<Identification> identificationList =
				mapIndentificationDtoToEntity(ownerDTO.getIdentifications());

		List<Email> emailList = mapEmailDtoToEntity(ownerDTO.getEmails());

		mappedEntity.setAddresses(addressList);
		mappedEntity.setPhones(phoneList);
		mappedEntity.setIdentifications(identificationList);
		mappedEntity.setEmails(emailList);

		return mappedEntity;
	}

	private List<Email> mapEmailDtoToEntity(List<EmailDTO> emails) {

		if (emails == null) {
			return Collections.emptyList();
		}

		List<Email> emailList = emails.stream().map(emailDTO -> {
			Email mappedEmail = modelMapper.map(emailDTO, Email.class);
			mappedEmail.setIsPrimary(false);
			mappedEmail.setEmailType(emailTypeRepository.findByType(emailDTO.getEmailType())
					.orElseThrow(() -> new ValidationException("EmailType not found")));
			return mappedEmail;
		}).collect(Collectors.toList());

		if (!emailList.isEmpty()) {
			emailList.get(0).setIsPrimary(true);
		}
		return emailList;
	}

	private List<Identification> mapIndentificationDtoToEntity(List<IdentificationDTO> identifications) {

		if (identifications == null) {
			return Collections.emptyList();
		}

		List<Identification> identificationList = identifications.stream().map(identificationDTO -> {
			Identification mappedIdentification = modelMapper.map(identificationDTO, Identification.class);
			mappedIdentification.setIsPrimary(false);
			mappedIdentification.setIdentificationType(
					identificationTypeRepository.findByType(identificationDTO.getIdentificationType())
							.orElseThrow(() -> new ValidationException("PhoneType not found")));
			return mappedIdentification;
		}).collect(Collectors.toList());

		if (!identificationList.isEmpty()) {
			identificationList.get(0).setIsPrimary(true);
		}
		return identificationList;
	}

	private List<Address> mapAddressDtoToEntity(List<AddressDTO> addressDTOList) {

		if (addressDTOList == null) {
			return Collections.emptyList();
		}

		List<Address> addressList = addressDTOList.stream().map(addressDTO -> {
			Address mappedAddress = modelMapper.map(addressDTO, Address.class);
			mappedAddress.setIsPrimary(false);
			mappedAddress.setAddressType(addressTypeRepository.findByType(addressDTO.getAddressType())
					.orElseThrow(() -> new ValidationException("AddressType not found")));
			return mappedAddress;
		}).collect(Collectors.toList());

		if (!addressList.isEmpty()) {
			addressList.get(0).setIsPrimary(true);
		}
		return addressList;
	}

	private List<Phone> mapPhoneDtoToEntity(List<PhoneDTO> phoneDTOList) {

		if (phoneDTOList == null) {
			return Collections.emptyList();
		}

		List<Phone> phoneList = phoneDTOList.stream().map(phoneDto -> {
			Phone mappedPhone = modelMapper.map(phoneDto, Phone.class);
			mappedPhone.setIsPrimary(false);
			mappedPhone.setPhoneType(phoneTypeRepository.findByType(phoneDto.getPhoneType())
					.orElseThrow(() -> new ValidationException("PhoneType not found")));
			return mappedPhone;
		}).collect(Collectors.toList());

		if (!phoneList.isEmpty()) {
			phoneList.get(0).setIsPrimary(true);
		}
		return phoneList;
	}

	public ApplicationDTO getDtoFromEntity(Application applicationEntity) {

		auditUtilsService.recoverAuditObjects(applicationEntity);
		ApplicationDTO result = modelMapper.map(applicationEntity, ApplicationDTO.class);
		Optional<Business> businessForApplication = businessRepository.findBusinessByApplication(applicationEntity);
		if (businessForApplication.isPresent()) {
			result.setBusiness(getDtoFromEntity(businessForApplication.get(), BusinessCategory.BUSINESS, applicationEntity));
		}
		Optional<Business> debtorForApplication = businessRepository.findDebtorByApplication(applicationEntity);
		if (debtorForApplication.isPresent()) {
			result.setDebtor(getDtoFromEntity(debtorForApplication.get(), BusinessCategory.DEBTOR, null));
		}
		List<Notes> notes = notesRepository.findAllByApplicationAndRoxFileNull(applicationEntity);
		result.setNotes(modelMapper.map(notes, new TypeToken<List<NotesDTO>>() {
		}.getType()));

		List<Owner> ownersForApplication = ownerRepository.findAllByApplication(applicationEntity);
		result.setOwners(modelMapper.map(ownersForApplication, new TypeToken<List<OwnerDTO>>() {
		}.getType()));

		return result;
	}

	public MinimalApplicationDTO getMinimalDtoFromEntity(Application applicationEntity) {

		MinimalApplicationDTO result = modelMapper.map(applicationEntity, MinimalApplicationDTO.class);
		Optional<Business> businessForApplication = businessRepository.findBusinessByApplication(applicationEntity);
		businessForApplication.ifPresent(business -> result.setApplicantName(business.getName()));
		return result;
	}

	public Client patchExistingData(Client existing, Client newData) {

		nonNullModelMapper.map(newData, existing);
		return existing;
	}

	public Owner patchExistingData(Owner existing, Owner newData) {

		nonNullModelMapper.map(newData, existing);
		return existing;
	}

	public Business patchExistingData(Business existing, UpdateBusinessDTO newData) {

		nonNullModelMapper.map(newData, existing);
		return existing;
	}

	public OwnerDTO getDtoFromEntity(Owner ownerEntityToSave) {

		return modelMapper.map(ownerEntityToSave, OwnerDTO.class);
	}

	public BusinessDTO getDtoFromEntity(Business businessToSave, BusinessCategory category, Application application) {
		BusinessDTO dtoToReturn = modelMapper.map(businessToSave, BusinessDTO.class);
		if (BusinessCategory.BUSINESS.equals(category)) {
			dtoToReturn.setContractAmount(application.getContractAmount());
		}
		auditUtilsService.recoverAuditObjects(businessToSave);
		return dtoToReturn;
	}

	public InteractionResponseDTO getDtoFromInteraction(InteractionResponse interactionResponseEntity) {

		if (interactionResponseEntity != null) {
			return modelMapper.map(interactionResponseEntity, InteractionResponseDTO.class);
		} else {
			return null;
		}
	}

	public RoxFileWithNotesDTO getDTOFromEntity(RoxFile roxFile) {

		auditUtilsService.recoverAuditObjects(roxFile);
		RoxFileWithNotesDTO result = modelMapper.map(roxFile, RoxFileWithNotesDTO.class);

		List<Notes> notes = notesRepository.findAllByApplicationAndRoxFile(roxFile.getApplication(), roxFile);
		result.setNotes(modelMapper.map(notes, new TypeToken<List<NotesDTO>>() {
		}.getType()));

		return result;
	}

	public InteractionHolderForTableDTO mapToInteractionHolder(InteractionResponse interactionResponse) {

		return modelMapper.map(interactionResponse, InteractionHolderForTableDTO.class);

	}

	public Client getEntityFromDTO(ClientDTO clientDTO) {

		Client mappedEntity = modelMapper.map(clientDTO, Client.class);

		mappedEntity.setBusinessType(getBusinessType(clientDTO.getBusinessType()));

		PhoneType phoneTypeFromRepository = phoneTypeRepository.findByType(clientDTO.getPhoneType())
				.orElseThrow(() -> new ValidationException("PhoneType not found"));
		mappedEntity.setPhoneType(phoneTypeFromRepository);

		return mappedEntity;
	}

	public BusinessType getBusinessType(String businessType) {

		return businessTypeRepository.findByType(businessType)
				.orElseThrow(() -> new ValidationException("businessType not found"));
	}

	public ClientDTO getDtoFromEntity(Client client) {

		auditUtilsService.recoverAuditObjects(client);
		return modelMapper.map(client, ClientDTO.class);
	}

	public CreateUserRequest createAdminUserForClient(UserRequest userRequest) {

		CreateUserRequest createUserRequest = modelMapper.map(userRequest, CreateUserRequest.class);
		return createUserRequest;
	}

	public UserDTO getDtoFromEntity(User user) {

		auditUtilsService.recoverAuditObjects(user);
		return modelMapper.map(user, UserDTO.class);
	}

	public User patchExistingData(User existing, UpdateUserDTO newData) {
		nonNullModelMapper.map(newData, existing);
		return existing;
	}

	public User getEntityFromDTO(CreateUserRequest createUserDTO) {

		User mappedEntity = modelMapper.map(createUserDTO, User.class);

		PhoneType phoneTypeFromRepository = phoneTypeRepository.findById(createUserDTO.getPhoneTypeId())
				.orElseThrow(() -> new ValidationException("PhoneType not found"));
		mappedEntity.setPhoneTypeId(phoneTypeFromRepository.getId());

		return mappedEntity;
	}

	public UserResponseDTO getDTOFromEntity(User user){
		UserResponseDTO mappedEntity = modelMapper.map(user, UserResponseDTO.class);

		mappedEntity.setRoles(new ArrayList<>());
		for (UserRole userRole: userRoleRepository.findByUserId(user.getUserId())){
			mappedEntity.getRoles().add(userRole.getRole().getName());
		}

		return mappedEntity;
	}

	public Role getEntityFromDTO(RoleDTO roleDTO) {
		return modelMapper.map(roleDTO, Role.class);
	}

	public Role getEntityFromDTO(CreateRoleDTO createRoleDTO) {
		return modelMapper.map(createRoleDTO, Role.class);
	}

    public RoleDTO getDtoFromEntity(Role role) {
		RoleDTO mappedEntity = modelMapper.map(role, RoleDTO.class);

		mappedEntity.setPrivileges(new ArrayList<>());
		for (RolePrivilege rolePrivilege: rolePrivilegeRepository.findAllByRoleId(role.getRoleId())){
			mappedEntity.getPrivileges().add(
					privilegeRepository.getById(rolePrivilege.getPrivilegeId())
							.getSystemName());
		}

		return mappedEntity;
    }

	public Privilege getEntityFromDTO(PrivilegeDTO privilegeDTO) {
		return modelMapper.map(privilegeDTO, Privilege.class);
	}

	public PrivilegeDTO getDTOFromEntity(Privilege privilege) {
		return modelMapper.map(privilege, PrivilegeDTO.class);
	}

    public FCSDocumentInteractionResponseDTO getDTOFromEntity(InteractionResponse interactionResponse) {
		return modelMapper.map(interactionResponse, FCSDocumentInteractionResponseDTO.class);
    }
}
