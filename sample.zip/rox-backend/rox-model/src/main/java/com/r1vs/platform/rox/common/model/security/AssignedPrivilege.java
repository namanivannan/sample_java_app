package com.r1vs.platform.rox.common.model.security;

import java.io.Serializable;
import java.util.Objects;

/**
 * This represents a privilege in the system. Normally it is assigned to a role as an association in the role_privilege
 * table.
 */
public class AssignedPrivilege implements Serializable {

	private static final long serialVersionUID = 155875799252196168L;

	private String privilegeName;

	public AssignedPrivilege() {

		super();
	}

	public AssignedPrivilege(final String privilegeName) {

		super();
		this.privilegeName = privilegeName;
	}

	public String getPrivilegeName() {

		return privilegeName;
	}

	public void setPrivilegeName(final String privilege) {

		this.privilegeName = privilege;
	}

	@Override
	public int hashCode() {

		return Objects.hash(privilegeName);
	}

	@Override
	public boolean equals(final Object obj) {

		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final AssignedPrivilege other = (AssignedPrivilege) obj;
		return Objects.equals(privilegeName, other.privilegeName);
	}

	@Override
	public String toString() {

		return "AssignedPrivilege [privilegeName=" + privilegeName + "]";
	}

}
