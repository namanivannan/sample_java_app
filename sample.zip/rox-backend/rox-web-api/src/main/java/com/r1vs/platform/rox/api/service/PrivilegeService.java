package com.r1vs.platform.rox.api.service;

import com.r1vs.platform.rox.api.exception.RoxApiException;
import com.r1vs.platform.rox.api.model.application.initiate.PrivilegeDTO;
import com.r1vs.platform.rox.common.db.repository.role.PrivilegeRepository;
import com.r1vs.platform.rox.common.model.users.Privilege;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class PrivilegeService {

	@Autowired
	private PrivilegeRepository privilegeRepository;

	@Autowired
	private ValidationUtils validationUtils;

	@Autowired
	private MapperService mapperService;


	public List<Privilege> getAllByPrivilegeIdIn(List<Integer> privilegeIdList) {

		return privilegeRepository.findAllByPrivilegeIdIn(privilegeIdList);
	}

	public List<Privilege> getAllByName(List<String> privilegeNameList) {

		return privilegeRepository.findAllBySystemNameIn(privilegeNameList);
	}


	public List<PrivilegeDTO> getAllPrivileges(String clientId){
		validationUtils.requireClient(clientId);
		List<PrivilegeDTO> privilegeDTOS = new ArrayList<>();
		for (Privilege privilege: privilegeRepository.findAll()){
			privilegeDTOS.add(mapperService.getDTOFromEntity(privilege));
		}
		return privilegeDTOS;
	}

	public PrivilegeDTO createPrivilege(String clientId, PrivilegeDTO privilegeDTO) {
		validationUtils.requireClient(clientId);
		if (privilegeRepository.findBySystemName(privilegeDTO.systemName).isPresent()){
			throw new RoxApiException("System Name already registered", HttpStatus.BAD_REQUEST);
		}
		privilegeRepository.save(mapperService.getEntityFromDTO(privilegeDTO));
		return privilegeDTO;
	}

	public PrivilegeDTO updatePrivilege(String clientId, String systemName, PrivilegeDTO privilegeDTO) {
		validationUtils.requireClient(clientId);
		Privilege privilege = validationUtils.requirePrivilege(systemName);
		privilege.setName(privilegeDTO.name);
		privilegeRepository.save(privilege);
		return mapperService.getDTOFromEntity(privilege);
	}
}