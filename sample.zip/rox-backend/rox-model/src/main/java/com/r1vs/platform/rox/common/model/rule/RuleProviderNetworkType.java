package com.r1vs.platform.rox.common.model.rule;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@Entity
@Table(name = "rule_provider_network_type")
public class RuleProviderNetworkType implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "rule_id", nullable = false)
	private Integer ruleId;

	@Id
	@Column(name = "provider_network_type_id", nullable = false)
	private Integer providerNetworkTypeId;

	public Integer getRuleId() {

		return ruleId;
	}

	public void setRuleId(final Integer ruleId) {

		this.ruleId = ruleId;
	}

	public Integer getProviderNetworkTypeId() {

		return providerNetworkTypeId;
	}

	public void setProviderNetworkTypeId(final Integer providerNetworkTypeId) {

		this.providerNetworkTypeId = providerNetworkTypeId;
	}

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof RuleProviderNetworkType)) {
			return false;
		}
		final RuleProviderNetworkType castOther = (RuleProviderNetworkType) other;
		return new EqualsBuilder().append(ruleId, castOther.ruleId)
				.append(providerNetworkTypeId, castOther.providerNetworkTypeId).isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(ruleId).append(providerNetworkTypeId).toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("ruleId", ruleId).append("providerNetworkTypeId", providerNetworkTypeId)
				.toString();
	}

}
