package com.r1vs.platform.rox.api.validator.user;

import com.r1vs.platform.rox.api.business.UserService;
import com.r1vs.platform.rox.api.exception.Error;
import com.r1vs.platform.rox.api.model.UserRequest;
import com.r1vs.platform.rox.api.processor.UserReferenceProcessor;
import com.r1vs.platform.rox.api.validator.RoxWriteWebApiValidator;
import com.r1vs.platform.rox.api.validator.ValidationMessages;
import com.r1vs.platform.rox.common.model.users.AccessGroup;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import java.util.Optional;

import static com.r1vs.platform.rox.api.util.ValidationUtil.addError;
import static com.r1vs.platform.rox.api.util.ValidationUtil.handleException;
import static java.util.Objects.nonNull;

@Component
public class UserValidator implements RoxWriteWebApiValidator<UserRequest> {

	private static final String PHONE_TYPE_CODE_ID = "phoneTypeCodeId";

	public static final String ACCESS_GROUP_ID = "accessGroupId";

	@Autowired
	private UserReferenceProcessor userReferenceProcessor;

	@Autowired
	private UserService userService;

	@Autowired
	protected MessageSource messageSource;

	@Override
	public void validate(final UserRequest userRequest) {

		final Error error = new Error();
		/*
				if (userRequest.getPhoneTypeCodeId() != null && !isValidPhoneTypeCodeId(userRequest.getPhoneTypeCodeId())) {
		
					addError(error, PHONE_TYPE_CODE_ID, ValidationMessages.INVALID_PHONE_TYPE_CODE_ID,
							userRequest.getPhoneTypeCodeId().toString());
				}
		
				if (nonNull(userRequest.getAccessGroupId())) {
		
					final Optional<AccessGroup> accessGroup = null;
		
					if (accessGroup.isEmpty()) {
						addError(error, ACCESS_GROUP_ID, ValidationMessages.INVALID_ACCESS_GROUP_ID,
								userRequest.getAccessGroupId().toString());
					}
				}
		*/
		handleException(error);

	}

	private boolean isValidPhoneTypeCodeId(final Integer codeId) {

		return userReferenceProcessor.getPhoneReference().containsKey(codeId);
	}

}
