package com.r1vs.platform.rox.common.model.business;

import com.r1vs.platform.rox.common.model.AuditedEntity;
import com.r1vs.platform.rox.common.model.notes.Notes;
import com.r1vs.platform.rox.common.model.users.User;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.List;
import java.util.UUID;

@Entity
@Table(name = "clients")
@EntityListeners(AuditingEntityListener.class)
public class Client extends AuditedEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@Column(name = "uuid")
	private UUID uuid;

	@Column(name = "code")
	private String code;

	@Column(name = "name")
	private String name;

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "client")
	private List<User> users;

	@OneToOne
	@JoinColumn(name = "business_type_id", nullable = false)
	private BusinessType businessType;

	@Column(name = "address1")
	private String address1;

	@Column(name = "address2")
	private String address2;

	@Column(name = "ein")
	private String ein;

	@Column(name = "phone")
	private String phone;


	@Column(name = "city")
	private String city;


	@Column(name = "state")
	private String state;


	@Column(name = "zip4")
	private String zip4;


	@Column(name = "zip5")
	private String zip5;


	@Column(name = "county")
	private String county;

	@OneToOne
	@JoinColumn(name = "phone_type_id", nullable = false)
	private PhoneType phoneType;

	@Column(name = "website")
	private String website;

	@Column(name = "active")
	private Long active;

	public Long getId() {

		return this.id;
	}

	public void setId(Long id) {

		this.id = id;
	}

	public UUID getUuid() {

		return uuid;
	}

	public void setUuid(UUID uuid) {

		this.uuid = uuid;
	}

	public String getCode() {

		return this.code;
	}

	public void setCode(String code) {

		this.code = code;
	}

	public String getName() {

		return this.name;
	}

	public void setName(String name) {

		this.name = name;
	}

	public BusinessType getBusinessType() {

		return businessType;
	}

	public void setBusinessType(BusinessType businessType) {

		this.businessType = businessType;
	}

	public String getAddress1() {

		return address1;
	}

	public void setAddress1(String address1) {

		this.address1 = address1;
	}

	public String getAddress2() {

		return address2;
	}

	public void setAddress2(String address2) {

		this.address2 = address2;
	}

	public String getEin() {

		return this.ein;
	}

	public void setEin(String ein) {

		this.ein = ein;
	}

	public String getPhone() {

		return phone;
	}

	public void setPhone(String phone) {

		this.phone = phone;
	}

	public String getWebsite() {

		return this.website;
	}

	public void setWebsite(String website) {

		this.website = website;
	}

	public Long getActive() {

		return this.active;
	}

	public void setActive(Long active) {

		this.active = active;
	}

	public PhoneType getPhoneType() {

		return phoneType;
	}

	public void setPhoneType(PhoneType phoneType) {

		this.phoneType = phoneType;
	}

	public List<User> getUsers() {

		return users;
	}

	public void setUsers(List<User> users) {

		this.users = users;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZip4() {
		return zip4;
	}

	public void setZip4(String zip4) {
		this.zip4 = zip4;
	}

	public String getZip5() {
		return zip5;
	}

	public void setZip5(String zip5) {
		this.zip5 = zip5;
	}

	public String getCounty() {
		return county;
	}

	public void setCounty(String county) {
		this.county = county;
	}
}
