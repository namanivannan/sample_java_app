package com.r1vs.platform.rox.common.model;

import javax.validation.constraints.Email;
import javax.validation.constraints.Size;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.hibernate.validator.constraints.Length;

public class ContactDetails {

	@Size(min = 0, max = 30)
	private String firstName;

	@Size(min = 0, max = 35)
	private String lastName;

	@Length(max = 1, message = "middle initial size cannot exceed 1 characters")
	private String middleInitial;

	@Length(max = 30, message = "contact title cannot exceed 30 characters")
	private String contactTitle;

	@Length(max = 55, message = "mailingAddressLine1 cannot exceed 55 characters")
	private String mailingAddressLine1;

	@Length(max = 55, message = "mailingAddressLine2 cannot exceed 55 characters")
	private String mailingAddressLine2;

	@Length(max = 30, message = "city cannot exceed 30 characters")
	private String city;

	@Length(max = 5, message = "countyParish size cannot exceed 5 characters")
	private String countyParish;

	@Length(max = 2, message = "state size cannot exceed 2 characters")
	private String state;

	@Length(max = 9, message = "zipCode size cannot exceed 9 characters")
	private String zipCode;

	@Length(max = 10, message = "phone number size cannot exceed 10 digits")
	private String phoneNumber;

	@Length(max = 10, message = "fax number size cannot exceed 10 digits")
	private String faxNumber;

	@Length(max = 2, message = "contact type size cannot exceed 2 characters")
	private String contactType;

	@Length(max = 5, message = "phone extension size cannot exceed 5 characters")
	private String phoneExtension;

	@Length(max = 50, message = "email address cannot exceed 50 characters")
	@Email
	private String emailAddress;

	private String prefix;

	private String suffix;

	public String getFirstName() {

		return firstName;
	}

	public void setFirstName(final String firstName) {

		this.firstName = firstName;
	}

	public String getLastName() {

		return lastName;
	}

	public void setLastName(final String lastName) {

		this.lastName = lastName;
	}

	public String getMiddleInitial() {

		return middleInitial;
	}

	public void setMiddleInitial(final String middleInitial) {

		this.middleInitial = middleInitial;
	}

	public String getContactTitle() {

		return contactTitle;
	}

	public void setContactTitle(final String contactTitle) {

		this.contactTitle = contactTitle;
	}

	public String getMailingAddressLine1() {

		return mailingAddressLine1;
	}

	public void setMailingAddressLine1(final String mailingAddressLine1) {

		this.mailingAddressLine1 = mailingAddressLine1;
	}

	public String getMailingAddressLine2() {

		return mailingAddressLine2;
	}

	public void setMailingAddressLine2(final String mailingAddressLine2) {

		this.mailingAddressLine2 = mailingAddressLine2;
	}

	public String getCity() {

		return city;
	}

	public void setCity(final String city) {

		this.city = city;
	}

	public String getCountyParish() {

		return countyParish;
	}

	public void setCountyParish(final String countyParish) {

		this.countyParish = countyParish;
	}

	public String getState() {

		return state;
	}

	public void setState(final String state) {

		this.state = state;
	}

	public String getZipCode() {

		return zipCode;
	}

	public void setZipCode(final String zipCode) {

		this.zipCode = zipCode;
	}

	public String getPhoneNumber() {

		return phoneNumber;
	}

	public void setPhoneNumber(final String phoneNumber) {

		this.phoneNumber = phoneNumber;
	}

	public String getFaxNumber() {

		return faxNumber;
	}

	public void setFaxNumber(final String faxNumber) {

		this.faxNumber = faxNumber;
	}

	public String getContactType() {

		return contactType;
	}

	public void setContactType(final String contactType) {

		this.contactType = contactType;
	}

	public String getPhoneExtension() {

		return phoneExtension;
	}

	public void setPhoneExtension(final String phoneExtension) {

		this.phoneExtension = phoneExtension;
	}

	public String getEmailAddress() {

		return emailAddress;
	}

	public void setEmailAddress(final String emailAddress) {

		this.emailAddress = emailAddress;
	}

	public String getPrefix() {

		return prefix;
	}

	public void setPrefix(final String prefix) {

		this.prefix = prefix;
	}

	public String getSuffix() {

		return suffix;
	}

	public void setSuffix(final String suffix) {

		this.suffix = suffix;
	}

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof ContactDetails)) {
			return false;
		}
		final ContactDetails castOther = (ContactDetails) other;
		return new EqualsBuilder().append(firstName, castOther.firstName).append(lastName, castOther.lastName)
				.append(middleInitial, castOther.middleInitial).append(contactTitle, castOther.contactTitle)
				.append(mailingAddressLine1, castOther.mailingAddressLine1)
				.append(mailingAddressLine2, castOther.mailingAddressLine2).append(city, castOther.city)
				.append(countyParish, castOther.countyParish).append(state, castOther.state)
				.append(zipCode, castOther.zipCode).append(phoneNumber, castOther.phoneNumber)
				.append(faxNumber, castOther.faxNumber).append(contactType, castOther.contactType)
				.append(phoneExtension, castOther.phoneExtension).append(emailAddress, castOther.emailAddress)
				.append(prefix, castOther.prefix).append(suffix, castOther.suffix).isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(firstName).append(lastName).append(middleInitial).append(contactTitle)
				.append(mailingAddressLine1).append(mailingAddressLine2).append(city).append(countyParish).append(state)
				.append(zipCode).append(phoneNumber).append(faxNumber).append(contactType).append(phoneExtension)
				.append(emailAddress).append(prefix).append(suffix).toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("firstName", firstName).append("lastName", lastName)
				.append("middleInitial", middleInitial).append("contactTitle", contactTitle)
				.append("mailingAddressLine1", mailingAddressLine1).append("mailingAddressLine2", mailingAddressLine2)
				.append("city", city).append("countyParish", countyParish).append("state", state)
				.append("zipCode", zipCode).append("phoneNumber", phoneNumber).append("faxNumber", faxNumber)
				.append("contactType", contactType).append("phoneExtension", phoneExtension)
				.append("emailAddress", emailAddress).append("prefix", prefix).append("suffix", suffix).toString();
	}

}
