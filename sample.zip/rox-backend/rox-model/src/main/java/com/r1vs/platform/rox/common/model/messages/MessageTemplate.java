package com.r1vs.platform.rox.common.model.messages;

import com.r1vs.platform.rox.common.model.AuditedEntity;
import com.r1vs.platform.rox.common.model.business.Status;
import com.r1vs.platform.rox.common.model.business.Client;
import org.apache.commons.lang3.builder.CompareToBuilder;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "message_template")
public class MessageTemplate extends AuditedEntity implements Serializable, Comparable<MessageTemplate> {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "message_template_id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer messageTemplateId;

	@Column(name = "message_name", nullable = false)
	private String messageName;

	@Column(name = "message_type", nullable = false)
	private String messageType;

	@Column(name = "privacy_setting", nullable = true)
	private String privacySetting;

	@Column(name = "privacy_level", nullable = true)
	private String privacyLevel;

	@Column(name = "description", nullable = false)
	private String description;

	@Column(name = "template", nullable = false)
	private String template;

	@Column(name = "work_queue", nullable = false)
	private String workQueue;

	@Column(name = "client_id")
	private Integer clientId;

	@Column(name = "status_id")
	@NotNull
	private Integer statusId;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "status_id", nullable = false, insertable = false, updatable = false)
	private Status status;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "client_id", nullable = false, insertable = false, updatable = false)
	private Client client;

	public static long getSerialVersionUID() {

		return serialVersionUID;
	}

	public Integer getClientId() {

		return clientId;
	}

	public void setClientId(Integer pbmId) {

		this.clientId = pbmId;
	}

	public Integer getStatusId() {

		return statusId;
	}

	public void setStatusId(Integer statusId) {

		this.statusId = statusId;
	}

	public Integer getMessageTemplateId() {

		return messageTemplateId;
	}

	public void setMessageTemplateId(Integer messageTemplateId) {

		this.messageTemplateId = messageTemplateId;
	}

	public String getMessageName() {

		return messageName;
	}

	public void setMessageName(String messageName) {

		this.messageName = messageName;
	}

	public String getWorkQueue() {

		return workQueue;
	}

	public void setWorkQueue(String workQueue) {

		this.workQueue = workQueue;
	}

	public String getMessageType() {

		return messageType;
	}

	public void setMessageType(String messageType) {

		this.messageType = messageType;
	}

	public String getPrivacySetting() {

		return privacySetting;
	}

	public void setPrivacySetting(String privacySetting) {

		this.privacySetting = privacySetting;
	}

	public String getPrivacyLevel() {

		return privacyLevel;
	}

	public void setPrivacyLevel(String privacyLevel) {

		this.privacyLevel = privacyLevel;
	}

	public String getDescription() {

		return description;
	}

	public void setDescription(String description) {

		this.description = description;
	}

	public String getTemplate() {

		return template;
	}

	public void setTemplate(String template) {

		this.template = template;
	}

	public Client getClient() {

		return client;
	}

	public void setClient(Client client) {

		this.client = client;
	}

	public Status getStatus() {

		return status;
	}

	public void setStatus(Status status) {

		this.status = status;
	}

	@Override
	public int compareTo(MessageTemplate other) {

		return new CompareToBuilder().append(messageTemplateId, other.messageTemplateId).toComparison();
	}

	@Override
	public String toString() {

		return "MessageTemplate{" +
				"messageTemplateId=" + messageTemplateId +
				", messageName='" + messageName + '\'' +
				", messageType='" + messageType + '\'' +
				", publicPrivateSettings='" + privacySetting + '\'' +
				", privacyLevel='" + privacyLevel + '\'' +
				", description='" + description + '\'' +
				", template='" + template + '\'' +
				", workQueue='" + workQueue + '\'' +
				", clientId=" + clientId +
				", statusId=" + statusId +
				", status=" + status +
				", client=" + client +
				'}';
	}
}
