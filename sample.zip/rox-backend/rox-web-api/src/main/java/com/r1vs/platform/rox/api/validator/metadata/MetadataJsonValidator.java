package com.r1vs.platform.rox.api.validator.metadata;

import com.jsoniter.any.Any;
import com.r1vs.platform.rox.api.exception.Error;
import com.r1vs.platform.rox.api.util.InterceptorConstants;
import com.r1vs.platform.rox.api.validator.ValidationMessages;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;

import static com.r1vs.platform.rox.api.util.ValidationUtil.addError;
import static com.r1vs.platform.rox.api.util.ValidationUtil.handleException;

public interface MetadataJsonValidator {

	void validate(Any t, Integer statusId);

	/**
	 * Validate and get the pbm id from the request stored in the interceptor.
	 *
	 * @return pbmId
	 */
	default Integer getClientIdForRequest() {

		final ServletRequestAttributes requestAttributes = (ServletRequestAttributes) RequestContextHolder
				.currentRequestAttributes();
		final HttpServletRequest request = requestAttributes.getRequest();
		final Integer clientId = request.getHeader(InterceptorConstants.CLIENT_ID) != null
				? Integer.valueOf(request.getHeader(InterceptorConstants.CLIENT_ID))
				: null;
		if (clientId == null) {
			final Error error = new Error();
			addError(error, InterceptorConstants.CLIENT_ID, ValidationMessages.INVALID_CLIENT_ID, null);
			handleException(error);
		}
		return clientId;
	}

}
