package com.r1vs.platform.rox.api.controller;

import com.r1vs.platform.rox.api.model.application.initiate.NotesDTO;
import com.r1vs.platform.rox.api.model.application.initiate.UpdateNoteDTO;
import com.r1vs.platform.rox.api.service.NotesService;
import com.r1vs.platform.rox.common.model.notes.Notes;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

import java.util.UUID;

import static com.r1vs.platform.rox.api.constants.ControllerConstants.*;
import static com.r1vs.platform.rox.api.util.ControllerUtils.getPageableFromHeaderParams;
import static com.r1vs.platform.rox.api.util.InterceptorConstants.CLIENT_ID;

@RestController
@RequestMapping("/v1")
public class NotesController {

	@Autowired
	private NotesService notesService;

	@PostMapping("/applications/{applicationId}/notes")
	@Operation(summary = "Create new Note in an application")
	public ResponseEntity<NotesDTO> createNote(@RequestHeader(CLIENT_ID) String clientId,
			@PathVariable UUID applicationId,
			@RequestBody NotesDTO notesDTO) {

		return new ResponseEntity<>(notesService.createNoteInApplication(clientId, applicationId, notesDTO),
				HttpStatus.CREATED);
	}

	@GetMapping("/applications/{applicationId}/notes")
	@Operation(summary = "Get Notes With Pagination")
	public ResponseEntity<Page<NotesDTO>> getNotes(
			@RequestHeader(value = X_PAGINATION_LIMIT, defaultValue = "20") Integer pageLimit,
			@RequestHeader(value = X_PAGINATION_NUM, defaultValue = "0") Integer pageNumber,
			@RequestHeader(value = X_PAGINATION_SORT, defaultValue = "createdAt,desc") String sortingParam,
			@RequestHeader(CLIENT_ID) String clientId,
			@PathVariable UUID applicationId) {

		Pageable pageParams = getPageableFromHeaderParams(pageLimit, pageNumber, sortingParam);
		return new ResponseEntity<>(notesService.getNotes(applicationId, clientId, pageParams), HttpStatus.OK);
	}

	@GetMapping("/applications/{applicationId}/notes/{noteId}")
	@Operation(summary = "Get Note")
	public ResponseEntity<NotesDTO> getNote(
			@RequestHeader(CLIENT_ID) String clientId,
			@PathVariable UUID applicationId,
			@PathVariable UUID noteId) {

		return new ResponseEntity<>(notesService.getNote(applicationId, noteId, clientId), HttpStatus.OK);
	}

	@PatchMapping("/applications/{applicationId}/notes/{noteId}")
	@Operation(summary = "Edit note of an Application")
	public ResponseEntity<NotesDTO> editNoteOfAnApplication(@RequestHeader(CLIENT_ID) String clientId,
			@PathVariable UUID applicationId,
			@PathVariable UUID noteId,
			@RequestBody UpdateNoteDTO notesDTO) {

		return new ResponseEntity<>(notesService.editNoteInApplication(clientId, applicationId, noteId, notesDTO),
				HttpStatus.OK);
	}

	@PostMapping("/applications/{applicationId}/files/{fileId}/notes")
	@Operation(summary = "Create new Note in Application Attachment")
	public ResponseEntity<NotesDTO> createNoteInAttachment(@RequestHeader(CLIENT_ID) String clientId,
			@PathVariable UUID applicationId,
			@PathVariable UUID fileId,
			@RequestBody NotesDTO notesDTO) {

		return new ResponseEntity<>(notesService.createNoteInAttachment(clientId, applicationId, fileId, notesDTO),
				HttpStatus.CREATED);
	}

	@PatchMapping("/applications/{applicationId}/files/{fileId}/notes/{noteId}")
	@Operation(summary = "Edit note of an Attachment")
	public ResponseEntity<NotesDTO> editNoteOfAnAttachment(@RequestHeader(CLIENT_ID) String clientId,
			@PathVariable UUID applicationId,
			@PathVariable UUID fileId,
			@PathVariable UUID noteId,
			@RequestBody UpdateNoteDTO notesDTO) {

		return new ResponseEntity<>(
				notesService.editNoteInAttachment(clientId, applicationId, fileId, noteId, notesDTO), HttpStatus.OK);
	}
}
