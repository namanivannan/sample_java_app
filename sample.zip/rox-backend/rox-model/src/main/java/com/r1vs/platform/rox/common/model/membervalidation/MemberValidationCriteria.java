package com.r1vs.platform.rox.common.model.membervalidation;

import com.r1vs.platform.rox.common.model.AuditedEntity;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "member_validation_criteria")
public class MemberValidationCriteria extends AuditedEntity implements Serializable {

	private static final long serialVersionUID = 3529528864595079251L;

	@Id
	@Column(name = "member_validation_criteria_id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long memberValidationCriteriaId;

	@Column(name = "status_id")
	@NotNull
	private Integer statusId;

	@Column(name = "name")
	@NotNull
	private String name;

	@Column(name = "description")
	private String description;

	@Column(name = "validation_criteria_type_id")
	@NotNull
	private Integer validationCriteriaTypeId;

	@Column(name = "json", nullable = false)
	@NotNull
	private String json;

	public Long getMemberValidationCriteriaId() {

		return memberValidationCriteriaId;
	}

	public void setMemberValidationCriteriaId(final Long memberValidationCriteriaId) {

		this.memberValidationCriteriaId = memberValidationCriteriaId;
	}

	public Integer getStatusId() {

		return statusId;
	}

	public void setStatusId(final Integer statusId) {

		this.statusId = statusId;
	}

	public String getName() {

		return name;
	}

	public void setName(final String name) {

		this.name = name;
	}

	public String getDescription() {

		return description;
	}

	public void setDescription(final String description) {

		this.description = description;
	}

	public Integer getValidationCriteriaTypeId() {

		return validationCriteriaTypeId;
	}

	public void setValidationCriteriaTypeId(final Integer validationCriteriaTypeId) {

		this.validationCriteriaTypeId = validationCriteriaTypeId;
	}

	public String getJson() {

		return json;
	}

	public void setJson(final String json) {

		this.json = json;
	}

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof MemberValidationCriteria)) {
			return false;
		}
		final MemberValidationCriteria castOther = (MemberValidationCriteria) other;
		return new EqualsBuilder().append(memberValidationCriteriaId, castOther.memberValidationCriteriaId)
				.append(statusId, castOther.statusId).append(name, castOther.name)
				.append(description, castOther.description)
				.append(validationCriteriaTypeId, castOther.validationCriteriaTypeId).append(json, castOther.json)
				.isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(memberValidationCriteriaId).append(statusId).append(name)
				.append(description).append(validationCriteriaTypeId).append(json).toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("memberValidationCriteriaId", memberValidationCriteriaId)
				.append("statusId", statusId).append("name", name).append("description", description)
				.append("validationCriteriaTypeId", validationCriteriaTypeId).append("json", json).toString();
	}

}
