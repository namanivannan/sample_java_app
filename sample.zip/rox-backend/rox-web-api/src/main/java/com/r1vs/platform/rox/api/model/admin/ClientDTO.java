package com.r1vs.platform.rox.api.model.admin;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.r1vs.platform.rox.api.model.application.initiate.UserDTO;

import java.io.Serializable;
import java.time.OffsetDateTime;

public class ClientDTO implements Serializable {

	private Long clientId;

    private String Uuid;

	private String code;

	private String name;

	private String businessType;

	private String address1;

	private String address2;

	private String city;

	private String state;

	private String zip4;

	private String zip5;

	private String county;

	private String ein;

	private String phoneType;

	private String phone;

	private String website;

	private OffsetDateTime createdAt;

	private OffsetDateTime updatedAt;

	private UserDTO createdBy;

	private UserDTO updatedBy;

    public String getUuid() {

		return Uuid;
	}

	public void setUuid(String uuid) {

		Uuid = uuid;
	}

	public String getCode() {

		return code;
	}

	public void setCode(String code) {

		this.code = code;
	}

	public String getName() {

		return name;
	}

	public void setName(String name) {

		this.name = name;
	}

	public String getBusinessType() {

		return businessType;
	}

	public void setBusinessType(String businessType) {

		this.businessType = businessType;
	}

	public String getAddress1() {

		return address1;
	}

	public void setAddress1(String address1) {

		this.address1 = address1;
	}

	public String getAddress2() {

		return address2;
	}

	public void setAddress2(String address2) {

		this.address2 = address2;
	}

	public String getCity() {

		return city;
	}

	public void setCity(String city) {

		this.city = city;
	}

	public String getState() {

		return state;
	}

	public void setState(String state) {

		this.state = state;
	}

	public String getZip4() {

		return zip4;
	}

	public void setZip4(String zip4) {

		this.zip4 = zip4;
	}

	public String getZip5() {

		return zip5;
	}

	public void setZip5(String zip5) {

		this.zip5 = zip5;
	}

	public String getCounty() {

		return county;
	}

	public void setCounty(String county) {

		this.county = county;
	}

	public String getEin() {

		return ein;
	}

	public void setEin(String ein) {

		this.ein = ein;
	}

	public String getPhoneType() {

		return phoneType;
	}

	public void setPhoneType(String phoneType) {

		this.phoneType = phoneType;
	}

	public String getPhone() {

		return phone;
	}

	public void setPhone(String phone) {

		this.phone = phone;
	}

	public String getWebsite() {

		return website;
	}

	public void setWebsite(String website) {

		this.website = website;
	}

	public OffsetDateTime getCreatedAt() {

		return createdAt;
	}

	public void setCreatedAt(OffsetDateTime createdAt) {

		this.createdAt = createdAt;
	}

	public OffsetDateTime getUpdatedAt() {

		return updatedAt;
	}

	public void setUpdatedAt(OffsetDateTime updatedAt) {

		this.updatedAt = updatedAt;
	}

	public UserDTO getCreatedBy() {

		return createdBy;
	}

	public void setCreatedBy(UserDTO createdBy) {

		this.createdBy = createdBy;
	}

	public UserDTO getUpdatedBy() {

		return updatedBy;
	}

	public void setUpdatedBy(UserDTO updatedBy) {

		this.updatedBy = updatedBy;
	}

	public Long getClientId() {
		return clientId;
	}

	public void setClientId(Long clientId) {
		this.clientId = clientId;
	}
}
