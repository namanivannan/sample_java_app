package com.r1vs.platform.rox.api.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.r1vs.platform.rox.api.model.application.initiate.NotesDTO;

import static org.hamcrest.collection.IsEmptyCollection.empty;
import com.r1vs.platform.rox.common.util.StringUtil;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.transaction.annotation.Transactional;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.hamcrest.Matchers.*;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@Sql("fixture2.sql")
public class NotesControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private DBConnection dbConnection;

	private String token;

	@Before
	public void setUp() throws Exception {

		if (StringUtil.isNullOrEmpty(token)) {
			token = dbConnection.loginToDb();
		}
	}

	@Test
	public void givenValidNoteAndApplication_whenCreateNoteEndpointIsHit_thenCreateNoteAndReturn200() throws Exception {

		NotesDTO notesDTO = new NotesDTO();
		notesDTO.setNotes("Note Test");

		mockMvc.perform(MockMvcRequestBuilders.post("/v1/applications/839e72fc-6433-46fd-a259-5dbb50b913d6/notes")
				.contentType(MediaType.APPLICATION_JSON)
				.header("x-client-id", "11")
				.header("Authorization", token)
				.content(objectMapper.writeValueAsString(notesDTO)))
				.andExpect(status().isCreated())
				.andExpect(jsonPath("$.notes", is("Note Test")))
				.andDo(print());

		mockMvc.perform(MockMvcRequestBuilders.get("/v1/applications/839e72fc-6433-46fd-a259-5dbb50b913d6")
				.contentType(MediaType.APPLICATION_JSON)
				.header("x-client-id", "11")
				.header("Authorization", token))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.notes", hasSize(1)))
				.andDo(print());
	}

	@Test
	public void givenValidNoteAndNotValidApplication_whenCreateNoteEndpointIsHit_thenReturn404() throws Exception {

		NotesDTO notesDTO = new NotesDTO();
		notesDTO.setNotes("Note Test");

		mockMvc.perform(MockMvcRequestBuilders.post("/v1/applications/11bdce27-8228-40ac-afbb-ea6894e55d17/notes")
				.contentType(MediaType.APPLICATION_JSON)
				.header("x-client-id", "11")
				.header("Authorization", token)
				.content(objectMapper.writeValueAsString(notesDTO)))
				.andExpect(status().isNotFound())
				.andDo(print());
	}

	@Test
	public void givenValidNoteAndFile_whenCreateNoteEndpointIsHit_thenCreateNoteAndReturn200() throws Exception {

		NotesDTO applicationNotesDTO = new NotesDTO();
		applicationNotesDTO.setNotes("Note Test");

		mockMvc.perform(MockMvcRequestBuilders.post(
				"/v1/applications/382b9037-5842-43e8-b99b-2f4611784cd6/files/27a88d52-ecff-4613-9b7f-88bc79adcd88/notes")
				.contentType(MediaType.APPLICATION_JSON)
				.header("x-client-id", "11")
				.header("Authorization", token)
				.content(objectMapper.writeValueAsString(applicationNotesDTO)))
				.andExpect(status().isCreated())
				.andExpect(jsonPath("$.notes", is("Note Test")))
				.andDo(print());

		mockMvc.perform(MockMvcRequestBuilders
				.get("/v1/applications/382b9037-5842-43e8-b99b-2f4611784cd6/files/27a88d52-ecff-4613-9b7f-88bc79adcd88")
				.contentType(MediaType.APPLICATION_JSON)
				.header("x-client-id", "11")
				.header("Authorization", token))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.notes", not(empty())))
				.andDo(print());
	}

	@Test
	public void givenASetOfNotesPersisted_whenCallEndpointToGetNotesFromApplication_thenApplicationsAreReturned()
			throws Exception {

		mockMvc.perform(MockMvcRequestBuilders.get("/v1/applications/382b9037-5842-43e8-b99b-2f4611784cd6/notes")
				.contentType(MediaType.APPLICATION_JSON)
				.header("x-client-id", "11")
				.header("Authorization", token))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.content", iterableWithSize(3)));
	}

	@Test
	public void givenExistingApplication_whenCallEndpointToGetNoteFromApplication_thenNoteIsReturned()
			throws Exception {

		mockMvc.perform(MockMvcRequestBuilders
				.get("/v1/applications/382b9037-5842-43e8-b99b-2f4611784cd6/notes/4ec7c8dd-ea82-483e-810d-666442ed99b7")
				.contentType(MediaType.APPLICATION_JSON)
				.header("x-client-id", "11")
				.header("Authorization", token))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.notes", is("test note 666442ed99b7")))
				.andDo(print());

	}
}