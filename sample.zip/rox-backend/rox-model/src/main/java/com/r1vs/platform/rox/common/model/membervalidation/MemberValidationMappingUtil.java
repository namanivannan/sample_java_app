package com.r1vs.platform.rox.common.model.membervalidation;

import com.jsoniter.JsonIterator;
import com.r1vs.platform.rox.common.model.membervalidation.cache.MemberValidationCriteriaConditionCache;
import com.r1vs.platform.rox.common.model.types.membervalidation.MemberValidationCriteriaType;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Entity from/to DTO mapping utilities.
 */
public class MemberValidationMappingUtil {

	/**
	 * Return a list of MemberValidationSetDTO given the MemberValidationSet list.
	 *
	 * @param memberValidationSets
	 * @return
	 */
	public static List<MemberValidationSetDTO>
			mapToMemberValidationSetDTOList(final List<MemberValidationSet> memberValidationSets) {

		if (memberValidationSets == null) {
			return new ArrayList<>();
		}
		return memberValidationSets.stream()
				.map(memberValidationSet -> mapToMemberValidationSetDTO(memberValidationSet))
				.collect(Collectors.toList());
	}

	/**
	 * Convert MemberValidationSet to MemberValidationSetDTO
	 *
	 * @param memberValidationSet
	 * @return
	 */
	public static MemberValidationSetDTO mapToMemberValidationSetDTO(final MemberValidationSet memberValidationSet) {

		final MemberValidationSetDTO dto = new MemberValidationSetDTO();
		dto.setCreatedAt(memberValidationSet.getCreatedAt());
		dto.setDeactivatedAt(memberValidationSet.getDeactivatedAt());
		dto.setEffectiveEndDate(memberValidationSet.getEffectiveEndDate());
		dto.setEffectiveStartDate(memberValidationSet.getEffectiveStartDate());
		dto.setDescription(memberValidationSet.getDescription());
		dto.setPbmDefault(memberValidationSet.getPbmDefault());
		dto.setDisableAuthenticationOnEnrollmentUpdate(
				memberValidationSet.getDisableAuthenticationOnEnrollmentUpdate());
		dto.setEnrollmentAuthenticationFailAction(
				String.valueOf(memberValidationSet.getEnrollmentAuthenticationFailActionId()));
		dto.setId(String.valueOf(memberValidationSet.getId()));
		dto.setMemberValidationCategories(JsonIterator.deserialize(memberValidationSet.getValidationCategoriesJson(),
				MemberValidationCategoryCriteriaIds.class));
		dto.setMemberValidationSetId(String.valueOf(memberValidationSet.getMemberValidationSetId()));
		dto.setName(memberValidationSet.getName());
		dto.setPbmId(String.valueOf(memberValidationSet.getPbmId()));
		dto.setStatus(String.valueOf(memberValidationSet.getStatusId()));
		return dto;
	}

	/**
	 * Convert MemberValidationCriteria to MemberValidationCriteriaDTO
	 *
	 * @param memberValidationCriteria
	 * @return
	 */
	public static MemberValidationCriteriaDTO
			mapToMemberValidationCriteriaDTO(final MemberValidationCriteria memberValidationCriteria) {

		final MemberValidationCriteriaDTO dto = new MemberValidationCriteriaDTO();
		dto.setCreatedAt(memberValidationCriteria.getCreatedAt());
		dto.setId(String.valueOf(memberValidationCriteria.getMemberValidationCriteriaId()));
		dto.setStatus(String.valueOf(memberValidationCriteria.getStatusId()));
		dto.setName(memberValidationCriteria.getName());
		dto.setDescription(memberValidationCriteria.getDescription());
		dto.setValidationCriteriaType(MemberValidationCriteriaType.HELPER
				.getEnumByKeyWithException(String.valueOf(memberValidationCriteria.getValidationCriteriaTypeId()))
				.key());
		dto.setCriteriaConfig(JsonIterator.deserialize(memberValidationCriteria.getJson(),
				MemberValidationCriteriaConditionCache.class));
		return dto;
	}
}
