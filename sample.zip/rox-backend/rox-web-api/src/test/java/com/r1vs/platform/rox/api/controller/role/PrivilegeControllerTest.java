package com.r1vs.platform.rox.api.controller.role;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.r1vs.platform.rox.api.controller.DBConnection;
import com.r1vs.platform.rox.api.utils.BaseTest;
import com.r1vs.platform.rox.common.db.repository.role.PrivilegeRepository;
import com.r1vs.platform.rox.common.model.users.Privilege;
import com.r1vs.platform.rox.common.util.StringUtil;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.transaction.annotation.Transactional;

import static com.r1vs.platform.rox.api.controller.DBConnection.TEST_USER_1;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.is;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@Sql("/com/r1vs/platform/rox/api/controller/fixture2.sql")
public class PrivilegeControllerTest extends BaseTest {

	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private PrivilegeRepository privilegeRepository;

	@Autowired
	private DBConnection dbConnection;

	private String token;

	private String token_user_1;

	private String token_user_2;

	@Before
	public void setUp() throws Exception {

		if (StringUtil.isNullOrEmpty(token)) {
			token = dbConnection.loginToDb();
			token_user_1 = dbConnection.loginToDb(TEST_USER_1);
			token_user_2 = token;
		}
	}

	@Test
	public void givenValidLoginAndValidCreatePrivilegeJSON_whenCreatePrivilegeEndpointIsHit_thenCreatesItSuccessfully() throws Exception {

		mockMvc.perform(MockMvcRequestBuilders.post("/v1/privileges")
						.contentType(MediaType.APPLICATION_JSON)
						.content(getTextFileAsString("/payloads/new_privilege.json"))
						.header("x-client-id", "11")
						.header("Authorization", token))
				.andExpect(status().isCreated())
				.andExpect(jsonPath("$.name", is("New Privilege Test")))
				.andExpect(jsonPath("$.systemName", is("NEW_PRIVILEGE_TEST")))
				.andDo(print());
	}

	@Test
	public void givenValidLoginAndNotValidPrivilegeSystemName_whenCreatePrivilegeEndpointIsHit_thenThrows() throws Exception {

		mockMvc.perform(MockMvcRequestBuilders.post("/v1/privileges")
						.contentType(MediaType.APPLICATION_JSON)
						.content(getTextFileAsString("/payloads/new_privilege2.json"))
						.header("x-client-id", "11")
						.header("Authorization", token))
				.andExpect(status().isCreated())
				.andDo(print());

		mockMvc.perform(MockMvcRequestBuilders.post("/v1/privileges")
						.contentType(MediaType.APPLICATION_JSON)
						.content(getTextFileAsString("/payloads/new_privilege2.json"))
						.header("x-client-id", "11")
						.header("Authorization", token))
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("$[0].message", is("System Name already registered")))
				.andDo(print());
	}

	@Test
	@Transactional
	public void givenValidLoginAndPrivilegeStoredInDB_whenUpdatingPrivilegeEndpointIsHit_thenUpdatePrivilegeSuccessfully() throws Exception{

		mockMvc.perform(MockMvcRequestBuilders.patch("/v1/privileges/CREATE_APPLICATION")
				.contentType(MediaType.APPLICATION_JSON)
				.content(getTextFileAsString("/payloads/new_privilege.json"))
				.header("x-client-id", "11")
				.header("Authorization", token))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.name", is("New Privilege Test")))
				.andExpect(jsonPath("$.systemName", is("CREATE_APPLICATION")))
				.andDo(print());

		Privilege privilege = privilegeRepository.getById(1);
		assertThat(privilege.getSystemName()).isEqualTo("CREATE_APPLICATION");
		assertThat(privilege.getName()).isEqualTo("New Privilege Test");
	}

	@Test
	public void givenValidLoginAndPrivilegesStoredInDB_whenGetListOfPrivilegesEndpointIsHit_thenListPrivileges() throws Exception {

		mockMvc.perform(MockMvcRequestBuilders.get("/v1/privileges")
						.contentType(MediaType.APPLICATION_JSON)
						.header("x-client-id", "11")
						.header("Authorization", token))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$[0].name", is("Create Application")))
				.andExpect(jsonPath("$[0].systemName", is("CREATE_APPLICATION")))
				.andExpect(jsonPath("$[1].name", is("Update Application")))
				.andExpect(jsonPath("$[1].systemName", is("UPDATE_APPLICATION")))
				.andExpect(jsonPath("$[2].name", is("View Client Applications")))
				.andExpect(jsonPath("$[2].systemName", is("MANAGE_APPLICATION")))
				.andDo(print());
	}
}
