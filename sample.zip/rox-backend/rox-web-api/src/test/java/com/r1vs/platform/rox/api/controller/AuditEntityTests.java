package com.r1vs.platform.rox.api.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.r1vs.platform.rox.api.model.application.initiate.ApplicationDTO;
import com.r1vs.platform.rox.api.model.application.initiate.BusinessDTO;
import com.r1vs.platform.rox.api.model.application.initiate.NotesDTO;
import com.r1vs.platform.rox.api.model.application.initiate.OwnerDTO;
import com.r1vs.platform.rox.common.db.repository.business.ApplicationRepository;
import com.r1vs.platform.rox.common.util.StringUtil;
import org.apache.commons.io.IOUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.io.IOException;

import static com.r1vs.platform.rox.api.controller.DBConnection.*;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@Sql("fixture2.sql")
public class AuditEntityTests {

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private DBConnection dbConnection;

	private String tokenUser1Client11;

	private String tokenUser2Client12;

	private String tokenUser3Client11; // disabled user

	private String tokenUser4Client11;

	@Before
	public void setUp() throws Exception {

		if (StringUtil.isNullOrEmpty(tokenUser1Client11)) {
			tokenUser1Client11 = dbConnection.loginToDb();
			tokenUser2Client12 = dbConnection.loginToDb(TEST_USER_1);
			tokenUser3Client11 = dbConnection.loginToDb(TEST_USER_2);
			tokenUser4Client11 = dbConnection.loginToDb(TEST_USER_3);
		}
	}

	@Test
	public void
			givenApplicationCreatedWithUser1_thenUpdateApplicationStatusWithDiffUser_thenCreatedByAndUpdatedByIsUpdatedAccordingly()
					throws Exception {

		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.post("/v1/applications")
				.contentType(MediaType.APPLICATION_JSON)
				.content(getTextFileAsString("/payloads/new_application.json"))
				.header("x-client-id", "11")
				.header("Authorization", tokenUser1Client11))
				.andDo(print())
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.status", is("New")))
				.andExpect(jsonPath("$.uuid", not(emptyOrNullString())))
				.andExpect(jsonPath("$.createdBy.name", is("RoxWrite User Client 1")))
				.andExpect(jsonPath("$.updatedBy.name", is("RoxWrite User Client 1")))
				.andReturn();

		String contentAsString = mvcResult.getResponse().getContentAsString();
		ApplicationDTO applicationDTO = objectMapper.readValue(contentAsString, ApplicationDTO.class);

		String applicationUUID = applicationDTO.getUuid();

		mockMvc.perform(patch("/v1/applications/" + applicationUUID + "/status")
				.contentType(MediaType.APPLICATION_JSON)
				.content("{\"status\": \"Pending\"}")
				.header("x-client-id", "11")
				.header("Authorization", tokenUser4Client11)) // uses user 3 token
				.andDo(print())
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.status", is("Pending")))
				.andExpect(jsonPath("$.uuid", not(emptyOrNullString())))
				.andExpect(jsonPath("$.createdBy.name", is("RoxWrite User Client 1")))
				.andExpect(jsonPath("$.updatedBy.name", is("RoxWrite4 User Client 1")));
	}

	//TODO FIX THIS TEST
	@Test
	public void
			givenApplicationCreatedWithUser1_thenUpdateApplicationBusinessWithDiffUser_thenCreatedByAndUpdatedByInApplicationIsUpdatedAccordingly()
					throws Exception {

		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.post("/v1/applications")
				.contentType(MediaType.APPLICATION_JSON)
				.content(getTextFileAsString("/payloads/new_application.json"))
				.header("x-client-id", "11")
				.header("Authorization", tokenUser1Client11))
				.andDo(print())
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.status", is("New")))
				.andExpect(jsonPath("$.uuid", not(emptyOrNullString())))
				.andExpect(jsonPath("$.createdBy.name", is("RoxWrite User Client 1")))
				.andExpect(jsonPath("$.updatedBy.name", is("RoxWrite User Client 1")))
				.andReturn();

		String contentAsString = mvcResult.getResponse().getContentAsString();
		ApplicationDTO applicationDTO = objectMapper.readValue(contentAsString, ApplicationDTO.class);

		String applicationUUID = applicationDTO.getUuid();

		BusinessDTO businessDTO = new BusinessDTO();
		businessDTO.setIndustryType("Transportation");
		businessDTO.setName("New Name");
		businessDTO.setBusinessType("Partnerships");
		businessDTO.setDotNumber("1");
		businessDTO.setMcNumber("1");

		mockMvc.perform(patch("/v1/applications/" + applicationUUID + "/business")
				.contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(businessDTO))
				.header("x-client-id", "11")
				.header("Authorization", tokenUser4Client11)) // uses user 4 token
				.andDo(print())
				.andExpect(status().isOk())
		//.andExpect(jsonPath("$.createdBy.name", is("RoxWrite User Client 1")))
		//.andExpect(jsonPath("$.updatedBy.name", is("RoxWrite4 User Client 1")))
		;

		// application changes the updated by based on business modification
		mockMvc.perform(get("/v1/applications/" + applicationUUID)
				.contentType(MediaType.APPLICATION_JSON)
				.header("x-client-id", "11")
				.header("Authorization", tokenUser4Client11))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.createdBy.name", is("RoxWrite User Client 1")))
				.andExpect(jsonPath("$.updatedBy.name", is("RoxWrite4 User Client 1")));
	}

	@Test
	public void
			givenApplicationCreatedWithUser1_thenUpdateOneOwnerWithDiffUser_thenCreatedByAndUpdatedByInApplicationIsUpdatedAccordingly()
					throws Exception {

		// Create Application
		MvcResult createApplicationResult = mockMvc.perform(MockMvcRequestBuilders.post("/v1/applications")
				.contentType(MediaType.APPLICATION_JSON)
				.content(getTextFileAsString("/payloads/new_application.json"))
				.header("x-client-id", "11")
				.header("Authorization", tokenUser1Client11))
				.andDo(print())
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.status", is("New")))
				.andExpect(jsonPath("$.uuid", not(emptyOrNullString())))
				.andExpect(jsonPath("$.createdBy.name", is("RoxWrite User Client 1")))
				.andExpect(jsonPath("$.updatedBy.name", is("RoxWrite User Client 1")))
				.andReturn();

		String contentAsString = createApplicationResult.getResponse().getContentAsString();
		ApplicationDTO applicationDTO = objectMapper.readValue(contentAsString, ApplicationDTO.class);

		String applicationUUID = applicationDTO.getUuid();

		// Post new Owner with user 4
		MvcResult createOwnerResult = mockMvc
				.perform(MockMvcRequestBuilders.post("/v1/applications/" + applicationUUID + "/owners")
						.contentType(MediaType.APPLICATION_JSON)
						.content(getTextFileAsString("/payloads/new_owner_payload.json"))
						.header("x-client-id", "11")
						.header("Authorization", tokenUser4Client11))
				.andExpect(status().isCreated())
				.andExpect(jsonPath("$.createdBy.name", is("RoxWrite4 User Client 1")))
				.andExpect(jsonPath("$.updatedBy.name", is("RoxWrite4 User Client 1")))
				.andReturn();

		// Application updatedby should be User4 due to new Owner
		mockMvc.perform(get("/v1/applications/" + applicationUUID)
				.contentType(MediaType.APPLICATION_JSON)
				.header("x-client-id", "11")
				.header("Authorization", tokenUser1Client11))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.createdBy.name", is("RoxWrite User Client 1")))
				.andExpect(jsonPath("$.updatedBy.name", is("RoxWrite4 User Client 1")));

		String ownerJson = createOwnerResult.getResponse().getContentAsString();
		OwnerDTO ownerDto = objectMapper.readValue(ownerJson, OwnerDTO.class);

		String ownerUUID = ownerDto.getUuid();

		// updating added owner with first user again, should show created by user4, updated by user 1
		MvcResult result = mockMvc
				.perform(MockMvcRequestBuilders.patch("/v1/applications/" + applicationUUID + "/owners/" + ownerUUID)
						.contentType(MediaType.APPLICATION_JSON)
						.content(getTextFileAsString("/payloads/new_owner_payload.json"))
						.header("x-client-id", "11")
						.header("Authorization", tokenUser1Client11))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.createdBy.name", is("RoxWrite4 User Client 1")))
				.andExpect(jsonPath("$.updatedBy.name", is("RoxWrite User Client 1")))
				.andReturn();

		// Application updatedBy should be user 1 again.
		mockMvc.perform(get("/v1/applications/" + applicationUUID)
				.contentType(MediaType.APPLICATION_JSON)
				.header("x-client-id", "11")
				.header("Authorization", tokenUser4Client11))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.createdBy.name", is("RoxWrite User Client 1")))
				.andExpect(jsonPath("$.updatedBy.name", is("RoxWrite User Client 1")));
	}

	@Test
	public void
			givenApplicationCreatedWithUser1_thenUpdateOneNoteWithDiffUser_thenCreatedByAndUpdatedByInApplicationIsUpdatedAccordingly()
					throws Exception {

		// Create Application
		MvcResult createApplicationResult = mockMvc.perform(MockMvcRequestBuilders.post("/v1/applications")
				.contentType(MediaType.APPLICATION_JSON)
				.content(getTextFileAsString("/payloads/new_application.json"))
				.header("x-client-id", "11")
				.header("Authorization", tokenUser1Client11))
				.andDo(print())
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.status", is("New")))
				.andExpect(jsonPath("$.uuid", not(emptyOrNullString())))
				.andExpect(jsonPath("$.createdBy.name", is("RoxWrite User Client 1")))
				.andExpect(jsonPath("$.updatedBy.name", is("RoxWrite User Client 1")))
				.andReturn();

		String contentAsString = createApplicationResult.getResponse().getContentAsString();
		ApplicationDTO applicationDTO = objectMapper.readValue(contentAsString, ApplicationDTO.class);

		String applicationUUID = applicationDTO.getUuid();

		// Post new Note with user 4

		NotesDTO notesDTO = new NotesDTO();
		notesDTO.setNotes("Note Test");

		MvcResult createNoteResult = mockMvc
				.perform(MockMvcRequestBuilders.post("/v1/applications/" + applicationUUID + "/notes")
						.contentType(MediaType.APPLICATION_JSON)
						.content(objectMapper.writeValueAsString(notesDTO))
						.header("x-client-id", "11")
						.header("Authorization", tokenUser4Client11))
				.andExpect(status().isCreated())
				.andExpect(jsonPath("$.createdBy.name", is("RoxWrite4 User Client 1")))
				.andExpect(jsonPath("$.updatedBy.name", is("RoxWrite4 User Client 1")))
				.andReturn();

		// Application updatedby should be User4 due to new Note
		mockMvc.perform(get("/v1/applications/" + applicationUUID)
				.contentType(MediaType.APPLICATION_JSON)
				.header("x-client-id", "11")
				.header("Authorization", tokenUser1Client11))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.createdBy.name", is("RoxWrite User Client 1")))
				.andExpect(jsonPath("$.updatedBy.name", is("RoxWrite4 User Client 1")));

		String noteJson = createNoteResult.getResponse().getContentAsString();
		NotesDTO receivedNoteDto = objectMapper.readValue(noteJson, NotesDTO.class);

		String newNoteUUID = receivedNoteDto.getUuid();

		// updating added note with first user again, should show created by user4, updated by user 1
		NotesDTO updateToNoteDTO = new NotesDTO();
		updateToNoteDTO.setNotes("Modified Note");

		MvcResult result = mockMvc
				.perform(MockMvcRequestBuilders.patch("/v1/applications/" + applicationUUID + "/notes/" + newNoteUUID)
						.contentType(MediaType.APPLICATION_JSON)
						.content(objectMapper.writeValueAsString(updateToNoteDTO))
						.header("x-client-id", "11")
						.header("Authorization", tokenUser1Client11))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.createdBy.name", is("RoxWrite4 User Client 1")))
				.andExpect(jsonPath("$.updatedBy.name", is("RoxWrite4 User Client 1")))
				.andReturn();

		// Application updatedBy should be user 1 again.
		mockMvc.perform(get("/v1/applications/" + applicationUUID)
				.contentType(MediaType.APPLICATION_JSON)
				.header("x-client-id", "11")
				.header("Authorization", tokenUser4Client11))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.createdBy.name", is("RoxWrite User Client 1")))
				.andExpect(jsonPath("$.updatedBy.name", is("RoxWrite User Client 1")));
	}

	// TODO make Application reflect latest updated

	public String getTextFileAsString(String filePath) throws IOException {

		return IOUtils.toString(
				this.getClass().getResourceAsStream(filePath),
				"UTF-8");
	}

}