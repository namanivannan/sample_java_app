package com.r1vs.platform.rox.api.util;

public class SystemHierarchyConstant {

	public static final String COST_SHARING_ORDER = "costSharingOrder";

	public static final String COST_SHARING_BASIS = "costSharingBasis";

	public static final String COVERAGE_LEVEL = "coverageLevel";

	public static final String PLAN_TYPE = "planType";

	public static final String PLAN_STATUS = "planStatus";

	public static final String EXTERNAL_PLAN_ID = "externalPlanId";

	public static final String PLAN_NAME = "planName";

	public static final String PRICING_METHODOLOGY = "pricingMethodology";

	public static final String RESTRICTION = "restriction";

	public static final String CONTACT = "contact";

	public static final String TAX_ASSESSMENT = "taxAssessment";

	public static final String CLAIM_RESPONSE_PLAN_ID = "claimResponsePlanId";

	public static final String CLAIM_TYPE = "claimType";

	public static final String COMPOUND_BRAND_CLASS = "compoundBrandClass";

	public static final String TAX_EXEMPTION = "taxExemption";

	public static final String SECURITY_USER_ACCESS_ID = "securityUserAccessId";

	public static final String PBM_NAME = "pbmName";

	public static final String EXTERNAL_PBM_ID = "externalPbmId";

	public static final String PBM_ID = "pbmId";

	public static final String PBM_STATUS = "pbmStatus";

	public static final String GROUP_NAME = "groupName";

	public static final String EXTERNAL_GROUP_ID = "externalGroupId";

	public static final String GROUP_STATUS = "groupStatus";

	public static final String ACCOUNT_TYPE = "accountType";

	public static final String CONTACT_TYPE = "contactType";

}
