package com.r1vs.platform.rox.api.controller;

import com.r1vs.platform.rox.api.model.application.initiate.RoxFileWithNotesDTO;
import com.r1vs.platform.rox.api.model.application.initiate.RoxFileDTO;
import com.r1vs.platform.rox.api.processor.FileProcessor;
import com.r1vs.platform.rox.api.service.ValidationUtils;
import com.r1vs.platform.rox.common.model.business.Application;
import com.r1vs.platform.rox.common.model.business.Client;
import com.r1vs.platform.rox.common.model.business.storage.RoxFile;
import com.r1vs.platform.rox.filemanagement.services.StorageService;
import io.swagger.v3.oas.annotations.Operation;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.UUID;

import static com.r1vs.platform.rox.api.util.InterceptorConstants.CLIENT_ID;

@RestController
@RequestMapping("/v1")
public class RoxFileController {

	@Autowired
	private StorageService storageService;

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private ValidationUtils validationUtils;

	@Autowired
	private FileProcessor fileProcessor;

	@PostMapping("/applications/{applicationId}/files")
	@Operation(summary = "Upload a File to S3 and attaches it to an Application")
	public ResponseEntity<RoxFileDTO> uploadFile(@RequestHeader(CLIENT_ID) String clientId,
			@RequestParam("file") MultipartFile file,
			@RequestParam("purpose") String purpose,
			@PathVariable UUID applicationId) throws IOException {

		return new ResponseEntity<>(fileProcessor.getValidateAndUploadFile(clientId, applicationId, file, purpose),
				HttpStatus.OK);
	}

	@GetMapping("/applications/{applicationId}/files/{fileId}")
	@Operation(summary = "Get File Info")
	public ResponseEntity<RoxFileWithNotesDTO> getFileDTO(@RequestHeader(CLIENT_ID) String clientId,
			@PathVariable UUID fileId,
			@PathVariable UUID applicationId) throws IOException {

		return new ResponseEntity<>(fileProcessor.getFileInfoWithNotes(clientId, applicationId, fileId), HttpStatus.OK);
	}

	@GetMapping("/applications/{applicationId}/files/{fileId}/download")
	@Operation(summary = "Downloads File from S3")
	public ResponseEntity<byte[]> getFile(@RequestHeader(CLIENT_ID) String clientId,
			@PathVariable UUID fileId,
			@PathVariable UUID applicationId) throws IOException {

		RoxFile roxFile = fileProcessor.getFile(clientId, applicationId, fileId);
		return ResponseEntity.ok()
				.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + roxFile.getFileName() + "\"")
				.contentType(MediaType.valueOf(roxFile.getFileType()))
				.body(storageService.getFile(roxFile).getInputStream().readAllBytes());
	}

	@GetMapping("/applications/{applicationId}/files/{fileId}/getURL")
	@Operation(summary = "Get File URL from S3")
	public ResponseEntity<String> getFileURL(@RequestHeader(CLIENT_ID) String clientId,
			@PathVariable UUID fileId,
			@PathVariable UUID applicationId) throws IOException {

		RoxFile roxFile = fileProcessor.getFile(clientId, applicationId, fileId);
		return new ResponseEntity<>(storageService.getFileURL(roxFile), HttpStatus.OK);
	}

	@DeleteMapping("/applications/{applicationId}/files/{fileId}")
	@Operation(summary = "Deletes attachment from application and file from S3")
	public ResponseEntity<Void> deleteFile(@RequestHeader(CLIENT_ID) String clientId,
			@PathVariable UUID fileId,
			@PathVariable UUID applicationId) throws IOException {

		RoxFile roxFile = fileProcessor.getFile(clientId, applicationId, fileId);
		storageService.deleteFile(roxFile);
		return ResponseEntity.ok().build();
	}
}
