package com.r1vs.platform.rox.filemanagement.services;

import com.amazonaws.AmazonServiceException;
import com.r1vs.platform.rox.StorageSpringBootApplication;
import com.r1vs.platform.rox.common.db.repository.business.ApplicationRepository;
import com.r1vs.platform.rox.common.model.business.storage.RoxFile;
import com.r1vs.platform.rox.filemanagement.exceptions.RoxStorageException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit4.SpringRunner;

import static org.assertj.core.api.Assertions.*;

import java.io.IOException;
import java.util.UUID;

@SpringBootTest(classes = StorageSpringBootApplication.class)
@RunWith(SpringRunner.class)
@ActiveProfiles("test")
@Sql("fixture.sql")
public class S3StorageTest {

	@Autowired
	private ApplicationRepository applicationRepository;

	@Autowired
	private S3Storage s3Storage;

	@Test
	public void givenValidFileAndInputStream_whenUploadingFileToS3_thenUploadFileToS3() throws IOException {

		//Given
		MockMultipartFile file = new MockMultipartFile(
				"testFile1234",
				"testFile1234.txt",
				MediaType.TEXT_PLAIN_VALUE,
				"Test Upload File".getBytes());

		RoxFile roxFile = new RoxFile();
		roxFile.setUuid(UUID.randomUUID());
		roxFile.setFileName(file.getOriginalFilename());
		roxFile.setFileType(file.getContentType());
		roxFile.setFileSize(file.getSize());
		roxFile.setPurpose("purpose 1");
		roxFile.setKey("keyTest");
		roxFile.setApplication(applicationRepository.getById(11L));

		//When
		s3Storage.storeFile(roxFile, file.getInputStream());

		//Then
		assertThat(s3Storage.getFile(roxFile).contentLength()).isEqualTo(16);
		assertThat(s3Storage.getFile(roxFile).getInputStream().readAllBytes()).isEqualTo("Test Upload File".getBytes());
	}

	@Test
	public void givenNotValidFile_whenUploadingFileToS3_thenThrowException() {

		//Given
		MockMultipartFile file = new MockMultipartFile(
				"testFile1234",
				"testFile1234.txt",
				MediaType.TEXT_PLAIN_VALUE,
				"Test Upload File".getBytes());
		RoxFile roxFile = new RoxFile();

		//When
		Throwable thrown = catchThrowable(() -> s3Storage.storeFile(roxFile, file.getInputStream()));

		//Then
		assertThat(thrown).isInstanceOf(RoxStorageException.class)
				.getRootCause().isInstanceOf(NullPointerException.class);
	}

	@Test
	public void givenValidStoredFileInS3_whenGettingFileFromS3_thenReturnFile() throws IOException {

		//Given
		MockMultipartFile file = new MockMultipartFile(
				"testFile1234",
				"testFile1234.txt",
				MediaType.TEXT_PLAIN_VALUE,
				"Test Upload File".getBytes());

		RoxFile roxFile = new RoxFile();
		roxFile.setUuid(UUID.randomUUID());
		roxFile.setFileName(file.getOriginalFilename());
		roxFile.setFileType(file.getContentType());
		roxFile.setFileSize(file.getSize());
		roxFile.setPurpose("purpose 1");
		roxFile.setKey("keyTest");
		roxFile.setApplication(applicationRepository.getById(11L));

		//When
		Resource resource = s3Storage.getFile(roxFile);

		//Then
		assertThat(resource.getInputStream().readAllBytes()).isEqualTo("Test Upload File".getBytes());
	}

	@Test
	public void givenNonExistingKey_whenGettingFileFromS3_thenNotFoundExceptionIsReported() {

		//Given
		MockMultipartFile file = new MockMultipartFile(
				"testFile1234",
				"testFile1234.txt",
				MediaType.TEXT_PLAIN_VALUE,
				"Test Upload File".getBytes());

		RoxFile roxFile = new RoxFile();
		roxFile.setKey("keyNotValid");

		//When
		Throwable thrown = catchThrowable(() -> s3Storage.getFile(roxFile));

		//Then
		assertThat(thrown).isInstanceOf(RoxStorageException.class)
				.getRootCause().isInstanceOf(AmazonServiceException.class)
				.hasMessageContaining("The specified key does not exist.");
		AmazonServiceException cause = (AmazonServiceException) thrown.getCause();
		assertThat(cause.getStatusCode()).isEqualTo(404);
	}

	@Test
	public void givenValidStoredFileInS3_whenGettingFileURLFromS3_thenReturnURL() throws IOException {

		//Given
		MockMultipartFile file = new MockMultipartFile(
				"testFile1234",
				"testFile1234.txt",
				MediaType.TEXT_PLAIN_VALUE,
				"Test Upload File".getBytes());

		RoxFile roxFile = new RoxFile();
		roxFile.setUuid(UUID.randomUUID());
		roxFile.setFileName(file.getOriginalFilename());
		roxFile.setFileType(file.getContentType());
		roxFile.setFileSize(file.getSize());
		roxFile.setPurpose("purpose 1");
		roxFile.setKey("keyTest");
		roxFile.setApplication(applicationRepository.getById(11L));

		//When
		s3Storage.storeFile(roxFile, file.getInputStream());
		String url = s3Storage.getFileURL(roxFile);

		//Then
		assertThat(url).isEqualTo("http://127.0.0.1:4566/roxbucket/keyTest");
	}

	@Test
	public void givenValidStoredFileInS3_whenDeletingFileFromS3_thenDeleteFile() throws IOException {

		//Given
		MockMultipartFile file = new MockMultipartFile(
				"testFile1234",
				"testFile1234.txt",
				MediaType.TEXT_PLAIN_VALUE,
				"Test Upload File".getBytes());

		RoxFile roxFile = new RoxFile();
		roxFile.setUuid(UUID.randomUUID());
		roxFile.setFileName(file.getOriginalFilename());
		roxFile.setFileType(file.getContentType());
		roxFile.setFileSize(file.getSize());
		roxFile.setPurpose("purpose 1");
		roxFile.setKey("keyTest");
		roxFile.setApplication(applicationRepository.getById(11L));

		//When
		s3Storage.storeFile(roxFile, file.getInputStream());
		s3Storage.deleteFile(roxFile);

		//Then
		Throwable thrown = catchThrowable(() -> s3Storage.getFile(roxFile));
		assertThat(thrown).isInstanceOf(RoxStorageException.class)
				.getRootCause().isInstanceOf(AmazonServiceException.class)
				.hasMessageContaining("The specified key does not exist.");
		AmazonServiceException cause = (AmazonServiceException) thrown.getCause();
		assertThat(cause.getStatusCode()).isEqualTo(404);
	}
}