package com.r1vs.platform.rox.api.controller;

import com.r1vs.platform.rox.api.PropertiesConfig;
import com.r1vs.platform.rox.api.business.UserAuditService;
import com.r1vs.platform.rox.api.business.UserService;
import com.r1vs.platform.rox.api.exception.ValidationException;
import com.r1vs.platform.rox.api.model.*;
import com.r1vs.platform.rox.api.model.application.initiate.*;
import com.r1vs.platform.rox.api.processor.UserProcessor;
import com.r1vs.platform.rox.api.validator.user.SignUpUserValidator;
import com.r1vs.platform.rox.api.validator.user.UserValidator;
import com.r1vs.platform.rox.common.model.users.RegistrationToken;
import com.r1vs.platform.rox.common.model.users.User;
import com.r1vs.platform.rox.common.model.users.UserAudit;
import com.r1vs.platform.rox.common.util.DateUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static com.r1vs.platform.rox.api.constants.ControllerConstants.X_PAGINATION_SORT;
import static com.r1vs.platform.rox.api.response.ResponseMessages.*;
import static com.r1vs.platform.rox.api.util.ControllerUtils.getPageableFromHeaderParams;
import static com.r1vs.platform.rox.api.util.InterceptorConstants.CLIENT_ID;

@RestController
@RequestMapping("/v1")
@Tag(name = "User", description = "User Service")
public class UserController {

	private static final Logger LOGGER = LoggerFactory.getLogger(UserController.class);

	@Autowired
	private UserService userService;

	@Autowired
	private UserAuditService userAuditService;

	@Autowired
	private UserProcessor userProcessor;

	@Autowired
	private PropertiesConfig propertiesConfig;

	@Autowired
	private UserValidator userValidator;

	@Autowired
	private SignUpUserValidator signUpUserValidator;


	@GetMapping("/user/me")
	@Operation(summary = "Get currently logged in user's info")
	public ResponseEntity<UserResponse> getLoggedInUser() {

		return userProcessor.processGetCurrentUser();
	}

    @PostMapping("/user/change-password")
    @Operation(summary = "Change Password")
    public ResponseEntity<MessageResponse> changePassword(@RequestBody final ChangePasswordDTO changePasswordDTO) {

        userProcessor.processSaveCurrentUserPassword(changePasswordDTO);

        final MessageResponse messageResponse = new MessageResponse();
        messageResponse.setMessage(PASSWORD + UPDATED_SUCCESSFULLY);
        return new ResponseEntity<>(messageResponse, HttpStatus.OK);
    }

    @PatchMapping("/user/update-me")
    @Operation(summary = "Update Me - logged in user update")
    public ResponseEntity<MessageResponse> changeMe(@RequestBody final UpdateUserDTO updateUserDTO) {

        userProcessor.processUpdateCurrentUser(updateUserDTO);

        final MessageResponse messageResponse = new MessageResponse();
        messageResponse.setMessage(USER + UPDATED_SUCCESSFULLY);
        return new ResponseEntity<>(messageResponse, HttpStatus.OK);
    }

    @PostMapping("/user/forgot-password")
    @Operation(summary = "Forgot Password")
    public ResponseEntity<ForgotPasswordResponse> forgotPassword(
            @RequestBody @Valid final ForgotPasswordRequest forgotPasswordRequest) {

        return userProcessor.processForgotPassword(forgotPasswordRequest);
    }

    /***
     * Below operations are performed by admin users
     * (either rox admin or client admin)
     ***/

    @GetMapping("/users")
    @Operation(summary = "Get users made by ClientId")
    public ResponseEntity<List<UserResponseDTO>> getUsersPage(@RequestHeader(CLIENT_ID) Long clientId,
                                                              @RequestHeader(X_PAGINATION_NUM) int pageNum,
                                                              @RequestHeader(X_PAGINATION_LIMIT) int pageLimit,
                                                              @RequestHeader(value = X_PAGINATION_SORT, defaultValue = "createdAt,desc") String sortingParam) {

        Pageable pageParams = getPageableFromHeaderParams(pageLimit, pageNum, sortingParam);
        return userProcessor.processGetAllUsersPage(clientId, pageParams);
    }

    @GetMapping("/users/{userId}")
    @Operation(summary = "Get user ")
    public ResponseEntity<UserResponse> getUser(
            @Validated @PathVariable(value = "userId", required = true) final Long userId) {

        return userService.findById(userId).map(registeredUser -> userProcessor.processGetUser(registeredUser))
                .orElseThrow(() -> new ValidationException(USER + userId + DOES_NOT_EXIST));
    }

    @GetMapping("/users/checkEmail")
    @Operation(summary = "Check if email is already registered")
    public ResponseEntity<CheckEmailResponseDTO> checkUnique(@RequestHeader(CLIENT_ID) String clientId,
                                                             @Valid @RequestBody final CheckEmailDTO checkEmailDTO) {
        return new ResponseEntity<>(userProcessor.validateUniqueEmail(clientId, checkEmailDTO.getEmail()), HttpStatus.OK);
    }


    @PostMapping("/users")
	@Operation(summary = "Create user")
	public ResponseEntity<MessageResponse> createUser(@RequestHeader(CLIENT_ID) String clientId,
													  @Valid @RequestBody final CreateUserRequest userRequest) {
		final User createdUser = userProcessor.processCreateUserAssociate(userRequest, clientId);

		final MessageResponse messageResponse = new MessageResponse();
		messageResponse.setMessage(USER + createdUser.getUsername() + CREATED_SUCCESSFULLY);
        return new ResponseEntity<>(messageResponse, HttpStatus.CREATED);
	}

	@PatchMapping("/users/{userId}")
	@Operation(summary = "Update User")
	public ResponseEntity<MessageResponse> updateUser(@RequestHeader(CLIENT_ID) String clientId,
													  @PathVariable Long userId,
													  @RequestBody final UpdateUserDTO updateUserDTO) {

		final MessageResponse messageResponse = new MessageResponse();
		messageResponse.setMessage(USER + userProcessor.processUpdateUser(updateUserDTO, userId).getUsername()
				+ UPDATED_SUCCESSFULLY);
		return new ResponseEntity<>(messageResponse, HttpStatus.OK);
	}
    @PostMapping("/users/{userId}/disable")
    @Operation(summary = "Inactivate User")
    public ResponseEntity<MessageResponse> inactivateUser(@PathVariable Long userId) {

        return userService.findById(userId)
                .map(user -> userProcessor.processDisableUser(user))
                .orElseThrow(() -> new ValidationException(USER + userId + DOES_NOT_EXIST));
    }

    @PostMapping("/users/{userId}/enable")
    @Operation(summary = "Activate User")
    public ResponseEntity<MessageResponse> activateUser(@PathVariable Long userId) {

        return userService.findById(userId)
                .map(user -> userProcessor.processEnableUser(user))
                .orElseThrow(() -> new ValidationException(USER + userId + DOES_NOT_EXIST));
    }

	@PostMapping("/users/{userId}/change-password")
	@Operation(summary = "Admin Change Password")
	public ResponseEntity<MessageResponse> adminChangePassword(@PathVariable Long userId,
															   @RequestBody final ChangePasswordDTO changePasswordDTO) {

		userProcessor.processAdminSavePassword(userId, changePasswordDTO);

		final MessageResponse messageResponse = new MessageResponse();
		messageResponse.setMessage(PASSWORD + UPDATED_SUCCESSFULLY);
		return new ResponseEntity<>(messageResponse, HttpStatus.OK);
	}


	@PostMapping("/users/{userId}/resend-token")
	@Operation(summary = "Resend User Registration Token")
	public ResponseEntity<MessageResponse> resendRegistrationToken(
			@Validated @PathVariable(value = "userId", required = true) final Long userId) {

		return userService.findById(userId).map(registeredUser -> userProcessor.processResendUserToken(registeredUser))
				.orElseThrow(() -> new ValidationException(USER + userId + DOES_NOT_EXIST));
	}

	@GetMapping("/users/{userId}/history")
	@Operation(summary = "Get History for a user")
	public ResponseEntity<List<UserAuditResponse>> getUserHistory(
			@Validated @PathVariable(value = "userId", required = true) final Long userId, final String startDate,
			final String endDate) {

		final Optional<User> user = userService.findById(userId);

		if (user.isPresent()) {

			final List<UserAudit> results = userAuditService.findByUserId(userId, DateUtil.parseLocalDate(startDate),
					DateUtil.parseLocalDate(endDate));

			final List<UserAuditResponse> auditResponses = new ArrayList<>(
					userProcessor.processUserAudit(user.get(), results));

			return new ResponseEntity<>(auditResponses, HttpStatus.OK);

		} else {
			throw new ValidationException(USER + userId + DOES_NOT_EXIST);
		}

	}


}
