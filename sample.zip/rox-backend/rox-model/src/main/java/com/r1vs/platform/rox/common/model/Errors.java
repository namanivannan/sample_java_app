package com.r1vs.platform.rox.common.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * This object hosts a list of errors
 *
 */
public class Errors implements Serializable {

	private static final long serialVersionUID = 754764508724242655L;

	private List<ErrorItem> errorItems = new ArrayList<>();

	public List<ErrorItem> getErrors() {

		return errorItems;
	}

	public void setErrors(final List<ErrorItem> errorItems) {

		this.errorItems = errorItems;
	}

	/**
	 * Add an Error.
	 *
	 * @param errorItem
	 * @return
	 */
	public ErrorItem addError(final ErrorItem errorItem) {

		if (errorItem == null) {
			throw new IllegalArgumentException("Null error passed in");
		}
		if (errorItems == null) {
			errorItems = new ArrayList<>();
		}
		errorItems.add(errorItem);
		return errorItem;
	}

	/**
	 * Add an Error with code and message
	 *
	 * @param code
	 * @param message
	 * @return
	 */
	public ErrorItem addError(final String code, final String message) {

		if (errorItems == null) {
			errorItems = new ArrayList<>();
		}
		final ErrorItem errorItem = new ErrorItem(code, message);
		errorItems.add(errorItem);
		return errorItem;
	}

	/**
	 * Add an Error with code only
	 *
	 * @param code
	 * @return
	 */
	public ErrorItem addError(final String code) {

		return addError(code, null);
	}

	/**
	 * If it contains Error.
	 *
	 * @return
	 */
	public final boolean hasErrors() {

		return errorItems != null && errorItems.size() > 0;
	}

	@Override
	public String toString() {

		final ToStringBuilder builder = new ToStringBuilder(this);
		builder.append("errorItems", errorItems);
		return builder.toString();
	}

	@Override
	public int hashCode() {

		return Objects.hash(errorItems);
	}

	@Override
	public boolean equals(final Object obj) {

		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final Errors other = (Errors) obj;
		return Objects.equals(errorItems, other.errorItems);
	}
}
