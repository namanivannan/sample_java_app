package com.r1vs.platform.rox.api.processor.role;

import com.r1vs.platform.rox.api.business.RoleService;
import com.r1vs.platform.rox.api.model.admin.RoleSearchRequestDTO;
import com.r1vs.platform.rox.api.model.application.initiate.RoleDTO;
import com.r1vs.platform.rox.api.model.application.initiate.CreateRoleDTO;
import com.r1vs.platform.rox.api.exception.RoxApiException;
import com.r1vs.platform.rox.api.model.role.*;
import com.r1vs.platform.rox.api.processor.CommonProcessor;
import com.r1vs.platform.rox.api.service.MapperService;
import com.r1vs.platform.rox.api.service.ValidationUtils;
import com.r1vs.platform.rox.api.service.role.RolePrivilegeService;
import com.r1vs.platform.rox.common.db.service.role.AccessDomainService;
import com.r1vs.platform.rox.common.db.repository.role.PrivilegeRepository;
import com.r1vs.platform.rox.common.model.types.role.AccessType;
import com.r1vs.platform.rox.common.model.users.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import javax.transaction.Transactional;
import java.time.OffsetDateTime;
import java.util.*;
import java.util.stream.Collectors;

import static java.util.Objects.nonNull;

@Component
public class RoleProcessor extends CommonProcessor<RoleResponse> {

	//TEMPORARY EXCLUSIVE ADMIN PRIVILEGE
	public static final List<String> UNASSIGNABLE_PRIVILEGES = List.of("ADMIN");

	@Autowired
	private AccessDomainService accessDomainService;

	@Autowired
	private RoleService roleService;

	@Autowired
	private RolePrivilegeService rolePrivilegeService;

	@Autowired
	private MapperService mapperService;

	@Autowired
	private PrivilegeRepository privilegeRepository;

	@Autowired
	private ValidationUtils validationUtils;

	@Transactional
	public RoleDTO processCreateRole(String clientId, final CreateRoleDTO roleDTO) {
		validationUtils.requireClient(clientId);
		final Role role = mapperService.getEntityFromDTO(roleDTO);
		role.setStatusId(0);
		validatePrivilege(roleDTO.getPrivileges());
		List<Privilege> privileges = privilegeRepository.findAllBySystemNameIn(roleDTO.getPrivileges());
		role.setPrivileges(Set.copyOf(privileges));

		roleService.save(role);

		savePrivilegeRole(privileges, role);

		return mapperService.getDtoFromEntity(role);
	}

	public boolean validatePrivilege(List<String> privileges){
		if (privileges.stream().anyMatch(UNASSIGNABLE_PRIVILEGES:: contains)){
			throw new RoxApiException(UNASSIGNABLE_PRIVILEGES +" CANNOT BE ASSIGNED", HttpStatus.FORBIDDEN);
		}
		return true;
	}

	private void savePrivilegeRole(final List<Privilege> privilegeList, final Role roleSaved) {

		privilegeList.forEach(p -> {
			final RolePrivilege rolePrivilege = new RolePrivilege();
			rolePrivilege.setRoleId(roleSaved.getRoleId());
			rolePrivilege.setPrivilegeId(p.getPrivilegeId());
			rolePrivilege.setCreatedAt(OffsetDateTime.now());
			rolePrivilege.setUpdatedAt(OffsetDateTime.now());
			rolePrivilege.setCreatedById(roleSaved.getCreatedById());
			rolePrivilege.setUpdatedById(roleSaved.getUpdatedById());
			rolePrivilegeService.save(rolePrivilege);
		});
	}

	private RoleResponse mapRoleToRoleResponse(final Role role, final boolean expand) {

		final RoleResponse roleResponse = new RoleResponse();
		roleResponse.setRoleId(role.getRoleId());
		roleResponse.setRoleName(role.getName());
		roleResponse.setRoleSystemName(role.getSystemName());
		roleResponse.setStatusId(role.getStatusId());

		if (expand) {
			final List<Integer> privilegeIdList = rolePrivilegeService.getAllByRole(role).stream()
					.map(rolePrivilege -> rolePrivilege.getPrivilegeId()).collect(Collectors.toList());

			final List<SubdomainResponse> subdomains = accessDomainService.getAll().stream()
					.map(ad -> accessDomainToSubdomainResponse(ad)).collect(Collectors.toList());

			subdomains.stream().forEach(dc -> {

				final List<AccessRequestedResponse> accessRequestedResponses = new ArrayList<>();

				Arrays.stream(AccessType.values()).forEach(a -> {
					final List<Integer> privilegeIdListForTheAccess = null;
					if (!privilegeIdListForTheAccess.isEmpty()
							&& containsPrivilegesOfThatAccess(privilegeIdList, privilegeIdListForTheAccess)) {
						final AccessRequestedResponse accessRequestedResponse = new AccessRequestedResponse();
						accessRequestedResponse.setAccess(a.key());
						accessRequestedResponses.add(accessRequestedResponse);
					}
				});
				dc.setAccessesRequested(accessRequestedResponses.isEmpty() ? null : accessRequestedResponses);
			});
			roleResponse.setSubdomains(subdomains);
		}
		return roleResponse;
	}

	private boolean containsPrivilegesOfThatAccess(final List<Integer> privilegeIdList,
			final List<Integer> privilegeIdListForTheAccess) {

		for (final Integer id : privilegeIdListForTheAccess) {
			if (!privilegeIdList.contains(id)) {
				return false;
			}
		}
		return true;
	}

//	public ResponseEntity<List<RoleResponse>> processSearchRole(final Integer roleId, final String roleName,
//			final Integer status,
//			final Integer paginationLimit, final Integer paginationNum, final boolean expand) {
//
//		final Page<Role> roleList =
//				roleService.getAllWithPagination(roleId, roleName, status, paginationLimit, paginationNum,
//						getClientIdForRequest());
//
//		final List<RoleResponse> roleResponseList =
//				roleList.stream().map(r -> mapRoleToRoleResponse(r, expand)).collect(Collectors.toList());
//
//		return buildResponseAsListWithPagination(roleList.getTotalElements(), paginationNum, paginationLimit,
//				roleResponseList);
//	}

	@Transactional
	public RoleDTO processUpdateRole(String clientId, final RoleDTO roleDTO, Integer roleId) {
		validationUtils.requireClient(clientId);
		final Role role = roleService.getRoleByRoleId(roleId);
		role.setName(roleDTO.getName());
		role.setSystemName(roleDTO.getSystemName());

		if (null!=roleDTO.getPrivileges()){
			rolePrivilegeService.deleteAllByRoleId(roleId);
			validatePrivilege(roleDTO.getPrivileges());
			for (String privilege: roleDTO.getPrivileges()){
				Privilege privilegeFromRepo = validationUtils.requirePrivilege(privilege);
				RolePrivilege rolePrivilege = new RolePrivilege();
				rolePrivilege.setPrivilegeId(privilegeFromRepo.getPrivilegeId());
				rolePrivilege.setRoleId(roleId);
				rolePrivilegeService.save(rolePrivilege);
			}
		}

		roleService.save(role);

		return mapperService.getDtoFromEntity(role);
	}

	public ResponseEntity<AccessListResponse> getAccessList() {

		final AccessListResponse accessListResponse = new AccessListResponse();
		final List<SubdomainResponse> subdomains = accessDomainService.getAll().stream()
				.map(ad -> accessDomainToSubdomainResponse(ad)).collect(Collectors.toList());

		accessListResponse.setSubdomains(subdomains);

		return new ResponseEntity<>(accessListResponse, HttpStatus.OK);
	}

	private SubdomainResponse accessDomainToSubdomainResponse(final AccessDomain accessDomain) {

		final SubdomainResponse subdomainResponse = new SubdomainResponse();
		subdomainResponse.setDomainCode(accessDomain.getDomainCode());
		subdomainResponse.setDomainName(accessDomain.getDomainDescription());
		subdomainResponse.setAccessesRequested(null);

		return subdomainResponse;
	}

	public ResponseEntity<RoleResponse> findByRoleId(final Integer roleId) {

		final Role role = roleService.getRoleByRoleId(roleId);
		if (nonNull(role)) {
			return new ResponseEntity<>(mapRoleToRoleResponse(role, true), HttpStatus.OK);
		}
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}

	public ResponseEntity<RoleResponse> processChangeStatus(final ChangeRoleStatusRequest changeRoleStatusRequest) {

		final Role role = roleService.getRoleByRoleId(changeRoleStatusRequest.getRoleId());
		if (nonNull(role)) {
			role.setStatusId(changeRoleStatusRequest.getStatusId());
			final Role roleFromDB = roleService.save(role);
			return new ResponseEntity<>(mapRoleToRoleResponse(roleFromDB, true), HttpStatus.OK);
		}
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}

	public ResponseEntity<RoleResponse> processDelete(final ChangeRoleStatusRequest changeRoleStatusRequest) {

		final Role role = roleService.getRoleByRoleId(changeRoleStatusRequest.getRoleId());
		if (nonNull(role)) {
			final List<RolePrivilege> rolePrivilegeList = rolePrivilegeService.getAllByRole(role);
			rolePrivilegeService.remove(rolePrivilegeList);

			roleService.remove(role);

			return new ResponseEntity<>(mapRoleToRoleResponse(role, true), HttpStatus.OK);
		}
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}

	public List<RoleDTO> getAllRoles(String clientId, RoleSearchRequestDTO searchRequest, Pageable pageable) {
		validationUtils.requireClient(clientId);
		List<RoleDTO> roleDTOS = new ArrayList<>();
		for (Role role: roleService.getAllWithPagination(searchRequest,pageable)){
			RoleDTO roleDTO = mapperService.getDtoFromEntity(role);
			roleDTOS.add(roleDTO);
		}
		return roleDTOS;
	}
}
