package com.r1vs.platform.rox.common.model.users;

import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.List;

import javax.persistence.*;

import com.r1vs.platform.rox.common.model.AuditedEntity;
import com.r1vs.platform.rox.common.model.business.Application;
import com.r1vs.platform.rox.common.model.business.Client;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "users")
public class User extends AuditedEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "user_id", nullable = false)
	private Long userId;

	@Column(name = "username", nullable = false)
	private String username;

	@Column(name = "first_name", nullable = false)
	private String firstName;

	@Column(name = "last_name", nullable = false)
	private String lastName;

	@Column(name = "password")
	private String password;

	@Column(name = "email", nullable = false)
	private String email;

	@Column(name = "phone_type_id")
	private Integer phoneTypeId;

	@Column(name = "phone")
	private String phone;

	@Column(name = "registered")
	private Boolean registered;

	@Column(name = "registered_date")
	private OffsetDateTime registeredDate;

	@Column(name = "version")
	private Integer version;

	@Column(name = "active")
	private Boolean active;

	@Column(name = "is_superuser")
	private Boolean isSuperuser;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "client_id", nullable = false)
	private Client client;

	@OneToOne(mappedBy = "user", cascade = CascadeType.ALL, fetch = FetchType.LAZY, optional = false)
	private RegistrationToken registrationToken;

	//@OneToOne(fetch = FetchType.LAZY)
	//@JoinColumn(name = "phone_type_id", referencedColumnName = "code_id", insertable = false, updatable = false)
	//private Code code;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "created_by", referencedColumnName = "user_id", insertable = false, updatable = false)
	private User createdUser;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "updated_by", referencedColumnName = "user_id", insertable = false, updatable = false)
	private User updatedUser;

	@OneToMany(fetch = FetchType.LAZY)
	@JoinTable(name = "user_group",
			joinColumns = { @JoinColumn(name = "user_id", referencedColumnName = "user_id") },
			inverseJoinColumns = { @JoinColumn(name = "access_group_id", referencedColumnName = "access_group_id") })
	private List<AccessGroup> accessGroups;

	@OneToMany(fetch = FetchType.LAZY)
	@JoinTable(name = "user_Role",
			joinColumns = @JoinColumn(name = "user_id", referencedColumnName = "user_id", insertable = false,
					updatable = false),
			inverseJoinColumns = @JoinColumn(name = "user_id", referencedColumnName = "user_id", insertable = false,
					updatable = false))
	private List<UserRole> userRoles;

	public User() {

		super();
		this.registered = false;
	}

	public Long getUserId() {

		return userId;
	}

	public void setUserId(final Long userId) {

		this.userId = userId;
	}

	public String getUsername() {

		return username;
	}

	public void setUsername(final String username) {

		this.username = username;
	}

	public String getFirstName() {

		return firstName;
	}

	public void setFirstName(final String firstName) {

		this.firstName = firstName;
	}

	public String getLastName() {

		return lastName;
	}

	public void setLastName(final String lastName) {

		this.lastName = lastName;
	}

	public String getPassword() {

		return password;
	}

	public void setPassword(final String password) {

		this.password = password;
	}

	public String getEmail() {

		return email;
	}

	public void setEmail(final String email) {

		this.email = email;
	}

	public Integer getPhoneTypeId() {

		return phoneTypeId;
	}

	public void setPhoneTypeId(final Integer phoneTypeId) {

		this.phoneTypeId = phoneTypeId;
	}

	public String getPhone() {

		return phone;
	}

	public void setPhone(final String phone) {

		this.phone = phone;
	}

	public Boolean isRegistered() {

		return registered;
	}

	public void setIsRegistered(final Boolean registered) {

		this.registered = registered;
	}

	public OffsetDateTime getRegisteredDate() {

		return registeredDate;
	}

	public void setRegisteredDate(final OffsetDateTime registeredDate) {

		this.registeredDate = registeredDate;
	}

	public Boolean isActive() {

		return active;
	}

	public void setActive(Boolean active) {

		this.active = active;
	}

	public Boolean isSuperuser() {

		return isSuperuser;
	}

	public void setSuperuser(Boolean superuser) {

		isSuperuser = superuser;
	}

	public Integer getVersion() {

		return version;
	}

	public void setVersion(final Integer version) {

		this.version = version;
	}

	public Client getClient() {

		return client;
	}

	public void setClient(final Client client) {

		this.client = client;
	}

	public RegistrationToken getRegistrationToken() {

		return registrationToken;
	}

	public void setRegistrationToken(final RegistrationToken registrationToken) {

		this.registrationToken = registrationToken;
	}
	/*
		public Code getCode() {
	
			return code;
		}
	
		public void setCode(final Code code) {
	
			this.code = code;
		}
	*/
	/*
		@Override
		public User getCreatedByUser() {
	
			return createdUser;
		}
	
		@Override
		public void setCreatedByUser(final User createdByUser) {
	
			this.createdUser = createdByUser;
		}
	*/

	public User getUpdatedUser() {

		return updatedUser;
	}

	public void setUpdatedUser(final User updatedUser) {

		this.updatedUser = updatedUser;
	}

	public Boolean getRegistered() {

		return registered;
	}

	public void setRegistered(final Boolean registered) {

		this.registered = registered;
	}

	public List<AccessGroup> getAccessGroups() {

		return accessGroups;
	}

	public void setAccessGroups(List<AccessGroup> accessGroups) {

		this.accessGroups = accessGroups;
	}

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof User)) {
			return false;
		}
		final User castOther = (User) other;
		return new EqualsBuilder().append(userId, castOther.userId).append(username, castOther.username)
				.append(firstName, castOther.firstName).append(lastName, castOther.lastName)
				.append(password, castOther.password).append(email, castOther.email)
				.append(phoneTypeId, castOther.phoneTypeId).append(phone, castOther.phone)
				.append(registered, castOther.registered).append(registeredDate, castOther.registeredDate)
				.append(active, castOther.active).append(isSuperuser, castOther.isSuperuser)
				.append(version, castOther.version).isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(userId).append(username).append(firstName).append(lastName).append(password)
				.append(email).append(phoneTypeId).append(phone).append(registered).append(registeredDate)
				.append(active).append(isSuperuser).append(version).toHashCode();
	}

	@Override
	public String toString() {

		return "User{" +
				"userId=" + userId +
				", username='" + username + '\'' +
				", firstName='" + firstName + '\'' +
				", lastName='" + lastName + '\'' +
				", password='" + password + '\'' +
				", email='" + email + '\'' +
				", phoneTypeId=" + phoneTypeId +
				", phone='" + phone + '\'' +
				", registered=" + registered +
				", registeredDate=" + registeredDate +
				", version=" + version +
				", active=" + active +
				", isSuperuser=" + isSuperuser +
				", client=" + client +
				", registrationToken=" + registrationToken +
				", createdUser=" + createdUser.getUsername() +
				", updatedUser=" + updatedUser.getUsername() +
				", userRoles=" + userRoles +
				'}';
	}
}
