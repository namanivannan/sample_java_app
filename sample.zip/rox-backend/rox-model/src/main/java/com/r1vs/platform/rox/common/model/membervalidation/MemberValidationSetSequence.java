package com.r1vs.platform.rox.common.model.membervalidation;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "member_validation_set_sequence")
public class MemberValidationSetSequence implements Serializable {

	private static final long serialVersionUID = -2807513212872451248L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "member_validation_set_sequence_id", nullable = false)
	private Integer sequenceId;

	public Integer getSequenceId() {

		return sequenceId;
	}

	public void setSequenceId(final Integer sequenceId) {

		this.sequenceId = sequenceId;
	}

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof MemberValidationSetSequence)) {
			return false;
		}
		final MemberValidationSetSequence castOther = (MemberValidationSetSequence) other;
		return new EqualsBuilder().append(sequenceId, castOther.sequenceId).isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(sequenceId).toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("sequenceId", sequenceId).toString();
	}

}
