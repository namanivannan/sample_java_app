package com.r1vs.platform.rox.api.processor;

import com.r1vs.platform.rox.api.model.UserStatus;
import com.r1vs.platform.rox.api.repository.RoleRepository;
import com.r1vs.platform.rox.common.db.repository.business.PhoneTypeRepository;
import com.r1vs.platform.rox.common.model.business.PhoneType;
import com.r1vs.platform.rox.common.model.types.StatusType;
import com.r1vs.platform.rox.common.model.users.Role;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.r1vs.platform.rox.api.security.SecurityConstants.MANAGE_CLIENT;

@Component
public class UserReferenceProcessor {

	private static final String PHONE_TYPE = "phoneTypeCodeId";

	private static final Integer PHONE_CODE_TYPE_ID = 7;

	private static final String ROLES = "roleIds";

	private static final String USER_STATUS = "userStatus";

	public static final String ROX_ADMIN = "ROX_ADMIN";

	private static Map<Integer, String> phoneCodeMap = new HashMap<>();

	@Autowired
	private PhoneTypeRepository phoneTypeRepository;

	@Autowired
	private RoleRepository roleRepository;

	@PostConstruct
	public void init() {

		phoneCodeMap = getPhoneReference();

	}

	public Map<String, Map<Integer, String>> getUserReference() {

		final Map<String, Map<Integer, String>> referenceMap = new HashMap<>();

		referenceMap.put(PHONE_TYPE, phoneCodeMap);

		referenceMap.put(ROLES, getRoleReference());

		referenceMap.put(USER_STATUS, UserStatus.getUserStatusList());

		return referenceMap;
	}

	public Map<Integer, String> getPhoneReference() {

		if (!phoneCodeMap.isEmpty()) {
			return phoneCodeMap;
		}

		final List<PhoneType> phoneCodes = phoneTypeRepository.findAll();

		return phoneCodes.stream().collect(Collectors.toMap(PhoneType::getId, PhoneType::getType));
	}

	public Map<Integer, String> getRoleReference() {

		final List<Role> roles = roleRepository.findAllByStatusId(StatusType.ACTIVE.key());

		if (isInstanceAdmin()) {

			return roles.stream().collect(Collectors.toMap(Role::getRoleId, Role::getName));
		}

		return roles.stream().filter(role -> !role.getSystemName().equals(ROX_ADMIN)) // return a filtered list of
				// roles with no instance
				// admin
				.collect(Collectors.toMap(Role::getRoleId, Role::getName));
	}

	private boolean isInstanceAdmin() {

		return SecurityContextHolder.getContext().getAuthentication().getAuthorities().stream()
				.anyMatch(a -> a.getAuthority().equals(MANAGE_CLIENT));
	}

}
