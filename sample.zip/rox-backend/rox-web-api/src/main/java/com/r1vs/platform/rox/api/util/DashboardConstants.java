package com.r1vs.platform.rox.api.util;

public class DashboardConstants {

	public static final String NAME = "name";

	public static final String VALUE = "value";

	public static final String DURATION = "duration";

	public static final String OVERVIEW = "overview";

	public static final String OPEN_APPLICATIONS = "openApplications";

	public static final String APPLICATIONS_VALUE = "applicationsValue";

	public static final String APPLICATIONS = "applications";

	public static final String MONTH = "month";

	public static final String NEW = "new";

	public static final String COMPLETED = "completed";

	public static final String PORTFOLIO_GROWTH = "portFolioGrowth";

}
