package com.r1vs.platform.rox.common.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@Entity
@Table(name = "language_code")
public class LanguageCode implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "id", nullable = false)
	private Integer id;

	@Column(name = "iso_code", nullable = false)
	private String isoCode;

	@Column(name = "language", nullable = false)
	private String language;

	// Added to convert Integer to String
	public String getIdAsString() {

		return String.valueOf(id);
	}

	public Integer getId() {

		return id;
	}

	public void setId(final Integer id) {

		this.id = id;
	}

	public String getIsoCode() {

		return isoCode;
	}

	public void setIsoCode(final String isoCode) {

		this.isoCode = isoCode;
	}

	public String getLanguage() {

		return language;
	}

	public void setLanguage(final String language) {

		this.language = language;
	}

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof LanguageCode)) {
			return false;
		}
		final LanguageCode castOther = (LanguageCode) other;
		return new EqualsBuilder().append(id, castOther.id).append(isoCode, castOther.isoCode)
				.append(language, castOther.language).isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(id).append(isoCode).append(language).toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("id", id).append("isoCode", isoCode).append("language", language)
				.toString();
	}

}
