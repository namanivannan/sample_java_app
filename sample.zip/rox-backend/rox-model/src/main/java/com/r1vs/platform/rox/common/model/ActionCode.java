package com.r1vs.platform.rox.common.model;

import com.r1vs.platform.rox.common.model.types.KeyValueEnumHelper;

public enum ActionCode {

	ADD("A", "Add"),
	CHANGE("C", "Change"),
	DELETE("D", "Delete"),
	TERMINATE("T", "Terminate"),
	REINSTATE("R",
			"Reinstate");

	private String key;

	private String value;

	public static final KeyValueEnumHelper<ActionCode, String, String> HELPER = KeyValueEnumHelper
			.adapt(ActionCode::key, ActionCode::value, ActionCode.values());

	ActionCode(final String key, final String value) {

		this.value = value;
		this.key = key;
	}

	public String key() {

		return this.key;
	}

	public String value() {

		return this.value;
	}

}
