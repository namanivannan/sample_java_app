package com.r1vs.platform.rox.api.controller;

import com.r1vs.platform.rox.api.model.application.initiate.BusinessDTO;
import com.r1vs.platform.rox.api.model.application.initiate.UpdateBusinessDTO;
import com.r1vs.platform.rox.api.service.BusinessService;
import com.r1vs.platform.rox.common.model.business.BusinessCategory;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.UUID;

import static com.r1vs.platform.rox.api.util.InterceptorConstants.CLIENT_ID;

@RestController
@RequestMapping(value = "/v1")
public class DebtorController {

	@Autowired
	private BusinessService businessService;

	@PostMapping("/applications/{applicationId}/debtors")
	@Operation(summary = "Creates new Debtor")
	public ResponseEntity<BusinessDTO> createDebtor(@RequestHeader(CLIENT_ID) String clientId,
			@PathVariable UUID applicationId,
			@RequestBody BusinessDTO debtorDTO) {

		return new ResponseEntity<>(businessService.createDebtor(clientId, applicationId, debtorDTO),
				HttpStatus.CREATED);
	}

	@PatchMapping("/applications/{applicationId}/debtors")
	@Operation(summary = "Modifies certain information of a Debtor")
	public ResponseEntity<BusinessDTO> updateDebtor(@RequestHeader(CLIENT_ID) String clientId,
			@PathVariable UUID applicationId,
			@Valid @RequestBody UpdateBusinessDTO updateDebtorDTO) {

		return new ResponseEntity<>(
				businessService.updateBusiness(clientId, applicationId, updateDebtorDTO, BusinessCategory.DEBTOR),
				HttpStatus.OK);
	}
}
