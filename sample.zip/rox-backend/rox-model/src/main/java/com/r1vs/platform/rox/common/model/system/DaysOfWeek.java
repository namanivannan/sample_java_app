package com.r1vs.platform.rox.common.model.system;

import java.util.EnumSet;

public enum DaysOfWeek {

	SUNDAY(1, "Sunday", "sunday"),
	MONDAY(2, "Monday", "monday"),
	TUESDAY(3, "Tuesday", "tuesday"),
	WEDNESDAY(4,
			"Wednesday", "wednesday"),
	THURSDAY(5, "Thursday",
			"thursday"),
	FRIDAY(6, "Friday", "friday"),
	SATURDAY(7, "Saturday", "saturday");

	private Integer key;

	private String value;

	private String internalCasing;

	DaysOfWeek(final Integer key, final String value, final String internalCasing) {

		this.key = key;
		this.value = value;
		this.internalCasing = internalCasing;
	}

	public Integer key() {

		return this.key;
	}

	/**
	 * Get day of the week name
	 *
	 * @return physical location time
	 */
	public String value() {

		return value;
	}

	public String internalCasing() {

		return internalCasing;
	}

	public static DaysOfWeek getByKey(final Integer key) {

		return EnumSet.allOf(DaysOfWeek.class).stream().filter(dow -> dow.key().equals(key)).findFirst().orElse(null);
	}

	public static DaysOfWeek getByInternalCasing(final String internalCasing) {

		return EnumSet.allOf(DaysOfWeek.class).stream().filter(dow -> dow.internalCasing().equals(internalCasing))
				.findFirst().orElse(null);
	}
}
