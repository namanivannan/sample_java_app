package com.r1vs.platform.rox.common.model.business;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "identification_type")
public class IdentificationType {

	@Id
	@Column(name = "id")
	private Long id;

	@Column(name = "type")
	private String type;

	public Long getId() {

		return this.id;
	}

	public void setId(Long id) {

		this.id = id;
	}

	public String getType() {

		return this.type;
	}

	public void setType(String type) {

		this.type = type;
	}
}
