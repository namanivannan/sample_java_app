package com.r1vs.platform.rox.api.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.r1vs.platform.rox.common.util.StringUtil;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.io.UnsupportedEncodingException;

import static com.r1vs.platform.rox.api.controller.DBConnection.TEST_USER_1;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.*;
import static org.hamcrest.Matchers.hasSize;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@Sql("fixture2.sql")
public class InteractionResponsesControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private DBConnection dbConnection;

	private String token;

	private String token_user_1;

	@Before
	public void setUp() throws Exception {

		if (StringUtil.isNullOrEmpty(token)) {
			token = dbConnection.loginToDb();
			token_user_1 = dbConnection.loginToDb(TEST_USER_1);
		}
	}

	@Test
	public void givenSomeInteractionResponsesInBD_whenRequestingThem_thenEndpointReturnsFullyPopulatedDTO()
			throws Exception {

		mockMvc.perform(MockMvcRequestBuilders
				.get("/v1/applications/839e72fc-6433-46fd-a259-5dbb50b913d6/interactionResponses?type=FMCSA")
				.contentType(MediaType.APPLICATION_JSON)
				.header("x-client-id", "11")
				.header("Authorization", token))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$[0].uuid", is(not(emptyOrNullString()))))
				.andExpect(jsonPath("$[0].provider", is("FMCSA")))
				.andExpect(jsonPath("$[0].name", is("Mickey Green Mouse")))
				.andExpect(jsonPath("$[0].code", is("VALID")))
				.andExpect(jsonPath("$[0].duration", is(3)))
				.andExpect(jsonPath("$[0].createdAt", is(not(emptyOrNullString()))))
				.andExpect(jsonPath("$[0].createdBy.name", is("RoxWrite User Client 1")))
				.andExpect(jsonPath("$[0].createdBy.firstName", is("RoxWrite")))
				.andExpect(jsonPath("$[0].createdBy.lastName", is("User Client 1")));

	}

	@Test
	public void givenSomeInteractionResponsesInBD_whenRequestingThem_thenEndpointReturnsFilteredLists()
			throws Exception {

		mockMvc.perform(MockMvcRequestBuilders
				.get("/v1/applications/839e72fc-6433-46fd-a259-5dbb50b913d6/interactionResponses?type=FMCSA")
				.contentType(MediaType.APPLICATION_JSON)
				.header("x-client-id", "11")
				.header("Authorization", token))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$", hasSize(3)));

		mockMvc.perform(MockMvcRequestBuilders
				.get("/v1/applications/839e72fc-6433-46fd-a259-5dbb50b913d6/interactionResponses?type=UCC")
				.contentType(MediaType.APPLICATION_JSON)
				.header("x-client-id", "11")
				.header("Authorization", token))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$", hasSize(2)))
				.andReturn();

	}

	@Test
	public void givenSomeInteractionResponsesInBD_whenRequestingForAppWithNoInteractions_thenEndpointReturnsEmptyList()
			throws Exception {

		MvcResult mvcResult = mockMvc
				.perform(MockMvcRequestBuilders
						.get("/v1/applications/4d61f5c0-bca0-4388-bb02-8693d298ffd5/interactionResponses?type=FMCSA")
						.contentType(MediaType.APPLICATION_JSON)
						.header("x-client-id", "11")
						.header("Authorization", token))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$", hasSize(0)))
				.andDo(print())
				.andReturn();
	}

	@Test
	public void givenSomeInteractionResponsesInBD_whenRequestingForAppWithNonExistentType_thenEndpointReturns400()
			throws Exception {

		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders
				.get("/v1/applications/4d61f5c0-bca0-4388-bb02-8693d298ffd5/interactionResponses?type=nonExistent")
				.contentType(MediaType.APPLICATION_JSON)
				.header("x-client-id", "11")
				.header("Authorization", token))
				.andExpect(status().isBadRequest())
				.andDo(print())
				.andReturn();
	}

	@Test
	public void
			givenSomeInteractionResponsesInBD_whenRequestingUCCResponses_thenEndpointReturnsHoldersCorrectlyPopulated()
					throws Exception {

		// TODO assert owner and business info
		MvcResult mvcResult = mockMvc
				.perform(MockMvcRequestBuilders
						.get("/v1/applications/839e72fc-6433-46fd-a259-5dbb50b913d6/interactionResponses?type=UCC")
						.contentType(MediaType.APPLICATION_JSON)
						.header("x-client-id", "11")
						.header("Authorization", token))
				.andExpect(status().isOk())
				.andDo(print())
				.andReturn();
	}

	// TODO test the response with entities with empty interaction responses boolean

}