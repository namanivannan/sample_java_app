package com.r1vs.platform.rox.api.service;

import com.r1vs.platform.rox.api.exception.RoxApiException;
import com.r1vs.platform.rox.api.model.application.initiate.*;
import com.r1vs.platform.rox.common.db.repository.business.*;
import com.r1vs.platform.rox.common.model.business.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.UUID;

@Service
public class BusinessService {

	private static final Logger LOGGER = LoggerFactory.getLogger(BusinessService.class);

	@Autowired
	private BusinessRepository businessRepository;

	@Autowired
	private ValidationUtils validationUtils;

	@Autowired
	private AuditUtilsService auditUtilsService;

	@Autowired
	private MapperService mapperService;

	public BusinessDTO updateBusiness(String clientId, UUID applicationId, UpdateBusinessDTO updateBusinessDTO,
			BusinessCategory businessCategory) {

		Application application = validateApplication(clientId, applicationId);
		if (!application.getStatus().getStatus().equals("New")) {
			throw new RoxApiException("Only Applications in \"New\" status are able to be updated",
					HttpStatus.BAD_REQUEST);
		}
		Business business = mapperService.patchExistingData(
				validationUtils.requireBusiness(application, businessCategory), updateBusinessDTO);
		if (null != updateBusinessDTO.getContractAmount() && businessCategory.equals(BusinessCategory.BUSINESS)) {
			application.setContractAmount(Long.valueOf(updateBusinessDTO.getContractAmount()));
		}
		businessRepository.save(business);
		auditUtilsService.recoverAuditObjects(business);
		auditUtilsService.touchApplicationUpdateFields(application, business);

		return mapperService.getDtoFromEntity(business, businessCategory, application);

	}

	public BusinessDTO createDebtor(String clientId, UUID applicationId, BusinessDTO debtorDTO) {

		Application application = validateApplication(clientId, applicationId);
		Business debtorFromDTO = mapperService.getEntityFromDTO(debtorDTO, BusinessCategory.DEBTOR);
		debtorFromDTO.setApplication(application);
		businessRepository.save(debtorFromDTO);
		return mapperService.getDtoFromEntity(debtorFromDTO, BusinessCategory.DEBTOR, null);
	}

	public Application validateApplication(String clientId, UUID applicationId) {

		Client client = validationUtils.requireClient(clientId);
		return validationUtils.requireApplication(applicationId, client);
	}
}
