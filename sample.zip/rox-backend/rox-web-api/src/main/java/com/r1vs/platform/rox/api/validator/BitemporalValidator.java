package com.r1vs.platform.rox.api.validator;

import com.r1vs.platform.rox.api.exception.Error;
import com.r1vs.platform.rox.common.util.DateUtil;

import java.time.LocalDate;

import static com.r1vs.platform.rox.api.util.ValidationUtil.addError;
import static com.r1vs.platform.rox.api.util.ValidationUtil.handleException;

/**
 * Class Validator for Bitemporal (PTA) related fields. A class that extends this indicates it's entity is PTA tracked.
 *
 * @author gbugaisky
 *
 */

public class BitemporalValidator {

	private static final String EFFECTIVE_START_DATE = "effectiveStartDate";

	private static final String EFFECTIVE_END_DATE = "effectiveEndDate";

	/**
	 * Validate that the effective start does not come after the effective end
	 *
	 * @param error error object
	 * @param effectiveStartDate effectiveStartDate
	 * @param effectiveEndDate effectiveEndDate
	 */

	protected void validateEffectiveDates(final Error error, final LocalDate effectiveStartDate,
			final LocalDate effectiveEndDate) {

		if (effectiveStartDate == null) {
			addError(error, EFFECTIVE_START_DATE, ValidationMessages.EFFECTIVE_START_DATE_CANNOT_BE_NULL, null);
		}
		if (effectiveEndDate == null) {
			addError(error, EFFECTIVE_END_DATE, ValidationMessages.EFFECTIVE_END_DATE_CANNOT_BE_NULL, null);
		}
		if (effectiveStartDate == null || effectiveEndDate == null) {
			handleException(error);
		}

		if (effectiveStartDate != null && effectiveStartDate.isAfter(effectiveEndDate)) {
			addError(error, EFFECTIVE_START_DATE, ValidationMessages.INVALID_START_DATE,
					DateUtil.getDateStringFromLocalDate(effectiveStartDate));
		}
	}
}
