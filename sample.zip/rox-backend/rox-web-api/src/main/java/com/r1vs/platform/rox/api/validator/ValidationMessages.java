package com.r1vs.platform.rox.api.validator;

public final class ValidationMessages {

	public final static String INVALID_START_DATE = "Effective start date is after effective end date.";

	public final static String INVALID_CLIENT_ID = "No Client id associated with the user";

	public final static String INVALID_USER_CLIENT_ID = "Invalid Client id for the user";

	public final static String INVALID_USER_ID = "No User id associated with the user";

	public final static String MISSING_USER_ID = "Missing user id";

	public final static String INVALID_STATUS = "Invalid status.";

	public final static String STATUS_CANNOT_BE_UPDATED = "Status cannot be updated. ";

	public final static String INVALID_EDIT_STATUS = "Cannot create a edit with status: ";

	public final static String INVALID_PLAN_STATUS = "Cannot create a plan with status: ";

	public final static String INVALID_RULE_STATUS = "Cannot create a rule with status: ";

	public final static String INVALID_PBM_STATUS = "Cannot create a pbm with status: ";

	public final static String INVALID_GROUP_STATUS = "Cannot create a group with status: ";

	public final static String INVALID_GROUP_PLAN_STATUS = "Cannot create a group plan with status: ";

	public final static String INVALID_CARRIER_STATUS = "Cannot create a carrier with status: ";

	public final static String INVALID_SPONSOR_STATUS = "Cannot create a sponsor with status: ";

	public final static String INVALID_ACCOUNT_STATUS = "Cannot create an account with status: ";

	public final static String INVALID_BASIS_OF_COST_CODE_STATUS = "Cannot create a basis of cost code with status: ";

	public final static String INVALID_CARRIER_ID = "Invalid Carrier ID.";

	// validation messages for Plan.
	public final static String INVALID_PLAN_TYPE = "Invalid plan type. ";

	public final static String PLAN_ID_NOT_EXISTS = "Entered plan id does not exist ";

	public final static String INVALID_COVERAGE_LEVEL = "Invalid coverage level. ";

	public final static String INVALID_TAX_EXEMPTION = "Invalid tax exemption. ";

	public final static String INVALID_COST_SHARING_BASIS = "Invalid cost sharing basis. ";

	public final static String INVALID_COST_SHARING_ORDER = "Invalid cost sharing order. ";

	public final static String PLAN_ID_ALREADY_EXISTS = "Entered ID is not unique ";

	public final static String PLAN_NAME_ALREADY_EXISTS = "Entered name is not unique ";

	public final static String INVALID_PRICING_METHODOLOGY = "Invalid pricing methodology.";

	public final static String INVALID_RESTRICTION = "Invalid Restriction.";

	// validation messages for Contact

	public final static String INVALID_STATE = "Invalid state.";

	public final static String INVALID_CONTACT_STRUCTURE = "Invalid contact structure.";

	public final static String INVALID_CONTACT_TYPE = "Invalid contact type.";

	public final static String INVALID_TAX_ASSESSMENT = "Invalid tax assessment.";

	public final static String INVALID_CLAIM_RESPONSE_PLAN_ID = "Invalid claim response plan id.";

	public final static String INVALID_PLAN_CLAIM_TYPE = "Invalid claim type.";

	public final static String INVALID_COMPOUND_BRAND_CLASS = "Invalid compound brand class.";

	public final static String INVALID_PLAN = "Plan is not effective. ";

	// validation messages for Pbm
	public final static String INVALID_PBM = "Pbm is not effective. ";

	public final static String PBM_ID_ALREADY_EXISTS = "Entered ID is not unique ";

	public final static String PBM_NAME_ALREADY_EXISTS = "Entered name is not unique ";

	public final static String PBM_ID_NOT_MATCH = "Pbm id from the user and from the plan don't match. ";

	public static final String PBM_ID_NOT_EXIST = "Pbm id does not exist";

	public static final String INVALID_DEFAULT_GROUP = "Invalid default group id";

	// validation messages for Group
	public final static String INVALID_GROUP = "Group is not effective. ";

	public final static String GROUP_NAME_NOT_EXISTS = "Group name does not exist";

	public final static String GROUP_ID_LENGTH_RANGE = "Group Id length must be between 1 and 15.";

	public final static String GROUP_NAME_LENGTH_RANGE = "Maximum name length must be less than 30";

	public final static String GROUP_ID_ALREADY_EXISTS = "Entered ID is not unique ";

	public final static String GROUP_NAME_ALREADY_EXISTS = "Entered name is not unique ";

	public final static String INVALID_FILE_UPDATE_TYPE = "Invalid Type of File Update";

	public final static String INVALID_ACCOUNT_ID = "Invalid Account ID.";

	// validation messages for group plan
	public final static String GROUP_PLAN_ID_LENGTH_RANGE = "GroupPlan Id length must be between 1 and 8.";

	public final static String GROUP_PLAN_ID_ALREADY_EXISTS = "Entered ID is not unique ";

	public final static String GROUP_PLAN_ASSOCIATION_CANNOT_BE_CHANGED = "You cannot change group plan association ";

	public final static String WRONG_GROUP_PLAN_ID = "Wrong group plan id associated with group id and plan id ";

	public final static String INVALID_GROUP_PLAN = "Group Plan is not effective. ";

	public final static String GROUP_ID_NOT_EXISTS = "Entered group id does not exist ";

	public static final String INVALID_ACTION_FOR_PLAN_MAX = "Invalid action For Plan Max";

	public static final String INVALID_COB_METHOD = "Invalid cob Method";

	public static final String INVALID_NULL = "This field can not be null";

	public static final String INVALID_COB_NOT_COVERED = "Invalid cob Not Covered";

	public static final String INVALID_COB_PAYMENT_REJECT = "Invalid cob Payment Reject";

	public static final String INVALID_COMPOUND_COVERAGE = "Invalid compound Coverage";

	public static final String INVALID_COST_AVOIDANCE_METHOD = "Invalid cost Avoidance Method";

	public static final String INVALID_DISPENSING_FEE_METHOD = "Invalid dispensing Fee Method";

	public static final String INVALID_COB_SETTINGS = "Invalid COB settings";

	public static final String COB_SETTINGS = "cobSettings";

	public static final String INVALID_MEMBER_FINANCIAL_RESPONSIBILITY = "Invalid member Financial Responsibility";

	public static final String INVALID_OTHER_COVERAGE_CODE = "Invalid other Coverage Code";

	public static final String INVALID_PRORATION = "Invalid proration";

	public static final String INVALID_REJECT_PROVIDER = "Invalid reject Provider";

	public static final String INVALID_REQUIRE_OTHER_PAYER_AMOUNT_PAID = "Invalid require Other PayerAmountPaid";

	public static final String INVALID_REQUIRE_OTHER_PAYER = "Invalid require Other Payer";

	// validation messages for Carrier
	public final static String CARRIER_NAME_LENGTH_RANGE = "Maximum name length must be less than 45";

	public final static String CARRIER_ID_ALREADY_EXISTS = "Entered ID is not unique ";

	public final static String CARRIER_NAME_ALREADY_EXISTS = "Entered name is not unique ";

	public final static String INVALID_CARRIER_TYPE = "Invalid carrier type.";

	public final static String CARRIER_TYPE_CANNOT_BE_NULL = "Carrier type cannot be null. ";

	public final static String INVALID_SPONSOR_NAME = "Invalid sponsor name.";

	public final static String INVALID_CARRIER = "Carrier is not effective. ";

	public final static String INVALID_SPONSOR_ID = "Invalid Sponsor ID.";

	// validation messages for Sponsors
	public final static String SPONSOR_ID_ALREADY_EXISTS = "Entered ID is not unique ";

	public final static String SPONSOR_NAME_ALREADY_EXISTS = "Entered name is not unique ";

	public final static String INVALID_SPONSOR_TYPE = "Invalid sponsor type. ";

	public final static String SPONSOR_TYPE_CANNOT_BE_NULL = "Sponsor type cannot be null. ";

	public final static String INVALID_PBM_TYPE = "Invalid pbm type. ";

	public final static String INVALID_SPONSOR = "Sponsor is not effective. ";

	public final static String INVALID_BASIS_OF_COST_CODE = "Basis of cost code is not effective. ";

	public final static String BASIS_OF_COST_CODE_ALREADY_EXISTS = "Entered code is not unique ";

	public final static String BASIS_OF_COST_CODE_REIMBURSEMENT_ASSIGNMENT_CANNOT_BE_NULL =
			"Basis of cost code reimbursement assignment cannot be null";

	public final static String INVALID_BASIS_OF_COST_CODE_REIMBURSEMENT_ASSIGNMENT =
			"Basis of cost code reimbursement assignment value is not effective";

	public final static String BASIS_OF_COST_CODE_DESCRIPTION_CANNOT_BE_NULL =
			"basis of cost code description cannot be null.";

	public final static String BASIS_OF_COST_CODE_CANNOT_BE_NULL = "Basis of cost code cannot be null.";

	public static final String ACCOUNT_NAME_LENGTH_RANGE = "Maximum name length must be less than 30";

	public final static String ACCOUNT_ID_ALREADY_EXISTS = "Entered ID is not unique ";

	public final static String ACCOUNT_NAME_ALREADY_EXISTS = "Entered name is not unique ";

	public final static String INVALID_ACCOUNT_TYPE = "Invalid account type. ";

	public final static String INVALID_CARD_STATUS = "Invalid cardStatus. ";

	public final static String ACCOUNT_TYPE_CANNOT_BE_NULL = "Account type cannot be null. ";

	public final static String INVALID_ACCOUNT = "Account is not effective. ";

	public final static String VENDOR_CANT_BE_NULL = "Vendor ID can not be null ";

	public final static String VENDOR_SHOULD_BE_NULL = "Vendor ID should be null ";

	// validation messages for Metadata

	public final static String MESSAGE_NAME_LENGTH_RESTRICTION = "MESSAGE_NAME_LENGTH_RESTRICTION";

	public final static String INVALID_MESSAGE_TEMPLATE_STATUS = "INVALID_MESSAGE_TEMPLATE_STATUS";

	// validation messages for Metadata

	public final static String INVALID_METADATA_CATEGORY_ID = "Invalid metadata category: ";

	public final static String INVALID_METADATA = "Invalid metadata: ";

	public final static String METADATA_NAME_ALREADY_EXISTS = "Entered name is not unique ";

	public final static String METADATA_NAME_LENGTH_RESTRICTION = "Metadata name length must be between 1 and 30";

	public final static String INVALID_METADATA_ID = "No metadata exists with given metadata Id";
	// validation messages for Age Limit

	public final static String INVALID_MINIMUM_AGE = "Minimum age must be greater than zero.";

	public final static String INVALID_MAXIMUM_AGE = "Maximum age must be greater than zero.";

	public final static String MIN_AGE_GREATER_THAN_MAX_AGE = "Minimum age must be less than  maximum age.";

	// validation messages for Days Supply limit
	public final static String DAYS_SUPPLY_LIMIT_EDIT_CANNOT_BE_NULL = "Days Supply Limit edit cannot be null.";

	public final static String INVALID_MINIMUM_DAYS_SUPPLY_MIN_LIMIT = "Minimum days supply cannot be less than zero.";

	public final static String INVALID_MINIMUM_DAYS_SUPPLY_MAX_LIMIT = "Minimum days supply must be less than 999.";

	public final static String INVALID_MAXIMUM_DAYS_SUPPLY_MIN_LIMIT = "Maximum days supply cannot be less than zero.";

	public final static String INVALID_MAXIMUM_DAYS_SUPPLY_MAX_LIMIT = "Maximum days supply must be less than 999.";

	public final static String MIN_DAYS_GREATER_THAN_MAX_DAYS =
			"Minimum days supply must be less than  maximum days supply.";

	// validation messages for Claim Min Max
	public final static String INVALID_MINIMUM_COST = "Minimum cost must be greater than zero.";

	public final static String INVALID_MAXIMUM_COST = "Maximum cost must be greater than zero.";

	public final static String MIN_COST_GREATER_THAN_MAX_COST = "Minimum cost must be less than  maximum cost limit.";

	public final static String INVALID_CLAIM_MIN_MAX_ACTION_TYPE = "Invalid claim min max action type.";

	// validation messages for incentive fee
	public final static String INVALID_INCENTIVE_FEE_METHOD = "Invalid incentive fee method.";

	public final static String INVALID_INCENTIVE_FEE_LIMITATION = "Invalid incentive fee limitation.";

	public final static String INVALID_INCENTIVE_BASIS = "Invalid incentive fee basis.";

	public final static String INVALID_FLAT_AMOUNT = "Flat amount must be greater than or equal to 0.";

	public final static String INCENTIVE_INVALID_FLAT_AMOUNT = "Flat amount must be greater than 0.";

	public final static String INVALID_FLAT_FIELDS = "Only flatAmount field is required";

	public final static String INVALID_RATE_RULE = "Rate rule cannot be null.";

	public final static String INVALID_RATE_RULE_TYPE = "Invalid rate rule type";

	public final static String INVALID_PERCENT_AMOUNT = "Percent amount must be greater than 0.";

	public final static String INVALID_PERCENT_FIELDS = "Only percent,minPrice and maxPrice fields are required";

	public final static String INVALID_INCENTIVE_FEE_MIN = "Incentive fee minimum must be greater than 0.";

	public final static String INVALID_INCENTIVE_MAX = "Incentive fee maximum must be greater than 0.";

	public final static String INCENTIVE_FEE_MIN_GREATER_THAN_MAX =
			"Incentive fee min must be less than incentive fee max.";

	// validation messages for pos rebate
	public final static String EMPTY_MIN_POS_REBATE = "Min POS rebate should not be empty.";

	public final static String EMPTY_MAX_POS_REBATE = "Max POS rebate should not be empty.";

	public final static String EMPTY_REBATE_METHOD = "Rebate method should not be empty.";

	public final static String INVALID_MIN_POS_REBATE = "Min POS rebate should be greater than 0.";

	public final static String INVALID_MAX_POS_REBATE = "Max POS rebate should be greater than 0.";

	public final static String MIN_POS_REBATE_GREATER_THAN_MAX = "Min POS rebate must be less than max POS rebate.";

	public final static String INVALID_REBATE_METHOD = "Invalid rebate method.";

	// validation messages for Quantity Limit
	public final static String INVALID_MIN_QUANTITY_LIMIT = "Minimum quantity limit must be greater than 0.";

	public final static String INVALID_MAX_QUANTITY_LIMIT = "Maximum quantity limit must be greater than 0.";

	public final static String MIN_QUANTITY_GREATER_THAN_MAX_QUANTITY =
			"Minimum quantity limit must be less than maximum quantity limit.";

	// validation messages for Quantity per day
	public final static String INVALID_MIN_QUANTITY_DAY = "Minimum quantity per day must be greater than 0.";

	public final static String INVALID_MAX_QUANTITY_DAY = "Maximum quantity per day must be greater than 0.";

	public final static String MIN_QUANTITY_DAY_GREATER_THAN_MAX_QUANTITY_DAY =
			"Minimum quantity per day must be less than maximum quantity per day.";

	// validation messages for Filing Limit
	public static final String INVALID_ONLINE_CLAIM_LIMIT = "Online claim limit cannot be null or empty";

	public static final String INVALID_OFFLINE_CLAIM_LIMIT = "Offline claim limit cannot be null or empty";

	public static final String INVALID_ONLINE_REVERSAL_LIMIT = "Online reversal limit cannot be null or empty";

	public static final String INVALID_OFFLINE_REVERSAL_LIMIT = "Offline reversal limit cannot be null or empty";

	public static final String INVALID_DAYS_PRESCRIPTION_FILLED = "Days of prescription filled cannot be null or empty";

	// validation messages for Refill Limit
	// validation messages for smallest package size edit

	// validation messages for Overrides
	public final static String INVALID_RESPONSE_CODE = "Invalid response code.";

	public final static String INVALID_EXTERNAL_REJECT_CODE = "Invalid external reject code.";

	public final static String INVALID_INTERNAL_REJECT_CODE = "Invalid internal reject code.";

	public final static String INVALID_TAG = "Invalid tag length";

	public final static String INVALID_DENY_OVERRIDE_AND_CLARIFICATIONS =
			"Denied Override cannot have Clarifications. ";

	public final static String INVALID_DENY_OVERRIDE_AND_LIMITATIONS = "Denied Override cannot have Limitations. ";

	public final static String INVALID_CLARIFICATIONS_AND_LIMITATIONS =
			"Override must have Clarifications or Limitations. ";

	public final static String INVALID_SYSTEM_ERROR_CODE = "Invalid system error code. ";

	public final static String INVALID_REASON_FOR_SERVICE = "Invalid reason for service. ";

	public final static String INVALID_PRIOR_AUTH = "Invalid prior auth. ";

	public final static String INVALID_SUBMISSION_CLARIFICATION_CODE = "Invalid submission clarification code. ";

	public final static String INVALID_ELIGIBILITY_CLARIFICATION_CODE = "Invalid eligibility clarification code. ";

	public final static String INVALID_PROFESSIONAL_SERVICE_CODE = "Invalid professional service code. ";

	public final static String INVALID_REASON_FOR_SERVICE_CODE = "Invalid reason for service code. ";

	public final static String INVALID_RESULT_OF_SERVICE_CODE = "Invalid result of service code. ";

	public final static String MIN_NO_OF_OCCURRENCES = "Number of occurrences must be greater than 0. ";

	public final static String MAX_NO_OF_OCCURRENCES = "Number of occurrences must be less than 1000. ";

	public final static String MIN_EVERY_X_DAYS = "Every X days must be equal or greater than 0. ";

	public final static String MAX_EVERY_X_DAYS = "Every X days must be lesser than 10000. ";

	public final static String MIN_DAYS_OF_OVERRIDE = "Days of overrides must be greater than 0. ";

	public final static String PRIOR_AUTH_TYPE_MAX_ALLOWED = "Max 1 Prior Auth Type allowed. ";

	public final static String PRIOR_AUTH_ID_MISSING = "Prior Auth ID missing. ";

	public final static String PRIOR_AUTH_ID_NOT_NEEDED = "Prior Auth ID not needed. ";

	public final static String SUBMISSION_CLARIFICATION_CODE_MAX_ALLOWED =
			"Max 3 Submission Clarification Codes allowed. ";

	public final static String ELIGIBILITY_CLARIFICATION_CODE_MAX_ALLOWED =
			"Max 1 Eligibility Clarification Codes allowed. ";

	public final static String PROFESSIONAL_SERVICE_CODE_MAX_ALLOWED = "Max 1 Professional Service Code allowed. ";

	public final static String RESULT_OF_SERVICE_CODE_MAX_ALLOWED = "Max 1 Result of Service Code allowed. ";

	public final static String REASON_OF_SERVICE_CODE_MAX_ALLOWED = "Max 1 Reason of Service Code allowed. ";

	public final static String DUPLICATE_CLARIFICATION = "Duplicate Clarifications exist with similar Codes. ";

	public final static String DUPLICATE_CODES = "Duplicate Codes within a Clarification. ";

	public final static String NO_CODES_FOR_CODE_TYPE = "No codes for the Code type. ";

	// Validation messages for other services fee
	public final static String EMPTY_COST_SHARING_METHOD = "Missing cost sharing method.";

	public final static String INVALID_COST_SHARING_METHOD = "Invalid cost sharing method.";

	public final static String INVALID_OTHER_SERVICES_FEE_LIMITATION = "Invalid other services fee limitation.";

	public final static String INVALID_OTHER_SERVICES_FEE_TYPE = "Invalid other services fee type.";

	public final static String INVALID_OTHER_SERVICES_FEE_BASIS = "Invalid other services fee basis.";

	public final static String INVALID_OTHER_SERVICES_FEE_COST_SHARING_METHOD =
			"Invalid other services fee cost sharing method.";

	public final static String INVALID_INCENTIVE_FEE_COST_SHARING_METHOD = "Invalid incentive fee cost sharing method.";

	public final static String INVALID_OTHER_SERVICES_FEE_METHOD = "Invalid other services fee method.";

	public final static String INVALID_OTHER_SERVICES_CLAIM_TYPE = "Invalid other services fee claim type.";

	public final static String INVALID_OTHER_SERVICES_FEE_MIN = "Other Services fee minimum must be greater than 0.";

	public final static String INVALID_OTHER_SERVICES_FEE_MAX = "Other Services fee maximum must be greater than 0.";

	public final static String OTHER_SERVICES_FEE_MIN_GREATER_THAN_MAX =
			"Other Services fee min must be less than Other Services fee max.";

	// Validation messages for program admin fee
	public final static String EMPTY_PROGRAM_ADMIN_FEE = "Missing program admin fee.";

	public final static String INVALID_PROGRAM_ADMIN_FEE = "Invalid program admin fee, must be zero or greater";

	public final static String EMPTY_PROGRAM_ADMIN_FEE_UC_MINIMUM = "Missing program admin fee U&C minimum.";

	public final static String INVALID_PROGRAM_ADMIN_FEE_UC_MINIMUM =
			"Invalid program admin fee U&C minimum, must be zero or greater.";

	public final static String EMPTY_PROGRAM_ADMIN_FEE_UC_OFFSET_METHOD = "Missing program admin fee U&C admin method.";

	public final static String INVALID_PROGRAM_ADMIN_FEE_UC_OFFSET_METHOD =
			"Invalid program admin fee U&C admin method.";

	public final static String EMPTY_PROGRAM_ADMIN_FEE_CLAIM_RESP_FIELD =
			"Empty program admin fee claim response field.";

	public final static String INVALID_PROGRAM_ADMIN_FEE_CLAIM_RESP_FIELD =
			"Invalid program admin fee claim response field.";

	public final static String EMPTY_PROGRAM_ADMIN_FEE_OFFSET_DOLLAR = "Empty program admin fee dollar offset amount.";

	public final static String INVALID_PROGRAM_ADMIN_FEE_OFFSET_DOLLAR =
			"Invalid program admin fee dollar offset amount, must be zero or greater.";

	public final static String EMPTY_PROGRAM_ADMIN_FEE_OFFSET_PERCENT =
			"Empty program admin fee percent offset amount.";

	public final static String INVALID_PROGRAM_ADMIN_FEE_OFFSET_PERCENT =
			"Invalid program admin fee percent offset amount, must be between zero and one hundred, inclusive.";

	public final static String INVALID_PROGRAM_ADMIN_FEE_MIN_OFFSET_PERCENT =
			"Invalid program admin fee minimum dollar offset for percent calculation, must be zero or greater.";

	public final static String INVALID_PROGRAM_ADMIN_FEE_MAX_OFFSET_PERCENT =
			"Invalid program admin fee maximum dollar offset for percent calculation, must be zero or greater.";

	public final static String INVALID_PROGRAM_ADMIN_FEE_MIN_MAX_OFFSET_PERCENT =
			"Invalid program admin fee min and max dollar offsets for percent calculation, max must be equal to or greater than min.";

	public final static String INVALID_MIN_MAX_OFFSET_PERCENT_PAF =
			"Value cannot be greater than the set program admin fee.";

	// Validation messages for ingredient cost
	public final static String CLAIM_SUBMISSION_METHOD_CANNOT_BE_EMPTY =
			"Claim submission methods cannot be null or empty.";

	public final static String INVALID_CLAIM_TYPE = "Invalid claim type";

	public final static String DAY_SUPPLY_RANGES_CANNOT_BE_EMPTY = "Day supply ranges cannot be null or empty.";

	public final static String INVALID_RANGE_START = "Invalid range start";

	public final static String INVALID_RANGE_END = "Invalid range end";

	public final static String INVALID_RANGE_LIMIT_REACHED = "Invalid range limit reached";

	public final static String INVALID_RANGE_START_DECIMALS_ALLOWED = "Invalid range start decimals allowed";

	public final static String INVALID_RANGE_END_DECIMALS_ALLOWED = "Invalid range end decimals allowed";

	public final static String INVALID_RANGE = "Range end cannot be less that range start.";

	public final static String INVALID_RANGE_NULL = "Range end or range start cannot be null";

	public final static String INVALID_RANGE_LIMITS_EQUALS = "Range start and range end cannot be equal";

	public final static String INVALID_RANGE_SEQUENCE = "Invalid Range sequence, ranges must be consecutive";

	public final static String BRAND_CLASSES_CANNOT_BE_EMPTY = "Brand classes cannot be null or empty.";

	public final static String INVALID_COST_OPTION_SUBSET = "Invalid cost option subset.";

	public final static String BRAND_CLASS_TYPE_CANNOT_BE_NULL = "Brand class type cannot be null or empty.";

	public final static String SUBSETS_CANNOT_BE_EMPTY = "Subsets cannot be null or empty.";

	public final static String INVALID_COST_OPTION_RATE_RULE = "Invalid cost option rate rule.";

	public final static String RATE_RULE_CANNOT_BE_EMPTY = "Rate rules cannot be null or empty.";

	public final static String INVALID_APPLICABLE_CLAIM_TYPE = "Invalid applicable claim type.";

	public final static String BASIS_OF_COST_CANNOT_BE_NULL = "Basis of cost type cannot be null.";

	public final static String MIN_ADJ_CANNOT_BE_GREATER_THAN_MAX_ADJ =
			"Min adjustment cannot be greater than max adjustment.";

	public final static String INVALID_FLAT_OPERATOR = "Invalid flat Operator.";

	public final static String INVALID_PERCENT_OPERATOR = "Invalid percent operator.";

	public final static String INVALID_CALCULATION_TYPE = "Invalid calculation type.";

	public final static String EMPTY_CALCULATION_TYPE = "Calculation Type field is missing.";

	// validation messages for DAW

	public final static String PRODUCT_SELECTION_CODE_NOT_SPECIFIED = "Production selection Codes not specified.";

	// validation messages for refill too soon

	public final static String INVALID_LOOKBACK_START = "Invalid loopback period start";

	public final static String INVALID_LOOKBACK_END = "Invalid loopback period end";

	public final static String INVALID_LOOKBACK_PERIOD_RANGE = "Loopback start must be less that loopback end";

	public final static String INVALID_RANGE_SIZE = "Invalid request, at least one rage is required";

	public final static String INVALID_ACTION_REQUIRED = "Invalid action required";

	public final static String INVALID_MINIMUM_TYPE = "Invalid minimum type";

	public final static String INVALID_FROM_DAY = "Invalid fromDay field, it should be inside the rage [1, 999]";

	public final static String INVALID_TO_DAY = "Invalid toDay field, it should be inside the rage [1, 999]";

	public final static String INVALID_DAY_RANGE = "Invalid range, toDay should be greater than or equal to fromDay";

	public final static String INVALID_NULL_MINIMUM_DAYS_USED = "Minimum days used is required";

	public final static String INVALID_NULL_PERCENT_DAYS_USED = "Minimum percent days used is required";

	public final static String INVALID_PERCENT_DAYS_USED =
			"Invalid minimum percent days used, value should be in the range ]0,100]";

	public final static String INVALID_DAYS_USED = "Minimum days used cannot exceed toDay";

	// validation messages for copay coinsurance

	public final static String INVALID_COST_SHARE_TYPE = "Invalid cost share type.";

	public final static String INVALID_BASIS_OF_CALCULATION = "Invalid basis of calculation type.";

	public final static String INVALID_SHARING_BASIS = "Invalid sharing basis.";

	public final static String ACCUMULATIONS_CANNOT_BE_NULL_OR_EMPTY = "Accumulations cannot be null or empty.";

	public final static String INVALID_NETWORK_TYPE = "Invalid network type.";

	public final static String INVALID_PROCESS_METHOD = "Invalid process method.";

	public final static String INVALID_NETWORK_CLASSIFICATION = "Invalid network classification";

	public final static String INVALID_ACCUMULATION_METHOD = "Invalid accumulation method.";

	public final static String BASIS_OF_COST_NOT_REQUIRED = "Basis of cost is not required.";

	public final static String FLAT_AMOUNT_NOT_REQUIRED = "Flat Amount is not required.";

	public final static String FLAT_OPERATOR_NOT_REQUIRED = "Flat operator is not required.";

	public final static String APPLICABLE_CLAIM_TYPE_NOT_REQUIRED = "Applicable claim type is not required.";

	public final static String INVALID_ACCUMULATION_PERIOD_TYPE = "Invalid accumulation period type.";

	public final static String INVALID_TIERED_FILLS_PERIOD_TYPE = "Invalid tiered fills period type.";

	public final static String INVALID_RATE_RULE_MIN_ADJUSTMENT =
			"Invalid mininum amount; Value must be greater than or equal to 0.";

	public final static String INVALID_RATE_RULE_MAX_ADJUSTMENT =
			"Invalid maximum amount; Value must be greater than 0.";

	public final static String INVALID_EITHER_FIELDS = "Non fields are required";

	// validation messages for Dispensing fee

	public final static String STATES_CANNOT_BE_EMPTY = "States cannot be null or empty.";

	public final static String INVALID_STATE_NAME = "Invalid state name.";

	public final static String INVALID_SUBSET_NAME = "Invalid subset name.";

	public final static String INVALID_BRAND_CLASS = "Invalid brand class.";

	public final static String DISPENSE_FEE_CALC_TYPE_CANNOT_BE_NULL = "Dispense fee calculation type cannot be null.";

	public final static String INVALID_DISPENSE_FEE_CALC_TYPE = "Invalid dispense fee calculation type.";

	public final static String TIERED_DAY_SUPPLY_CANNOT_BE_NULL = "Tiered day supply cannot be null.";

	public final static String FIXED_AND_MULTIPLE_DAY_SUPPLY_CANNOT_BE_NULL =
			"Fixed and multiple day supply cannot be null.";

	public final static String DAY_SUPPLY_MULTIPLE_NOT_APPLICABLE = "Day Supply Multiple is not applicable";

	public final static String DAY_SUPPLY_MULTIPLE_CANNOT_BE_NULL = "Day Supply Multiple cannot be null.";

	// validation messages for claim history
	public final static String CLAIM_HISTORY_NOT_FOUND = "No claim history found for the given search. ";

	public final static String CLAIM_HISTORY_DRUG_NOT_FOUND = "No claim history found for drug with transaction id: ";

	public final static String CLAIM_HISTORY_SUMMARY_NOT_FOUND = "No claim history summary found with transaction id: ";

	public final static String CLAIM_HISTORY_FINANCIAL_NOT_FOUND =
			"No claim history found for financial with transaction id: ";

	public final static String CLAIM_HISTORY_MEMBER_NOT_FOUND =
			"No claim history found for member with transaction id: ";

	public final static String CLAIM_HISTORY_CLAIM_NOT_FOUND = "No claim history found for claim with transaction id: ";

	public final static String CLAIM_HISTORY_TRANSACTION_DATA_NOT_FOUND =
			"No claim history found for transaction data with transaction id: ";

	public final static String CLAIM_HISTORY_PRESCRIBER_NOT_FOUND =
			"No claim history found for prescriber with transaction id: ";

	public final static String CLAIM_HISTORY_PROVIDER_NOT_FOUND =
			"No claim history found for provider with transaction id: ";

	// validation messages for provider

	public final static String NO_PROVIDER_EXISTS = "No provider exists.";

	public final static String INVALID_LANGUAGE_CODE_1 = "Invalid language code 1";

	public final static String INVALID_LANGUAGE_CODE_2 = "Invalid language code 2";

	public final static String INVALID_LANGUAGE_CODE_3 = "Invalid language code 3";

	public final static String INVALID_LANGUAGE_CODE_4 = "Invalid language code 4";

	public final static String INVALID_LANGUAGE_CODE_5 = "Invalid language code 5";

	public static final String INVALID_ZIP_CODE = "Invalid zip code";

	public final static String INVALID_ACCEPTS_E_PRESCRIPTION_CODE = "Invalid accepts e presciption code";

	public final static String INVALID_CLOSED_DOOR_FACILITY = "Invalid closed door facility";

	public final static String INVALID_COMPOUNDING_SERVICE_CODE = "Invalid compounding service code";

	public final static String INVALID_DELIVERY_SERVICE_CODE = "Invalid delivery service code";

	public final static String INVALID_DRIVE_UP_WINDOW_CODE = "Invalid drive up window code";

	public final static String INVALID_DURABLE_MEDICAL_EQUIPMENT = "Invalid durable medical equipment";

	public final static String INVALID_HANDICAPPED_ACCESSIBLE_CODE = "Invalid handicapped accessible code";

	public final static String INVALID_IMMUNIZATIONS_PROVIDED_CODE = "Invalid immunizations provided code";

	public final static String INVALID_MULTIDOSE_COMPLIANCE_PACKAGING_CODE =
			"Invalid multidose compliance packaging code";

	public final static String INVALID_THREE_FORTY_B_STATUS_CODE = "Invalid 340b status code";

	public final static String INVALID_TWENTY_FOUR_HOUR_EMERGENCY_CODE = "Invalid 24 hour emergency code";

	public final static String INVALID_WALKIN_CLINIC_CODE = "Invalid walkin clinical code";

	public final static String INVALID_EPRESCIBING_NETWORK_IDENTIFIER = "Invalid ePrescibing Network Identifier";

	public final static String INVALID_EPRESCIBING_SERVICE_LEVEL_CODE = "Invalid ePrescibing Service Level Code";

	public final static String PROCESSOR_PROVIDER_ID_ALREADY_EXISTS = "Entered ID is not unique ";

	public final static String PROCESSOR_PROVIDER_ID_DOESNT_EXIST = "Processor provider id doesn't exist ";

	public final static String INVALID_DISPENSER_CLASS_CODE = "Invalid Dispenser class code";

	public final static String INVALID_PRIMARY_PROVIDER_TYPE = "Invalid primary provider type";

	public final static String INVALID_SECONDARY_PROVIDER_TYPE = "Invalid secondary provider type";

	public final static String INVALID_TERTIARY_PROVIDER_TYPE = "Invalid tertiary provider type";

	public final static String INVALID_DEACTIVATION_CODE = "Invalid deactivation code";

	public final static String INVALID_REINSTATEMENT_CODE = "Invalid reinstatement code";

	public final static String INVALID_PROVIDER = "Provider is not effective.";

	public final static String INVALID_FOR_ANY_WILLING_PROVIDERS = "Providers are not allowed.";

	public final static String INVALID_PROVIDER_ALIAS = "Provider alias is not effective.";

	public final static String PROVIDER_PRIMARY_ID_CANNOT_BE_NULL =
			"Provider primary id cannot be null when updating the request";

	public final static String NO_PROVIDER_ALIAS_EXISTS = "No provider alias exists.";

	public final static String INVALID_PROVIDER_GROUP = "Provider group is not effective.";

	public final static String NO_PROVIDER_GROUP_EXISTS = "No provider group exists.";

	public final static String PROVIDER_GROUP_ALREADY_EXISTS_WITH_ID = "Entered provider group id is not unique ";

	public final static String PROVIDER_GROUP_ALREADY_EXISTS_WITH_NAME = "Entered provider group name is not unique ";

	public final static String PROVIDER_GROUP_TYPE_CANNOT_BE_NULL = "Provider group type cannot be null.";

	public final static String PROVIDER_GROUP_NPI_CANNOT_BE_NULL = "Provider group NPI cannot be null.";

	public final static String PROVIDER_GROUP_FEDERAL_TAX_ID_CANNOT_BE_NULL =
			"Provider group federal tax id cannot be null. ";

	public final static String PROVIDER_GROUP_RELATIONSHIP_ID_CANNOT_BE_NULL =
			"Provider group relationship id cannot be null.";

	public final static String PROVIDER_GROUP_ADDRESS_LINE1_CANNOT_BE_NULL =
			"Provider group address line1 cannot be null.";

	public final static String PROVIDER_GROUP_CITY_CANNOT_BE_NULL = "Provider group city cannot be null.";

	public final static String PROVIDER_GROUP_STATE_CODE_CANNOT_BE_NULL = "Provider group state code cannot be null.";

	public final static String PROVIDER_GROUP_ZIP_CODE_CANNOT_BE_NULL = "Provider group zip code cannot be null.";

	public final static String PROVIDER_GROUP_LOCATION_CANNOT_BE_NULL = "Provider group location cannot be null.";

	public final static String PROVIDER_GRP_ID_CANNOT_BE_NULL = "Provider group (id) cannot be null.";

	public final static String PROVIDER_NETWORK_ALREADY_EXISTS_WITH_NAME =
			"Provider Network already exists with provider network name";

	public final static String PROVIDER_NETWORK_ALREADY_EXISTS_WITH_ID =
			"Provider Network already exists with provider network id";

	public final static String PROVIDER_NETWORK_CONFIG_DOESNOT_EXISTS = "No Provider Network Config exists with id";

	public final static String INVALID_PROVIDER_NETWORK_JSON = "Invalid provider network json structure";

	public final static String INVALID_EDIT = "Invalid edit";

	public final static String INVALID_PLAN_ID = "Plan id does not exist";

	public final static String INVALID_PROVIDER_NETWORK = "Invalid providerNetwork";

	public final static String INVALID_USER = "Invalid user.";

	public final static String INVALID_PHONE_TYPE_CODE_ID = "Invalid phoneTypeCodeId";

	public final static String INVALID_ACCESS_GROUP_ID = "Invalid access group id";

	public final static String THE_USER_IS_ALREADY_REGISTERED = "THE_USER_IS_ALREADY_REGISTERED";

	public static final String USER_REQUEST = "UserRequest";

	// validation messages for criteria
	public final static String INVALID_CRITERIA = "Criteria is not effective. ";

	public final static String CRITERIA_NAME_ALREADY_EXISTS = "Entered name is not unique ";

	public final static String INVALID_CRITERIA_STATUS = "Cannot create criteria with status: ";

	public final static String INVALID_SINGLE_DOMAIN_COUNT = "The number of domains must be equal to one";

	public final static String INVALID_DOMAIN_COUNT = "The number of domains must not be empty";

	public final static String INVALID_CRITERIA_ID = "Invalid criteria id";

	public final static String INVALID_FORMAT_ID = "Invalid format id";

	public final static String INVALID_EMBEDDED_CRITERIA_ID = "Invalid embedded criteria id";

	public final static String INVALID_EMBEDDED_CRITERIA_DOMAINS =
			"Embedded Criteria must contain a domain from criteria being created";

	public final static String CRITERIA_NOT_EMBEDDABLE = "Criteria not embeddable";

	public final static String CRITERIA_IS_ALREADY_EMBEDDED = "Criteria is already embedded";

	public final static String INVALID_DOMAIN = "Invalid domain";

	public final static String CONDITION_LIST_SIZE_MUST_BE_ONE = "a condition list size must equal to one";

	public final static String STATUS_MUST_BE_ACTIVE = "STATUS_MUST_BE_ACTIVE";

	// validation for BAG update
	public final static String UPDATE_BAG_REQUEST_CANNOT_BE_NULL = "updateBenefitAssignmentGroupRequest cannot be null";

	public final static String CANNOT_DELETE_BAG = "Cannot delete a Benefit Assignment Group using this endpoint.";

	public final static String EFFECTIVE_START_DATE_CANNOT_BE_NULL = "effectiveStartDate cannot be null";

	public final static String EFFECTIVE_END_DATE_CANNOT_BE_NULL = "effectiveEndDate cannot be null";

	public final static String ERROR_DESERIALIZING_RULE_PRIORITY_JSON = "Error deserializing rulePriorty JSON";

	public final static String CANNOT_ACTIVATE_BAG_WITH_NO_RULES =
			"Cannot activate a Benefit Assignment Group with no rules added to it";

	// validation for BAG creation

	public final static String CREATE_BAG_REQUEST_CANNOT_BE_NULL = "createBenefitAssignmentGroupRequest cannot be null";

	public final static String INVALID_STATUS_FOR_CREATE_BAG = "Benefit Assignment Group cannot be created for status";

	public final static String INVALID_RULE_HIERARCHY_ID = "Invalid ruleHierarchyId";

	public final static String INVALID_RULE_TYPE = "Invalid ruleType";

	public final static String INVALID_RULE_TYPE_FOR_RULE_HIERARCHY_ID = "Invalid ruleType for ruleHierarchyId";

	public final static String PLAN_ID_CANNOT_BE_NULL_FOR_RULE_HIERARCHY_ID =
			"planId cannot be null for ruleHierarchyId";

	// validation for Rule update

	public final static String UPDATE_RULE_REQUEST_CANNOT_BE_NULL = "updateRuleRequest cannot be null";

	public final static String CANNOT_DELETE_RULE = "Cannot delete a Rule using this endpoint.";

	public final static String RULE_ID_CANNOT_BE_NULL = "ruleId cannot be null";

	public final static String INLINE_CRITERIA_CANNOT_BE_NULL = "inlineCriteria cannot be null";

	public final static String RULE_NAME_CANNOT_BE_NULL_EMPTY = "ruleName cannot be null/empty";

	public final static String CRITERIA_ROW_ID_CANNOT_BE_NULL =
			"criteriaRowId cannot be null if supplying a criteriaId";

	public final static String RULE_NAME_ALREADY_EXISTS = "Rule name already exists.";

	public final static String CRITERIA_REQUIRED_FOR_RULE_ACTIVATION = "Criteria required for rule activation.";

	public final static String CANNOT_CHANGE_TYPE_FOR_THIS_RULE = "Cannot update type for this rule";

	// validation for Rule creation

	public final static String CANNOT_CREATE_RULE_FOR_STATUS = "New rule cannot be created for status";

	public final static String CANNOT_SPECIFY_CRITERIA_ID_AND_INLINE_CRITERIA =
			"Cannot specify both an existing criteriaId and inline criteria";

	public final static String CRITERIA_ATTRIBUTE_ID_CANNOT_BE_NULL =
			"criteria.attributeId cannot be null if specifying an inline criteria";

	public final static String CRITERIA_VALUE_CANNOT_BE_NULL =
			"criteria.attributeValue cannot be null if specifying an inline criteria";

	public final static String PARENT_CRITERIA_MUST_BE_NULL_FOR_PLAN_RULE_HIERARCHY_LEVEL =
			"parentCritieria must be null for Plan Hierarchy Level";

	public final static String CANNOT_CREATE_ADDITIONAL_RULE_FOR_RULE_HIERARCHY_LEVEL =
			"Cannot create additional rules for Benefit Assignment Group Hierarchy Level";

	public final static String INVALID_METDATA_IDS = "Metadata IDs not found in the system";

	public final static String CANNOT_CREATE_BENEFIT_COVERAGE_RULE_WITHOUT_METADATA =
			"Cannot create benefit coverage rules without metadata";

	public final static String NO_RULE_TYPE_DEFINED = "No rule type defined";

	public final static String BENEFIT_COVERAGE_RULE_WRONG_METADATA_CATEGORY =
			"Wrong metadata category for Benefit Coverage rules";

	public final static String CANNOT_CREATE_POS_REBATES_RULE_WITHOUT_METADATA =
			"Cannot create POS rebates rules without metadata";

	public final static String POS_REBATES_RULE_WRONG_METADATA_CATEGORY =
			"Wrong metadata category for POS rebates rules";

	public final static String CANNOT_CREATE_PREFERRED_DRUG_RULE_WITHOUT_METADATA =
			"Cannot create Preferred Drug rules without metadata";

	public final static String PREFERRED_DRUG_TIERS_RULE_WRONG_METADATA_CATEGORY =
			"Wrong metadata category for preferred drug tiers rules";

	public final static String CANNOT_CREATE_FORMULARY_RULE_WITHOUT_METADATA =
			"Cannot create Formulary rules without metadata";

	public final static String FORMULARY_RULE_WRONG_METADATA_CATEGORY = "Wrong metadata category for Formulary rules";

	// Prior Authorization
	public final static String PRIOR_AUTHORIZATION_RULE_WRONG_METADATA_CATEGORY =
			"Wrong metadata category for Prior Authorization rules";

	public final static String CANNOT_CREATE_PRIOR_AUTHORIZATION_RULE_WITHOUT_METADATA =
			"Cannot create Prior Authorization rules without metadata";

	// rebate pricing code

	public final static String INVALID_REBATE_PRICING_CODE = "Rebate Pricing Code is not effective. ";

	public final static String INVALID_REBATE_PRICING_CODE_STATUS = "Cannot create a Rebate Pricing Code with status: ";

	public final static String CODE_ALREADY_EXISTS =
			"Cannot save POS Rebate with this code. Code has already been used.";

	public final static String INVALID_VALUE_NOT_IN_BETWEEN_1_AND_9999 =
			"Invalid value, minimum value is 1, maximum value is 9999";

	public static final String MAX_DAYS_FROM_INITIAL_RX = "maxDaysFromInitialRx";

	public static final String MAX_REFILLS = "maxRefills";

	public static final String MAX_DAYS_OF_THERAPY = "maxDaysOfTherapy";

	public static final String MAX_DAYS_OF_INITIAL_THERAPY = "maxDaysOfInitialTherapy";

	// Deductible Edit
	public final static String INVALID_DEDUCTIBLE_PERIOD_TYPE = "Invalid deductible period type.";

	public final static String INVALID_DEDUCTIBLE_METHOD_TYPE = "Invalid deductible method.";

	public final static String INVALID_DEDUCTIBLE_PROCESSING_TYPE = "Invalid deductible processing type.";

	public static final String LOOK_BACK_PERIOD = "lookBackPeriod";

	public final static String DRUG_LOOKUP_TOOL_SEARCH_NOT_FOUND = "Cannot find Drug Lookup Tool search data.";

	public final static String DRUG_DETAILS_LOOKUP_TOOL_SEARCH_NOT_FOUND =
			"No drug details found for the given search.";

	public final static String MEMBER_INFO_MIDDLE_INITIAL_EXCEEDED_LENGTH =
			"Member info middle initial can contain only one character initial.";

	public final static String MEMBER_INFO_SUFFIX_EXCEEDED_LENGHT =
			"Member Info Suffic Cannot Exceed One Character Limit";

	// Max Accumulation Edits
	public final static String INVALID_ACCUMULATION_METHOD_TYPE = "Invalid accumulation method type.";

	// Below are the keys declared in the message.properties
	public final static String MISSING_REQUIRED_FIELD = "MISSING_REQUIRED_FIELD";

	// Field [{0}] has an invalid selection: [{1}]
	public final static String INVALID_SELECTION = "INVALID_SELECTION";

	// Field [{0}] has more than {1} decimal points
	public final static String TOO_MANY_DECIMAL_POINTS = "TOO_MANY_DECIMAL_POINTS";

	// Field [{0}] should be in range ({1},{2}]
	public final static String INVALID_MIN_EXCLUSIVE_AND_MAX_INCLUSIVE_RANGE =
			"INVALID_MIN_EXCLUSIVE_AND_MAX_INCLUSIVE_RANGE";

	// Field [{0}] should be in range ({1},{2})
	public final static String INVALID_MIN_EXCLUSIVE_AND_MAX_EXCLUSIVE_RANGE =
			"INVALID_MIN_EXCLUSIVE_AND_MAX_EXCLUSIVE_RANGE";

	// Field [{0}] should be in range [{1},{2}]
	public final static String INVALID_MIN_INCLUSIVE_AND_MAX_INCLUSIVE_RANGE =
			"INVALID_MIN_INCLUSIVE_AND_MAX_INCLUSIVE_RANGE";

	// Field [{0}] should be in range [{1},{2})
	public final static String INVALID_MIN_INCLUSIVE_AND_MAX_EXCLUSIVE_RANGE =
			"INVALID_MIN_INCLUSIVE_AND_MAX_EXCLUSIVE_RANGE";

	// # Expecting a < b
	// INVALID_LESS_THAN=Field [{0}] should be less than field [{1}]
	public final static String INVALID_LESS_THAN = "INVALID_LESS_THAN";

	// # Expecting a <= b
	// INVALID_NOT_LARGER_THAN=Field [{0}] should not be larger than [{1}]
	public final static String INVALID_NOT_LARGER_THAN = "INVALID_NOT_LARGER_THAN";

	// # Expecting a > b
	// INVALID_LARGER_THAN=Field [{0}] should be larger than field [{1}]
	public final static String INVALID_LARGER_THAN = "INVALID_LARGER_THAN";

	// # Expecting a>= b
	// INVALID_NOT_LESS_THAN=Field [{0}] should not be less than [{1}]
	public final static String INVALID_NOT_LESS_THAN = "INVALID_NOT_LESS_THAN";

	// INVALID_DATE=Field [{0}] is not a valid date of format {1}
	public final static String INVALID_DATE = "INVALID_DATE";

	// # Expecting two fields with different values
	// DUPLICATE_VALUES=Field [{0}] should not have the same value as field [{1}]
	public final static String DUPLICATE_VALUES = "DUPLICATE_VALUES";

	// # Expecting at least one product selection code is selected for DAW edit

	public final static String MISSING_PRODUCT_SELECTION_CODE = "MISSING_PRODUCT_SELECTION_CODE";

	// Fieldvalue > 3
	public final static String TOO_MANY_STRING_LENGTH = "TOO_MANY_STRING_LENGTH";

	// # Expecting at least one step Therapy step for StepTherapy edit

	public final static String MISSING_THERAPY_STEP = "MISSING_THERAPY_STEP";

	public final static String THERAPY_STEPS_MUST_BE_FILLED = "THERAPY_STEPS_MUST_BE_FILLED";

	public final static String MANDATORY_THERAPY_STEPS_MUST_BE_FILLED = "MANDATORY_THERAPY_STEPS_MUST_BE_FILLED";

	public final static String MISSING_REQUIRED_FIELD_FEE_MIN = "Field Fee Min is required field";

	public final static String MISSING_REQUIRED_FIELD_FEE_MAX = "Field Fee Max is required field";

	public final static String MISSING_BCA_ID = "Bca_id should not be null";

	public final static String INVALID_BCA = "This is not an active bca.";

	public final static String INVALID_DEDUCTIBLE_MEMBER =
			"Member deductible must be greater than 0 and less than 10 digits";

	public final static String INVALID_DEDUCTIBLE_FAMILY =
			"Family deductible must be greater than 0 and less than 10 digits";

	public final static String INVALID_DEDUCTIBLE_MEMBER_DECIMAL =
			"Member deductible decimal must be less than 3 digits";

	public final static String INVALID_DEDUCTIBLE_FAMILY_DECIMAL =
			"Family deductible decimal must be less than 3 digits";

	public final static String INVALID_DEDUCTIBLE_MEMBER_TO_MEET = "Member to meet deductible must be greater than 0";

	public final static String INVALID_DEDUCTIBLE_DURATION_IN_MONTHS =
			"Duration in months must be greater than 0 and less than 4 digits";

	public final static String INVALID_DEDUCTIBLE_PRIOR_ROLL_OVER_MONTHS =
			"Prior roll over months must be greater than 0 and less than 3 digits";

	public final static String INVALID_DEDUCTIBLE_CURRENT_ROLL_OVER_MONTHS =
			"Current roll over must be greater than 0 and less than 3 digits";

}
