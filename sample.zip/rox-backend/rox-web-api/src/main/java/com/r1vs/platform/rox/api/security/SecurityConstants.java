package com.r1vs.platform.rox.api.security;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import java.util.Arrays;
import java.util.Set;
import java.util.stream.Collectors;

public final class SecurityConstants {

	public static final String SECRET = "SecretKeyToGenJWTs";

	// public static final long AUTH_TOKEN_EXPIRATION_TIME = 900_000; // 15 minutes

	// public static final long REFRESH_TOKEN_EXPIRATION_TIME = 28_800_000; // 8
	// hours

	public static final String TOKEN_PREFIX = "Bearer ";

	public static final String AUTH_STRING = "Authorization";

	public static final String REFRESH_STRING = "Refresh_token";

	static final String[] AUTH_WHITELIST = { "/v2/api-docs", "/swagger-resources", "/swagger-resources/**",
			"/configuration/ui", "/configuration/security", "/swagger-ui.html", "/webjars/**",
			"/users/confirm-registration/*", "/users/save-password", "/healthcheck", "/v1/pricing",
			"/v1/token/refresh", "/users/forgot-password","/login/*", "/logout/*" };

	public static final String MATCHES_ALL = "/**";

	//Roles
	public static final String CLIENT_ADMIN = "CLIENT_ADMIN";

	// Privileges
	public static final String MANAGE_CLIENT = "MANAGE_CLIENT";

	public static final String MANAGE_CLIENT_USER = "MANAGE_CLIENT_USER";

    public static final String MANAGE_USER = "MANAGE_USER";

	public static final String MANAGE_ROLE = "MANAGE_ROLE";

    public static final String MANAGE_PRIVILEGES = "MANAGE_PRIVILEGES";

	public static final String ADMIN = "ADMIN";

	// APPLICATION

	public static final String APPLICATION_ALL_ACCESS = "APPLICATION_DATA_ACCESS_*";

	public static final String APPLICATION_LIST_ACCESS = "APPLICATION_DATA_ACCESS_LIST";

	public static final String APPLICATION_GET_ACCESS = "APPLICATION_DATA_ACCESS_GET";

	public static final GrantedAuthority APPLICATION_ALL_AUTHORITY = new SimpleGrantedAuthority(APPLICATION_ALL_ACCESS);

	public static final GrantedAuthority APPLICATION_LIST_AUTHORITY =
			new SimpleGrantedAuthority(APPLICATION_LIST_ACCESS);

	public static final GrantedAuthority APPLICATION_GET_AUTHORITY = new SimpleGrantedAuthority(APPLICATION_GET_ACCESS);

	// Any of authorities below will allow user to view PHI
	public static final Set<GrantedAuthority> APPLICATION_VIEW_AUTHORITIES =
			Arrays.asList(APPLICATION_ALL_AUTHORITY, APPLICATION_LIST_AUTHORITY, APPLICATION_GET_AUTHORITY).stream()
					.collect(Collectors.toSet());

}
