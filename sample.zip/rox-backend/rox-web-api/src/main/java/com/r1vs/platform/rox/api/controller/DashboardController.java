package com.r1vs.platform.rox.api.controller;

import com.r1vs.platform.rox.api.service.DashboardService;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

import static com.r1vs.platform.rox.api.constants.ControllerConstants.X_PAGINATION_LIMIT;
import static com.r1vs.platform.rox.api.constants.ControllerConstants.X_PAGINATION_NUM;
import static com.r1vs.platform.rox.api.util.InterceptorConstants.CLIENT_ID;

@RestController
@RequestMapping(value = "/v1")
public class DashboardController {

	@Autowired
	private DashboardService dashboardService;

	@GetMapping("/dashboard/portFolioGrowth")
	@Operation(summary = "Get dashboard data for port folio growth section")
	public ResponseEntity<Map<String, Object>> getDashboardPortFolioGrowth(@RequestHeader(CLIENT_ID) String clientId) {

		return new ResponseEntity<>(dashboardService.getPortFolioGrowth(clientId), HttpStatus.OK);
	}

	@GetMapping("/dashboard/overview")
	@Operation(summary = "Get dashboard data for overview section")
	public ResponseEntity<Map<String, Object>> getDashboardOverview(@RequestHeader(CLIENT_ID) String clientId) {

		return new ResponseEntity<>(dashboardService.getDashboardOverview(clientId), HttpStatus.OK);
	}

	@GetMapping("/dashboard/applications")
	@Operation(summary = "Get dashboard data for applications section")
	public ResponseEntity<Map<String, Object>> getDashboardApplications(@RequestHeader(CLIENT_ID) String clientId) {

		return new ResponseEntity<>(dashboardService.getDashboardApplications(clientId), HttpStatus.OK);
	}

	@GetMapping("/dashboard/rox/portFolioGrowth")
	@Operation(summary = "Get dashboard data for port folio growth section")
	public ResponseEntity<Map<String, Object>> getAdminDashboardPortFolioGrowth() {

		return new ResponseEntity<>(dashboardService.getAdminPortFolioGrowth(), HttpStatus.OK);
	}

	@GetMapping("/dashboard/rox/overview")
	@Operation(summary = "Get dashboard data for overview section")
	public ResponseEntity<Map<String, Object>> getAdminDashboardOverview() {

		return new ResponseEntity<>(dashboardService.getAdminDashboardOverview(), HttpStatus.OK);
	}

	@GetMapping("/dashboard/rox/applications")
	@Operation(summary = "Get dashboard data for applications section")
	public ResponseEntity<Map<String, Object>> getAdminDashboardApplications(@RequestHeader(CLIENT_ID) String clientId) {

		return new ResponseEntity<>(dashboardService.getAdminDashboardApplications(), HttpStatus.OK);
	}
}
