package com.r1vs.platform.rox.common.model.membervalidation;

import com.r1vs.platform.rox.common.model.BitemporalEntity;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "group_member_validation_set")
public class GroupMemberValidationSet extends BitemporalEntity implements Serializable {

	private static final long serialVersionUID = -4011747758139863749L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "group_member_validation_set_id", nullable = false)
	private Long groupMemberValidationSetId;

	@Column(name = "group_id")
	@NotNull
	private Integer groupId;

	@Column(name = "member_validation_set_id")
	@NotNull
	private Integer memberValidationSetId;

	public Long getGroupMemberValidationSetId() {

		return groupMemberValidationSetId;
	}

	public void setGroupMemberValidationSetId(final Long groupMemberValidationSetId) {

		this.groupMemberValidationSetId = groupMemberValidationSetId;
	}

	public Integer getGroupId() {

		return groupId;
	}

	public void setGroupId(final Integer groupId) {

		this.groupId = groupId;
	}

	public Integer getMemberValidationSetId() {

		return memberValidationSetId;
	}

	public void setMemberValidationSetId(final Integer memberValidationSetId) {

		this.memberValidationSetId = memberValidationSetId;
	}

	@Override
	public boolean equals(final Object other) {

		if (!(other instanceof GroupMemberValidationSet)) {
			return false;
		}
		final GroupMemberValidationSet castOther = (GroupMemberValidationSet) other;
		return new EqualsBuilder().append(groupMemberValidationSetId, castOther.groupMemberValidationSetId)
				.append(groupId, castOther.groupId).append(memberValidationSetId, castOther.memberValidationSetId)
				.isEquals();
	}

	@Override
	public int hashCode() {

		return new HashCodeBuilder().append(groupMemberValidationSetId).append(groupId).append(memberValidationSetId)
				.toHashCode();
	}

	@Override
	public String toString() {

		return new ToStringBuilder(this).append("groupMemberValidationSetId", groupMemberValidationSetId)
				.append("groupId", groupId).append("memberValidationSetId", memberValidationSetId).toString();
	}

}
