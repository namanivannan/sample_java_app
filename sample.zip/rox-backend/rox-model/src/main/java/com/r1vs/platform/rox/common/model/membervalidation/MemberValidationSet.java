package com.r1vs.platform.rox.common.model.membervalidation;

import com.r1vs.platform.rox.common.model.BitemporalEntity;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Objects;

@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "member_validation_set")
public class MemberValidationSet extends BitemporalEntity implements Serializable {

	private static final long serialVersionUID = -8177576537486705403L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", nullable = false)
	private Long id;

	@Column(name = "member_validation_set_id", nullable = false)
	private Integer memberValidationSetId;

	@Column(name = "status_id")
	@NotNull
	private Integer statusId;

	@Column(name = "pbm_id")
	@NotNull
	private Integer pbmId;

	@Column(name = "name")
	@NotNull
	private String name;

	@Column(name = "description")
	private String description;

	@Column(name = "pbm_default")
	private Boolean pbmDefault;

	@Column(name = "enrollment_authentication_fail_action_id")
	@NotNull
	private Integer enrollmentAuthenticationFailActionId;

	@Column(name = "disable_authentication_on_enrollment_update")
	@NotNull
	private Boolean disableAuthenticationOnEnrollmentUpdate;

	@Column(name = "validation_categories_json", nullable = false)
	@NotNull
	private String validationCategoriesJson;

	public Long getId() {

		return id;
	}

	public void setId(final Long id) {

		this.id = id;
	}

	public Integer getMemberValidationSetId() {

		return memberValidationSetId;
	}

	public void setMemberValidationSetId(final Integer memberValidationSetId) {

		this.memberValidationSetId = memberValidationSetId;
	}

	public Integer getStatusId() {

		return statusId;
	}

	public void setStatusId(final Integer statusId) {

		this.statusId = statusId;
	}

	public Integer getPbmId() {

		return pbmId;
	}

	public void setPbmId(final Integer pbmId) {

		this.pbmId = pbmId;
	}

	public String getName() {

		return name;
	}

	public void setName(final String name) {

		this.name = name;
	}

	public String getDescription() {

		return description;
	}

	public void setDescription(final String description) {

		this.description = description;
	}

	public Boolean getPbmDefault() {

		return pbmDefault;
	}

	public void setPbmDefault(final Boolean pbmDefault) {

		this.pbmDefault = pbmDefault;
	}

	public Integer getEnrollmentAuthenticationFailActionId() {

		return enrollmentAuthenticationFailActionId;
	}

	public void setEnrollmentAuthenticationFailActionId(final Integer enrollmentAuthenticationFailActionId) {

		this.enrollmentAuthenticationFailActionId = enrollmentAuthenticationFailActionId;
	}

	public Boolean getDisableAuthenticationOnEnrollmentUpdate() {

		return disableAuthenticationOnEnrollmentUpdate;
	}

	public void setDisableAuthenticationOnEnrollmentUpdate(final Boolean disableAuthenticationOnEnrollmentUpdate) {

		this.disableAuthenticationOnEnrollmentUpdate = disableAuthenticationOnEnrollmentUpdate;
	}

	public String getValidationCategoriesJson() {

		return validationCategoriesJson;
	}

	public void setValidationCategoriesJson(final String validationCategoriesJson) {

		this.validationCategoriesJson = validationCategoriesJson;
	}

	@Override
	public boolean equals(final Object obj) {

		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final MemberValidationSet other = (MemberValidationSet) obj;
		return Objects.equals(description, other.description)
				&& Objects.equals(disableAuthenticationOnEnrollmentUpdate,
						other.disableAuthenticationOnEnrollmentUpdate)
				&& Objects.equals(enrollmentAuthenticationFailActionId, other.enrollmentAuthenticationFailActionId)
				&& Objects.equals(id, other.id) && Objects.equals(memberValidationSetId, other.memberValidationSetId)
				&& Objects.equals(name, other.name) && Objects.equals(pbmDefault, other.pbmDefault)
				&& Objects.equals(pbmId, other.pbmId) && Objects.equals(statusId, other.statusId)
				&& Objects.equals(validationCategoriesJson, other.validationCategoriesJson);
	}

	@Override
	public int hashCode() {

		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash(description, disableAuthenticationOnEnrollmentUpdate,
				enrollmentAuthenticationFailActionId, id, memberValidationSetId, name, pbmDefault, pbmId, statusId,
				validationCategoriesJson);
		return result;
	}

	@Override
	public String toString() {

		final ToStringBuilder builder = new ToStringBuilder(this);
		builder.append("id", id).append("memberValidationSetId", memberValidationSetId).append("statusId", statusId)
				.append("pbmId", pbmId).append("name", name).append("description", description)
				.append("pbmDefault", pbmDefault)
				.append("enrollmentAuthenticationFailActionId", enrollmentAuthenticationFailActionId)
				.append("disableAuthenticationOnEnrollmentUpdate", disableAuthenticationOnEnrollmentUpdate)
				.append("validationCategoriesJson", validationCategoriesJson);
		return builder.toString();
	}

}
