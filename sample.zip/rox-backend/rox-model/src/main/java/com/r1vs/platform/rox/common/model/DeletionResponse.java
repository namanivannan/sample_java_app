package com.r1vs.platform.rox.common.model;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * Response of table/entity deletions
 *
 */
public class DeletionResponse implements Serializable {

	private static final long serialVersionUID = 360315519624419580L;

	private long total = 0;

	private String entityName;

	public long getTotal() {

		return total;
	}

	public void setTotal(final long total) {

		this.total = total;
	}

	public String getEntityName() {

		return entityName;
	}

	public void setEntityName(final String entityName) {

		this.entityName = entityName;
	}

	@Override
	public String toString() {

		final ToStringBuilder builder = new ToStringBuilder(this);
		builder.append("total", total);
		if (entityName != null) {
			builder.append("entityName", entityName);
		}
		return builder.toString();
	}

}
