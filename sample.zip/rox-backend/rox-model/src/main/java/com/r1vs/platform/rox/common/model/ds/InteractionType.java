package com.r1vs.platform.rox.common.model.ds;

public enum InteractionType {
	FMCSA,
	UCC,
	BACKGROUND,
	CREDIT
}
