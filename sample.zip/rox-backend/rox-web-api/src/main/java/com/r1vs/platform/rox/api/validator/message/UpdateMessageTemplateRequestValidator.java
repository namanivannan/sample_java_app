package com.r1vs.platform.rox.api.validator.message;

import com.r1vs.platform.rox.api.exception.Error;
import com.r1vs.platform.rox.api.model.message.UpdateMessageTemplateRequest;
import com.r1vs.platform.rox.api.validator.RoxWriteWebApiValidator;
import org.springframework.stereotype.Component;

import static com.r1vs.platform.rox.api.util.ValidationUtil.handleException;

@Component
public class UpdateMessageTemplateRequestValidator extends MessageTemplateRequestValidator
		implements RoxWriteWebApiValidator<UpdateMessageTemplateRequest> {

	@Override
	public void validate(final UpdateMessageTemplateRequest messageTemplateRequest) {

		final Error error = new Error();
		validateMessageNameForUpdate(error, messageTemplateRequest, getClientIdForRequest());
		validateMessageType(error, messageTemplateRequest.getMessageType());
		validatePrivacyLevel(error, messageTemplateRequest.getPrivacyLevel());
		validatePrivacySetting(error, messageTemplateRequest.getPrivacySetting());
		validateStatusCode(error, messageTemplateRequest.getStatusId());
		handleException(error);
	}

}
