package com.r1vs.platform.rox.api.business;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.AuditorAware;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.util.Optional;

public class AuditorAwareImpl implements AuditorAware<Long> {

	private static final Logger LOGGER = LoggerFactory.getLogger(AuditorAwareImpl.class);

	@Override
	public Optional<Long> getCurrentAuditor() {

		final ServletRequestAttributes requestAttributes = (ServletRequestAttributes) RequestContextHolder
				.currentRequestAttributes();

		final HttpServletRequest request = requestAttributes.getRequest();

		final Long userId = (Long) request.getAttribute("userId");

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Returning userId from request as {}", userId);
		}

		return Optional.ofNullable(userId);
	}

}
