package com.r1vs.platform.rox.common.model.dp;

import java.io.Serializable;
import java.time.OffsetDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Version;

import com.r1vs.platform.rox.common.model.AuditedEntity;

@Entity
@Table(name = "dp_job_execution")
public class JobExecution extends AuditedEntity implements Serializable {

	private static final long serialVersionUID = 2628233015010123904L;

	@Id
	@Column(name = "id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Version
	private Integer version;

	@Column(name = "pbm_id")
	private Integer pbmId;

	@Column(name = "job_id", insertable = false, updatable = false)
	private Integer jobId;

	@Column(name = "run_number")
	private Integer runNumber;

	@Column(name = "input_id")
	private Integer inputId;

	@Column(name = "registration_code")
	private String registrationCode;

	@Column(name = "state", nullable = false)
	private String state;

	/**
	 * Only set to 1 when the state is in STARTING or RUNNING so only one such execution allowed per job
	 */
	@Column(name = "pending_flag", nullable = true)
	private String pendingFlag;

	@Column(name = "start_at", updatable = true)
	private OffsetDateTime startAt;

	@Column(name = "end_at", updatable = true)
	private OffsetDateTime endAt;

	@Column(name = "error_code")
	private String errorCode;

	@Column(name = "error_message")
	private String errorMessage;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "job_id")
	private Job job;

	public Integer getId() {

		return id;
	}

	public void setId(final Integer id) {

		this.id = id;
	}

	public Integer getVersion() {

		return version;
	}

	public void setVersion(final Integer version) {

		this.version = version;
	}

	public Integer getPbmId() {

		return pbmId;
	}

	public void setPbmId(final Integer pbmId) {

		this.pbmId = pbmId;
	}

	public String getRegistrationCode() {

		return registrationCode;
	}

	public void setRegistrationCode(final String registrationCode) {

		this.registrationCode = registrationCode;
	}

	public String getState() {

		return state;
	}

	public void setState(final String state) {

		this.state = state;
	}

	public OffsetDateTime getStartAt() {

		return startAt;
	}

	public void setStartAt(final OffsetDateTime startAt) {

		this.startAt = startAt;
	}

	public OffsetDateTime getEndAt() {

		return endAt;
	}

	public void setEndAt(final OffsetDateTime endAt) {

		this.endAt = endAt;
	}

	public String getErrorCode() {

		return errorCode;
	}

	public void setErrorCode(final String errorCode) {

		this.errorCode = errorCode;
	}

	public String getErrorMessage() {

		return errorMessage;
	}

	public void setErrorMessage(final String errorMessage) {

		this.errorMessage = errorMessage;
	}

	public Integer getJobId() {

		return jobId;
	}

	public void setJobId(final Integer jobId) {

		this.jobId = jobId;
	}

	public Integer getRunNumber() {

		return runNumber;
	}

	public void setRunNumber(final Integer runNumber) {

		this.runNumber = runNumber;
	}

	public Job getJob() {

		return job;
	}

	public void setJob(final Job job) {

		this.job = job;
	}

	public String getPendingFlag() {

		return pendingFlag;
	}

	public void setPendingFlag(final String pendingFlag) {

		this.pendingFlag = pendingFlag;
	}

	public Integer getInputId() {

		return inputId;
	}

	public void setInputId(final Integer inputId) {

		this.inputId = inputId;
	}

}
