package com.r1vs.platform.rox.common.util;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.apache.maven.model.Model;
import org.apache.maven.model.io.xpp3.MavenXpp3Reader;
import org.codehaus.plexus.util.xml.pull.XmlPullParserException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class VersionUtil {

	private static final Logger LOGGER = LoggerFactory.getLogger(VersionUtil.class);

	private final static String POM_FILE = "pom.xml";

	/**
	 * This method will help you get the module version number from its pom.
	 *
	 * @return moduleVersionNumber
	 *
	 */
	public static String getModuleVersionNumber() {

		final MavenXpp3Reader reader = new MavenXpp3Reader();

		Model model = null;
		try {
			model = reader.read(new FileReader(POM_FILE));
		} catch (final FileNotFoundException e) {
			LOGGER.error("File Not found: ", e.getMessage());
		} catch (final IOException e) {
			LOGGER.error("Error reading file: ", e.getMessage());
		} catch (final XmlPullParserException e) {
			LOGGER.error("Error parsing xml file: ", e.getMessage());
		}

		if (model != null) {
			return model.getVersion();
		}
		return null;

	}

	/**
	 * This method will help you get the parent pom version number.
	 *
	 * @return parentModuleVersionNumber
	 *
	 */
	public static String getParentModuleVersionNumber() {

		final MavenXpp3Reader reader = new MavenXpp3Reader();
		Model model = null;
		try {
			model = reader.read(new FileReader(POM_FILE));
		} catch (final FileNotFoundException e) {
			LOGGER.error("File Not found: ", e.getMessage());
		} catch (final IOException e) {
			LOGGER.error("Error reading file: ", e.getMessage());
		} catch (final XmlPullParserException e) {
			LOGGER.error("Error parsing xml file: ", e.getMessage());
		}

		if (model != null && model.getParent() != null) {
			return model.getParent().getVersion();
		}

		return null;
	}

}
