package com.r1vs.platform.rox.api.model.role;

public class ChangeRoleStatusRequest {

	private Integer roleId;

	private Integer statusId;

	public Integer getStatusId() {

		return statusId;
	}

	public void setStatusId(final Integer statusId) {

		this.statusId = statusId;
	}

	public Integer getRoleId() {

		return roleId;
	}

	public void setRoleId(final Integer roleId) {

		this.roleId = roleId;
	}
}
