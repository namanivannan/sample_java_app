package com.r1vs.platform.rox.api.defaultvaluesetter.metadata;

import com.r1vs.platform.rox.api.model.metadata.CreateMetadataRequest;
import com.r1vs.platform.rox.api.model.metadata.UpdateMetadataRequest;

public interface MetadataDefaultValueSetter {

	void setDefaultValues(CreateMetadataRequest createMetadataRequest);

	void setDefaultValues(UpdateMetadataRequest updateMetadataRequest);

}
