package com.r1vs.platform.rox.common.model.rule;

/**
 * This is the wrapper class to match the rule priority JSON in rule table.
 */
public class RuleWrapper {

	private Long ruleId;

	private Integer priority;

	public Long getRuleId() {

		return ruleId;
	}

	public void setRuleId(Long ruleId) {

		this.ruleId = ruleId;
	}

	public Integer getPriority() {

		return priority;
	}

	public void setPriority(Integer priority) {

		this.priority = priority;
	}

	@Override
	public String toString() {

		return "RuleWrapper [ruleId=" + ruleId + ", priority=" + priority + "]";
	}

	@Override
	public int hashCode() {

		final int prime = 31;
		int result = 1;
		result = prime * result + ((priority == null) ? 0 : priority.hashCode());
		result = prime * result + ((ruleId == null) ? 0 : ruleId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {

		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RuleWrapper other = (RuleWrapper) obj;
		if (priority == null) {
			if (other.priority != null)
				return false;
		} else if (!priority.equals(other.priority))
			return false;
		if (ruleId == null) {
			if (other.ruleId != null)
				return false;
		} else if (!ruleId.equals(other.ruleId))
			return false;
		return true;
	}

}
