package com.r1vs.platform.rox.api.util;

import com.r1vs.platform.rox.api.exception.Error;
import com.r1vs.platform.rox.api.exception.*;
import org.springframework.util.CollectionUtils;

public class ValidationUtil {

	/**
	 * Handle and throw InvalidDataException
	 *
	 * @param error error
	 */
	public static void handleException(final Error error) {

		if (!CollectionUtils.isEmpty(error.getErrorResponses())) {
			throw new InvalidDataException(error.getErrorResponses());
		}
	}

	/**
	 * Handle and throw InvalidDataException
	 *
	 * @param error error
	 */
	public static void handleException(final FormError error) {

		if (null != error.getErrorResponse()) {
			throw new InvalidFormDataException(error.getErrorResponse());
		}
	}

	/**
	 * Add error response to error list
	 *
	 * @param error error
	 * @param field field
	 * @param message message
	 * @param value value
	 */
	public static ErrorResponse addError(final Error error, final String field, final String message,
			final String value) {

		return error.addErrorResponse(new ErrorResponse(field, message, value));
	}

	/**
	 * Add error response to error list
	 *
	 * @param error error
	 * @param field field
	 * @param message message
	 * @param value value
	 */
	public static void addError(final FormError error, final Object value) {

		error.addFormErrorResponse(new FormErrorResponse(value));
	}

	/**
	 * Add the error and handle exception
	 *
	 * @param error error
	 * @param field error
	 * @param message message
	 * @param value value
	 */
	public static void addErrorAndHandle(final Error error, final String field, final String message,
			final String value) {

		addError(error, field, message, value);
		handleException(error);

	}

}
