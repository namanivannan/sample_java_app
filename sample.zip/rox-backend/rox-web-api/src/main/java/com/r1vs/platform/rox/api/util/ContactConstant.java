package com.r1vs.platform.rox.api.util;

public class ContactConstant {

	public static final String STATE = "state";

	public static final String CONTACT_TYPE = "contactType";

	public static final String CONTACT_JSON = "contactJson";

}
