package com.r1vs.platform.rox.api.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.r1vs.platform.rox.api.model.application.initiate.ApplicationDTO;
import com.r1vs.platform.rox.common.db.repository.business.ApplicationRepository;
import com.r1vs.platform.rox.common.model.business.Application;
import com.r1vs.platform.rox.common.util.StringUtil;
import org.apache.commons.io.IOUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Optional;
import java.util.ArrayList;
import java.util.UUID;

import static com.r1vs.platform.rox.api.controller.DBConnection.TEST_USER_1;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@Sql("fixture2.sql")
public class ApplicationControllerTest {

	@Autowired
	private ApplicationRepository applicationRepository;

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private DBConnection dbConnection;

	private String token;

	private String token_user_1;

	private String token_user_2;

	@Before
	public void setUp() throws Exception {

		if (StringUtil.isNullOrEmpty(token)) {
			token = dbConnection.loginToDb();
			token_user_1 = dbConnection.loginToDb(TEST_USER_1);
			token_user_2 = token;
		}
	}

	@Test
	@WithMockUser
	public void givenValidApplication_whenCreateEndpointIsHit_thenCreatesItSuccessfully() throws Exception {

		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.post("/v1/applications")
				.contentType(MediaType.APPLICATION_JSON)
				.content(getTextFileAsString("/payloads/new_application.json"))
				.header("x-client-id", "11")
				.header("Authorization", token))
				.andDo(print())
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.status", is("New")))
				.andExpect(jsonPath("$.uuid", not(emptyOrNullString())))
				.andExpect(jsonPath("$.business", notNullValue()))
				.andExpect(jsonPath("$.business.phones", hasSize(1)))
				.andExpect(jsonPath("$.business.identifications", hasSize(1)))
				.andExpect(jsonPath("$.business.addresses", hasSize(1)))
				.andExpect(jsonPath("$.business.emails", hasSize(1)))
				.andExpect(jsonPath("$.business.contractAmount", is(10000)))

				.andReturn();

		assertThat(mvcResult.getResponse().getContentAsString()).isNotBlank();
	}

	@Test
	@WithMockUser
	public void givenValidApplicationCreated_whenGetApplicationEndpointIsHit_thenItIsReturnedSuccessfully()
			throws Exception {

		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.post("/v1/applications")
				.contentType(MediaType.APPLICATION_JSON)
				.content(getTextFileAsString("/payloads/new_application.json"))
				.header("x-client-id", "11")
				.header("Authorization", token))
				.andDo(print())
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.status", is("New")))
				.andExpect(jsonPath("$.uuid", not(emptyOrNullString())))
				.andReturn();

		ApplicationDTO applicationDTO =
				objectMapper.readValue(mvcResult.getResponse().getContentAsString(), ApplicationDTO.class);
		String applicationUUID = applicationDTO.getUuid();

		MvcResult getResult = mockMvc.perform(MockMvcRequestBuilders.get("/v1/applications/" + applicationUUID)
				.header("x-client-id", "11")
				.header("Authorization", token))
				.andDo(print())
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.status", is("New")))
				.andExpect(jsonPath("$.uuid", not(emptyOrNullString())))
				.andReturn();

	}

	@Test
	public void givenAlreadyStoredApplicationWithDebtor_whenRequestingApplication_thenFieldsAreCorrectlyPopulated()
			throws Exception {

		mockMvc.perform(MockMvcRequestBuilders.get("/v1/applications/84ec6f35-f861-406c-a4ec-b9d33ccb88dc")
				.header("x-client-id", "12")
				.header("Authorization", token_user_1))
				.andDo(print())
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.status", is("Under Review")))
				.andExpect(jsonPath("$.uuid", not(emptyOrNullString())))
				.andExpect(jsonPath("$.debtor.name", endsWith("Debtor")))
				.andReturn();

	}

	@Test
	public void givenASetOfApplications_whenListApplicationsEndpointIsHit_thenListsApplicationsForThatClient()
			throws Exception {

		// given

		// when endpoint is hit as user 1
		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/v1/applications")
				.contentType(MediaType.APPLICATION_JSON)
				.header("x-client-id", "12")
				.header("Authorization", token_user_1))
				.andDo(print())
				.andExpect(status().isOk())
				.andExpect(jsonPath("$", hasSize(3)))
				.andExpect(jsonPath("$[0].status", notNullValue()))
				.andExpect(jsonPath("$[0].uuid", not(emptyOrNullString())))
				.andExpect(jsonPath("$[0].applicantName", is("Red Transportation")))
				.andReturn();

		assertThat(mvcResult.getResponse().getContentAsString()).isNotBlank();

		// when endpoint is hit as user 2
		MvcResult mvcResult2 = mockMvc.perform(MockMvcRequestBuilders.get("/v1/applications")
				.contentType(MediaType.APPLICATION_JSON)
				.header("x-client-id", "11")
				.header("Authorization", token))
				.andDo(print())
				.andExpect(status().isOk())
				.andExpect(jsonPath("$", hasSize(3)))
				.andExpect(jsonPath("$[0].status", notNullValue()))
				.andExpect(jsonPath("$[0].uuid", not(emptyOrNullString())))
				.andExpect(jsonPath("$[*].applicantName",
						containsInAnyOrder("Green Transportation", "Blue Transportation", "Brown Transportation")))
				.andReturn();

		assertThat(mvcResult2.getResponse().getContentAsString()).isNotBlank();

	}

	@Test
	public void givenASetOfApplications_whenListApplicationWithSorting_thenListIsSorted() throws Exception {

		// when endpoint is hit with created date asc
		mockMvc.perform(MockMvcRequestBuilders.get("/v1/applications")
				.contentType(MediaType.APPLICATION_JSON)
				.header("x-client-id", "12")
				.header("X-Pagination-Sort", "createdAt,asc")
				.header("Authorization", token_user_1))
				.andDo(print())
				.andExpect(status().isOk())
				.andExpect(jsonPath("$", hasSize(3)))
				.andExpect(jsonPath("$[0].status", notNullValue()))
				.andExpect(jsonPath("$[0].uuid", not(emptyOrNullString())))
				.andExpect(jsonPath("$[0].applicantName", is("Pink Transportation")))
				.andExpect(jsonPath("$[1].applicantName", is("Purple Transportation")))
				.andExpect(jsonPath("$[2].applicantName", is("Red Transportation")));

		// when endpoint is hit with created date desc
		mockMvc.perform(MockMvcRequestBuilders.get("/v1/applications")
				.contentType(MediaType.APPLICATION_JSON)
				.header("x-client-id", "12")
				.header("X-Pagination-Sort", "createdAt,desc")
				.header("Authorization", token_user_1))
				.andDo(print())
				.andExpect(status().isOk())
				.andExpect(jsonPath("$", hasSize(3)))
				.andExpect(jsonPath("$[0].status", notNullValue()))
				.andExpect(jsonPath("$[0].uuid", not(emptyOrNullString())))
				.andExpect(jsonPath("$[0].applicantName", is("Red Transportation")))
				.andExpect(jsonPath("$[1].applicantName", is("Purple Transportation")))
				.andExpect(jsonPath("$[2].applicantName", is("Pink Transportation")));
	}

	@Test
	public void
			givenASetOfApplications_whenListApplicationsEndpointIsHitWithBusinessName_thenListsApplicationsForThoseFilters()
					throws Exception {

		// when endpoint is hit as default user and business_name
		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/v1/applications")
				.queryParam("businessName", "Blue")
				.contentType(MediaType.APPLICATION_JSON)
				.header("x-client-id", "11")
				.header("Authorization", token))
				.andDo(print())
				.andExpect(status().isOk())
				.andExpect(jsonPath("$", hasSize(1)))
				.andExpect(jsonPath("$[0].status", notNullValue()))
				.andExpect(jsonPath("$[0].uuid", not(emptyOrNullString())))
				.andExpect(jsonPath("$[0].applicantName", stringContainsInOrder("Blue Transportation")))
				.andReturn();

		// when endpoint is hit as default user and business_name doesn't match
		mockMvc.perform(MockMvcRequestBuilders.get("/v1/applications")
				.queryParam("businessName", "WHITE Transport")
				.contentType(MediaType.APPLICATION_JSON)
				.header("x-client-id", "11")
				.header("Authorization", token))
				.andDo(print())
				.andExpect(status().isOk())
				.andExpect(jsonPath("$", hasSize(0)));
	}

	@Test
	public void
			givenASetOfApplications_whenListApplicationsEndpointIsHitWithCreatedDateFilter_thenListsApplicationsForThoseFilters()
					throws Exception {

		// when endpoint is hit as default user and date created
		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/v1/applications")
				.queryParam("creationDate", "2022-02-20")
				.contentType(MediaType.APPLICATION_JSON)
				.header("x-client-id", "11")
				.header("Authorization", token))
				.andDo(print())
				.andExpect(status().isOk())
				.andExpect(jsonPath("$", hasSize(2)))
				.andExpect(jsonPath("$[*].applicantName",
						containsInAnyOrder("Blue Transportation", "Brown Transportation")))
				.andExpect(header().string("X-PAGINATION-TOTAL-PAGES", is("1")))
				.andExpect(header().string("X-PAGINATION-HAS-NEXT-PAGE", is("false")))
				.andExpect(header().string("X-PAGINATION-CURRENT-PAGE-NUM", is("0")))
				.andReturn();

		// when endpoint is hit as default user and business_name doesn't match
		mockMvc.perform(MockMvcRequestBuilders.get("/v1/applications")
				.queryParam("creationDate", "2021-02-20") // last year, no matches
				.contentType(MediaType.APPLICATION_JSON)
				.header("x-client-id", "11")
				.header("Authorization", token))
				.andDo(print())
				.andExpect(status().isOk())
				.andExpect(jsonPath("$", hasSize(0)));
	}

	public String getTextFileAsString(String filePath) throws IOException {

		return IOUtils.toString(
				this.getClass().getResourceAsStream(filePath),
				"UTF-8");
	}

	@Test
	public void givenSetOfApplications_whenListApplications_thenInfoForListingIsShownCorrectly() throws Exception {

		mockMvc.perform(MockMvcRequestBuilders.get("/v1/applications")
				.contentType(MediaType.APPLICATION_JSON)
				.header("x-client-id", "11")
				.header("Authorization", token))
				.andDo(print())
				.andExpect(status().isOk())
				.andExpect(jsonPath("$", hasSize(3)))
				.andExpect(jsonPath("$[*].applicantName",
						containsInAnyOrder("Blue Transportation", "Brown Transportation", "Green Transportation")))
				.andExpect(jsonPath("$[*].createdAt", notNullValue()))
				.andExpect(jsonPath("$[*].updatedAt", notNullValue()))
				.andExpect(jsonPath("$[0].duration", isA(Number.class)))
				.andExpect(jsonPath("$[*].createdBy.id", notNullValue()))
				.andExpect(jsonPath("$[0].createdBy.name", is("RoxWrite User Client 1")))
				.andExpect(jsonPath("$[0].createdBy.firstName", is("RoxWrite")))
				.andExpect(jsonPath("$[0].createdBy.lastName", is("User Client 1")))
				.andExpect(jsonPath("$[1].createdBy.name", is("RoxWrite User Client 1")))
				.andExpect(jsonPath("$[2].createdBy.name", is("RoxWrite User Client 1")))
				.andExpect(jsonPath("$[*].updatedBy.id", notNullValue()))
				.andExpect(jsonPath("$[0].updatedBy.name", is("RoxWrite User Client 1")))
				.andExpect(jsonPath("$[1].updatedBy.name", is("RoxWrite User Client 1")))
				.andExpect(jsonPath("$[2].updatedBy.name", is("RoxWrite User Client 1")));

		Optional<Application> byUuid =
				applicationRepository.findByUuid(UUID.fromString("588d3527-0938-4ad9-839b-7a7ca4ed851d"));

		mockMvc.perform(MockMvcRequestBuilders.get("/v1/applications")
				.contentType(MediaType.APPLICATION_JSON)
				.header("x-client-id", "12")
				.header("Authorization", token_user_1))
				.andDo(print())
				.andExpect(status().isOk())
				.andExpect(jsonPath("$", hasSize(3)))
				.andExpect(jsonPath("$[*].applicantName",
						containsInAnyOrder("Red Transportation", "Pink Transportation", "Purple Transportation")))
				.andExpect(jsonPath("$[*].createdAt", notNullValue()))
				.andExpect(jsonPath("$[*].updatedAt", notNullValue()))
				.andExpect(jsonPath("$[0].duration", isA(Number.class)))
				.andExpect(jsonPath("$[*].createdBy.id", notNullValue()))
				.andExpect(jsonPath("$[0].createdBy.name", is("RoxWrite2 User Client 2")))
				.andExpect(jsonPath("$[1].createdBy.name", is("RoxWrite2 User Client 2")))
				.andExpect(jsonPath("$[2].createdBy.name", is("RoxWrite2 User Client 2")))
				.andExpect(jsonPath("$[*].updatedBy.id", notNullValue()))
				.andExpect(jsonPath("$[0].updatedBy.name", is("RoxWrite2 User Client 2")))
				.andExpect(jsonPath("$[1].updatedBy.name", is("RoxWrite2 User Client 2")))
				.andExpect(jsonPath("$[2].updatedBy.name", is("RoxWrite2 User Client 2")));
	}

	@Test
	@Transactional
	public void givenValidApplication_whenChangeStatusEndpointIsHit_thenChangesItSuccessfully() throws Exception {

		// given
		String sampleInputJson = getTextFileAsString("/payloads/new_application.json");
		ApplicationDTO input = objectMapper.readValue(sampleInputJson, ApplicationDTO.class);

		// when
		Application application = applicationRepository.getById(11L);
		String uuid = application.getUuid().toString();

		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.patch("/v1/applications/" + uuid + "/status")
				.contentType(MediaType.APPLICATION_JSON)
				.content("{\"status\": \"Pending\"}")
				.header("x-client-id", "11")
				.header("Authorization", token))
				.andDo(print())
				.andExpect(jsonPath("$.status", is("Pending")))
				.andExpect(jsonPath("$.uuid", not(emptyOrNullString())))
				.andExpect(status().isOk())
				.andReturn();

		// TODO add clean up to avoid collisions with other tests
	}

	@Test
	@Transactional
	public void givenApprovedApplication_whenChangeStatusEndpointIsHit_thenChangesItSuccessfully() throws Exception {

		// given Approved application in fixture with this UUID
		String uuid = "4d61f5c0-bca0-4388-bb02-8693d298ffd5";

		// when
		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.patch("/v1/applications/" + uuid + "/status")
				.contentType(MediaType.APPLICATION_JSON)
				.content("{\"status\": \"New\"}")
				.header("x-client-id", "11")
				.header("Authorization", token))
				.andDo(print())
				.andExpect(jsonPath("$[0].message",
						is("Application in status Approved is not able to set its status as New")))
				.andExpect(status().isBadRequest())
				.andReturn();

	}

	@Test
	public void givenNonExistingApplication_whenChangeStatusEndpointIsHit_thenThrowsError() throws Exception {

		String uuid = "e81ee7ad-25e3-4531-b71a-95b16d998cb1";

		mockMvc.perform(MockMvcRequestBuilders.patch("/v1/applications/" + uuid + "/status")
				.contentType(MediaType.APPLICATION_JSON)
				.content("{\"status\": \"Under Review\"}")
				.header("x-client-id", "11")
				.header("Authorization", token))
				.andDo(print())
				.andExpect(status().isNotFound())
				.andReturn();
	}

	@Test
	@Transactional
	public void givenExistingApplicationAndNonExistingApplicationStatus_whenChangeStatusEndpointIsHit_thenThrowsError()
			throws Exception {

		// given
		String sampleInputJson = getTextFileAsString("/payloads/new_application.json");
		ApplicationDTO input = objectMapper.readValue(sampleInputJson, ApplicationDTO.class);

		// when
		Application application = applicationRepository.getById(11L);
		String uuid = application.getUuid().toString();

		mockMvc.perform(MockMvcRequestBuilders.patch("/v1/applications/" + uuid + "/status")
				.contentType(MediaType.APPLICATION_JSON)
				.content("{\"status\": \"FakeStatus\"}")
				.header("x-client-id", "11")
				.header("Authorization", token))
				.andDo(print())
				.andExpect(status().isBadRequest())
				.andReturn();
	}

	@Test
	public void
			givenValidApplicationWithAttachments_whenListAttachmentsEndpointIsHit_thenListAllAttachmentOfApplicationAndReturn200()
					throws Exception {

		mockMvc.perform(MockMvcRequestBuilders.get("/v1/applications/382b9037-5842-43e8-b99b-2f4611784cd6/files")
				.contentType(MediaType.APPLICATION_JSON)
				.header("x-client-id", "11")
				.header("Authorization", token))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.[0].fileName", is("testFile1.png")))
				.andExpect(jsonPath("$.[0].purpose", is("purpose 1")))
				.andExpect(jsonPath("$.[1].fileName", is("testFile2.png")))
				.andExpect(jsonPath("$.[1].purpose", is("purpose 2")))
				.andDo(print());
	}
}