package com.r1vs.platform.rox.common.model.types;

import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

public enum CompoundCodeType implements KeyValueEnum {

	NOT_SPECIFIED("0", "Not Specified"),
	NOT_COMPOUND("1", "Not A Compound"),
	COMPOUND("2", "Compound");

	private final String key;

	private final String value;

	CompoundCodeType(final String key, final String value) {

		this.value = value;
		this.key = key;
	}

	public String key() {

		return this.key;
	}

	public String value() {

		return this.value;
	}

	/**
	 * Get a map of compound type .
	 *
	 * @return compoundCodeTypeMap
	 */
	public static Map<String, String> getCompoundCodeTypeMap() {

		return Arrays.stream(CompoundCodeType.values())
				.collect(Collectors.toMap(CompoundCodeType::key, CompoundCodeType::value));

	}

}
