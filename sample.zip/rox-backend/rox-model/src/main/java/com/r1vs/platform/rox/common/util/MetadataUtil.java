package com.r1vs.platform.rox.common.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jsoniter.JsonIterator;
import com.r1vs.platform.rox.common.model.cache.MetadataCache;
import com.r1vs.platform.rox.common.model.metadatacategories.MessageMetadata;

public class MetadataUtil {

	private static final Logger LOGGER = LoggerFactory.getLogger(MetadataUtil.class);

	private static ObjectMapper jacksonObjectMapper = new ObjectMapper();

	private MetadataUtil() {

	}

	public static MessageMetadata getMessageMetadataFromJson(final MetadataCache metadataCache) {

		return JsonIterator.deserialize(metadataCache.getMetadataJson(), MessageMetadata.class);
	}

	public static List<Long> getMetadataIdsFromJsonObjectString(final String jsonObjectString) {

		List<Long> metadataIds = new ArrayList<>();

		if (StringUtils.isEmpty(jsonObjectString)) {
			return metadataIds;
		}

		try {

			metadataIds = jacksonObjectMapper.readValue(jsonObjectString, new TypeReference<List<Long>>() {
			});
		} catch (final IOException e) {
			LOGGER.error("Could not serialize metadataIds string to List object {}", jsonObjectString);
		}

		return metadataIds;
	}

}
