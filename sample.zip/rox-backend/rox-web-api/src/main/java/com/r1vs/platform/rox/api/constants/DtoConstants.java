package com.r1vs.platform.rox.api.constants;

/**
 * Class used to store conventions to be used along all the DTOs
 */
public class DtoConstants {

	public static final String DATE_FORMAT_FOR_DTO = "yyyy-MM-dd";

}
